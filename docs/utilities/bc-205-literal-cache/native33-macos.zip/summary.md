# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.975 [0.9134028275334725, 1.4449722373198963] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.032 [1.0008068645861947, 1.083289662007222] | inconclusive-noisy |
| full | aa | `calls_200000` | 1.018 [1.0027321200056445, 1.083056244664596] | inconclusive-noisy |
| full | aa | `array_200000` | 1.030 [0.9595518161295418, 1.1343577915560854] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.981 [0.9032591297909545, 1.1736933876770836] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.006 [0.9166900503012677, 1.3285590499204094] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.991 [0.9244859179000651, 1.27399494674887] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.010 [0.9528341997957541, 1.158562109744648] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.960 [0.9121137283055353, 0.9904802116327506] | pass |
| full | aa | `multiply_10000d_x1000` | 1.028 [0.9574385832946979, 1.104875215551314] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.005 [0.9318507288476175, 1.0283765315609443] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.027 [0.8956733666804929, 1.073660512693215] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.8656923214257162, 1.0311769588982527] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.993 [0.9150424105450103, 1.0010072991900096] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.063 [1.0189057180307952, 1.2199829159849154] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.988 [0.8905003717624973, 1.0507606439092416] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.997 [0.9374211971515046, 1.0110158032663674] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.984 [0.9723700653612559, 1.07220116491018] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.965 [0.8363360262025941, 1.116615719057766] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 1.038 [0.9649209437343776, 1.169160600745144] | inconclusive-noisy |
| full | paired | `startup` | 1.012 [0.9528275333550809, 1.0618708507803976] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.848 [0.7735020229435822, 0.8848048050551832] | pass |
| full | paired | `calls_200000` | 0.922 [0.8315208218042347, 0.984807070579385] | pass |
| full | paired | `array_200000` | 0.908 [0.8418328531121136, 0.9766626007175896] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.853 [0.7722987224859214, 0.8947585630082052] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.927 [0.8801377445489973, 1.0069445155524321] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.883 [0.7896122499130903, 1.1807974996031423] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.944 [0.881888367438145, 1.0159244660581597] | pass |
| full | paired | `multiply_100d_x100000` | 0.923 [0.8772164281888037, 1.0081208270756388] | pass |
| full | paired | `multiply_10000d_x1000` | 0.956 [0.8970228076335328, 1.016538369445194] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.088 [0.9670286993918401, 1.1525795725402077] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.028 [0.925951436035132, 1.059031722513329] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.038 [0.9009816552552653, 1.2029412152543097] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.015 [0.9950436639342783, 1.1208672683408982] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.011 [0.944301408726447, 1.0521721714451167] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.956 [0.8530862714857664, 1.0723359645330612] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.932 [0.883823435098158, 1.035704141729983] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.002 [0.9613027222342941, 1.1517393520936179] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.919 [0.8594229704893483, 1.1590232969116812] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.006 [0.004591039071266307, 0.007990035208667473] | pass |
