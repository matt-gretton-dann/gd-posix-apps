# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.906 [0.8681295860442829, 1.0351629316925972] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.995 [0.9871441913843311, 1.0203694067746356] | pass |
| full | aa | `calls_200000` | 1.001 [0.8477192838830773, 1.051592404028103] | inconclusive-noisy |
| full | aa | `array_200000` | 1.010 [0.9723561175355028, 1.0374440828089673] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.012 [1.001044256351194, 1.0574793666828866] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.988 [0.9725436048812439, 1.0017757100796176] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.992 [0.979843749075321, 1.0127796745586106] | pass |
| full | aa | `fibonacci_1000_x100` | 1.000 [0.9064180233169155, 1.0283210714179325] | pass |
| full | aa | `multiply_100d_x100000` | 1.001 [0.9817229651905871, 1.0206997776766384] | pass |
| full | aa | `multiply_10000d_x1000` | 0.997 [0.9789051052287047, 1.0075895474591559] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.010 [0.9970860940939896, 1.021581713094491] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9952910915731706, 1.0035037726863372] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.995 [0.9719675632011399, 1.007504971587959] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.9947147882539122, 1.002646317594103] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.989 [0.9504715399135372, 1.0503445497816373] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.995 [0.98472066776111, 1.0067316190289122] | pass |
| full | aa | `sparse_array_200000` | 0.996 [0.9705294661111505, 1.00941148988112] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.001 [0.9950417444315895, 1.0021877407408868] | pass |
| full | aa | `streaming_statements_20000` | 1.002 [0.9320568765861766, 1.074828038192478] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 1.002 [0.9905349955431635, 1.031348358106091] | pass |
| full | paired | `startup` | 0.970 [0.839005562844008, 1.0391036438141772] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.831 [0.8167400710237329, 0.8552820610745532] | pass |
| full | paired | `calls_200000` | 0.943 [0.936573953261127, 1.1903546935561875] | inconclusive-noisy |
| full | paired | `array_200000` | 0.884 [0.8690626880029069, 0.9513832144510428] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.876 [0.8378087849974588, 0.8894234792039422] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.908 [0.754517517307862, 0.9255945222162401] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.899 [0.858923179378454, 1.0382637869729316] | pass |
| full | paired | `fibonacci_1000_x100` | 0.987 [0.9718443313432299, 0.9968109488561857] | pass |
| full | paired | `multiply_100d_x100000` | 0.935 [0.8881567661547283, 0.9865924614223932] | pass |
| full | paired | `multiply_10000d_x1000` | 1.012 [0.9866827935690459, 1.0468165655102275] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.986 [0.9250299131921488, 1.1119742418340288] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.004 [1.0016251417361988, 1.0129646093512579] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.991 [0.9607317737536485, 1.0004490930444105] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.005 [0.9675694147168388, 1.0118185818645553] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.009 [0.9672642933870246, 1.0292539978551294] | pass |
| full | paired | `power_100d_e17_x1000` | 0.981 [0.9387583148574968, 1.0196985359279829] | pass |
| full | paired | `sparse_array_200000` | 0.883 [0.8465589684242949, 0.9619772782739956] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.991 [0.9761919782639269, 1.0034571928461593] | pass |
| full | paired | `streaming_statements_20000` | 1.006 [0.8787005028177849, 1.0185915008035327] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.008 [0.006865440299281199, 0.007788268166810488] | pass |
