# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.935 [0.7912950717540785, 1.032547769168225] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.999 [0.9841214422778759, 1.0023175470161585] | pass |
| full | aa | `calls_200000` | 1.005 [0.9935876142428465, 1.015493851748485] | pass |
| full | aa | `array_200000` | 1.003 [0.9937542468641531, 1.0117160709733237] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.997 [0.9933373935650187, 1.0133549634834287] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.004 [0.9802630634164152, 1.0128019330448212] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.982 [0.948227828137522, 1.0670112829267944] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.000 [0.9905983152065695, 1.0339656863873148] | pass |
| full | aa | `multiply_100d_x100000` | 1.001 [0.9950135751641128, 1.0096298142476734] | pass |
| full | aa | `multiply_10000d_x1000` | 0.997 [0.9825936822900299, 1.001182930417855] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.004 [0.9902349006421539, 1.0116465888438864] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.9860270698625021, 1.0057807334775462] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9924766973859979, 1.0050018860706462] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.997 [0.9594303740828978, 1.00770627804093] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.994 [0.9572185363204203, 1.0433016805227064] | pass |
| full | aa | `power_100d_e17_x1000` | 0.989 [0.9830006078802872, 1.0054013574972176] | pass |
| full | aa | `sparse_array_200000` | 1.003 [0.9941497558332636, 1.0038194834371539] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.997 [0.991786818931583, 1.008587428077179] | pass |
| full | aa | `streaming_statements_20000` | 0.992 [0.9836311219541888, 0.9963478470295081] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.000 [0.9944275753824842, 1.0018831914782491] | pass |
| full | paired | `startup` | 1.038 [0.738571909254919, 1.151592952482803] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.831 [0.8251527674681707, 0.8460792374963078] | pass |
| full | paired | `calls_200000` | 0.940 [0.9380457565393506, 0.9555249663040354] | pass |
| full | paired | `array_200000` | 0.911 [0.8855453464052171, 0.9227907559625924] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.914 [0.8976550577653016, 0.9405894459604134] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.966 [0.933458931694036, 0.9786764681885054] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.962 [0.9243283577125833, 0.9810854230696444] | pass |
| full | paired | `fibonacci_1000_x100` | 1.012 [0.9928943788186012, 1.0437562473140423] | pass |
| full | paired | `multiply_100d_x100000` | 0.931 [0.9108566117732197, 0.9491966545855698] | pass |
| full | paired | `multiply_10000d_x1000` | 1.002 [0.9815365410086754, 1.009668386747114] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.997 [0.9888064583468695, 1.000682109876271] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.998 [0.9713521719914197, 1.0017168773367253] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.011 [1.0057997683166795, 1.0207306825332203] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.999 [0.9811226398997457, 1.0043569114355442] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.009 [0.9825202632760542, 1.042391501891344] | pass |
| full | paired | `power_100d_e17_x1000` | 1.003 [0.983223304683654, 1.0132453677158806] | pass |
| full | paired | `sparse_array_200000` | 0.887 [0.8818228876190123, 0.8990191124299491] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.994 [0.9888350940797305, 1.0028153401941067] | pass |
| full | paired | `streaming_statements_20000` | 1.006 [0.9692323377815497, 1.0171824476136184] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.003 [0.002965807328170985, 0.0033246377732114784] | pass |
