# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.931 [0.910317306894595, 1.0926192169723166] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.992 [0.9701140734409698, 1.0210125081915689] | pass |
| full | aa | `calls_200000` | 0.972 [0.9208828227518941, 1.0032627271527714] | pass |
| full | aa | `array_200000` | 1.001 [0.988748796702071, 1.0276969066280044] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.971 [0.9408037783971926, 1.00334093016559] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.000 [0.9972827824795764, 1.0657194767542695] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.000 [0.9949741809220705, 1.0329607806160754] | pass |
| full | aa | `fibonacci_1000_x100` | 1.018 [0.9937371142725806, 1.030578110966678] | pass |
| full | aa | `multiply_100d_x100000` | 0.993 [0.9548226716247997, 1.0113933550480565] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9961256498874898, 1.0029617674160551] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.998 [0.9423795319940602, 1.0285804820235034] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9977502801527229, 1.0015723757672734] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9630823365632333, 1.0030295033507866] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9973160792465013, 1.0028177520364512] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.985 [0.9652935184590107, 1.0221566306707872] | pass |
| full | aa | `power_100d_e17_x1000` | 1.002 [0.9977184536418899, 1.0165688013806355] | pass |
| full | aa | `sparse_array_200000` | 1.004 [0.9475940518758752, 1.0147927158886023] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.999 [0.9957593847331397, 1.0026866809845167] | pass |
| full | aa | `streaming_statements_20000` | 0.982 [0.909224011713111, 0.9952665546234915] | pass |
| full | paired | `startup` | 1.082 [0.9716472555264029, 1.1734435486234422] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.570 [0.5551676079143721, 0.5827821922878063] | pass |
| full | paired | `calls_200000` | 0.639 [0.5961404570744406, 0.6996793474009916] | pass |
| full | paired | `array_200000` | 0.634 [0.6116221208671081, 0.6397961116335661] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.571 [0.5104975020247267, 0.6697153698674122] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.576 [0.5092228057931337, 0.6637079185686029] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.583 [0.45377752940990884, 0.5973479671343707] | pass |
| full | paired | `fibonacci_1000_x100` | 0.711 [0.6735248121760367, 0.7683570884480064] | pass |
| full | paired | `multiply_100d_x100000` | 0.758 [0.7564044950606941, 0.7808959656203587] | pass |
| full | paired | `multiply_10000d_x1000` | 1.009 [1.0069474529834865, 1.0154637435555405] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.987 [0.9622391642009409, 1.0399101949817324] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.009 [0.9933686418853859, 1.0122367470956497] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.913 [0.9063309221530341, 0.938050872664395] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.013 [1.0059986590569994, 1.0237390366204921] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.994 [0.9446874497784595, 1.0335723282605087] | pass |
| full | paired | `power_100d_e17_x1000` | 0.936 [0.896386551765751, 0.998040839338392] | pass |
| full | paired | `sparse_array_200000` | 0.540 [0.5318753585089517, 0.5570866472504313] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.001 [0.9948844791178107, 1.0061536183161284] | pass |
| full | paired | `streaming_statements_20000` | 0.995 [0.9558989579639191, 1.1787112734727474] | inconclusive-noisy |
