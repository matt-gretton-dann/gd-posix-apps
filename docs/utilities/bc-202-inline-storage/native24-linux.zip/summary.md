# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.885 [0.7762555400436524, 1.2421187746524933] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.004 [0.993188131177597, 1.0202127626522972] | pass |
| full | aa | `calls_200000` | 0.993 [0.955167415969996, 1.017274586122584] | pass |
| full | aa | `array_200000` | 1.007 [0.9845122797441648, 1.0182793383731443] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.008 [0.967363175313634, 1.0212039347516182] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.995 [0.9822396527064177, 1.028954218981693] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.999 [0.9945763922495913, 1.0125302069771618] | pass |
| full | aa | `fibonacci_1000_x100` | 1.006 [1.000236741739191, 1.0158490458939797] | pass |
| full | aa | `multiply_100d_x100000` | 0.996 [0.99327009912167, 1.0265619549691223] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9990962665664168, 1.0026410470769778] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9893840507503698, 1.0057504572819274] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9988426494357829, 1.0014652727589295] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9955002670221736, 1.001376857825527] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9919560533890417, 1.0019109747843897] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.008 [0.9806756146340232, 1.0323347185506797] | pass |
| full | aa | `power_100d_e17_x1000` | 0.999 [0.9949731878687147, 1.0034215782539169] | pass |
| full | aa | `sparse_array_200000` | 1.004 [0.9845742079308755, 1.0594200281609092] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9956289680645337, 1.0020931002938958] | pass |
| full | aa | `streaming_statements_20000` | 1.002 [0.978303211243096, 1.0119574954674315] | pass |
| full | paired | `startup` | 1.124 [0.8709306717697147, 1.273762532899139] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.759 [0.740838089510252, 0.7688955446398407] | pass |
| full | paired | `calls_200000` | 0.843 [0.8353116088032048, 0.854570997714709] | pass |
| full | paired | `array_200000` | 0.785 [0.7759353612283818, 0.7951264421618929] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.758 [0.7458948074518845, 0.7769863988671666] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.785 [0.7624877394108771, 0.7948667562700108] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.790 [0.7842553543109604, 0.8151048779677186] | pass |
| full | paired | `fibonacci_1000_x100` | 0.837 [0.8143580624959089, 0.8681663077557831] | pass |
| full | paired | `multiply_100d_x100000` | 0.871 [0.8664206863452686, 0.899276037204926] | pass |
| full | paired | `multiply_10000d_x1000` | 0.860 [0.8570957904770634, 0.8653169100698517] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.011 [0.9952848644114936, 1.0340344462072537] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.815 [0.813721287836173, 0.8170551096210672] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.955 [0.9498538786842772, 0.9556886361211141] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.337 [0.33702850343023955, 0.34034177005826666] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.963 [0.9475698368816637, 0.9834192667054068] | pass |
| full | paired | `power_100d_e17_x1000` | 0.966 [0.9582628385924343, 0.9688245310384288] | pass |
| full | paired | `sparse_array_200000` | 0.769 [0.7598963084486491, 0.8064885240427441] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.004 [1.0025759716884037, 1.0087988175364937] | pass |
| full | paired | `streaming_statements_20000` | 1.008 [1.002931874280697, 1.010820612849985] | pass |
