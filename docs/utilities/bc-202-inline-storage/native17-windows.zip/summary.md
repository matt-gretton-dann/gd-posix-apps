# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.938 [0.8965505642445393, 1.111642682907441] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.011 [0.9768277978527136, 1.020844773044493] | pass |
| full | aa | `calls_200000` | 1.011 [0.9998174948199395, 1.0530220660873413] | inconclusive-noisy |
| full | aa | `array_200000` | 1.011 [0.9920078795827941, 1.0297982786832438] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.996 [0.9393933323493634, 1.0555282978841625] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.998 [0.9876258646081689, 1.009987265364378] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.011 [0.9979840740867861, 1.0767763201018787] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.999 [0.9800827074011406, 1.10059171597677] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.004 [0.9563608534248355, 1.0056807201045626] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9990853994585402, 1.001205040547318] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.991 [0.9773504900766016, 0.994939370552298] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9968437201233101, 1.0027449949946903] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9988428368780321, 1.0075371633410932] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9988088050999254, 1.0030406031119228] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.995 [0.9803488562083625, 1.0284201023924675] | pass |
| full | aa | `power_100d_e17_x1000` | 0.995 [0.9900110392552425, 1.0001631325085507] | pass |
| full | aa | `sparse_array_200000` | 1.018 [0.9864255876810718, 1.0391673863854514] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9966784867110894, 1.0018792462529964] | pass |
| full | aa | `streaming_statements_20000` | 1.031 [0.9921089153655838, 1.110480586659654] | inconclusive-noisy |
| full | paired | `startup` | 1.084 [0.9031107622477691, 1.1373249981186317] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.590 [0.5845501981960537, 0.5939568608031016] | pass |
| full | paired | `calls_200000` | 0.722 [0.7182787154750151, 0.7394771487790822] | pass |
| full | paired | `array_200000` | 0.620 [0.6041121085780448, 0.6279804250102853] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.598 [0.5690734381076628, 0.6033164031474932] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.614 [0.6118940280802637, 0.6274325963755885] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.622 [0.619654016260531, 0.6299721494589061] | pass |
| full | paired | `fibonacci_1000_x100` | 0.753 [0.7401730987845416, 0.7641588366613139] | pass |
| full | paired | `multiply_100d_x100000` | 0.812 [0.7713256915005566, 0.8143740139365383] | pass |
| full | paired | `multiply_10000d_x1000` | 1.014 [1.012957115983199, 1.0167130395033932] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.025 [1.0216420154118162, 1.039713682240102] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.013 [1.0101261622202549, 1.0215803169616495] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.920 [0.9056128348137286, 0.9285390667838505] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.019 [1.016709294435761, 1.028447759454254] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.989 [0.7334862186858174, 1.0305286167339416] | pass |
| full | paired | `power_100d_e17_x1000` | 0.957 [0.9495843972378333, 0.962419280284168] | pass |
| full | paired | `sparse_array_200000` | 0.552 [0.5340602222450002, 0.5652401879156222] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.000 [0.9983641722990273, 1.0065878328367859] | pass |
| full | paired | `streaming_statements_20000` | 0.990 [0.8964340812036319, 1.0315762009581544] | pass |
