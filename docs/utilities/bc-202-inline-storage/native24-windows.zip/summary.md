# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.946 [0.9262717186464738, 1.059286720998173] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.999 [0.9874498259889277, 1.0269977961009014] | pass |
| full | aa | `calls_200000` | 0.989 [0.9803358865294703, 1.031377197038493] | pass |
| full | aa | `array_200000` | 1.001 [0.9820154669471098, 1.0097188227287224] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.974 [0.9685870173357535, 1.0411272896439105] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.017 [0.9551460623108761, 1.0451909429484103] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.000 [0.9741719156722111, 1.0144281604051315] | pass |
| full | aa | `fibonacci_1000_x100` | 1.001 [0.9581164567906049, 1.019342161528272] | pass |
| full | aa | `multiply_100d_x100000` | 0.998 [0.9919305546127577, 1.0259695240183473] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.997954214874138, 1.0033477453451811] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.98643890234639, 1.0066192311093116] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9964885305877442, 1.0017730525845834] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9838536872444358, 1.002397185522461] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.997598464244639, 1.0027241133496985] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.008 [0.9800358177952612, 1.0210109210117437] | pass |
| full | aa | `power_100d_e17_x1000` | 1.005 [0.9408217679880906, 1.0231663807681095] | pass |
| full | aa | `sparse_array_200000` | 1.018 [0.9890601044138352, 1.040107999323639] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.001 [0.9922713733076537, 1.0065383538770225] | pass |
| full | aa | `streaming_statements_20000` | 1.007 [0.9907094042247553, 1.0207044316324685] | pass |
| full | paired | `startup` | 1.042 [0.9675116651564051, 1.1008165974628634] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.641 [0.6087075896572438, 0.6445050099154708] | pass |
| full | paired | `calls_200000` | 0.663 [0.6382798655664906, 0.6817226747282067] | pass |
| full | paired | `array_200000` | 0.681 [0.6722162533622353, 0.6894752188509004] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.573 [0.5405722541003796, 0.6679474748707538] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.631 [0.5897786872634903, 0.6515010079625685] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.634 [0.6102758526679519, 0.6733311515639986] | pass |
| full | paired | `fibonacci_1000_x100` | 0.786 [0.7760330995607888, 0.8248768682057533] | pass |
| full | paired | `multiply_100d_x100000` | 0.818 [0.7530354782956382, 0.8223097969520897] | pass |
| full | paired | `multiply_10000d_x1000` | 0.899 [0.8925050955601479, 0.9071896678806418] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.006 [0.9729473306956108, 1.0186584744769882] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.853 [0.8367825049683698, 0.8564412163494698] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.938 [0.9335388318100253, 0.9621554135523214] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.340 [0.3393852784333784, 0.34125821922328586] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.018 [0.9685283847926422, 1.0475774812258136] | pass |
| full | paired | `power_100d_e17_x1000` | 0.960 [0.9512592963953181, 0.980281019381821] | pass |
| full | paired | `sparse_array_200000` | 0.605 [0.5974634551025995, 0.6566329950959686] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.993 [0.9760924808219703, 1.0033738845509752] | pass |
| full | paired | `streaming_statements_20000` | 0.948 [0.9061711726886772, 1.0261053556203712] | pass |
