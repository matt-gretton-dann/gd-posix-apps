# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.915 [0.8064794893957956, 1.3158682645380748] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.016 [0.992836738588081, 1.0522251834539145] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.998 [0.9899259510809364, 1.0174819870098748] | pass |
| full | aa | `array_200000` | 1.018 [0.9884585885728518, 1.0251874862416823] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.022 [0.9974300150607832, 1.0345643661692552] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.014 [0.9812896168354076, 1.0951036572947552] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.018 [0.9990026697373887, 1.0329515585144218] | pass |
| full | aa | `fibonacci_1000_x100` | 1.007 [0.9760237000746455, 1.0289088958433978] | pass |
| full | aa | `multiply_100d_x100000` | 0.994 [0.9841735409974067, 1.0202879803903906] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9966931015582281, 1.004208290159243] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.998 [0.9890493613065887, 1.0011721878024427] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.994771371697637, 1.001687592291186] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9992155028100825, 1.0038145307307258] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9990169633130136, 1.0012164050280334] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.004 [0.9639089018099135, 1.01782123924584] | pass |
| full | aa | `power_100d_e17_x1000` | 0.995 [0.9931974903018608, 1.003058865946806] | pass |
| full | aa | `sparse_array_200000` | 1.014 [0.9830932562527427, 1.0272532480645573] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.995157710809908, 1.0029875630292242] | pass |
| full | aa | `streaming_statements_20000` | 0.998 [0.9884303068794482, 1.031076298958998] | pass |
| full | paired | `startup` | 1.118 [0.7471003594034763, 1.2549059365117357] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.810 [0.7776614853536811, 0.8202538494214783] | pass |
| full | paired | `calls_200000` | 0.897 [0.8685225385081232, 0.9027314258785145] | pass |
| full | paired | `array_200000` | 0.808 [0.7891753722117222, 0.8183883855683705] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.806 [0.7906911554317858, 0.81413970527705] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.831 [0.8176165130748062, 0.8571673025488352] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.846 [0.8076072529339867, 0.9027691220434549] | pass |
| full | paired | `fibonacci_1000_x100` | 0.888 [0.8764346500827995, 0.8903487611457147] | pass |
| full | paired | `multiply_100d_x100000` | 0.890 [0.8858854717509462, 0.8970687583700152] | pass |
| full | paired | `multiply_10000d_x1000` | 1.020 [1.0102493396655388, 1.0277592671733486] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.025 [1.0226352977877, 1.0345710990803427] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.005 [1.0042887797491362, 1.0105893444309135] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.972 [0.9690882788275303, 0.975866478293492] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.076 [1.0745339334966346, 1.08095372145627] | confirmed regression |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.985 [0.9686062413778338, 0.9952966315706628] | pass |
| full | paired | `power_100d_e17_x1000` | 0.973 [0.9657791490955943, 0.9782058213109269] | pass |
| full | paired | `sparse_array_200000` | 0.778 [0.7599219702284465, 0.7990587689809788] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.998 [0.9976182603519437, 1.0014663126384995] | pass |
| full | paired | `streaming_statements_20000` | 1.006 [0.9858607452079157, 1.0108387398571894] | pass |
