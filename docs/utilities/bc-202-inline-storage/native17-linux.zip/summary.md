# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.841 [0.7255956758777982, 1.275480488767771] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.995 [0.9624013401438314, 1.0159574830324838] | pass |
| full | aa | `calls_200000` | 1.001 [0.9889772174311741, 1.0142655564253042] | pass |
| full | aa | `array_200000` | 0.992 [0.9804834480817566, 1.0094816153943629] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.998 [0.9795748244176185, 1.0074402291265567] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.991 [0.9751683214114563, 1.0281411325275924] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.999 [0.9828040900404704, 1.0087917614929534] | pass |
| full | aa | `fibonacci_1000_x100` | 1.004 [0.9956832368808288, 1.0194093996857414] | pass |
| full | aa | `multiply_100d_x100000` | 1.008 [0.9966336036542964, 1.0123866732077633] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9993630054128964, 1.0005047934673479] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.994 [0.9884924500917326, 0.9985783859627532] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.998832318753253, 1.0051348590865308] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9969007825234099, 1.0011984686554392] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9990843177074534, 1.0008639922566227] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.980 [0.9695182550029404, 1.0301456683086028] | pass |
| full | aa | `power_100d_e17_x1000` | 1.000 [0.9969257625903735, 1.010741748717711] | pass |
| full | aa | `sparse_array_200000` | 1.006 [0.9796098026754506, 1.0163780143162988] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.999 [0.9976186449634553, 1.0004524634390572] | pass |
| full | aa | `streaming_statements_20000` | 1.000 [0.9857775472691103, 1.0027258932258696] | pass |
| full | paired | `startup` | 1.206 [0.8770537780799142, 1.2965446151915412] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.709 [0.668378734025134, 0.7150345191105001] | pass |
| full | paired | `calls_200000` | 0.784 [0.7757788076558735, 0.7881691287258467] | pass |
| full | paired | `array_200000` | 0.735 [0.7174721699165462, 0.7421398011191453] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.729 [0.7182290850761086, 0.7345802565342503] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.766 [0.7565782741140135, 0.7794461898184452] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.768 [0.7623610354855807, 0.8030913481380524] | pass |
| full | paired | `fibonacci_1000_x100` | 0.868 [0.8612620147280017, 0.8754985275669451] | pass |
| full | paired | `multiply_100d_x100000` | 0.896 [0.8942676292383706, 0.9044493780193316] | pass |
| full | paired | `multiply_10000d_x1000` | 1.022 [1.0206978525252295, 1.0227734892446971] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.076 [1.0732771118498718, 1.0822929478815895] | confirmed regression |
| full | paired | `multiply_dense_10000d_x500` | 1.020 [1.0190483447872831, 1.0228130831546096] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.948 [0.9455976632190085, 0.9518925691330024] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.075 [1.0742227110684868, 1.0754530675364582] | confirmed regression |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.958840573981505, 1.0281951596228558] | pass |
| full | paired | `power_100d_e17_x1000` | 0.959 [0.9538906377674411, 0.9647549648543768] | pass |
| full | paired | `sparse_array_200000` | 0.683 [0.664105337490886, 0.699243391146254] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.001 [0.9991295880436003, 1.0035187541175967] | pass |
| full | paired | `streaming_statements_20000` | 0.984 [0.9725925500652413, 0.9946446349967505] | pass |
