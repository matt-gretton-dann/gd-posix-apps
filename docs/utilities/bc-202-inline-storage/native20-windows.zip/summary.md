# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.983 [0.9333503781244952, 1.0595263254479497] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.002 [0.9814560017154683, 1.0442484476546072] | pass |
| full | aa | `calls_200000` | 1.001 [0.9785151823863252, 1.0197580746223873] | pass |
| full | aa | `array_200000` | 0.992 [0.9554512122222414, 1.0208937721035074] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.985 [0.9613438364454684, 1.0240420433199782] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.993 [0.9280382964761963, 1.032119490701547] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.998 [0.9818843488845417, 1.0507067697796313] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.992 [0.9333238742006794, 1.109093340154314] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.999 [0.9642470868244929, 1.042066353404265] | pass |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.9964192895501287, 1.0346193646477042] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.009 [0.9842589842604377, 1.091031381131065] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.9953563294007113, 1.0052764057666765] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.992114024136406, 1.0007740465420472] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9983727610489121, 1.0048324966416944] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.007 [0.9773029928964606, 1.041333888105865] | pass |
| full | aa | `power_100d_e17_x1000` | 1.002 [0.9956711701843297, 1.0226428223779478] | pass |
| full | aa | `sparse_array_200000` | 0.976 [0.9496224134720453, 0.9895980522567795] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.001 [0.9786793250219598, 1.0066072815017149] | pass |
| full | aa | `streaming_statements_20000` | 0.996 [0.9920865712481332, 1.0621131991146613] | inconclusive-noisy |
| full | paired | `startup` | 1.008 [0.9503628909292452, 1.075337873605343] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.579 [0.5770934743291602, 0.587945394184188] | pass |
| full | paired | `calls_200000` | 0.746 [0.738643656621416, 0.80795925451516] | pass |
| full | paired | `array_200000` | 0.648 [0.6245025733675201, 0.6585017134893586] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.578 [0.5416529338821112, 0.62935413097685] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.596 [0.5801649424337849, 0.6172566440167908] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.594 [0.5422283044751119, 0.6147937752525172] | pass |
| full | paired | `fibonacci_1000_x100` | 0.782 [0.7495343624088433, 0.8548086248492287] | pass |
| full | paired | `multiply_100d_x100000` | 0.810 [0.7854893176554301, 0.8388230984468708] | pass |
| full | paired | `multiply_10000d_x1000` | 1.032 [1.0305427043093351, 1.0457498772998863] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.033 [0.9896152146621872, 1.0435181501961601] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.006 [1.0004442759590266, 1.0061647018934265] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.944 [0.9129709665491891, 0.946364680282809] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.040 [1.0301816775280948, 1.0691087767599536] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.999 [0.9841747878879887, 1.0480164816986424] | pass |
| full | paired | `power_100d_e17_x1000` | 0.958 [0.9267654521104871, 0.9669772672806716] | pass |
| full | paired | `sparse_array_200000` | 0.564 [0.541617516983812, 0.5956892560316145] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.999 [0.9882332766245445, 1.0070820973652628] | pass |
| full | paired | `streaming_statements_20000` | 1.026 [0.982416462498465, 1.0749953721902816] | inconclusive-noisy |
