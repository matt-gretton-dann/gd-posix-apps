# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.020 [0.8910631760271971, 1.140444041250768] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.007 [0.9889432427839497, 1.0167781373728824] | pass |
| full | aa | `calls_200000` | 0.996 [0.9770648839032233, 1.0128120490610195] | pass |
| full | aa | `array_200000` | 1.015 [0.988996763303355, 1.0466523746247278] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.994 [0.983276785101515, 1.009325738994472] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.991 [0.9876585389076047, 1.0081568894074258] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.010 [0.9798852233419063, 1.0220725826904096] | pass |
| full | aa | `fibonacci_1000_x100` | 1.004 [0.9867197603591135, 1.0287535201401872] | pass |
| full | aa | `multiply_100d_x100000` | 0.990 [0.9732373601616499, 1.0144207435899895] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9907654489263408, 1.002819700792204] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.003 [0.9934252219219939, 1.0207755729995394] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.007 [1.0043209138733604, 1.0172924811783803] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.008 [0.9840940588250388, 1.0179751703366966] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.007 [1.0001807194860415, 1.0096242904009884] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.985 [0.9704901335835969, 1.0768613125801754] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.018 [0.9902067950521817, 1.0488312045157058] | pass |
| full | aa | `sparse_array_200000` | 0.999 [0.9873341520104564, 1.0078748566273772] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9914039772414425, 1.0155178046660476] | pass |
| full | aa | `streaming_statements_20000` | 1.003 [0.9804785127731108, 1.0075644463257156] | pass |
| full | paired | `startup` | 1.054 [0.9857004757955508, 1.0682951208102547] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.711 [0.703826680333809, 0.711944000963619] | pass |
| full | paired | `calls_200000` | 0.783 [0.7756846092814771, 0.7989497889043191] | pass |
| full | paired | `array_200000` | 0.720 [0.7008840923308691, 0.7414855612966144] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.739 [0.7262682356042595, 0.7471609705320811] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.762 [0.7507696064332143, 0.7768594655201552] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.764 [0.728881123473586, 0.7742810113763605] | pass |
| full | paired | `fibonacci_1000_x100` | 0.863 [0.8610515622404973, 0.8992194763736968] | pass |
| full | paired | `multiply_100d_x100000` | 0.886 [0.8730511026383561, 0.8953633146545977] | pass |
| full | paired | `multiply_10000d_x1000` | 1.025 [1.0216837012352855, 1.0299767803078057] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.090 [1.0591677573529177, 1.1030609777617781] | confirmed regression |
| full | paired | `multiply_dense_10000d_x500` | 1.025 [1.014074996324343, 1.0332584904925892] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.897 [0.8826841156998926, 0.9246587890513691] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.073 [1.0690449236139359, 1.0849199988990572] | confirmed regression |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.961 [0.9330868102785922, 1.0582650480571423] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.977 [0.9394388545162896, 1.0013216212318388] | pass |
| full | paired | `sparse_array_200000` | 0.748 [0.7394448935921558, 0.763433155286325] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.997 [0.9885028428032087, 1.0042591087619481] | pass |
| full | paired | `streaming_statements_20000` | 0.979 [0.9548206835865691, 0.9930893023085583] | pass |
