# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.904 [0.8935005136744484, 1.1137745000621586] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.994 [0.9737563427833325, 1.007162949373243] | pass |
| full | aa | `calls_200000` | 0.998 [0.939315414763583, 1.0017931888960163] | pass |
| full | aa | `array_200000` | 0.985 [0.954754083062545, 1.0139888157952468] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.006 [0.9940298547198531, 1.1395615045605128] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.020 [0.9861236345135349, 1.0405055229541835] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.000 [0.994060230890708, 1.0072893868656982] | pass |
| full | aa | `fibonacci_1000_x100` | 1.003 [0.9888507001997221, 1.0588630211323449] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.001 [0.9323111686804674, 1.026136259536133] | pass |
| full | aa | `multiply_10000d_x1000` | 1.010 [0.9561165062272501, 1.0297138192292405] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.994 [0.9832559864277266, 1.020947153737929] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9869434599755098, 1.0240996171409162] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.007 [0.9860441773541824, 1.0215409485001294] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9887384815003744, 1.06677313627095] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.047 [0.8844110935319598, 1.1373744963345063] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.037 [1.0013712662477876, 1.1959798020882255] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.004 [0.9471508768825512, 1.014766930960764] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.999 [0.9606678555709355, 1.0068159967118195] | pass |
| full | aa | `streaming_statements_20000` | 0.999 [0.9775543219016759, 1.0110419883442687] | pass |
| full | paired | `startup` | 1.112 [0.6076600521484113, 1.1983121130434418] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.594 [0.5772320228816346, 0.6384568605918532] | pass |
| full | paired | `calls_200000` | 0.743 [0.6929266429396632, 0.7572485592869058] | pass |
| full | paired | `array_200000` | 0.573 [0.5365419240909316, 0.5953860801501426] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.591 [0.5192556098228545, 0.6895412512645243] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.648 [0.6435646795981728, 0.6852585796278383] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.661 [0.6131266203738271, 0.6952691879604035] | pass |
| full | paired | `fibonacci_1000_x100` | 0.791 [0.7518997543356076, 0.7965070938385607] | pass |
| full | paired | `multiply_100d_x100000` | 0.863 [0.8204348692634388, 0.921688930078752] | pass |
| full | paired | `multiply_10000d_x1000` | 0.991 [0.9523574903694949, 1.0450820846269766] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.127 [0.9960105267351073, 1.152061611431768] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.998 [0.9601036926085424, 1.0426005623586527] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.960 [0.9511376850828995, 1.0256146266205777] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.030 [1.0136829745184057, 1.0738778861561198] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.944 [0.8107426122443419, 1.028890606146869] | pass |
| full | paired | `power_100d_e17_x1000` | 0.946 [0.8914017775355729, 0.9642710997332067] | pass |
| full | paired | `sparse_array_200000` | 0.576 [0.5664270920078331, 0.6235202149389317] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.991 [0.9675757948415782, 0.9980614935405099] | pass |
| full | paired | `streaming_statements_20000` | 0.994 [0.9206480449541542, 1.0218298790720803] | pass |
