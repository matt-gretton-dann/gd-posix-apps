# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.983 [0.8006407406623689, 1.1043903844784926] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.001 [0.9961733427906899, 1.0104459607687004] | pass |
| full | aa | `calls_200000` | 0.999 [0.9904941812682575, 1.007307836685745] | pass |
| full | aa | `array_200000` | 1.005 [0.9975953421317201, 1.0200818847610313] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.004 [0.9890784790258967, 1.0209154152603301] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.001 [0.9897999322572106, 1.0085193938410757] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.003 [0.9951816518451138, 1.0045552991319853] | pass |
| full | aa | `fibonacci_1000_x100` | 1.002 [0.9894910285706006, 1.0217143283643402] | pass |
| full | aa | `multiply_100d_x100000` | 1.005 [1.0036713800840233, 1.0148070377808291] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9973721291138088, 1.00285784983466] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9948320545489182, 1.000205206069371] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.002 [0.996726212252856, 1.004228377620498] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.993996538840521, 1.0030016461289566] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9969026193570799, 1.0003695443506124] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.988 [0.9262847941790879, 1.0640397475363188] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.998 [0.988321301091681, 1.0028644709666004] | pass |
| full | aa | `sparse_array_200000` | 0.996 [0.9892699767513182, 1.0125283766868092] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9964545357364085, 1.001009371560433] | pass |
| full | aa | `streaming_statements_20000` | 0.992 [0.9868051435842173, 1.0159991411179565] | pass |
| full | paired | `startup` | 1.087 [0.9675179374245692, 1.1467110279968786] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.701 [0.6950710473274261, 0.7047259213500329] | pass |
| full | paired | `calls_200000` | 0.758 [0.7552137103453274, 0.7636561672650486] | pass |
| full | paired | `array_200000` | 0.691 [0.6892236739384214, 0.7032526832414897] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.712 [0.7069141285709925, 0.7170166488534281] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.001 [0.9995161254932058, 1.0086914094142048] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.006 [1.003077993905054, 1.0141503841298551] | pass |
| full | paired | `fibonacci_1000_x100` | 0.861 [0.8511265618178232, 0.8799016055319652] | pass |
| full | paired | `multiply_100d_x100000` | 0.864 [0.8611324653672863, 0.864922546935729] | pass |
| full | paired | `multiply_10000d_x1000` | 1.041 [1.0381102935477513, 1.0459378862378157] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.096 [1.0841975858730002, 1.1018956730713612] | confirmed regression |
| full | paired | `multiply_dense_10000d_x500` | 1.035 [1.0308720383875245, 1.0382675723402743] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.933 [0.9306222186752927, 0.9382274635397707] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.088 [1.0842183338361953, 1.0961410946032] | confirmed regression |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.070 [0.995741132447494, 1.1678153461190868] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.973 [0.970978334363557, 0.9822995592438434] | pass |
| full | paired | `sparse_array_200000` | 0.720 [0.7161944141824559, 0.7217281249135692] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.997 [0.9930015094912662, 0.99933389805203] | pass |
| full | paired | `streaming_statements_20000` | 0.997 [0.9871509432485116, 1.009907371236445] | pass |
