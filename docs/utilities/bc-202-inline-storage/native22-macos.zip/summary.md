# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.006 [0.944573215841773, 1.0451538267572398] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.996 [0.9158421104174936, 1.0013570948944797] | pass |
| full | aa | `calls_200000` | 1.009 [0.9999232497396519, 1.0255486307510382] | pass |
| full | aa | `array_200000` | 0.988 [0.9420170743647004, 1.071866821952173] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 1.022 [0.9795623040592344, 1.0292988577602575] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.006 [0.9403253497481501, 1.0309639430402116] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.026 [0.9989403525819858, 1.1712354542346646] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.001 [0.9378934621375893, 1.033788946364601] | pass |
| full | aa | `multiply_100d_x100000` | 0.990 [0.9375711568360298, 1.0333859200938331] | pass |
| full | aa | `multiply_10000d_x1000` | 1.004 [0.98510631921319, 1.05790051849652] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.002 [0.9848638053969332, 1.0679265485018548] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.009 [0.928552840248847, 1.0881573144273466] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.005 [0.9616712634677945, 1.0177240658205522] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.971 [0.9315218736664346, 1.0224265560464407] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.065 [0.954350592567562, 1.1408226644626065] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.001 [0.9542618912468809, 1.0443333408208866] | pass |
| full | aa | `sparse_array_200000` | 0.996 [0.9734380746330834, 1.0112104566739992] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.995 [0.9523104405815276, 1.0220731109768162] | pass |
| full | aa | `streaming_statements_20000` | 1.005 [0.9812192548708308, 1.0490016028862772] | pass |
| full | paired | `startup` | 1.077 [0.9011939789668255, 1.1449381921786415] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.704 [0.6646590162578778, 0.7244587625569604] | pass |
| full | paired | `calls_200000` | 0.840 [0.8195591977404719, 0.8430895514380163] | pass |
| full | paired | `array_200000` | 0.631 [0.6074061435216127, 0.6593549849618888] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.683 [0.6765420750946722, 0.6947263875114285] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.748 [0.7408955722801974, 0.7939022399904783] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.749 [0.7315038618255868, 0.7516481347410213] | pass |
| full | paired | `fibonacci_1000_x100` | 0.810 [0.7879422434702541, 0.8261468582949852] | pass |
| full | paired | `multiply_100d_x100000` | 0.866 [0.8580788629108025, 0.8758512606499118] | pass |
| full | paired | `multiply_10000d_x1000` | 0.998 [0.9796539337717651, 1.0084802347663784] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.047 [0.9902313947638628, 1.0527328878493056] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.9641279020628944, 1.0325301174615968] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.959 [0.9228729637440417, 0.9900148069379838] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.979 [0.960455499452025, 0.9940701900028317] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.005 [0.9564099901838691, 1.0424243133897615] | pass |
| full | paired | `power_100d_e17_x1000` | 0.960 [0.924351311927284, 0.9871304048964499] | pass |
| full | paired | `sparse_array_200000` | 0.680 [0.6562963497064195, 0.6872587510042133] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.999 [0.9684962368074438, 1.01573459836979] | pass |
| full | paired | `streaming_statements_20000` | 0.986 [0.9350257757282978, 0.9962368490503062] | pass |
