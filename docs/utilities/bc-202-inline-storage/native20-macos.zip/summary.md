# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.913 [0.780633352442446, 1.2697480695483805] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.988 [0.9569268878985474, 1.089300965512729] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.982 [0.8605487052918853, 1.0825168221868808] | inconclusive-noisy |
| full | aa | `array_200000` | 0.964 [0.8752134992393681, 0.9905573413116967] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.944 [0.7814469491486331, 1.208610847135539] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.009 [0.8328002882442919, 1.1833915984652357] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.901 [0.8421517484174781, 1.1437033771685836] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.118 [0.9153959631656917, 1.2171446380610562] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.114 [0.7914272159879825, 1.2552633724196396] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9524982866984731, 1.0530108157286664] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.987 [0.8817807635654662, 1.129723869577078] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.003 [0.9264345417443784, 1.0438246562335367] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.047 [0.9889803301727091, 1.2083984051539354] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 0.990 [0.9588116836619726, 1.0131536381986979] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.983 [0.7611532760802562, 1.3040960602135587] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.935 [0.7651444669721613, 1.0379617667699486] | pass |
| full | aa | `sparse_array_200000` | 0.939 [0.841523273668264, 1.105647646036776] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.958 [0.8890834930609783, 1.0169533221781126] | pass |
| full | aa | `streaming_statements_20000` | 0.975 [0.9015302241771864, 1.1359567240734403] | inconclusive-noisy |
| full | paired | `startup` | 0.975 [0.587440231987092, 1.3901436594863237] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.622 [0.5130694630814332, 0.6994278908048006] | pass |
| full | paired | `calls_200000` | 0.725 [0.6768260011647168, 0.760506554100639] | pass |
| full | paired | `array_200000` | 0.618 [0.4934187503844592, 0.6970474194422511] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.629 [0.577023145335023, 0.7152756397935058] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.641 [0.5993123848009185, 0.7328369424420671] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.636 [0.6137885779721174, 0.6974805809817151] | pass |
| full | paired | `fibonacci_1000_x100` | 0.677 [0.6453207236963836, 0.7570842073352204] | pass |
| full | paired | `multiply_100d_x100000` | 0.813 [0.6304040514563857, 0.9223651466977301] | pass |
| full | paired | `multiply_10000d_x1000` | 0.983 [0.9299509731146279, 1.0796501410897377] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.111 [1.0956124911477911, 1.3908788651286417] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.992 [0.9458820972687151, 1.0536294736240017] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.935 [0.8346789536144337, 0.9710622310952949] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.033 [0.9717472985043418, 1.0792718610167995] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.991 [0.8829221790013687, 1.1618238842859971] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.975 [0.8203514265130111, 1.0246380060263651] | pass |
| full | paired | `sparse_array_200000` | 0.605 [0.48227135950960703, 0.6735836011917309] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.036 [0.9910253985901002, 1.1106971230801521] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.935 [0.8994400982258284, 1.189662061928408] | inconclusive-noisy |
