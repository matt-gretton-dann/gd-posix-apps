# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.907 [0.7556734783118977, 1.0577501948538566] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.102 [0.9627001246564364, 1.1675196940669064] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.904 [0.7948176137838188, 1.128205004630046] | inconclusive-noisy |
| full | aa | `array_200000` | 1.041 [0.9425290479269716, 1.0462237897399644] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.177 [0.9163255213601585, 1.2876995123808916] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.023 [0.8786866699251887, 1.236353379954637] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.970 [0.8103523839797417, 1.1091891470417428] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.997 [0.8874137873476464, 1.2035325872301206] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.001 [0.868483700525696, 1.1706589477354272] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.031 [1.0081514200687696, 1.0809985515292047] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.001 [0.9091523534506268, 1.126916642374495] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 0.994 [0.9334789680423807, 1.0524041026206836] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.964 [0.9396424597024806, 1.0883136840293761] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.008 [0.9478042697069545, 1.1009698877798932] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.058 [0.7407751382010892, 1.4782413041417088] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.047 [0.9267070747350455, 1.18295708931091] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.930 [0.8675499573766015, 1.1182137797196543] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.006 [0.9532287194010209, 1.06294054434295] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.949 [0.8138930347158977, 1.2229684772326146] | inconclusive-noisy |
| full | paired | `startup` | 0.685 [0.461033104706393, 1.1016959182606858] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.691 [0.682369871150199, 0.7857611322514523] | pass |
| full | paired | `calls_200000` | 0.843 [0.7297258178656832, 0.9082092419436183] | pass |
| full | paired | `array_200000` | 0.682 [0.5960358994004898, 0.7273179457779755] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.706 [0.6808345058582259, 0.8965598222187353] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.746 [0.709627648018302, 0.7880696536357148] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.747 [0.7096753785549105, 0.9304929485962516] | pass |
| full | paired | `fibonacci_1000_x100` | 0.871 [0.757205670647811, 1.0148874148679825] | pass |
| full | paired | `multiply_100d_x100000` | 0.840 [0.7186336627159314, 0.8485414952862012] | pass |
| full | paired | `multiply_10000d_x1000` | 0.882 [0.8645481546142811, 0.99883774692771] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.019 [0.9625902298657917, 1.2553505631389823] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.884 [0.820898528433871, 1.0302168015908735] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.989 [0.9300153419351306, 1.0287599998602412] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.359 [0.3285739297243686, 0.3745207680339813] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.982 [0.8719904726879669, 1.1738636853519564] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.843 [0.8170493894881673, 0.987958020899545] | pass |
| full | paired | `sparse_array_200000` | 0.703 [0.6686027061417966, 0.809378033675849] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.996 [0.9456686710918453, 1.0209469338952177] | pass |
| full | paired | `streaming_statements_20000` | 1.044 [0.9006455905404097, 1.0925371359931175] | inconclusive-noisy |
