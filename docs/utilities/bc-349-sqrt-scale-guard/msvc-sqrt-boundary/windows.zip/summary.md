# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.942 [0.9258458232364002, 1.080456402763069] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.995 [0.9624575128219076, 1.014905808669617] | pass |
| full | aa | `calls_200000` | 1.012 [0.9964940297045801, 1.028191855539259] | pass |
| full | aa | `array_200000` | 0.990 [0.9532218396458678, 1.0298226195467997] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.001 [0.9900986252308733, 1.0116110531906448] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.009 [0.9981713771898821, 1.0219481571613316] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.001 [0.9911135244889083, 1.0038804209983367] | pass |
| full | aa | `fibonacci_1000_x100` | 1.005 [0.9629012445457004, 1.052046889277572] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 0.989 [0.9829367873647947, 1.012629373157044] | pass |
| full | aa | `multiply_100d_x100000` | 1.015 [1.0024947327142597, 1.032503159891098] | pass |
| full | aa | `multiply_10000d_x1000` | 1.004 [0.9982561327681964, 1.0112968323441154] | pass |
| full | aa | `divide_scale100_x100000` | 0.995 [0.9880777920260033, 1.0440427651611128] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.000 [0.9822416252359428, 1.0090039739963284] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9846565511534227, 1.0222621700341845] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9920267259504745, 1.0125190011892757] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9917426894013149, 1.0512858282154758] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.009 [0.9936528134774786, 1.0408480998708902] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.997 [0.9885214268524031, 1.0062481755100516] | pass |
| full | aa | `power_100d_e17_x1000` | 1.002 [0.9898974124059489, 1.0142265611140244] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.997 [0.980166471582046, 1.015248339667686] | pass |
| full | aa | `recursion_50_x1000` | 1.012 [0.9944092106054949, 1.026007261357297] | pass |
| full | aa | `sparse_array_200000` | 0.999 [0.9958996437966605, 1.0263003053834716] | pass |
| full | aa | `frontend_definitions_2000` | 1.029 [0.953703443717469, 1.242636440055282] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.001 [0.9764206614278186, 1.0189165751851421] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.992 [0.9298406499133309, 1.0589856793898675] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.990 [0.9360053350904466, 1.0388207145369313] | pass |
| full | aa | `square_100d_x100000` | 1.004 [0.984546855132132, 1.0190509339158733] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9941610880303893, 1.0101734586558944] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.940 [0.8853369087045758, 1.0683727242710692] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.988 [0.9819138679638786, 1.03320653272772] | pass |
| full | aa | `octal_output_1000d_x300` | 1.018 [0.967545201045065, 1.026305199522223] | pass |
| full | aa | `binary_input_100000d_x3` | 1.003 [0.9704837402597121, 1.0115747633154348] | pass |
| full | aa | `hex_input_100000d_x3` | 1.007 [0.9912078896915435, 1.023514079228258] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.993 [0.9854677094397528, 0.9957315351706237] | pass |
| full | aa | `file_statements_20000` | 1.002 [0.9257586628964981, 1.0673520173389703] | inconclusive-noisy |
| full | paired | `startup` | 0.974 [0.8681634008808807, 1.0185625549412438] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.081 [1.0266384360482044, 1.09114108766154] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.013 [0.9749110365838745, 1.120248762970597] | inconclusive-noisy |
| full | paired | `array_200000` | 1.078 [1.035024551528582, 1.1092495582434285] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.051 [1.0444338511125368, 1.0749762611434284] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.119 [1.024653269374322, 1.2602399427171738] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.118 [1.105560248270914, 1.1443493510622647] | confirmed regression |
| full | paired | `fibonacci_1000_x100` | 1.023 [1.019735745175996, 1.129698027889709] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.005 [0.949701214557192, 1.0185705881779243] | pass |
| full | paired | `multiply_100d_x100000` | 1.047 [1.0003091731150262, 1.0705003458248339] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.985 [0.9716274403199766, 1.0121005054722523] | pass |
| full | paired | `divide_scale100_x100000` | 1.077 [0.9834567317067552, 1.0960956293037838] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.997 [0.9842975206613573, 1.0276543424679254] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.996 [0.9737867636228801, 1.0144551459913604] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.991937221708123, 1.033587434707581] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.993 [0.8928237233832448, 1.0487808882926555] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.012 [0.9515128912754163, 1.0502351056671906] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.004 [0.9913293839985536, 1.0131460242102173] | pass |
| full | paired | `power_100d_e17_x1000` | 1.003 [0.9880204452945636, 1.016560725055997] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.046 [1.0333313034111484, 1.0668656047795304] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.005 [0.9253708749612412, 1.029777611207608] | pass |
| full | paired | `sparse_array_200000` | 1.060 [1.0253220421910827, 1.161552450038598] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.017 [0.9869972857617316, 1.1513945033943764] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.025 [0.7666558872479131, 1.0433414810751063] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.986 [0.9400822750865925, 1.0362961481049464] | pass |
| full | paired | `streaming_statements_20000` | 0.994 [0.9423097887269838, 1.021171471600639] | pass |
| full | paired | `square_100d_x100000` | 1.007 [0.9616969188926828, 1.0427270746760946] | pass |
| full | paired | `square_10000d_x500` | 1.000 [0.992820614620061, 1.0204428562527945] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.054 [0.9731138166231945, 1.1019039399421853] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.009 [0.9989328271969855, 1.1370309325776224] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.016 [0.9950394533668359, 1.0243522661918043] | pass |
| full | paired | `binary_input_100000d_x3` | 1.012 [0.912481693638082, 1.0208921331973093] | pass |
| full | paired | `hex_input_100000d_x3` | 0.996 [0.9329588701864787, 1.0257363376903] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.033 [1.0002437027009725, 1.0390808405491951] | pass |
| full | paired | `file_statements_20000` | 1.016 [0.9879134719027907, 1.0531748051181788] | inconclusive-noisy |
