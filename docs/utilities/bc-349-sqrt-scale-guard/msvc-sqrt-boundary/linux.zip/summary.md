# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.899 [0.8364119562151429, 1.1793600713052448] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.004 [0.9713093783586179, 1.0170091694090124] | pass |
| full | aa | `calls_200000` | 0.999 [0.9839225428883065, 1.0184699671888422] | pass |
| full | aa | `array_200000` | 0.998 [0.9890938377770089, 1.0058005902211387] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.997 [0.9915729921270726, 1.0033296538719771] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.003 [0.9854470728309351, 1.015709324039498] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.999 [0.9943768971944775, 1.0011774700265255] | pass |
| full | aa | `fibonacci_1000_x100` | 1.002 [0.9513812898544299, 1.0234730910634184] | pass |
| full | aa | `factorial_1000_x50` | 1.001 [0.9974512106369676, 1.006697656037164] | pass |
| full | aa | `multiply_100d_x100000` | 1.008 [0.9675864604997592, 1.0269868847105323] | pass |
| full | aa | `multiply_10000d_x1000` | 0.999 [0.9472248845549384, 1.0025401385120005] | pass |
| full | aa | `divide_scale100_x100000` | 1.009 [0.991435499705439, 1.0277464701558439] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.996 [0.9940804579798065, 1.0060137583850597] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.003 [0.9979408707461352, 1.0562986256877989] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.8743780945118018, 1.0212964303999919] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9946695738590066, 1.0024436963041263] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.990 [0.9760877802661678, 1.0217548317684548] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.001 [0.9958115057296061, 1.0069334642161283] | pass |
| full | aa | `power_100d_e17_x1000` | 1.006 [0.9961989231737547, 1.0113161088166507] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.991 [0.9585685581824709, 1.0125213346126083] | pass |
| full | aa | `recursion_50_x1000` | 1.010 [1.0017762731990654, 1.0247193243729174] | pass |
| full | aa | `sparse_array_200000` | 1.004 [0.9924802508317259, 1.0171821044805591] | pass |
| full | aa | `frontend_definitions_2000` | 0.999 [0.9902233337517997, 1.0208149882744013] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.990 [0.9792653766108265, 1.0212169813232297] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.989 [0.8826849578029654, 1.0719364492247054] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.001 [0.9864146676737556, 1.0090510902370977] | pass |
| full | aa | `square_100d_x100000` | 1.000 [0.9942394486586554, 1.0076878191000813] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9982702054779732, 1.0023129468391403] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.975 [0.858396985956362, 1.0160725290008075] | pass |
| full | aa | `binary_output_1000d_x300` | 1.005 [0.9744284129591991, 1.0302307054543793] | pass |
| full | aa | `octal_output_1000d_x300` | 1.000 [0.9899118989055397, 1.012193508728736] | pass |
| full | aa | `binary_input_100000d_x3` | 0.995 [0.986946685366825, 1.0062208513217377] | pass |
| full | aa | `hex_input_100000d_x3` | 1.001 [0.9912518954449898, 1.0171849940639814] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.003 [0.9935395221741364, 1.0044648240222431] | pass |
| full | aa | `file_statements_20000` | 1.003 [0.9943699795628164, 1.011050956181338] | pass |
| full | paired | `startup` | 0.945 [0.8751307359417215, 1.1046560320097552] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.947 [0.9134008332091328, 0.9691022872861611] | pass |
| full | paired | `calls_200000` | 0.990 [0.9771548714234031, 0.9978405254470846] | pass |
| full | paired | `array_200000` | 0.993 [0.9678460825541282, 0.9962077941385287] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.970 [0.9230577220973386, 0.9820843655104763] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.997 [0.9792852114187204, 1.0055818966340222] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.996 [0.9773186915966292, 1.0002956259103235] | pass |
| full | paired | `fibonacci_1000_x100` | 0.955 [0.9472945751232317, 0.9850644058288756] | pass |
| full | paired | `factorial_1000_x50` | 0.994 [0.9809221787462713, 0.9992643325508118] | pass |
| full | paired | `multiply_100d_x100000` | 0.968 [0.9500800231916402, 0.9846878250935456] | pass |
| full | paired | `multiply_10000d_x1000` | 0.999 [0.9968880431703351, 1.0000584280663563] | pass |
| full | paired | `divide_scale100_x100000` | 0.973 [0.9674835132032209, 0.9765533899433944] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.994 [0.9907724701717059, 1.0003127589094456] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.997 [0.9946643132151837, 1.0009010770663174] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.978383492300587, 1.0114954664560087] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.978 [0.973698782964951, 0.9807649995678498] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.9749858211172797, 1.0103799675792897] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.998 [0.9959680694868102, 1.0044043521527517] | pass |
| full | paired | `power_100d_e17_x1000` | 1.007 [0.993017027385747, 1.0188730926950034] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.988 [0.9683284436760499, 0.9947662713979746] | pass |
| full | paired | `recursion_50_x1000` | 0.964 [0.959459113018172, 0.9872167413563986] | pass |
| full | paired | `sparse_array_200000` | 0.987 [0.9839164878974292, 1.0044619885817183] | pass |
| full | paired | `frontend_definitions_2000` | 0.994 [0.9776789455817626, 0.9991449855897303] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.987 [0.9711335999877316, 1.0086141871027559] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.956 [0.8984208490074993, 1.107816257339326] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.986 [0.9775120731830594, 0.9951046878210311] | pass |
| full | paired | `square_100d_x100000` | 0.978 [0.972761072125876, 0.9879519040385439] | pass |
| full | paired | `square_10000d_x500` | 0.999 [0.9980087134829136, 1.0001494945935083] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.017 [0.9852460216144031, 1.2435585438472168] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.004 [0.9527440377272872, 1.0146887651198955] | pass |
| full | paired | `octal_output_1000d_x300` | 0.995 [0.9824100547711291, 0.9992772215621356] | pass |
| full | paired | `binary_input_100000d_x3` | 0.991 [0.9897229321602272, 0.9962557138108863] | pass |
| full | paired | `hex_input_100000d_x3` | 0.998 [0.9845224834477802, 1.0032740770333963] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.992 [0.9882591135063071, 0.998473330268914] | pass |
| full | paired | `file_statements_20000` | 1.000 [0.993790965193814, 1.012244414400675] | pass |
