# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.875 [0.825429881680601, 1.0650079522086684] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.981 [0.8058523459428679, 1.053709964752521] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.947 [0.9051531904267242, 1.048676642810384] | pass |
| full | aa | `array_200000` | 1.006 [0.8920409769163465, 1.0409145968799394] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.021 [0.9929511088925765, 1.061870165127012] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.988 [0.9523691695023216, 1.027572142433921] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.974 [0.9550610231724316, 1.0618047987017896] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.922 [0.8597704621951678, 1.0641219606513084] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 0.977 [0.882267451022857, 0.9925230593114229] | pass |
| full | aa | `multiply_100d_x100000` | 0.943 [0.9342433215455347, 1.0866174480337245] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.982 [0.933922230679147, 1.0687799353460121] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.016 [0.8842540865688897, 1.0541738978029063] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.002 [0.8952068088034294, 1.100833066755297] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.013 [0.9589980424975322, 1.040171032304218] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9718197423921933, 1.0821350681962791] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.033 [0.985768409889742, 1.1467631838967673] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.964 [0.8863659902462235, 1.0519671820601613] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 1.021 [0.9070711506587947, 1.0832302307126964] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.973 [0.8862858585207566, 1.0268455258642164] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.981 [0.7871778549287067, 1.023103367625588] | pass |
| full | aa | `recursion_50_x1000` | 0.970 [0.9292069996136516, 1.1129690608457297] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.006 [0.8727391587709228, 1.047130557345916] | pass |
| full | aa | `frontend_definitions_2000` | 1.004 [0.9276945173580963, 1.128478858673869] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.002 [0.8091015677890436, 1.068905982757631] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.037 [0.9944200149469409, 1.2291092966323316] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.983 [0.922804294330557, 1.0395576397254704] | pass |
| full | aa | `square_100d_x100000` | 1.006 [0.9694793110386227, 1.231854122660551] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.999 [0.9152550148409331, 1.0718571724368566] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.939 [0.891377370165058, 1.1305712401559451] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.998 [0.8872890635477727, 1.0716878744218856] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 0.994 [0.8362851625766708, 1.0505440510295647] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 0.988 [0.9090366245052675, 1.0252673344205188] | pass |
| full | aa | `hex_input_100000d_x3` | 0.981 [0.862173239286511, 1.0330043671923606] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.966 [0.9346947023807554, 1.05202625420655] | inconclusive-noisy |
| full | aa | `file_statements_20000` | 1.006 [0.9472881110140604, 1.4254754513610712] | inconclusive-noisy |
| full | paired | `startup` | 0.983 [0.7487110127095317, 1.0052088150317702] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.038 [0.9504796453443444, 1.1806708003230026] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.990 [0.8524252102809965, 1.0880833489112234] | inconclusive-noisy |
| full | paired | `array_200000` | 1.050 [0.8923994717953838, 1.1558213350559787] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.796 [0.7086872298908281, 0.9742650545828028] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.965 [0.8035756376275052, 1.074290155741044] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.959 [0.8729510179278461, 1.1306638179847808] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.804 [0.6751280012660773, 0.9735726353951965] | pass |
| full | paired | `factorial_1000_x50` | 0.949 [0.8686137426991218, 1.0953606414791734] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.990 [0.8719214753370541, 1.1355197743931822] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.009 [0.9656216666176702, 1.0838904519695127] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.969 [0.7945916217849274, 1.3015455205600086] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.905 [0.8586749666955681, 1.0910953807611312] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.039 [0.9471916398310909, 1.1977476060938628] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.995 [0.8919851810826854, 1.1798729484632313] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.935 [0.8688689434864538, 1.13269716661182] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.007 [0.8913110538709033, 1.2061487861332596] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.997 [0.8174460061600638, 1.2729090762417719] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.847 [0.815142719493552, 1.0399539485489189] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.090 [0.8608817404938558, 1.2310840789463555] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.046 [0.9552607086965392, 1.2110397680933347] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.030 [0.7615487412791714, 1.2938685696062961] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.970 [0.8676605082351049, 1.6936086101173318] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.887 [0.8161051836139688, 0.9765585540168039] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.909 [0.6014505273442765, 1.2365500891814392] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.026 [0.7570319919907148, 1.221363561578165] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.998 [0.9353838120309644, 1.2125423495839642] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.092 [0.9167343125713332, 1.2190859381821253] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.978 [0.8990620075765815, 1.5326658074693922] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.163 [0.9084379029550468, 1.3325160662252247] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.031 [0.6424275931138135, 1.1903034089501925] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.045 [0.9005391413665307, 1.3890513788351828] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.911 [0.8222019206071023, 1.1217658005384403] | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 0.996 [0.9109491520880519, 1.083024995104234] | inconclusive-noisy |
| full | paired | `file_statements_20000` | 0.991 [0.8134010867091687, 1.1321200754518987] | inconclusive-noisy |
