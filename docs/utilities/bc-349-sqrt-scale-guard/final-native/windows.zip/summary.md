# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.957 [0.9006804841409864, 1.0658771426877216] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.994 [0.9497889735165257, 1.0334633017160755] | pass |
| full | aa | `calls_200000` | 0.992 [0.9662887020119609, 1.0101273317560167] | pass |
| full | aa | `array_200000` | 1.001 [0.9777442441858073, 1.0207742913867406] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.000 [0.9735632632352658, 1.0071740419916368] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.982 [0.9794125503245561, 1.0076607708131358] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.010 [0.9837344113500379, 1.0102268509418693] | pass |
| full | aa | `fibonacci_1000_x100` | 0.998 [0.949622586523255, 1.0182081324200152] | pass |
| full | aa | `factorial_1000_x50` | 0.997 [0.985756114511201, 1.0201650311091066] | pass |
| full | aa | `multiply_100d_x100000` | 0.935 [0.914935215392469, 0.953381381039901] | pass |
| full | aa | `multiply_10000d_x1000` | 1.003 [0.9881665233831525, 1.008451469124309] | pass |
| full | aa | `divide_scale100_x100000` | 0.944 [0.9402068867472808, 0.9481798333558354] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9906061008834431, 1.000981704447412] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9745916272613895, 1.0210623282138531] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9869146753550988, 1.009521578442608] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.989401255735043, 1.0140640650878543] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.976 [0.9683557729457636, 1.0324224951959073] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.999 [0.9952700065800171, 1.0059281446469654] | pass |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9968741938268287, 1.0281971047880962] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.998 [0.9723465463800199, 1.0186980897628568] | pass |
| full | aa | `recursion_50_x1000` | 1.006 [0.9818803924394034, 1.0154807299480748] | pass |
| full | aa | `sparse_array_200000` | 0.982 [0.9682358172413541, 0.998050953867796] | pass |
| full | aa | `frontend_definitions_2000` | 0.994 [0.9875076546238083, 1.0029237859227962] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.990 [0.9694222980644241, 1.0133250297373055] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.977 [0.8623711474027365, 1.0615935349227337] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.994 [0.9532045460198528, 1.019445710140901] | pass |
| full | aa | `square_100d_x100000` | 0.951 [0.9414265248539092, 0.9569702998941904] | pass |
| full | aa | `square_10000d_x500` | 1.002 [0.9993377738153045, 1.008893827558437] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.999 [0.8899046279563593, 1.0224932967049964] | pass |
| full | aa | `binary_output_1000d_x300` | 1.007 [0.9905289702098994, 1.0316248100588978] | pass |
| full | aa | `octal_output_1000d_x300` | 1.003 [0.9965064479781627, 1.0341428791861924] | pass |
| full | aa | `binary_input_100000d_x3` | 0.992 [0.9895481786717462, 0.9973062457332452] | pass |
| full | aa | `hex_input_100000d_x3` | 0.993 [0.9566631298349116, 1.0039172667951275] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.003 [0.9952897951918719, 1.0090914937163684] | pass |
| full | aa | `file_statements_20000` | 0.990 [0.9369861831729814, 0.9988104880888944] | pass |
| full | paired | `startup` | 0.937 [0.8849887053421811, 1.047091412761939] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.014 [1.0051877375806009, 1.0502364584612118] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.003 [0.9561057936691532, 1.0289174589438443] | pass |
| full | paired | `array_200000` | 1.001 [0.9805552900814919, 1.0366210857227651] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.005 [0.9879054571081072, 1.1794910593631378] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.095 [1.050717299039459, 1.2045965357357862] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.054 [1.0404770839023794, 1.0805963577017181] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.995 [0.9543189533230901, 1.007500374084769] | pass |
| full | paired | `factorial_1000_x50` | 1.001 [0.9858586485451705, 1.0109164800600514] | pass |
| full | paired | `multiply_100d_x100000` | 0.942 [0.8767949371197042, 0.9559402379397451] | pass |
| full | paired | `multiply_10000d_x1000` | 0.992 [0.988204772366484, 1.006218014242716] | pass |
| full | paired | `divide_scale100_x100000` | 0.942 [0.9295286506475049, 1.0235230469601386] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.002 [0.9772553292190176, 1.0070095597017723] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.002 [0.9944545383135598, 1.0044013479347884] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.987 [0.977603732906374, 1.002372272634609] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.006 [0.9578065691878402, 1.0098180622429025] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.007 [0.9771995134217606, 1.0140732468767917] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.991 [0.9834516198563483, 1.0100391718488637] | pass |
| full | paired | `power_100d_e17_x1000` | 0.983 [0.9398448448828524, 1.0168485719903224] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.013 [0.9132497698467077, 1.0627656617829782] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.994 [0.9755513057014775, 1.0370378001219116] | pass |
| full | paired | `sparse_array_200000` | 1.019 [0.992435284581536, 1.0455625822346986] | pass |
| full | paired | `frontend_definitions_2000` | 1.005 [0.96613582280548, 1.0339411330082318] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.010 [0.9918678823068202, 1.0244770955553943] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.006 [0.921598325665963, 1.162380547888986] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.998 [0.9862593627917449, 1.0403261522408669] | pass |
| full | paired | `square_100d_x100000` | 0.956 [0.9451457691574149, 0.9889817114458821] | pass |
| full | paired | `square_10000d_x500` | 1.004 [1.0012989882342855, 1.0118428232050554] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.017 [0.8579112394358145, 1.0450160771635615] | pass |
| full | paired | `binary_output_1000d_x300` | 0.999 [0.9837866158542679, 1.053977718500874] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.004 [0.9820883553333684, 1.0341895279914533] | pass |
| full | paired | `binary_input_100000d_x3` | 1.002 [0.991136712205841, 1.014201140716238] | pass |
| full | paired | `hex_input_100000d_x3` | 1.002 [0.9942819717134067, 1.0183854483450243] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.002 [0.9758883524810809, 1.0104178378325914] | pass |
| full | paired | `file_statements_20000` | 0.999 [0.975381546160926, 1.0972258465448539] | inconclusive-noisy |
