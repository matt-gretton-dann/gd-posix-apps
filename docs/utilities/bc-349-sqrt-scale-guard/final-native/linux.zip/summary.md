# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.786 [0.7130184736742271, 1.1783467400829695] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.996 [0.9927496881465305, 0.997000074877302] | pass |
| full | aa | `calls_200000` | 1.000 [0.9475093886542688, 1.0077601354296417] | pass |
| full | aa | `array_200000` | 1.001 [0.993874102783165, 1.0072351438958862] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.996 [0.9834470426966473, 1.0166148486667632] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.001 [0.9848431322465863, 1.0144698502777516] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.998 [0.9787631686919395, 1.0075702536713167] | pass |
| full | aa | `fibonacci_1000_x100` | 0.994 [0.9898832332147492, 1.0686633070561915] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.001 [0.9878877817690955, 1.0071711427807422] | pass |
| full | aa | `multiply_100d_x100000` | 0.998 [0.9741842884973848, 1.0091174076891063] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [1.0002397836013368, 1.0035834612634784] | pass |
| full | aa | `divide_scale100_x100000` | 1.008 [0.9846607780992785, 1.016503622573526] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.001 [0.9931364338853749, 1.0039144335388188] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.997 [0.9939229036992823, 1.0020264657480056] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9879856716546209, 1.0117595389051952] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.002 [0.9998056642805218, 1.0082223448230485] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.988 [0.9596350003704297, 1.0269073445561256] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.002 [0.9932108244829949, 1.0131499461895097] | pass |
| full | aa | `power_100d_e17_x1000` | 1.004 [0.9966958371609371, 1.0155198270201136] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.994 [0.9796119042726057, 1.0469956459736198] | pass |
| full | aa | `recursion_50_x1000` | 1.004 [0.980209911274458, 1.0070130091865315] | pass |
| full | aa | `sparse_array_200000` | 1.004 [0.9958135590730598, 1.0124309398974831] | pass |
| full | aa | `frontend_definitions_2000` | 1.001 [0.9818696366975133, 1.0260210664988236] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.015 [0.9879816884341721, 1.032517962144382] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.895 [0.7565501894372192, 1.086405543989381] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.001 [0.9835455120562361, 1.0088198040879957] | pass |
| full | aa | `square_100d_x100000` | 0.998 [0.9823916271399123, 1.005288552224507] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9986292492475025, 1.0035726970945402] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.957 [0.7947985710156782, 1.0307938765260454] | pass |
| full | aa | `binary_output_1000d_x300` | 1.004 [0.9918218603919388, 1.018529242230794] | pass |
| full | aa | `octal_output_1000d_x300` | 0.996 [0.9925788997820477, 1.013708603432979] | pass |
| full | aa | `binary_input_100000d_x3` | 0.995 [0.9846962661924941, 1.0038440865907758] | pass |
| full | aa | `hex_input_100000d_x3` | 1.001 [0.9872554895156194, 1.0347995186463244] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.005 [1.0001255902270403, 1.0079715681049164] | pass |
| full | aa | `file_statements_20000` | 1.009 [0.9812336475414085, 1.0117287870131564] | pass |
| full | paired | `startup` | 0.945 [0.8005875578496503, 1.073166929008093] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.990 [0.9718052246313039, 0.9967533437618794] | pass |
| full | paired | `calls_200000` | 1.003 [0.9974334811236985, 1.0182878082416735] | pass |
| full | paired | `array_200000` | 0.987 [0.9813079013955457, 1.0008171582686984] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.974 [0.9525595990620134, 1.0004386894685255] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.012 [0.9817691532813019, 1.0176417812485692] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.032 [1.0193656451555078, 1.0545782369088235] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.000 [0.9905500342596428, 1.0109025191602483] | pass |
| full | paired | `factorial_1000_x50` | 1.010 [1.0055110350911316, 1.0194899744178594] | pass |
| full | paired | `multiply_100d_x100000` | 0.990 [0.8869936461676796, 0.9932956553028413] | pass |
| full | paired | `multiply_10000d_x1000` | 0.997 [0.9716657954408713, 1.0005177069997033] | pass |
| full | paired | `divide_scale100_x100000` | 0.990 [0.9820541551809876, 0.9923611007539062] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.998 [0.9917028101822014, 1.0143845577131316] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.997 [0.9932365442361191, 0.9970861129698986] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9918694064622721, 1.0045103784241947] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.982 [0.9778916305779067, 0.984305212107045] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.006 [0.9597310798202494, 1.0286390099903344] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.000 [0.9935340096401157, 1.0050997788870948] | pass |
| full | paired | `power_100d_e17_x1000` | 0.999 [0.9803644527769815, 1.0111089940151041] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.994 [0.964114809704426, 1.0287818105941857] | pass |
| full | paired | `recursion_50_x1000` | 1.014 [0.9974178418956671, 1.023201782132725] | pass |
| full | paired | `sparse_array_200000` | 0.975 [0.9706169073016837, 0.9846671428591321] | pass |
| full | paired | `frontend_definitions_2000` | 0.990 [0.9621972718137188, 1.0008622218249774] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.990 [0.9550176561277834, 1.0003049527855143] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.962 [0.8595106621015871, 1.0449669790572875] | pass |
| full | paired | `streaming_statements_20000` | 0.988 [0.9801265807921877, 0.9912782996120746] | pass |
| full | paired | `square_100d_x100000` | 0.977 [0.972014867700448, 0.9884228689633553] | pass |
| full | paired | `square_10000d_x500` | 0.998 [0.9970194347246562, 0.9993680337944912] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.081 [0.9235899136296291, 1.1449754329633373] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.994 [0.9734694831415704, 1.0082960519999873] | pass |
| full | paired | `octal_output_1000d_x300` | 0.998 [0.9859356853494745, 1.0036607791587095] | pass |
| full | paired | `binary_input_100000d_x3` | 0.987 [0.9700893509003362, 1.020245445218483] | pass |
| full | paired | `hex_input_100000d_x3` | 1.001 [0.9920018017930652, 1.0078721091176706] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.000 [0.9965076609956636, 1.009025947188583] | pass |
| full | paired | `file_statements_20000` | 0.990 [0.9846822011006874, 0.9973475847597182] | pass |
