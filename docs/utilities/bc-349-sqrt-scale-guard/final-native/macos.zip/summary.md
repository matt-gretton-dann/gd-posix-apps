# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.055 [0.8521083063835457, 1.2417322376083797] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.004 [0.8671044326166056, 1.145917342620607] | inconclusive-noisy |
| full | aa | `calls_200000` | 1.072 [0.9770009942575854, 1.1835428753612234] | inconclusive-noisy |
| full | aa | `array_200000` | 1.111 [0.9969888063472395, 1.1765084971992594] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.986 [0.9101766661096431, 1.233099282954271] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.955 [0.8912408645901778, 1.00290459472034] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.047 [0.9776468807192502, 1.1712869595386877] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.008 [0.8417683152786242, 1.1897656417855507] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 0.970 [0.9258005693979499, 1.114393698168319] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.004 [0.752501310839002, 1.05479502048554] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.016 [0.9175182225071546, 1.1005496780980983] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 0.965 [0.7947736574160996, 1.0609576622165606] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.000 [0.934485763298723, 1.1161159405069487] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.049 [0.9465561590271787, 1.078794053995955] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.982 [0.9692495582362641, 1.0338420976284082] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.092 [0.8826203312412627, 1.2876834088945301] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.8252319539814106, 1.0980149650460929] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 1.016 [0.9433551956717431, 1.359648723957791] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.002 [0.8178860495924316, 1.05295271702598] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 1.010 [0.797853011050844, 1.1412941211039893] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.990 [0.8997616668078049, 1.0477346141582145] | pass |
| full | aa | `sparse_array_200000` | 0.983 [0.9486416397757346, 1.0264752960194476] | pass |
| full | aa | `frontend_definitions_2000` | 1.010 [0.8429486966752858, 1.298789761945991] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.060 [1.0420077613080656, 1.3155986277382605] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.035 [0.8640843032279302, 1.0736431367466996] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.009 [0.8677262562086975, 1.2276578201223352] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.995 [0.9210167243164459, 1.0517037696413842] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.985 [0.9538543441429235, 1.088388406326981] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.995 [0.9401954720528948, 1.115270097126389] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.069 [0.8639192160179376, 1.2993329075599795] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 1.010 [0.9802401307628514, 1.0575212314993059] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 0.986 [0.9393454765618205, 1.2636983210767323] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 0.995 [0.8570954564199902, 1.115357328373666] | inconclusive-noisy |
| full | aa | `temporary_chain_1000d_x50000` | 0.977 [0.9660287222174434, 1.1487836145269803] | inconclusive-noisy |
| full | aa | `file_statements_20000` | 1.068 [0.9239128525602244, 1.2484431210130944] | inconclusive-noisy |
| full | paired | `startup` | 0.940 [0.8102019214039812, 1.133458750544437] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.981 [0.8252378158217629, 1.1340843774408809] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.911 [0.7162242192577779, 1.017223803547347] | pass |
| full | paired | `array_200000` | 0.988 [0.8069745872155446, 1.2023229134633027] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.982 [0.9292567580101907, 1.148744913393751] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.064 [1.0269129114490778, 1.134496192935166] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.943 [0.7953350788543526, 1.0638539763084849] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.983 [0.7557105172090908, 1.0930036689762705] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.998 [0.9655218183381347, 1.0217601387923196] | pass |
| full | paired | `multiply_100d_x100000` | 0.888 [0.7536765120957062, 1.0262424432967743] | pass |
| full | paired | `multiply_10000d_x1000` | 0.966 [0.8899477675633, 1.0673773200034327] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.007 [0.9218504928417081, 1.0553716560217736] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.958 [0.8232203224555921, 1.1183271306461455] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.019 [0.9862793144918325, 1.2016338479481878] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.970 [0.8589821116980845, 1.1267620980666788] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.980 [0.9469080695057119, 1.0613788240132735] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.935 [0.857816327839465, 1.1272730583339785] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.984 [0.8843903936889176, 1.3354436394604476] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.992 [0.9293962609835393, 1.1817978392126733] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.921 [0.8740878479647923, 1.1427722468733343] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.003 [0.6358834339947456, 1.2276390917222453] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.057 [0.8989192699053153, 1.7411097326522995] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.005 [0.8979154258219828, 1.2890894626430105] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.921 [0.7095081305513119, 1.0437190049750373] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.013 [0.7871619508571386, 1.1823592118406363] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.925 [0.7059667702164516, 1.0374977452401075] | pass |
| full | paired | `square_100d_x100000` | 0.942 [0.7727768649747819, 1.183730337079189] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.891 [0.7866412728754602, 1.0266506268093767] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.057 [0.9223984121239616, 1.6365781847572576] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.995 [0.8719338775420665, 1.0753649530662237] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.924 [0.7885295760189603, 1.0315429975913664] | pass |
| full | paired | `binary_input_100000d_x3` | 1.016 [0.9690102542773532, 1.205601776360107] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 1.069 [0.9723953574904918, 1.1691804535877726] | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.001 [0.8997336866161519, 1.0389790149282556] | pass |
| full | paired | `file_statements_20000` | 1.069 [0.8963165555376673, 1.1256350106927402] | inconclusive-noisy |
