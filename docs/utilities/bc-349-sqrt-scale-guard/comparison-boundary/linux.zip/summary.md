# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.907 [0.7957246519566892, 1.068328387725136] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.021 [0.9767693560791252, 1.0351906568394544] | pass |
| full | aa | `calls_200000` | 0.993 [0.9679179919655486, 1.0471533279869945] | pass |
| full | aa | `array_200000` | 0.996 [0.988696568778205, 1.0154296837312935] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.003 [0.9901079355575917, 1.0184475578933245] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.002 [0.986060203621138, 1.0077258249845722] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.002 [0.9874499061468656, 1.0148241755533625] | pass |
| full | aa | `fibonacci_1000_x100` | 1.001 [0.9955295726277247, 1.0140237313867295] | pass |
| full | aa | `factorial_1000_x50` | 1.001 [0.9973159590527518, 1.0072280084951035] | pass |
| full | aa | `multiply_100d_x100000` | 1.000 [0.980027739037478, 1.020728292997348] | pass |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.994335350650339, 1.0020901967470834] | pass |
| full | aa | `divide_scale100_x100000` | 0.996 [0.9844954279657856, 1.0110051821237016] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.003 [0.9973608474346298, 1.0050770250579397] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.997 [0.9534660521435597, 1.0022021855919712] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9893700004395726, 1.0154963705837707] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9961691805783308, 1.0014116909809385] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.999 [0.9730714639244902, 1.0200436571959146] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9967596450618998, 1.0030679364410007] | pass |
| full | aa | `power_100d_e17_x1000` | 1.007 [0.9971727211458455, 1.0259060834331766] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.990 [0.9674719824581837, 1.0002066265647789] | pass |
| full | aa | `recursion_50_x1000` | 0.989 [0.9614826942051874, 1.0061179631653199] | pass |
| full | aa | `sparse_array_200000` | 0.988 [0.9872772255058357, 1.008594395719642] | pass |
| full | aa | `frontend_definitions_2000` | 0.990 [0.9835412153869082, 0.9984959539199505] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.998 [0.9926678721221813, 1.0225544431370608] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.968 [0.8856664032411384, 1.0342032275364388] | pass |
| full | aa | `streaming_statements_20000` | 1.003 [0.9942505018567782, 1.0760160759842987] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.004 [0.9895884496640505, 1.0084361560520303] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9998149155196832, 1.0011114314624743] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.989 [0.8728984175946135, 1.0230722597250228] | pass |
| full | aa | `binary_output_1000d_x300` | 1.009 [0.9751501373075998, 1.0188012415174257] | pass |
| full | aa | `octal_output_1000d_x300` | 1.000 [0.9916986343489433, 1.0111654267326897] | pass |
| full | aa | `binary_input_100000d_x3` | 0.992 [0.9889819865023177, 1.0053154800108168] | pass |
| full | aa | `hex_input_100000d_x3` | 0.995 [0.9910603493897197, 0.9981441713496654] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.000 [0.9972601783796738, 1.0051092570176823] | pass |
| full | aa | `file_statements_20000` | 0.998 [0.9890290467089881, 1.0124532216976465] | pass |
| full | paired | `startup` | 0.933 [0.8219475291119596, 1.0781453726740031] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.946 [0.9386202293684377, 0.9678895280472349] | pass |
| full | paired | `calls_200000` | 0.992 [0.9804927851145672, 1.0194889948057566] | pass |
| full | paired | `array_200000` | 0.986 [0.984821698043376, 0.9971577652273385] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.962 [0.951628937100462, 0.9739283012343939] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.987 [0.9805076182198662, 0.9935690690565803] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.982 [0.9775702336928448, 0.9934778151251941] | pass |
| full | paired | `fibonacci_1000_x100` | 0.946 [0.9296752130264196, 0.9710184703422563] | pass |
| full | paired | `factorial_1000_x50` | 0.993 [0.9724293688891694, 0.9978878633773035] | pass |
| full | paired | `multiply_100d_x100000` | 0.953 [0.9478723323927398, 0.9809967179885017] | pass |
| full | paired | `multiply_10000d_x1000` | 0.999 [0.9970849856914188, 1.0015648692655499] | pass |
| full | paired | `divide_scale100_x100000` | 0.971 [0.9576347993978748, 0.9846076676317251] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.995 [0.9854542791243883, 1.0017494476788757] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.997 [0.9933669128228514, 1.0014666500526945] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.993 [0.9796433027964596, 1.0098310870720595] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.979 [0.9761569023388647, 0.9852804052498138] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.999 [0.9802408236868947, 1.025129141197438] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.996 [0.993545176485091, 0.9997107839467049] | pass |
| full | paired | `power_100d_e17_x1000` | 1.004 [0.9855157278524609, 1.012279669236956] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.977 [0.9634871857575221, 1.0163688247127944] | pass |
| full | paired | `recursion_50_x1000` | 0.977 [0.9656166721908981, 0.9855372675741622] | pass |
| full | paired | `sparse_array_200000` | 0.968 [0.9549641348294502, 0.9895694264762008] | pass |
| full | paired | `frontend_definitions_2000` | 0.990 [0.9829225024347116, 1.0085855454945323] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.992 [0.9622914297159741, 0.9966158975804071] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.944 [0.9270249255679307, 1.0428601859288136] | pass |
| full | paired | `streaming_statements_20000` | 0.995 [0.9885192955822049, 1.005069479894018] | pass |
| full | paired | `square_100d_x100000` | 0.977 [0.9725944533700844, 0.9840976092299268] | pass |
| full | paired | `square_10000d_x500` | 0.999 [0.9982037279317032, 1.0001533946538077] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.021 [0.9847075758761327, 1.0778692096919127] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.018 [0.9565021811627453, 1.0437473993386395] | pass |
| full | paired | `octal_output_1000d_x300` | 1.001 [0.9927134016378661, 1.007742680351047] | pass |
| full | paired | `binary_input_100000d_x3` | 0.991 [0.9877452291613601, 1.0241396533621205] | pass |
| full | paired | `hex_input_100000d_x3` | 0.993 [0.9810036704277503, 0.996891921765546] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.995 [0.9926810427120085, 1.000534772338037] | pass |
| full | paired | `file_statements_20000` | 1.001 [0.9781625859490427, 1.0059546263116144] | pass |
