# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.973 [0.8863743402023458, 1.0136093236187036] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.998 [0.9762686036308744, 1.0488998072269793] | pass |
| full | aa | `calls_200000` | 1.004 [0.976604780610613, 1.0483983976102802] | pass |
| full | aa | `array_200000` | 0.996 [0.9728154156467491, 1.0000123843841555] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.001 [0.9662326197443754, 1.012802327012282] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.002 [0.9498588604286459, 1.0215579045649152] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.990 [0.9606470023391275, 1.0001281481749396] | pass |
| full | aa | `fibonacci_1000_x100` | 0.995 [0.9632202192280652, 1.0181149981733202] | pass |
| full | aa | `factorial_1000_x50` | 1.071 [0.9613711177678715, 1.1126914310903961] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.014 [0.9895148274651626, 1.0235040366277293] | pass |
| full | aa | `multiply_10000d_x1000` | 1.008 [0.9828424062346339, 1.012571043530682] | pass |
| full | aa | `divide_scale100_x100000` | 0.997 [0.9687116433601901, 1.007507279232308] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.009 [0.9692429460610231, 1.0132760797982252] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.9923263158464868, 1.0234798419157032] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9711698615637837, 1.022895380208424] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.005 [0.984211885831202, 1.0750970741524797] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.013 [0.968066186959348, 1.1397922378573009] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 1.009 [0.9543037008188662, 1.0226307948845663] | pass |
| full | aa | `power_100d_e17_x1000` | 0.992 [0.9400406592562648, 1.0284293663380915] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.997 [0.9835804850595353, 1.0571906873616084] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.999 [0.9685380139542645, 1.0276308271881147] | pass |
| full | aa | `sparse_array_200000` | 1.006 [0.9902034958064514, 1.0396645245672986] | pass |
| full | aa | `frontend_definitions_2000` | 1.033 [0.9987213636742949, 1.1608188904357233] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.993 [0.9599544344438169, 1.1347488227839166] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.011 [0.9907478265230519, 1.0227825709956087] | pass |
| full | aa | `streaming_statements_20000` | 0.994 [0.9562036012993386, 1.0117644107948973] | pass |
| full | aa | `square_100d_x100000` | 0.996 [0.9319555873366382, 1.0118323242547373] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9599534188240397, 1.0361914596078898] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.035 [0.9467022279810418, 1.1483723688662724] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.991 [0.9255266257732049, 1.0286922096952864] | pass |
| full | aa | `octal_output_1000d_x300` | 1.000 [0.9903247631415248, 1.0404034729714224] | pass |
| full | aa | `binary_input_100000d_x3` | 1.001 [0.9612414304299463, 1.0327222475896833] | pass |
| full | aa | `hex_input_100000d_x3` | 0.998 [0.9651416712383257, 1.04639659572272] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.012 [0.9956393983985617, 1.0363095364217023] | pass |
| full | aa | `file_statements_20000` | 1.001 [0.9814923714138726, 1.0184634921736921] | pass |
| full | paired | `startup` | 0.978 [0.9057394374375851, 1.0641124671676243] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.999 [0.9753838085205081, 1.0123352893271593] | pass |
| full | paired | `calls_200000` | 1.004 [0.9666983240078081, 1.024708061940709] | pass |
| full | paired | `array_200000` | 0.996 [0.9559250063971948, 1.015895752787589] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.997 [0.9722175752870219, 1.0166563224566447] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.020 [0.9535063377573333, 1.0550416809534] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.998 [0.9907079707922695, 1.0511793090487345] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.990 [0.9616276125511874, 0.9967828887476619] | pass |
| full | paired | `factorial_1000_x50` | 0.992 [0.9657416217031731, 1.037469843805816] | pass |
| full | paired | `multiply_100d_x100000` | 1.008 [0.9692076559408052, 1.0807231553988612] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.967 [0.9435998269032816, 1.0151689556814785] | pass |
| full | paired | `divide_scale100_x100000` | 0.997 [0.8715032161645117, 1.0218473946855988] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.011 [0.9933905874601727, 1.0880181673675882] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.977 [0.9602581918353117, 1.0096473437475177] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9804465997920441, 1.0106117259030831] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.994 [0.9707881217419604, 1.0173629071009536] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.960 [0.8843099176746375, 1.0324653978048441] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.006 [0.942136212047504, 1.090615927503201] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.007 [1.0034116528224644, 1.0103242105284727] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.005 [0.9814981409269907, 1.104431768187668] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.995 [0.9794469906700568, 1.1745844067966327] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.023 [0.9875604055392765, 1.0904114911008842] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.979 [0.9670899970822195, 1.0223430993425753] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.003 [0.9419431032418263, 1.0079822405759074] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.036 [1.0035341314334378, 1.097470499825765] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.988 [0.974169310319329, 0.9989446400264929] | pass |
| full | paired | `square_100d_x100000` | 0.992 [0.9640510295568644, 1.0062755739091975] | pass |
| full | paired | `square_10000d_x500` | 1.006 [0.9929049402449066, 1.1207390820397376] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 1.040 [0.9686036868164168, 1.1300003275968744] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.980 [0.8964893938944146, 1.0183418928823478] | pass |
| full | paired | `octal_output_1000d_x300` | 1.004 [0.96772735796988, 1.0751620998250495] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.002 [0.9976969001804207, 1.0165052594824007] | pass |
| full | paired | `hex_input_100000d_x3` | 0.966 [0.9501016995788321, 1.0173252785442342] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.000 [0.9797331630336656, 1.1673044445463918] | inconclusive-noisy |
| full | paired | `file_statements_20000` | 1.001 [0.9954290671323037, 1.0165850086020811] | pass |
