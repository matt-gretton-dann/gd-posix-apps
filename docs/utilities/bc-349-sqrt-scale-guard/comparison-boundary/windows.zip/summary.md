# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.894 [0.8777941620130997, 1.1223246911511893] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.990 [0.9676618344910921, 1.002566864872773] | pass |
| full | aa | `calls_200000` | 0.995 [0.9923706763943541, 1.016725820137715] | pass |
| full | aa | `array_200000` | 1.004 [0.9876008236433449, 1.0201327632243258] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.986 [0.973565742948115, 1.0020579051940226] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.002 [0.97926844900058, 1.0456153347941726] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.993 [0.9765402888208711, 1.0083818009844594] | pass |
| full | aa | `fibonacci_1000_x100` | 0.997 [0.9818104877903115, 1.0178054456603278] | pass |
| full | aa | `factorial_1000_x50` | 0.999 [0.9913620741205266, 1.0217809642198366] | pass |
| full | aa | `multiply_100d_x100000` | 0.976 [0.9728651842742405, 1.049955668745798] | pass |
| full | aa | `multiply_10000d_x1000` | 0.999 [0.9897531926577106, 1.0099237982332454] | pass |
| full | aa | `divide_scale100_x100000` | 0.991 [0.9813895154203708, 1.0109129537014594] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9869618203913859, 1.0078577591005737] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9789635888942932, 1.0077026559654505] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9879529689686534, 1.0005326709865867] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9771586942153507, 1.0452925719643253] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.003 [0.9788779848327152, 1.0304855407698772] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.004 [0.9969004875757443, 1.0066271783365437] | pass |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9571611970421274, 1.0106083748582877] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.991 [0.9640018492025306, 1.0193108158212059] | pass |
| full | aa | `recursion_50_x1000` | 1.008 [0.9992789420905793, 1.0159880607980583] | pass |
| full | aa | `sparse_array_200000` | 0.998 [0.962579848173786, 1.0214190385128308] | pass |
| full | aa | `frontend_definitions_2000` | 0.994 [0.9795536498110219, 1.023943478634812] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.995 [0.9847265560859465, 1.0277295383308596] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.984 [0.9393522923477625, 1.0162470822458407] | pass |
| full | aa | `streaming_statements_20000` | 0.998 [0.9451756732150447, 1.033066975161097] | pass |
| full | aa | `square_100d_x100000` | 0.974 [0.9326273463099636, 0.9860794059005691] | pass |
| full | aa | `square_10000d_x500` | 1.003 [0.9948769403088393, 1.008020867228516] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.969 [0.9226477301547432, 1.0545722953099825] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.003 [0.9781292334547569, 1.0087101355569978] | pass |
| full | aa | `octal_output_1000d_x300` | 0.992 [0.9801564439602152, 1.0189649200613657] | pass |
| full | aa | `binary_input_100000d_x3` | 0.998 [0.9813849164971161, 1.011617979229521] | pass |
| full | aa | `hex_input_100000d_x3` | 0.998 [0.9877398102486236, 1.0053976941263598] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.997 [0.9908255843887114, 0.9995896233887457] | pass |
| full | aa | `file_statements_20000` | 0.996 [0.9771239378827294, 1.0602388276938621] | inconclusive-noisy |
| full | paired | `startup` | 0.943 [0.8923918065625853, 1.008479458480269] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.997 [0.983106883109358, 1.0044255549090912] | pass |
| full | paired | `calls_200000` | 1.028 [0.9873078441602504, 1.0379087314389503] | pass |
| full | paired | `array_200000` | 0.988 [0.9772128612881762, 1.0302528240228863] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.005 [0.9896875963686306, 1.0210924838245956] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.069 [1.0573807836372378, 1.092712741751279] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.065 [1.0614606966854454, 1.066161528746971] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.003 [0.9822702779795008, 1.0117592891050164] | pass |
| full | paired | `factorial_1000_x50` | 1.020 [1.0165674269141067, 1.0354521291762981] | pass |
| full | paired | `multiply_100d_x100000` | 0.988 [0.9752547803261753, 1.0043147240412864] | pass |
| full | paired | `multiply_10000d_x1000` | 0.997 [0.9745093414569866, 0.9988982073925873] | pass |
| full | paired | `divide_scale100_x100000` | 0.997 [0.9927228969718864, 1.0212469699299485] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.004 [0.9984029069050112, 1.0100461966320342] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.998 [0.995766489646238, 1.0142042266691036] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9092711695695332, 1.0135005941692163] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.007 [0.9956244260509345, 1.0159117847764514] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.012 [0.9491863612856387, 1.0368612541401325] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.001 [0.9835292927435103, 1.0081294839082668] | pass |
| full | paired | `power_100d_e17_x1000` | 0.995 [0.9852819889285857, 1.006067239385597] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.006 [0.9804675568371096, 1.0226279309848418] | pass |
| full | paired | `recursion_50_x1000` | 0.995 [0.9802807207467926, 1.0056531509734965] | pass |
| full | paired | `sparse_array_200000` | 1.032 [1.0118442136390287, 1.0724529310089956] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.025 [0.9944946402575732, 1.1493240424148166] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.027 [1.0131726517827462, 1.0328463025710495] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.002 [0.960739882641998, 1.0191691165712065] | pass |
| full | paired | `streaming_statements_20000` | 1.004 [0.938212668277471, 1.0566347629133237] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.989 [0.9783579990680579, 1.0307901156848196] | pass |
| full | paired | `square_10000d_x500` | 1.005 [0.9983270953245558, 1.0141735371086267] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.022 [0.9431566770302788, 1.0632108677237486] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.005 [0.9785343706457157, 1.020815927786604] | pass |
| full | paired | `octal_output_1000d_x300` | 1.002 [0.9804153234202249, 1.0314028666224644] | pass |
| full | paired | `binary_input_100000d_x3` | 0.999 [0.8574468085102553, 1.0113438933550645] | pass |
| full | paired | `hex_input_100000d_x3` | 0.998 [0.9646561295077699, 1.0036788675446575] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.994 [0.9707031418659404, 1.0034449644754244] | pass |
| full | paired | `file_statements_20000` | 1.016 [0.9914462235521695, 1.0302045050740989] | pass |
