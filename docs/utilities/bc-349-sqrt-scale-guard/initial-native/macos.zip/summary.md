# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.001 [0.9450617158148394, 1.1382852132516832] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.957 [0.8805012983635008, 1.0457078175679655] | pass |
| full | aa | `calls_200000` | 1.055 [0.9903948562381188, 1.159225766932351] | inconclusive-noisy |
| full | aa | `array_200000` | 1.066 [0.9124577245439024, 1.2360527998958124] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.983 [0.9607326085996294, 1.0062308442889458] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.993 [0.817806062272248, 1.0441773231047948] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.989 [0.9445142566432927, 1.1002709434089202] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.030 [0.7276909444099527, 1.2227633881629383] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.124 [0.8022785246077518, 1.2361944520801134] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.031 [0.9851630556017988, 1.1207058416592992] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.988 [0.9561646527769082, 1.070550811062754] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.023 [0.970587855160682, 1.1308245112099324] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.048 [0.9528692482634245, 1.178052906016973] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.026 [0.9689986333895452, 1.089989653041285] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.013 [0.9600177353941053, 1.1317803763724614] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 0.976 [0.9297156092518174, 1.0876845404471345] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.045 [0.9983203244110455, 1.0945575442910696] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 1.016 [0.6027716135261092, 1.0873334469316163] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.997 [0.9467853047666461, 1.2767837697886077] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 0.992 [0.8511386974913805, 1.0606839716941838] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.990 [0.8710432721541366, 1.1039688903960534] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.976 [0.9197309831214403, 1.099920092427853] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.995 [0.938931036456122, 1.0827255786881307] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.040 [0.9549068908275602, 1.1564528244684664] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 0.987 [0.7240200546920009, 1.015293298609028] | pass |
| full | aa | `streaming_statements_20000` | 1.002 [0.8995030422564808, 1.2742606819062263] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.024 [0.927010990064634, 1.1157869664170461] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.942 [0.9057468569692114, 1.088576088079402] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 1.023 [0.940863988960834, 1.1309697500195994] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.010 [0.9025647040047862, 1.6707140600504322] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 1.036 [0.9480120201614028, 1.1368789288114656] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 0.976 [0.895694455030622, 1.0895038622842914] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 1.049 [0.8962993570572151, 1.1866429826774856] | inconclusive-noisy |
| full | aa | `temporary_chain_1000d_x50000` | 1.080 [0.9076340856549947, 1.1048285420350603] | inconclusive-noisy |
| full | aa | `file_statements_20000` | 0.940 [0.8671079896776018, 1.1829501703407854] | inconclusive-noisy |
| full | paired | `startup` | 1.102 [0.6111050862220337, 1.548152117722098] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.954 [0.8908825981146216, 1.0178829394056108] | pass |
| full | paired | `calls_200000` | 1.058 [0.762700366506576, 1.3742319271133039] | inconclusive-noisy |
| full | paired | `array_200000` | 1.001 [0.9134606232716683, 1.1640395237617156] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.996 [0.7468440172503155, 1.1724139984836173] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.943 [0.8920108601274003, 1.0031985131965822] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.911 [0.758517304383235, 1.1527185328375849] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.021 [0.8516574516933865, 1.478430837038871] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.013 [0.995065843680902, 1.301832618491613] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.127 [0.8943130055231633, 1.4039078452927203] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.027 [0.9288543010563718, 1.0401083730574767] | pass |
| full | paired | `divide_scale100_x100000` | 0.992 [0.9401653750395793, 1.0739346737007793] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.031 [0.8784216914403705, 1.2063766506900413] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.957 [0.8907137921115571, 1.0795760021419938] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.874 [0.7928242734981727, 1.0098429609000699] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.047 [0.909418531007928, 1.1607933007678473] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.975 [0.8659749891109173, 1.14828076240959] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.978 [0.8280522015381937, 1.232710693247809] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.016 [0.9736018488530596, 1.5017765391284343] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.997 [0.871174107349575, 1.1515992474753298] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.046 [0.9920610900275076, 1.147258942942602] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.977 [0.9336536243407159, 1.1953822937055623] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.012 [0.8332981054593744, 1.074075072033796] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.007 [0.9794248465147171, 1.1127204943564537] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.038 [0.6451616158451688, 1.3159559543163653] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.080 [0.7761781692272081, 1.1402118140770543] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.993 [0.9520839506863138, 1.1643284775749176] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.966 [0.912637401753211, 1.137840367748925] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.956 [0.6431304824497974, 1.2372447094120926] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.023 [0.935262089940517, 1.3429650800291841] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.060 [0.9319426475802312, 1.3744961754222382] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.978 [0.9464055366850505, 1.2562504891947996] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.986 [0.8918851558485857, 1.1210495296203051] | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.050 [0.9994548239196934, 1.1415440637714016] | inconclusive-noisy |
| full | paired | `file_statements_20000` | 1.097 [0.7811964919678719, 1.2871421950655613] | inconclusive-noisy |
