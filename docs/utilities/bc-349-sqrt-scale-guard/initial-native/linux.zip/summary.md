# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.991 [0.769443091505372, 1.0305402024054742] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.000 [0.9897528424656246, 1.0301439210859995] | pass |
| full | aa | `calls_200000` | 1.000 [0.9896621458819165, 1.012524010549774] | pass |
| full | aa | `array_200000` | 1.006 [1.003312324576227, 1.00797548511502] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.993 [0.9844051502558592, 1.005126093998562] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.983 [0.9585767444536201, 1.012339578520716] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.962 [0.8728946606691961, 1.0238529595948835] | pass |
| full | aa | `fibonacci_1000_x100` | 0.995 [0.9902796241370969, 1.0093888902037016] | pass |
| full | aa | `factorial_1000_x50` | 0.998 [0.9879138607116318, 1.0033149196100983] | pass |
| full | aa | `multiply_100d_x100000` | 1.005 [0.9882488153261302, 1.0064109350720425] | pass |
| full | aa | `multiply_10000d_x1000` | 1.005 [0.9920425482409235, 1.0257216110469587] | pass |
| full | aa | `divide_scale100_x100000` | 1.000 [0.9944585564087806, 1.0110228032368012] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.998 [0.9896205366212044, 1.0141084619368619] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.994 [0.8957174813858335, 1.0095711016205648] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.005 [0.9774674796511625, 1.010114441731707] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.995 [0.9868999275754073, 1.0016483805995129] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.996 [0.9492577518768172, 1.0181017501362666] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.988167907442421, 1.0036585864405045] | pass |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9758474514517566, 1.0274477275765486] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.017 [0.9841610950100931, 1.0458402802301732] | pass |
| full | aa | `recursion_50_x1000` | 1.008 [0.9984367655291394, 1.0188523838392765] | pass |
| full | aa | `sparse_array_200000` | 0.999 [0.9823435493224332, 1.016732047364058] | pass |
| full | aa | `frontend_definitions_2000` | 1.000 [0.9771382689426557, 1.0086850051389555] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.005 [0.9213224611212998, 1.0290618985890536] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.990 [0.9617445605509662, 1.0870619277924167] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.993 [0.9745739974737071, 0.998145878274728] | pass |
| full | aa | `square_100d_x100000` | 1.012 [1.0054991228268106, 1.0204852078223656] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9914265977110711, 1.0091200359323937] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.971 [0.924621492765753, 1.028189724805777] | pass |
| full | aa | `binary_output_1000d_x300` | 1.007 [0.9919521419369025, 1.030345220495422] | pass |
| full | aa | `octal_output_1000d_x300` | 0.998 [0.9879291807817573, 1.005375978246933] | pass |
| full | aa | `binary_input_100000d_x3` | 1.006 [0.9793050350535686, 1.0313658056137078] | pass |
| full | aa | `hex_input_100000d_x3` | 1.004 [0.9847637389065357, 1.0132906151132735] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.997 [0.9751647255644122, 1.0038705571971058] | pass |
| full | aa | `file_statements_20000` | 1.004 [0.9928839211694734, 1.0116332947132727] | pass |
| full | paired | `startup` | 0.945 [0.8487931534054642, 1.163226163716542] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.004 [0.9932010272037376, 1.0160109646380078] | pass |
| full | paired | `calls_200000` | 0.995 [0.9809521891658503, 1.003129728626257] | pass |
| full | paired | `array_200000` | 0.996 [0.9491091691271316, 1.0000113493152194] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.006 [0.9836594266021347, 1.0221018257489167] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.060 [1.052356421013805, 1.0985625086124569] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.039 [0.9311821075732166, 1.0888227407023645] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.996 [0.9788034305637952, 1.001836115117908] | pass |
| full | paired | `factorial_1000_x50` | 0.992 [0.9862618104472617, 1.0005595090283632] | pass |
| full | paired | `multiply_100d_x100000` | 1.002 [0.9961671627929101, 1.0096376625956192] | pass |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9906165829166507, 1.105784026738519] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.990 [0.9649169163483586, 1.0121875341561997] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.997 [0.9951865091185603, 1.0091983779921132] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.001 [0.8304474864404178, 1.0519879482579624] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.993 [0.9897903447441406, 1.0229198457842374] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.982 [0.9652006020370197, 1.0874300409221316] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.9870715246870863, 1.0252069059941815] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.000 [0.9742650514151784, 1.0264074333609818] | pass |
| full | paired | `power_100d_e17_x1000` | 0.996 [0.9728266302074311, 1.0068185904471056] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.966 [0.9391272418097775, 1.0245638770458292] | pass |
| full | paired | `recursion_50_x1000` | 1.014 [1.0070805563432834, 1.209137953028416] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.014 [0.9905123212151036, 1.022164452479927] | pass |
| full | paired | `frontend_definitions_2000` | 0.996 [0.9874251859825792, 1.0052834581565997] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.040 [0.9872826633397831, 1.0752993345879338] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.987 [0.9328938611129005, 1.0429616686719145] | pass |
| full | paired | `streaming_statements_20000` | 0.996 [0.9829222446570713, 1.0004618179533777] | pass |
| full | paired | `square_100d_x100000` | 1.003 [0.9852288797616385, 1.0107074311216842] | pass |
| full | paired | `square_10000d_x500` | 1.000 [0.9938867717073246, 1.0094116957911143] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.078 [0.962433304565268, 1.1469874446042556] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.003 [0.9839712100331194, 1.0057549859342103] | pass |
| full | paired | `octal_output_1000d_x300` | 0.986 [0.9247364781105201, 1.004840084536161] | pass |
| full | paired | `binary_input_100000d_x3` | 1.018 [0.997094546511121, 1.0356256253762792] | pass |
| full | paired | `hex_input_100000d_x3` | 0.994 [0.9880472164361227, 1.0160876133479941] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.000 [0.9802893674942342, 1.0083347686565445] | pass |
| full | paired | `file_statements_20000` | 0.988 [0.9874350882100298, 0.9954731457480955] | pass |
