# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.921 [0.9031626131048834, 1.0751644999418952] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.998 [0.9920781003585754, 1.0029342688877476] | pass |
| full | aa | `calls_200000` | 0.991 [0.9825787454729042, 1.0042870936913038] | pass |
| full | aa | `array_200000` | 0.997 [0.993054211592615, 1.0072573590214935] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.011 [0.9862866236073425, 1.2365710147082327] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.002 [0.9769273049798004, 1.0255632312348568] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.001 [0.9976273572708245, 1.014785322284959] | pass |
| full | aa | `fibonacci_1000_x100` | 1.012 [1.0015972199488672, 1.020514071199061] | pass |
| full | aa | `factorial_1000_x50` | 1.022 [1.0016771399450364, 1.0303347649826986] | pass |
| full | aa | `multiply_100d_x100000` | 0.953 [0.9356926993854081, 0.9733612304943184] | pass |
| full | aa | `multiply_10000d_x1000` | 0.997 [0.9832285367373527, 1.006242727228077] | pass |
| full | aa | `divide_scale100_x100000` | 0.949 [0.9294625683562324, 1.025968502082652] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.996 [0.9844086719464318, 1.0013614433288198] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.996 [0.9874184933225392, 0.9998969596338587] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.994 [0.9697136874200293, 1.021578411524163] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.9885857321654636, 1.0459984586056308] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.998 [0.9655098517067748, 1.0155062500013325] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.006 [0.9914568884848237, 1.0343007739833738] | pass |
| full | aa | `power_100d_e17_x1000` | 1.001 [0.9832599417961421, 1.0147597376242994] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.994 [0.9923766284368638, 1.0343546460999469] | pass |
| full | aa | `recursion_50_x1000` | 1.004 [0.9827459214995458, 1.0138127737600608] | pass |
| full | aa | `sparse_array_200000` | 1.002 [0.9865601459601117, 1.03178870437552] | pass |
| full | aa | `frontend_definitions_2000` | 1.000 [0.9397157973916517, 1.0570789922599033] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.991 [0.9667282809595495, 0.9967066508670448] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.951 [0.8998316726786099, 1.043815522211335] | pass |
| full | aa | `streaming_statements_20000` | 0.992 [0.9853607414200163, 1.0525735394223323] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.951 [0.9464987370802637, 1.0032796162214548] | pass |
| full | aa | `square_10000d_x500` | 0.999 [0.9960722569526674, 1.0080406591698683] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.962 [0.9051559870348854, 1.0209436133481649] | pass |
| full | aa | `binary_output_1000d_x300` | 1.000 [0.9796544088425806, 1.0150979464198406] | pass |
| full | aa | `octal_output_1000d_x300` | 1.007 [0.9468647565677859, 1.036277066095754] | pass |
| full | aa | `binary_input_100000d_x3` | 0.990 [0.980998880023419, 0.9959567560783961] | pass |
| full | aa | `hex_input_100000d_x3` | 1.001 [0.9843690833891586, 1.0082766923947544] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.999 [0.9928263016615966, 1.0051647790739031] | pass |
| full | aa | `file_statements_20000` | 1.006 [0.980817107193567, 1.0716050402147304] | inconclusive-noisy |
| full | paired | `startup` | 0.936 [0.8820068939140192, 1.071669235465467] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.998 [0.9856619543200599, 1.0074108356690326] | pass |
| full | paired | `calls_200000` | 1.001 [0.976898625354083, 1.0300850970182927] | pass |
| full | paired | `array_200000` | 1.010 [0.9470121993016742, 1.0350493850208546] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.993 [0.9804574921047006, 1.0159408939003347] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.058 [0.9969999177776355, 1.067958676583443] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.063 [1.0528485606637707, 1.0765964156417145] | confirmed regression |
| full | paired | `fibonacci_1000_x100` | 1.011 [0.979844642842626, 1.0187731022883593] | pass |
| full | paired | `factorial_1000_x50` | 0.999 [0.9830444817450962, 1.0695543514700767] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.948 [0.8902397931126215, 0.9666049969733562] | pass |
| full | paired | `multiply_10000d_x1000` | 1.000 [0.9831000710214929, 1.0107886141984133] | pass |
| full | paired | `divide_scale100_x100000` | 0.944 [0.8512543024424785, 0.9561348142032287] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.996 [0.9773929160366442, 1.000961360878627] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.998 [0.9895316960025571, 1.0187488148262194] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9952381090561208, 1.0045120850008662] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.006 [0.999260707451179, 1.0159446627996147] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.998 [0.9741603463665587, 1.0565487674176384] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.997 [0.9929234149376548, 1.0032420709734038] | pass |
| full | paired | `power_100d_e17_x1000` | 0.997 [0.9821932399369812, 1.000171809066171] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.013 [0.9879813972905502, 1.0263375896266718] | pass |
| full | paired | `recursion_50_x1000` | 0.996 [0.980777177942653, 1.0097200869494825] | pass |
| full | paired | `sparse_array_200000` | 0.995 [0.9578770076504844, 1.0743372955663353] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.005 [0.9798367672764488, 1.0470666064845573] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.004 [0.8795173158561056, 1.0221088068365605] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.994 [0.9846856668241352, 1.0477453580860732] | pass |
| full | paired | `streaming_statements_20000` | 0.991 [0.9617664688692138, 1.0115775261123239] | pass |
| full | paired | `square_100d_x100000` | 0.959 [0.9090606095120985, 0.9813822003108914] | pass |
| full | paired | `square_10000d_x500` | 1.002 [0.998348686369764, 1.0055921159100376] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.029 [0.9690484826550542, 1.1187051954658758] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.002 [0.9820584040247351, 1.0226853133973455] | pass |
| full | paired | `octal_output_1000d_x300` | 0.998 [0.9693078766894297, 1.0170203961043034] | pass |
| full | paired | `binary_input_100000d_x3` | 1.005 [0.9857735063686797, 1.027864055656946] | pass |
| full | paired | `hex_input_100000d_x3` | 0.998 [0.9650505631371025, 1.0059672896809984] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.999 [0.9976828146649633, 1.0082423871422272] | pass |
| full | paired | `file_statements_20000` | 1.005 [0.9880121523941103, 1.0286353868669034] | pass |
