# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.978 [0.9511071355676206, 1.0514489524220383] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.992 [0.9704813479740376, 1.0039385035518364] | pass | - |
| full | aa | `calls_200000` | 1.000 [0.9897371717557274, 1.0140024961716365] | pass | - |
| full | aa | `array_200000` | 1.005 [0.9596219132293696, 1.0143174021443018] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 0.993 [0.9864442718535804, 1.0129713715581417] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.001 [0.9959369622911425, 1.0405888155129657] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 1.002 [0.8688206763335389, 1.0161932163980323] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 1.008 [0.9777323819165518, 1.0206043930970676] | pass | - |
| full | aa | `factorial_1000_x50` | 0.992 [0.978589535011568, 1.0005393869071273] | pass | - |
| full | aa | `multiply_100d_x100000` | 0.999 [0.9914265110898824, 1.0156545804231947] | pass | - |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.99658806040262, 1.0038773434169932] | pass | - |
| full | aa | `divide_scale100_x100000` | 1.001 [0.9854475274327579, 1.0150186777817798] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.001 [0.9953404957759698, 1.0018542603909] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.000 [0.9984329815041133, 1.000675611771028] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.003 [0.9973797459195668, 1.0088238549131225] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.003 [0.9912583573031577, 1.0151635959466325] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9959456445826126, 1.0029596736394495] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.004 [0.9881987103687254, 1.0073592649016623] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.002 [0.9982545302778567, 1.0023003605486516] | pass | - |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9850815874231322, 1.0046289390021237] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.008 [0.9482713197156863, 1.0327551038302327] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 0.998 [0.9865183222251288, 1.009897953256955] | pass | - |
| full | aa | `sparse_array_200000` | 0.998 [0.9606830593490318, 1.0131634779980674] | pass | - |
| full | aa | `frontend_definitions_2000` | 0.996 [0.9850921842526993, 1.0095509900453874] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.006 [0.995689742284398, 1.030179209096506] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 0.986 [0.9626909016795225, 1.0910650475635073] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.999 [0.9861903199668429, 1.0177381475593825] | pass | - |
| full | aa | `square_100d_x100000` | 0.997 [0.9789998824895825, 1.0383673219924487] | pass | - |
| full | aa | `square_10000d_x500` | 1.001 [0.9998406071150614, 1.0012890399581766] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.999 [0.9066155031090197, 1.0411612910842698] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.005 [0.9982932693444198, 1.0218801951082443] | pass | - |
| full | aa | `octal_output_1000d_x300` | 0.997 [0.9859860582828807, 1.0170481774791407] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.001 [0.9873191793186731, 1.0155899346137007] | pass | - |
| full | aa | `hex_input_100000d_x3` | 0.990 [0.9732089867524095, 0.9986356740797665] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.001 [0.9964091339441637, 1.0068992559414447] | pass | - |
| full | aa | `file_statements_20000` | 0.999 [0.9840550992288638, 1.0157420028522113] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.000 [0.9983701737557956, 1.0004924223353502] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.006 [0.9951240885937942, 1.0259024627054305] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 0.995 [0.9772214805285256, 1.020950401983769] | pass | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.999 [0.9933595893880293, 1.0016100445339544] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.995 [0.9847869264053511, 1.0035670626343753] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.003 [0.9858651554732862, 1.0102586673118361] | pass | - |
| full | paired | `startup` | 0.990 [0.9755648123884095, 1.0753060669249839] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.002 [0.9895341654761676, 1.0152809000512817] | pass | pass |
| full | paired | `calls_200000` | 0.999 [0.9659239548497343, 1.0333481026118554] | pass | pass |
| full | paired | `array_200000` | 1.006 [0.9899766707301372, 1.0204612155646038] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 1.002 [0.9828005369198916, 1.0068853173259522] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 0.999 [0.9948020101250143, 1.0116705360311264] | pass | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.000 [0.9884183375984021, 1.0130861838066028] | pass | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.000 [0.972287366769161, 1.0203841279212937] | pass | pass |
| full | paired | `factorial_1000_x50` | 0.996 [0.9864165973259238, 1.0008001894825305] | pass | pass |
| full | paired | `multiply_100d_x100000` | 0.989 [0.9774748250405868, 1.0013608135243894] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9964146421714539, 1.0116796829213506] | pass | pass |
| full | paired | `divide_scale100_x100000` | 1.000 [0.9732356902007633, 1.0162974137149898] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 1.005 [0.9970571499890819, 1.028405433360143] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 1.000 [0.9973115761391903, 1.000648969525663] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.001 [0.9987693605074454, 1.0031545393397991] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.993 [0.9773481280268423, 1.019523697951669] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.999 [0.9945223400946573, 1.002004205568684] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.996 [0.9868868655063703, 1.008480599935054] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.998 [0.994310773022807, 1.0004650506921322] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.995 [0.9839961467906034, 1.016592710146188] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 0.993 [0.9804408668493165, 1.0149058352131963] | pass | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.002 [0.9930632339156266, 1.0149630965612904] | pass | pass |
| full | paired | `sparse_array_200000` | 1.000 [0.9857264124810474, 1.019302407973882] | pass | pass |
| full | paired | `frontend_definitions_2000` | 0.999 [0.9916726534559394, 1.022426765809818] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 1.007 [0.9545085172229766, 1.0154808708056349] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 1.048 [0.9871128576489814, 1.0795016258513457] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.996 [0.980021778762345, 1.0095025385392147] | pass | pass |
| full | paired | `square_100d_x100000` | 0.997 [0.9884743309186451, 1.007256139861648] | pass | pass |
| full | paired | `square_10000d_x500` | 1.000 [0.9998748624751332, 1.0022658738402952] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.005 [0.9634348085892662, 1.0248208410953135] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.008 [0.9991083250457675, 1.0778972169927483] | inconclusive-noisy | pass |
| full | paired | `octal_output_1000d_x300` | 1.000 [0.9950758409131677, 1.0109606956466721] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.991 [0.9826267522531557, 1.0047634274344888] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 1.005 [1.0007213266568078, 1.0216834869455864] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.997 [0.9922442868533332, 1.0070721140770411] | pass | pass |
| full | paired | `file_statements_20000` | 1.002 [0.9633399372772865, 1.016826440945526] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.000 [0.9993960767699939, 1.0003817922210643] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.959 [0.9306845352617941, 0.9955279412635747] | pass | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.992 [0.9140435292225657, 1.0704577343650599] | inconclusive-noisy | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.999 [0.9984124371221563, 1.0030001095502157] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.997 [0.9800563857892258, 1.0332155345204024] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.984 [0.945825685270683, 0.9924526292310814] | pass | pass |
