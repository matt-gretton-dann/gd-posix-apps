# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.933 [0.6610766094625983, 1.078441419532414] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.907 [0.766063942860575, 1.0328042382154912] | inconclusive-noisy | - |
| full | aa | `calls_200000` | 1.114 [0.9619361509200902, 1.2142702486725685] | inconclusive-noisy | - |
| full | aa | `array_200000` | 0.923 [0.8649641657702454, 1.123275194280145] | inconclusive-noisy | - |
| full | aa | `compare_high_1000d_x100000` | 1.191 [0.9139294383892156, 1.4527839611154216] | inconclusive-noisy | - |
| full | aa | `compare_low_1000d_x100000` | 1.005 [0.9148369200947325, 1.300028965884462] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.107 [0.8713677630472194, 1.2011115970231208] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 0.945 [0.9080468650551917, 1.1491932681628438] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 0.984 [0.8911529690080175, 1.134166242689719] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 0.841 [0.7601143613149204, 1.066104238076458] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 1.020 [0.945668859438543, 1.1146155452234179] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 1.019 [0.6516519501396401, 1.0876294068341599] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 0.980 [0.8635022164298336, 1.2152838368305685] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 0.979 [0.8710609470541085, 1.102939386899875] | inconclusive-noisy | - |
| full | aa | `multiply_dense_10000d_x500` | 1.021 [0.9246747296398768, 1.0878688290199219] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.965 [0.9365023819445386, 1.038746274075359] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.958 [0.908236637157558, 1.0482334795563555] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.046 [0.8759687376241988, 1.1107616638411282] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.138 [1.0053302390820242, 1.1981124567150465] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 1.054 [0.7901544976850613, 1.3748087867397292] | inconclusive-noisy | - |
| full | aa | `ibase_literal_flip_20000` | 1.050 [0.966223475884121, 1.1344292865155734] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 1.021 [0.7743016350697228, 1.1367937676962692] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 0.981 [0.8723837835547911, 1.1310666355144776] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 1.057 [0.817343038816386, 1.1788593866380328] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 1.039 [0.7415483132397751, 1.8179417398032047] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 0.955 [0.6926061965461268, 1.1249286219116663] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.927 [0.865515553802889, 1.1715801020529786] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 0.896 [0.7864267869764596, 1.0931081222856736] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 0.963 [0.9558986801754205, 1.0322338523630024] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.974 [0.8245817390604858, 1.086233378890506] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.078 [0.9812865587708164, 1.1347907255674008] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 1.007 [0.8139616137136688, 1.199558200800838] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 0.920 [0.876499285320446, 1.157284751190037] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 1.028 [0.9105500647549126, 1.0401699377207438] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.978 [0.8215763370158189, 1.1877908761967457] | inconclusive-noisy | - |
| full | aa | `file_statements_20000` | 1.084 [0.9712309084177523, 1.2501060731285263] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.010 [0.8923347252241585, 1.0304997790296302] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 0.905 [0.821095448075076, 1.006379684978843] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 0.946 [0.7852400174815187, 1.045851125483259] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.985 [0.9213719444922863, 1.041168858890724] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.171 [0.8253462931226946, 1.3304949831378943] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.930 [0.812413805374489, 1.3434500460670704] | inconclusive-noisy | - |
| full | paired | `startup` | 1.059 [1.0381900174790804, 1.2072671315775305] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.946 [0.9060032620668861, 1.15475073448049] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `calls_200000` | 1.064 [0.8744398378907147, 1.4454184291505456] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `array_200000` | 0.951 [0.8675378484430296, 1.2298340135504273] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.879 [0.7940438130386757, 1.2542875814729404] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.979 [0.761321655684445, 1.1752190812912675] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.032 [0.8367119647098298, 1.0921917979501126] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.039 [0.9079111572191406, 1.1859952636598012] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.963 [0.8581320370018423, 1.1992974808605925] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.945 [0.8071579332732992, 1.1392677813263044] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.060 [0.9451305869164894, 1.1638871878048418] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.084 [0.9335992642501498, 1.3275216595311972] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.081 [0.9417419549669852, 1.2551193776262373] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 0.980 [0.8977577852424883, 1.067569989427115] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.899 [0.8591514233591977, 1.0829173235012588] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.935 [0.8031361733912631, 0.9877792970419406] | pass | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.949 [0.8521255802590404, 1.1887490008383739] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.042 [0.9664661503684406, 1.266661064855496] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.032 [0.9258574540206865, 1.104662891294602] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.982 [0.6985347840829397, 1.0263733640772692] | pass | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.041 [0.8756399456568509, 1.304978528705019] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.044 [0.8116393833471249, 1.3384639046848628] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.108 [1.0334003803904437, 1.2255136606082557] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.994 [0.7980138437503091, 1.483402332209482] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.966 [0.8160939637601988, 1.137832009968515] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.943 [0.7009293667874554, 1.1127738510951297] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.950 [0.9183783777382127, 1.0731825494770788] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.979 [0.9492078992246911, 1.1460665809000994] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.003 [0.9695813703201376, 1.0937956811919116] | inconclusive-noisy | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.971 [0.7583876143763719, 1.1027748253797363] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.891 [0.7045889282646236, 1.1781484983039376] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.989 [0.8636354189926063, 1.1998778524279232] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.197 [0.9079309353155876, 1.2585375507549328] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.892 [0.8276196925327397, 1.0467885767208671] | pass | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.052 [0.8671816624291547, 1.2195478710224623] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `file_statements_20000` | 1.020 [0.8664532125477141, 1.180974193913668] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 1.033 [1.007445215669721, 1.059280454414822] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.978 [0.910967387305456, 1.2010584498094001] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.901 [0.73329997456778, 1.1480520589969325] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.954 [0.8113107921686338, 1.0160033783494389] | pass | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.922 [0.6959093643469845, 1.0726918148331503] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.034 [0.8228207622140559, 1.7067119262426393] | inconclusive-noisy | inconclusive-noisy |
