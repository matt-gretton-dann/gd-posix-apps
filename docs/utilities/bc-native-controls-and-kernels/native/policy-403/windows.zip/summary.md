# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.002 [0.9410757912490023, 1.078366664134745] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.976 [0.9631438885935919, 0.9869848881677736] | pass | - |
| full | aa | `calls_200000` | 0.996 [0.9875384178232116, 1.0453590190592077] | pass | - |
| full | aa | `array_200000` | 0.989 [0.9575580469490479, 1.015227501037081] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 0.990 [0.969287927416746, 0.997855507136142] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 0.990 [0.9732440004363262, 0.9971633470499268] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 0.983 [0.9720174437479109, 0.9960474488285486] | pass | - |
| full | aa | `fibonacci_1000_x100` | 0.982 [0.9167562895942628, 1.0136788370043488] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 0.991 [0.9833497682670608, 1.0419803753530936] | pass | - |
| full | aa | `multiply_100d_x100000` | 0.987 [0.9659824563089769, 0.9998962705719194] | pass | - |
| full | aa | `multiply_10000d_x1000` | 0.997 [0.9936745291358525, 1.0097812070191603] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.985 [0.9696016390255209, 0.9982862955576628] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 0.996 [0.9807925919901166, 1.0040855721710782] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.002 [0.9899274565263655, 1.010006047039115] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 0.997 [0.9891750070106882, 1.0042924702021996] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9879695089693925, 1.0234571022897925] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9943159959348536, 1.0176022108504543] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.006 [0.9922791451612946, 1.0313676994284942] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.002 [0.9828843176046632, 1.0226122411169793] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.997 [0.9671674884227375, 1.0020881868279665] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 0.993 [0.9846640145130232, 1.1942256449278996] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 0.998 [0.9818490690258611, 1.0075921335797653] | pass | - |
| full | aa | `sparse_array_200000` | 0.986 [0.981383459508504, 1.023841948659317] | pass | - |
| full | aa | `frontend_definitions_2000` | 0.996 [0.94806073766055, 1.0591917219407108] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 1.004 [0.9999783923917208, 1.0104222539089933] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.016 [0.9549409336111243, 1.0225536193005593] | pass | - |
| full | aa | `streaming_statements_20000` | 1.011 [1.0016520899722474, 1.0548166229187128] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 0.991 [0.9890206678929504, 1.0023628998023129] | pass | - |
| full | aa | `square_10000d_x500` | 0.997 [0.9938570392191816, 1.0072328029808744] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.983 [0.9277105641280905, 1.058391484480395] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.998 [0.884335310767964, 1.0156535775912574] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 0.993 [0.9852802809305188, 1.0115080939804697] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.005 [0.9885359547687405, 1.0242388792181338] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.002 [0.9487955538355853, 1.069463915718113] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.978 [0.9706181675268599, 0.9935419737248816] | pass | - |
| full | aa | `file_statements_20000` | 0.998 [0.916424777136386, 1.1689484309043565] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.000 [0.9988192674001658, 1.0026173059215198] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.016 [0.9710115201853518, 1.0395317528312866] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 0.994 [0.9737393651945017, 1.0198345592820912] | pass | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.003 [0.9818236064505211, 1.0166451374798462] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.984 [0.9576878878475311, 1.022474588931093] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.004 [0.9570857679116177, 1.0244566094247085] | pass | - |
| full | paired | `startup` | 1.010 [0.9217256095567282, 1.1028736246076125] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.990 [0.9796796539797616, 1.0039131275171889] | pass | pass |
| full | paired | `calls_200000` | 0.991 [0.9772739889203595, 0.9996022228233737] | pass | pass |
| full | paired | `array_200000` | 0.988 [0.9777382772828653, 1.0089414557084415] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 0.983 [0.9716996499105423, 1.035945794631821] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 0.980 [0.9329169445856431, 0.9977430510337001] | pass | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.994 [0.9765459924984614, 1.0181271063686355] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 0.968 [0.9452810730480353, 0.9712355062785979] | pass | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.005 [0.9835724856835407, 1.013876967095014] | pass | pass |
| full | paired | `multiply_100d_x100000` | 0.997 [0.9812902245673158, 1.173326799856852] | inconclusive-noisy | pass |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9863182355371535, 1.0046660825603635] | pass | pass |
| full | paired | `divide_scale100_x100000` | 0.975 [0.857231292230938, 0.9949253168454182] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 1.004 [0.9941630002143794, 1.0224965201305145] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 1.002 [0.9909077020269305, 1.0056608203889406] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.010 [0.9979033060652285, 1.0258620629235071] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9711810195896735, 1.0151263485115218] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.001 [0.9740875052076197, 1.0015166239883828] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.991 [0.9567286172116081, 1.0056007592116623] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.004 [0.993270783520463, 1.0279750899233744] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 1.003 [0.9912727322178597, 1.0167525102762844] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 0.974 [0.8358967954789402, 0.9965703600293854] | pass | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.972 [0.9530314357845565, 0.98517509035804] | pass | pass |
| full | paired | `sparse_array_200000` | 0.968 [0.955531088662356, 1.0069215551510715] | pass | pass |
| full | paired | `frontend_definitions_2000` | 1.012 [0.9962404941350292, 1.0535198168738549] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.993 [0.8884899810494105, 1.0233457968881081] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 0.999 [0.9425063246233157, 1.0427143919215436] | pass | pass |
| full | paired | `streaming_statements_20000` | 0.984 [0.9647142907369345, 1.0182760335334966] | pass | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.988 [0.9826486323629879, 1.0035166432543723] | pass | pass |
| full | paired | `square_10000d_x500` | 0.998 [0.9939023851889802, 1.0123317151233389] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.961 [0.9270858794591503, 1.04788466489191] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.993 [0.9856441862720803, 1.0759220826510085] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.998 [0.9373143633707651, 1.0237766405252047] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 1.005 [0.9936822689773092, 1.0186932693946547] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.993 [0.9480331419199243, 1.009825178320217] | pass | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.002 [0.991538213948723, 1.0436618090795993] | pass | pass |
| full | paired | `file_statements_20000` | 1.061 [0.9662784844690061, 1.0957236898674803] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 1.000 [0.996711399160339, 1.0020896798791536] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.981 [0.9213094889344466, 1.0061846933924106] | pass | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.041 [0.9794559113341621, 1.083617961200261] | inconclusive-noisy | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.007 [0.9728377863801082, 1.0095809372774471] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.009 [0.9956749145036025, 1.0302553749176095] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.984 [0.9432684407846483, 0.9960803257246067] | pass | pass |
