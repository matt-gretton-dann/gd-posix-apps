# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.982 [0.9385792198430868, 1.1105931507654814] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.997 [0.9564481580438452, 1.0106352664050933] | pass | - |
| full | aa | `calls_200000` | 0.988 [0.9767439929709765, 1.029176373527191] | pass | - |
| full | aa | `array_200000` | 1.008 [0.9809267548752774, 1.0169127443183694] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 0.998 [0.9879955575909634, 1.0171294664814419] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.000 [0.9742203408654679, 1.018021046322027] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 1.002 [0.9859100048341959, 1.0108986821298662] | pass | - |
| full | aa | `fibonacci_1000_x100` | 0.985 [0.9479112669720102, 0.9899994617211944] | inconclusive-noisy | - |
| full | aa | `fibonacci_10000_x10` | 0.993 [0.9716249288070696, 1.0023135549771156] | pass | - |
| full | aa | `factorial_1000_x50` | 1.004 [0.9919375373167811, 1.0071226639342048] | pass | - |
| full | aa | `factorial_5000_x5` | 1.004 [1.001246600562238, 1.006428107332843] | pass | - |
| full | aa | `multiply_100d_x100000` | 1.006 [0.9795888436490132, 1.0126742543419307] | pass | - |
| full | aa | `multiply_1000d_x10000` | 0.996 [0.9938317274575353, 1.0057669613478921] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9973082135352864, 1.100116213283008] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 0.995 [0.9865967885792646, 1.0138136405250893] | pass | - |
| full | aa | `divide_scale1000_x10000` | 1.000 [0.9919360288995069, 1.0016570980793242] | pass | - |
| full | aa | `divide_scale5000_x5000` | 1.002 [0.9980485400033214, 1.0053279603565233] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.002 [1.0006552515990468, 1.0188822638856077] | pass | - |
| full | aa | `sqrt_scale1000_x50` | 1.002 [0.9977281501689469, 1.0027484318874744] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.000 [0.9988649493345398, 1.0005707224630638] | pass | - |
| full | aa | `multiply_dense_1000d_x5000` | 0.997 [0.9895288100323416, 1.0048371805733778] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9320911439791966, 1.0117984104663633] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9825812496622037, 1.0157176606870861] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9986667853892631, 1.0035506094913822] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.006 [0.9743035399842913, 1.0089685965358208] | pass | - |
| full | aa | `divide_multilimb_1000d_900d_s1000_x500` | 1.001 [0.9943672179493561, 1.0094477780116127] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9768173309286444, 1.03416375724452] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.997 [0.9930487616530073, 1.0041353479007014] | pass | - |
| full | aa | `power_20d_e32_x2000` | 1.001 [0.995341156431676, 1.0042292798811623] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 0.984 [0.9646758667085147, 1.0129703281458378] | pass | - |
| full | aa | `recursion_50_x1000` | 1.006 [0.9801616076035425, 1.0171472156583847] | pass | - |
| full | aa | `sparse_array_200000` | 1.005 [0.9933329451385609, 1.0112665107338072] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.000 [0.980427495744838, 1.0102199013774287] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.016 [1.0032579169668625, 1.031102387671456] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.024 [0.9538007646066414, 1.1305859548673542] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.003 [0.9858737852596614, 1.0080955902385291] | pass | - |
| full | aa | `square_100d_x100000` | 0.998 [0.9890463400000735, 1.0287139579190074] | pass | - |
| full | aa | `square_1000d_x10000` | 1.000 [0.9996599936002863, 1.0017745044351494] | pass | - |
| full | aa | `square_10000d_x500` | 1.001 [0.9998695043486392, 1.0013145778077883] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.992 [0.9607706179658745, 1.0532851740844127] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.001 [0.9922971507644188, 1.0095049828646545] | pass | - |
| full | aa | `octal_output_1000d_x300` | 1.002 [0.9987093730115864, 1.0085965727019282] | pass | - |
| full | aa | `binary_input_100000d_x3` | 0.991 [0.983913268392606, 1.0055840660860895] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.000 [0.9934829990165042, 1.0072071550848438] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.009 [0.9958555218758127, 1.024445595162288] | pass | - |
| full | aa | `file_statements_20000` | 1.003 [0.9982506214278519, 1.0094302916873368] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.000 [0.9994182229959766, 1.0011482967848035] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 0.996 [0.9891288503499613, 1.0142683373052077] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.000 [0.934488565187501, 1.0241786569041846] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.001 [0.9985977188396524, 1.0075406069135004] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.008 [0.9929561551242703, 1.0372569070721176] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t500_x5000` | 1.001 [1.0002422840102483, 1.0035894954585194] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t2000_x5000` | 1.002 [0.9921899012212655, 1.0200244068462356] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.002 [0.9780375252529071, 1.0110699570107669] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t500_x5000` | 1.001 [0.9974743960923551, 1.0050863007087654] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t2000_x5000` | 0.997 [0.9679467511403055, 1.0087164905327966] | pass | - |
| full | paired | `startup` | 1.004 [0.9422683294968645, 1.040088835338527] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.136 [1.1036636376167088, 1.154148390949862] | confirmed regression | pass |
| full | paired | `calls_200000` | 1.180 [1.1085225847939502, 1.188576561745416] | confirmed regression | pass |
| full | paired | `array_200000` | 1.079 [1.072828749346205, 1.1168149536818606] | confirmed regression | pass |
| full | paired | `compare_high_1000d_x100000` | 1.134 [1.0996942282459012, 1.1463061955785274] | confirmed regression | pass |
| full | paired | `compare_low_1000d_x100000` | 1.093 [1.0825812979001606, 1.1203906203390488] | confirmed regression | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.100 [1.0932981535732111, 1.1249820833285233] | confirmed regression | pass |
| full | paired | `fibonacci_1000_x100` | 1.105 [1.0944858859119446, 1.108439493908731] | confirmed regression | inconclusive-noisy |
| full | paired | `fibonacci_10000_x10` | 1.056 [1.0499595592459878, 1.0656181739057324] | inconclusive-noisy | pass |
| full | paired | `factorial_1000_x50` | 1.030 [1.0279276599196376, 1.044842051231155] | pass | pass |
| full | paired | `factorial_5000_x5` | 1.008 [1.0025979455210874, 1.0146822786548337] | pass | pass |
| full | paired | `multiply_100d_x100000` | 1.045 [1.0382787247386724, 1.0669865979398265] | inconclusive-noisy | pass |
| full | paired | `multiply_1000d_x10000` | 0.999 [0.9956783095713586, 1.0025264860665544] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 0.999 [0.9937339810314902, 1.0022323208333386] | pass | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.031 [1.020545687956449, 1.0554818498835268] | inconclusive-noisy | pass |
| full | paired | `divide_scale1000_x10000` | 1.009 [0.9902252146974401, 1.0190272283833086] | pass | pass |
| full | paired | `divide_scale5000_x5000` | 1.010 [1.0011574407798116, 1.0194346949114657] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 1.006 [1.0032234753470959, 1.0120991462293496] | pass | pass |
| full | paired | `sqrt_scale1000_x50` | 1.027 [1.0254675503815935, 1.0382271959639469] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 1.015 [1.0143222946450836, 1.0196381197346476] | pass | pass |
| full | paired | `multiply_dense_1000d_x5000` | 0.996 [0.9862176479353336, 1.0039587367754648] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.996 [0.993488238457851, 1.0028778767032978] | pass | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.988 [0.9859335956614568, 1.0114023668315635] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.999 [0.9923354911659344, 1.0047403490779407] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.011 [1.0079188409997508, 1.0202911953574245] | pass | pass |
| full | paired | `divide_multilimb_1000d_900d_s1000_x500` | 1.018 [1.0071157532850006, 1.0304042696973674] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.010 [1.005263077821742, 1.0118196729714826] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.999 [0.9969035679169815, 1.0093263001163393] | pass | pass |
| full | paired | `power_20d_e32_x2000` | 1.011 [0.9634005728360052, 1.0270790148720994] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 1.063 [1.0420773187553953, 1.1379951223845381] | inconclusive-noisy | pass |
| full | paired | `recursion_50_x1000` | 1.056 [1.0237299210649058, 1.0850244874956003] | inconclusive-noisy | pass |
| full | paired | `sparse_array_200000` | 1.089 [1.0536997467524614, 1.0969175496482364] | inconclusive-noisy | pass |
| full | paired | `frontend_definitions_2000` | 1.001 [0.9907011529061142, 1.0110126650633788] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 0.999 [0.9715495427696097, 1.0116542521781788] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 1.023 [0.9430512599443645, 1.0656236025422325] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.017 [1.0046604589377057, 1.030252762297015] | pass | pass |
| full | paired | `square_100d_x100000` | 1.020 [1.006585539916819, 1.029101099610535] | pass | pass |
| full | paired | `square_1000d_x10000` | 1.004 [1.002257134927947, 1.0070351321550646] | pass | pass |
| full | paired | `square_10000d_x500` | 1.001 [0.9994614902012223, 1.0026681146140628] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.059 [1.0410948633157409, 1.1015570584581214] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.000 [0.9891119541156649, 1.0165089379624987] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 1.001 [0.9941665700745618, 1.0109345310069096] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.999 [0.9801843494979025, 1.0144029080692911] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.994 [0.9899065591018871, 1.0307633321035239] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.021 [1.0120739432328296, 1.0249559977090592] | pass | pass |
| full | paired | `file_statements_20000` | 1.016 [1.000325068093987, 1.0626394991994612] | inconclusive-noisy | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.016 [1.015306296237668, 1.0194184033111686] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 1.124 [1.0897558393266398, 1.1705977276984671] | confirmed regression | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.039 [0.9353751184410573, 1.1031368898783562] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.015 [1.010439564062745, 1.0170684023167396] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.022 [1.012809715034982, 1.0337769181025769] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t500_x5000` | 1.001 [0.9983098397050196, 1.0021095652794718] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t2000_x5000` | 0.997 [0.995308762102811, 1.0109882404147896] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.039 [0.992695678651487, 1.0587476579028807] | inconclusive-noisy | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t500_x5000` | 1.002 [0.998297284058565, 1.0065646991640804] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t2000_x5000` | 1.005 [0.9977291625266571, 1.0180859276199825] | pass | pass |
| holdout | aa | `startup` | 1.014 [0.9862130947220763, 1.0775904884580068] | inconclusive-noisy | - |
| holdout | aa | `loop_875000` | 0.992 [0.966835812248244, 1.00466850154358] | pass | - |
| holdout | aa | `calls_175000` | 0.990 [0.9593345067779341, 1.0175005003819615] | pass | - |
| holdout | aa | `array_175000` | 0.994 [0.9667487384132356, 1.0092671381415712] | pass | - |
| holdout | aa | `compare_high_1125d_x87500` | 0.998 [0.9853728750014743, 1.014277741131799] | pass | - |
| holdout | aa | `compare_low_1125d_x87500` | 1.000 [0.9927782174894523, 1.0178125737808565] | pass | - |
| holdout | aa | `compare_equal_1125d_x87500` | 1.008 [0.996050244936705, 1.0203176292160354] | pass | - |
| holdout | aa | `fibonacci_1125_x88` | 0.992 [0.986019877002546, 1.013198893952003] | pass | - |
| holdout | aa | `fibonacci_11250_x9` | 0.991 [0.9785898956029714, 0.9994359575324897] | pass | - |
| holdout | aa | `factorial_1125_x44` | 1.006 [0.9959742994441276, 1.0152792445045413] | pass | - |
| holdout | aa | `factorial_5625_x5` | 1.001 [1.0003656275637576, 1.004374139875114] | pass | - |
| holdout | aa | `multiply_112d_x87500` | 0.996 [0.9683883375885748, 1.0085608185515722] | pass | - |
| holdout | aa | `multiply_1125d_x8750` | 0.996 [0.9944980114842251, 0.9993528710254734] | pass | - |
| holdout | aa | `multiply_11250d_x875` | 0.998 [0.9964956001737197, 1.0025737788198386] | pass | - |
| holdout | aa | `divide_scale112_x87500` | 0.992 [0.979470251036934, 1.0031672851328761] | pass | - |
| holdout | aa | `divide_scale1125_x8750` | 1.000 [0.9912156459257395, 1.012070409248945] | pass | - |
| holdout | aa | `divide_scale5625_x4375` | 0.999 [0.9977827083698128, 1.0010970832151338] | pass | - |
| holdout | aa | `sqrt_scale112_x4375` | 1.003 [0.9956375004248395, 1.0061137292934497] | pass | - |
| holdout | aa | `sqrt_scale1125_x44` | 1.000 [0.9992001851585133, 1.0032611228002457] | pass | - |
| holdout | aa | `sqrt_scale5625_x5` | 0.999 [0.9974700069719783, 1.0018550779106405] | pass | - |
| holdout | aa | `multiply_dense_1125d_x4375` | 0.998 [0.9952953510812428, 1.016004597568234] | pass | - |
| holdout | aa | `multiply_dense_11250d_x438` | 0.998 [0.9962593098166563, 0.9987621537726036] | pass | - |
| holdout | aa | `multiply_unbalanced_11250d_112d_x1750` | 0.994 [0.9913231391482609, 1.0133299964502416] | pass | - |
| holdout | aa | `multiply_sparse_11250d_x875` | 1.000 [0.9978041573326742, 1.0021409522107707] | pass | - |
| holdout | aa | `divide_multilimb_1012d_506d_s112_x875` | 1.005 [0.9802384882142022, 1.0160431515222583] | pass | - |
| holdout | aa | `divide_multilimb_1125d_1012d_s1125_x438` | 0.998 [0.9795912420306984, 1.0087175259515246] | pass | - |
| holdout | aa | `modulo_1125d_393d_x2625` | 0.999 [0.9950799710663771, 1.002433731362952] | pass | - |
| holdout | aa | `power_112d_e17_x875` | 1.002 [0.9876729918187376, 1.0091619314696145] | pass | - |
| holdout | aa | `power_22d_e32_x1750` | 1.006 [0.9896768715431907, 1.0358891404321262] | pass | - |
| holdout | aa | `ibase_literal_flip_17500` | 1.012 [0.9764152181116005, 1.0195865287062629] | pass | - |
| holdout | aa | `recursion_56_x875` | 1.008 [1.002477950136919, 1.031426901111222] | pass | - |
| holdout | aa | `sparse_array_175000` | 1.001 [0.9842470177969904, 1.0485528310225245] | pass | - |
| holdout | aa | `frontend_definitions_1750` | 0.996 [0.9891460843616119, 1.0055271046723895] | pass | - |
| holdout | aa | `decimal_input_4500d_x88` | 1.009 [0.9968275484155593, 1.0343041716734334] | pass | - |
| holdout | aa | `decimal_output_225d_x875` | 1.014 [0.9935403463348378, 1.037479733444465] | pass | - |
| holdout | aa | `streaming_statements_17500` | 0.993 [0.9847737766240543, 1.0084282814775416] | pass | - |
| holdout | aa | `square_112d_x87500` | 0.996 [0.9860197661126425, 1.0118437371965274] | pass | - |
| holdout | aa | `square_1125d_x8750` | 0.999 [0.9975735027742794, 1.0001163898925078] | pass | - |
| holdout | aa | `square_11250d_x438` | 1.000 [0.9985059886487474, 1.0022603070885339] | pass | - |
| holdout | aa | `literal_repeat_2250d_x1750` | 1.012 [0.926548672609002, 1.0998921653045324] | inconclusive-noisy | - |
| holdout | aa | `binary_output_1125d_x263` | 1.005 [0.9960543075833546, 1.0093273918785515] | pass | - |
| holdout | aa | `octal_output_1125d_x263` | 1.000 [0.9969670511643306, 1.0045660540873935] | pass | - |
| holdout | aa | `binary_input_112500d_x3` | 1.001 [0.9905364761027111, 1.0039104380124577] | pass | - |
| holdout | aa | `hex_input_112500d_x3` | 1.004 [0.9975571380448205, 1.0176155391323038] | pass | - |
| holdout | aa | `temporary_chain_1125d_x43750` | 0.995 [0.9907490208816272, 1.0063607433365533] | pass | - |
| holdout | aa | `file_statements_17500` | 1.000 [0.9784095982947395, 1.006798702541662] | pass | - |
| holdout | aa | `sqrt_large_scale11250_x5` | 1.000 [0.9995218112325838, 1.00102874952784] | pass | - |
| holdout | aa | `sqrt_tiny_scale1152_x27` | 1.021 [0.9962279619634395, 1.0389060744612757] | pass | - |
| holdout | aa | `sqrt_tiny_scale4608_x1` | 0.993 [0.9559116641765215, 1.0201462974015714] | pass | - |
| holdout | aa | `sqrt_integer_power2250_scale112_x9` | 1.000 [0.9978630718308151, 1.0052910829033652] | pass | - |
| holdout | aa | `divide_scaled_dense_s1125_t1125_x4375` | 1.013 [0.9923075246595556, 1.0214074752430167] | pass | - |
| holdout | aa | `divide_scaled_dense_s1125_t562_x4375` | 1.000 [0.9987386029320188, 1.0029259743097179] | pass | - |
| holdout | aa | `divide_scaled_dense_s1125_t2250_x4375` | 1.005 [0.9991988671594544, 1.0117903566115884] | pass | - |
| holdout | aa | `divide_scaled_trailing_zero_s1125_t1125_x4375` | 1.008 [0.9923211183385957, 1.0177905840323471] | pass | - |
| holdout | aa | `divide_scaled_trailing_zero_s1125_t562_x4375` | 1.002 [0.9977064644415263, 1.0042813465708584] | pass | - |
| holdout | aa | `divide_scaled_trailing_zero_s1125_t2250_x4375` | 0.996 [0.9507875504018909, 1.0154094639310363] | pass | - |
| holdout | paired | `startup` | 0.977 [0.9096165558375771, 1.0360688913612606] | inconclusive-noisy | inconclusive-noisy |
| holdout | paired | `loop_875000` | 1.129 [1.114861484328797, 1.15722891089704] | confirmed regression | pass |
| holdout | paired | `calls_175000` | 1.133 [1.1092966465361855, 1.1715462637665977] | confirmed regression | pass |
| holdout | paired | `array_175000` | 1.079 [1.0676799859073733, 1.0909279915069683] | confirmed regression | pass |
| holdout | paired | `compare_high_1125d_x87500` | 1.118 [1.0692832130838203, 1.1358152526955423] | confirmed regression | pass |
| holdout | paired | `compare_low_1125d_x87500` | 1.103 [1.092644711804376, 1.108613219943704] | confirmed regression | pass |
| holdout | paired | `compare_equal_1125d_x87500` | 1.097 [1.0801097952973195, 1.101409620712087] | confirmed regression | pass |
| holdout | paired | `fibonacci_1125_x88` | 1.089 [1.080287195225757, 1.1234534487033825] | confirmed regression | pass |
| holdout | paired | `fibonacci_11250_x9` | 1.053 [1.037396268801656, 1.060604580505427] | inconclusive-noisy | pass |
| holdout | paired | `factorial_1125_x44` | 1.037 [1.022843419557524, 1.0388597410133533] | pass | pass |
| holdout | paired | `factorial_5625_x5` | 1.007 [1.001053453752193, 1.010651066729529] | pass | pass |
| holdout | paired | `multiply_112d_x87500` | 1.023 [0.9979177281955147, 1.0575006237905906] | inconclusive-noisy | pass |
| holdout | paired | `multiply_1125d_x8750` | 1.000 [0.9982583515495729, 1.0095770688735726] | pass | pass |
| holdout | paired | `multiply_11250d_x875` | 1.001 [0.9988057066652508, 1.0025243045506955] | pass | pass |
| holdout | paired | `divide_scale112_x87500` | 1.018 [1.0086641226776845, 1.0370479725786936] | pass | pass |
| holdout | paired | `divide_scale1125_x8750` | 1.005 [0.9949950222840453, 1.0097726260793096] | pass | pass |
| holdout | paired | `divide_scale5625_x4375` | 1.007 [0.9944203082532763, 1.0153904094741082] | pass | pass |
| holdout | paired | `sqrt_scale112_x4375` | 1.013 [1.0053909281131772, 1.0155466147393424] | pass | pass |
| holdout | paired | `sqrt_scale1125_x44` | 1.023 [1.0197465206767453, 1.0274106135122347] | pass | pass |
| holdout | paired | `sqrt_scale5625_x5` | 1.015 [1.013288310153446, 1.0153087719205123] | pass | pass |
| holdout | paired | `multiply_dense_1125d_x4375` | 1.002 [0.9883323601663336, 1.024643255838505] | pass | pass |
| holdout | paired | `multiply_dense_11250d_x438` | 1.001 [0.8933017217190221, 1.0035278338661544] | pass | pass |
| holdout | paired | `multiply_unbalanced_11250d_112d_x1750` | 1.005 [0.9936016816514035, 1.0140660723344792] | pass | pass |
| holdout | paired | `multiply_sparse_11250d_x875` | 0.998 [0.9942330877962737, 1.0003403836438791] | pass | pass |
| holdout | paired | `divide_multilimb_1012d_506d_s112_x875` | 1.016 [0.9936725166934806, 1.0268260189391945] | pass | pass |
| holdout | paired | `divide_multilimb_1125d_1012d_s1125_x438` | 1.040 [1.0275826205886125, 1.0475512922836685] | pass | pass |
| holdout | paired | `modulo_1125d_393d_x2625` | 1.009 [1.0079545772936995, 1.0182430984578967] | pass | pass |
| holdout | paired | `power_112d_e17_x875` | 1.001 [0.9919104582469478, 1.0115060129628233] | pass | pass |
| holdout | paired | `power_22d_e32_x1750` | 0.989 [0.9576264356664804, 1.01777419205785] | pass | pass |
| holdout | paired | `ibase_literal_flip_17500` | 1.073 [1.0486701546062178, 1.1542329183433144] | inconclusive-noisy | pass |
| holdout | paired | `recursion_56_x875` | 1.055 [1.04185756979804, 1.07221365078854] | inconclusive-noisy | pass |
| holdout | paired | `sparse_array_175000` | 1.088 [1.0613333100427245, 1.0908768607128547] | confirmed regression | pass |
| holdout | paired | `frontend_definitions_1750` | 0.998 [0.9794846773040069, 1.0164007421458114] | pass | pass |
| holdout | paired | `decimal_input_4500d_x88` | 1.006 [0.9737387194880023, 1.0232174979778819] | pass | pass |
| holdout | paired | `decimal_output_225d_x875` | 1.034 [0.9539861290853184, 1.1020809966119738] | inconclusive-noisy | pass |
| holdout | paired | `streaming_statements_17500` | 1.018 [1.0156750035152486, 1.0280193420917592] | pass | pass |
| holdout | paired | `square_112d_x87500` | 1.025 [1.0194538221508758, 1.0328302561527434] | pass | pass |
| holdout | paired | `square_1125d_x8750` | 1.001 [0.9997809418045486, 1.0019414040524408] | pass | pass |
| holdout | paired | `square_11250d_x438` | 1.001 [1.0000549147031665, 1.0014682634609315] | pass | pass |
| holdout | paired | `literal_repeat_2250d_x1750` | 1.049 [0.965431976028947, 1.136762348994032] | inconclusive-noisy | inconclusive-noisy |
| holdout | paired | `binary_output_1125d_x263` | 0.999 [0.9815245073062401, 1.003642498697969] | pass | pass |
| holdout | paired | `octal_output_1125d_x263` | 1.000 [0.9767808618906904, 1.0113331936718963] | pass | pass |
| holdout | paired | `binary_input_112500d_x3` | 0.992 [0.9841246305836121, 1.012026021768234] | pass | pass |
| holdout | paired | `hex_input_112500d_x3` | 0.998 [0.9933599805634509, 1.0023758669874754] | pass | pass |
| holdout | paired | `temporary_chain_1125d_x43750` | 1.035 [1.032428537687675, 1.038465770010924] | pass | pass |
| holdout | paired | `file_statements_17500` | 1.023 [0.9950605779252795, 1.0547084950565497] | inconclusive-noisy | pass |
| holdout | paired | `sqrt_large_scale11250_x5` | 1.017 [1.0157665511118787, 1.0178765664953062] | pass | pass |
| holdout | paired | `sqrt_tiny_scale1152_x27` | 1.074 [1.033150582801558, 1.0983294955051457] | inconclusive-noisy | pass |
| holdout | paired | `sqrt_tiny_scale4608_x1` | 1.063 [0.949586358687124, 1.0945023666143445] | inconclusive-noisy | pass |
| holdout | paired | `sqrt_integer_power2250_scale112_x9` | 1.016 [1.0119766874032474, 1.0195087656765123] | pass | pass |
| holdout | paired | `divide_scaled_dense_s1125_t1125_x4375` | 1.018 [1.0103113107424946, 1.0700800497618461] | inconclusive-noisy | pass |
| holdout | paired | `divide_scaled_dense_s1125_t562_x4375` | 0.999 [0.9973528114062455, 1.0023505348150914] | pass | pass |
| holdout | paired | `divide_scaled_dense_s1125_t2250_x4375` | 1.006 [0.997409460167119, 1.0151067835980263] | pass | pass |
| holdout | paired | `divide_scaled_trailing_zero_s1125_t1125_x4375` | 1.007 [0.990978451323207, 1.0556685065066869] | inconclusive-noisy | pass |
| holdout | paired | `divide_scaled_trailing_zero_s1125_t562_x4375` | 0.995 [0.9925140954769575, 1.0006476581632062] | pass | pass |
| holdout | paired | `divide_scaled_trailing_zero_s1125_t2250_x4375` | 1.006 [0.9946357322729097, 1.0343739361737085] | pass | pass |
