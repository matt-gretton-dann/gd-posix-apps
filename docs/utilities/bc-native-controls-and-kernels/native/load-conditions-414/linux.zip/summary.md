# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.083 [0.8132363032688854, 1.1992459655043908] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.999 [0.9794117951597148, 1.0075303326559546] | pass | - |
| full | aa | `calls_200000` | 0.993 [0.9776986420208791, 1.0238065599984614] | pass | - |
| full | aa | `array_200000` | 1.012 [0.9788718340125089, 1.021040371584356] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.001 [0.9909423568504847, 1.0033991729682221] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.001 [0.9794247516871025, 1.0378484239646033] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 1.001 [0.991690374708545, 1.0086649155718432] | pass | - |
| full | aa | `fibonacci_1000_x100` | 1.004 [0.9907228161567994, 1.0150655266913007] | pass | - |
| full | aa | `factorial_1000_x50` | 1.002 [0.9961827746608867, 1.0193469245394051] | pass | - |
| full | aa | `multiply_100d_x100000` | 1.004 [0.9900478506806054, 1.016150027260742] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.8882104046055272, 1.0212339760216482] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 1.001 [0.9827591533398576, 1.006533279622735] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.003 [0.9834256617086895, 1.0055308533518945] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.000 [0.9932043703709872, 1.0130035608711458] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.007 [0.9571818818663129, 1.010226914458558] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.005 [0.9473024043164714, 1.0283690822856275] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.9914146520622616, 1.0101737396704227] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.009 [0.9800712313994387, 1.023453966717267] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.994 [0.9818897730947761, 1.0049702549512813] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.995 [0.9850395979656349, 1.010661189012127] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.006 [0.9920010520461778, 1.0335950084637338] | pass | - |
| full | aa | `recursion_50_x1000` | 1.002 [0.9868438018662334, 1.0096098090508843] | pass | - |
| full | aa | `sparse_array_200000` | 1.008 [0.9880119909245557, 1.0195516300416576] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.015 [1.0050419486027717, 1.025297742170734] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 0.996 [0.974985787451528, 1.0260694027936414] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.010 [0.8721559279531088, 1.1264674515175945] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.016 [1.008196111878393, 1.0231386942048855] | pass | - |
| full | aa | `square_100d_x100000` | 0.999 [0.9863690244909431, 1.002834675475849] | pass | - |
| full | aa | `square_10000d_x500` | 1.001 [0.9776478039432636, 1.0071331306635676] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.928 [0.8426730861710904, 1.2212072335643966] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.012 [0.9726998444309883, 1.0121318443089846] | pass | - |
| full | aa | `octal_output_1000d_x300` | 1.000 [0.9841411401595677, 1.0369496231908828] | pass | - |
| full | aa | `binary_input_100000d_x3` | 0.998 [0.9788487286846479, 1.0060292335683805] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.003 [0.9881663688549032, 1.0147550739706752] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.003 [0.9984241319658067, 1.0195923105126712] | pass | - |
| full | aa | `file_statements_20000` | 1.029 [1.0054086428810927, 1.036198344811999] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.005 [0.9943915835403196, 1.024136041462626] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.038 [0.9779226316692884, 1.0925860758709833] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.017 [0.9594318684027521, 1.1396482437104407] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.995 [0.988796313958136, 1.0016591546609932] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.972 [0.9494878652533703, 1.0191915126163493] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.005 [0.9717766383526233, 1.0548541201796762] | inconclusive-noisy | - |
| full | paired | `startup` | 1.026 [0.9212253312146679, 1.0696115769827128] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.003 [0.9856409370848498, 1.0167488083989464] | pass | pass |
| full | paired | `calls_200000` | 0.981 [0.968984715030388, 0.9889391317249723] | pass | pass |
| full | paired | `array_200000` | 0.998 [0.9792740059454167, 1.0076986067270262] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 0.979 [0.9641864723405966, 0.9837591073030969] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 1.027 [1.0121560840950978, 1.1031724736199457] | inconclusive-noisy | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.993 [0.9677537648221155, 1.0512984744091207] | inconclusive-noisy | pass |
| full | paired | `fibonacci_1000_x100` | 0.988 [0.9745360057553404, 1.0418237721380104] | pass | pass |
| full | paired | `factorial_1000_x50` | 0.988 [0.9744827887563153, 1.0075728358556821] | pass | pass |
| full | paired | `multiply_100d_x100000` | 0.975 [0.8882824904183252, 0.9854405474067741] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 1.003 [0.9929869428506471, 1.01479872377673] | pass | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.985 [0.9366265038391062, 0.9929108869047674] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 0.999 [0.9932992961191811, 1.0063024615421425] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 1.011 [0.9967455091500712, 1.040415368901977] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.001 [0.9852067486096313, 1.012636919805223] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9877451237738275, 1.0211427934977113] | pass | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.998 [0.9878651657457256, 1.0032196165845746] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.9898740721418234, 1.0202438472652011] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.001 [0.9932695419762944, 1.0135829604614153] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.997 [0.9829335305374556, 1.0061765840471206] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 0.960 [0.9364578764924799, 1.0134996628002109] | pass | pass |
| full | paired | `recursion_50_x1000` | 0.972 [0.9567092017339841, 0.9774585415615344] | pass | pass |
| full | paired | `sparse_array_200000` | 1.009 [0.9965729334831882, 1.0294603068909702] | pass | pass |
| full | paired | `frontend_definitions_2000` | 1.011 [0.9612044671233198, 1.0308477759376988] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 0.986 [0.9392698639405336, 1.049474464019147] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 1.012 [0.942433328401222, 1.0755672077670253] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.016 [1.0114991498387114, 1.0251934628001347] | pass | pass |
| full | paired | `square_100d_x100000` | 0.985 [0.9777006851375128, 1.002241562718977] | pass | pass |
| full | paired | `square_10000d_x500` | 0.996 [0.9868040758011064, 0.9979338392111277] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.995 [0.7937978070869227, 1.0313370785571256] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.004 [0.9965735164306943, 1.0193039256970582] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 0.999 [0.9883254668120914, 1.026546442829786] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.980 [0.9550832487221066, 1.0146409030042012] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.984 [0.9500993152386784, 1.0684903334864202] | inconclusive-noisy | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.992 [0.9810936087979362, 1.002704225083149] | pass | pass |
| full | paired | `file_statements_20000` | 1.014 [1.0019415449651503, 1.0306154022256186] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.034 [1.0108628855049893, 1.0405168784962229] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.935 [0.8887244520678802, 0.9643674629193925] | pass | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.051 [0.9294518372502445, 1.1157785229234218] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.034 [1.003113619612151, 1.04524245153005] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.004 [0.9422784935039742, 1.070685185530935] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.972 [0.9639785084302521, 1.0062505555672132] | pass | inconclusive-noisy |
