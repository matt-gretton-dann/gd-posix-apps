# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.954 [0.9288173431261343, 1.05226022314933] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 1.014 [0.9777516325342369, 1.027152233059314] | pass | - |
| full | aa | `calls_200000` | 1.008 [0.9595043567909991, 1.0380623797257391] | pass | - |
| full | aa | `array_200000` | 1.006 [0.9761641893737466, 1.014162525266455] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 0.994 [0.9882644328026782, 1.0076810072673776] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.000 [0.9892810284698703, 1.1348139264372024] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 0.988 [0.9792324933348939, 1.0041814462506746] | pass | - |
| full | aa | `fibonacci_1000_x100` | 1.019 [0.9980639964038521, 1.0259518049804022] | pass | - |
| full | aa | `factorial_1000_x50` | 1.018 [1.010044202793151, 1.0503774550575324] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 1.030 [1.0080886948485086, 1.0454522418042738] | pass | - |
| full | aa | `multiply_10000d_x1000` | 0.996 [0.9886172882874379, 1.0056956573334483] | pass | - |
| full | aa | `divide_scale100_x100000` | 1.000 [0.9943879738147089, 1.0186434785643288] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.003 [0.9773214154791269, 1.0063671945860062] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.000 [0.9964988932146275, 1.0087872852883049] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 0.985 [0.9762152309585811, 1.0051670482010207] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9939350089332935, 1.0203799149531674] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.004 [0.9872087195825701, 1.0699064135021352] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.016 [0.9858592922424595, 1.032093028048385] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.986 [0.9478258760512785, 1.005559066720018] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9944213853911693, 1.015590941131896] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.019 [1.0101266031066372, 1.0447100574784352] | pass | - |
| full | aa | `recursion_50_x1000` | 1.012 [0.9980101919394752, 1.0201763001821507] | pass | - |
| full | aa | `sparse_array_200000` | 0.989 [0.9728084847095944, 1.002690751941508] | pass | - |
| full | aa | `frontend_definitions_2000` | 0.990 [0.9835493941469671, 1.0066472820409818] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.020 [0.9926245735593502, 1.1054135192728893] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 0.997 [0.9702127659567853, 1.0292901062069464] | pass | - |
| full | aa | `streaming_statements_20000` | 0.985 [0.9390094845670487, 1.0333769562479511] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 1.013 [1.001358059869647, 1.0181854490126998] | pass | - |
| full | aa | `square_10000d_x500` | 0.998 [0.9943210674546996, 1.0036609885439538] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 1.007 [0.9549796287880468, 1.054726704014668] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.013 [0.9904944455937662, 1.0652185498209987] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 1.006 [0.9818946820146959, 1.0362919370891859] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.010 [0.9834557625771619, 1.0398518505462757] | pass | - |
| full | aa | `hex_input_100000d_x3` | 0.998 [0.9555217872364303, 1.0037659762262863] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.002 [0.9997977470690157, 1.005292923320313] | pass | - |
| full | aa | `file_statements_20000` | 1.008 [0.9642819779774686, 1.0693637666184088] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.001 [0.9986056132976812, 1.0055298170698415] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.014 [0.9620846403100155, 1.0310341793927045] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.021 [0.9782280403462215, 1.0381852983542523] | pass | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.999 [0.9899756751009241, 1.007066325050392] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.990 [0.9808410867131212, 1.01245659752656] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.012 [0.9414636487685549, 1.015642002171108] | inconclusive-noisy | - |
| full | paired | `startup` | 0.995 [0.9070739028176805, 1.0614619643156638] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.967 [0.9578047750584184, 0.9995152322920826] | pass | pass |
| full | paired | `calls_200000` | 0.998 [0.9695602434828176, 1.03561996593944] | pass | pass |
| full | paired | `array_200000` | 1.011 [0.9969765712504297, 1.0956516011671178] | inconclusive-noisy | pass |
| full | paired | `compare_high_1000d_x100000` | 1.004 [0.9873516258643602, 1.099973187195167] | inconclusive-noisy | pass |
| full | paired | `compare_low_1000d_x100000` | 0.981 [0.902749403390488, 1.0125866855094872] | pass | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.984 [0.974350094065434, 1.048880158779732] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 1.034 [0.9968903377546167, 1.1752966655618293] | inconclusive-noisy | pass |
| full | paired | `factorial_1000_x50` | 1.040 [1.0212987171603356, 1.1183861470308114] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.017 [0.9959921529469332, 1.0612418405521544] | inconclusive-noisy | pass |
| full | paired | `multiply_10000d_x1000` | 0.997 [0.9780584765542084, 1.002419365180421] | pass | pass |
| full | paired | `divide_scale100_x100000` | 1.011 [0.9977155869491059, 1.2702313345876817] | inconclusive-noisy | pass |
| full | paired | `sqrt_scale100_x5000` | 1.000 [0.9008896632895463, 1.0068106241926498] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 0.999 [0.9961228678608847, 1.0059676744474086] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.016 [0.9932495023942183, 1.070185021223282] | inconclusive-noisy | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.8750975734620554, 1.0203656814541677] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.002 [0.9864992033077199, 1.020632208268234] | pass | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.994 [0.9571096360866698, 1.040037502963052] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.993 [0.9823495042984184, 1.0021114133607099] | pass | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.012 [0.9863346301303291, 1.03439681315721] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 1.033 [1.0103921711218997, 1.0896302080229618] | inconclusive-noisy | pass |
| full | paired | `recursion_50_x1000` | 0.991 [0.9667295029541431, 1.0110106884257244] | pass | pass |
| full | paired | `sparse_array_200000` | 0.982 [0.937555699795971, 1.0450250662002254] | pass | pass |
| full | paired | `frontend_definitions_2000` | 0.985 [0.9522237503420005, 1.0147103556859152] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 1.000 [0.9852958178283431, 1.017548520681079] | pass | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.034 [0.979807605032492, 1.076830937714626] | inconclusive-noisy | pass |
| full | paired | `streaming_statements_20000` | 1.013 [0.9147585213195291, 1.046250791226655] | pass | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.009 [0.918583150964691, 1.0230767982368942] | pass | pass |
| full | paired | `square_10000d_x500` | 0.997 [0.9848854962721691, 1.0028979068938617] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.995 [0.948113365763112, 1.016380646006358] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.010 [1.0053154583870474, 1.0854969995830377] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.017 [1.0003890676581975, 1.116101109924184] | inconclusive-noisy | pass |
| full | paired | `binary_input_100000d_x3` | 0.999 [0.9370898581943541, 1.0189740977077508] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.999 [0.9962889924461621, 1.0316872221319677] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.994 [0.9893380015216632, 1.0086258200691838] | pass | pass |
| full | paired | `file_statements_20000` | 1.022 [0.9220865279144442, 1.1243910390304281] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 0.999 [0.997380518551738, 1.0027334070247795] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 1.006 [0.9146929420156847, 1.0403121703690479] | pass | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.995 [0.9437703462539845, 1.0561568368501792] | inconclusive-noisy | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.001 [0.9913988139340556, 1.0217535108383873] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.992 [0.9578678535168462, 1.0314169565938498] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.973 [0.9356605114668773, 1.0087222398659375] | pass | inconclusive-noisy |
