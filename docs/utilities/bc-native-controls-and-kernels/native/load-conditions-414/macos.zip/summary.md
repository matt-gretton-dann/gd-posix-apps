# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.024 [0.9405298349584283, 1.1093062670251268] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 1.025 [0.96403234576119, 1.1012683115947652] | inconclusive-noisy | - |
| full | aa | `calls_200000` | 0.996 [0.9348798649851204, 1.0246749137407487] | inconclusive-noisy | - |
| full | aa | `array_200000` | 1.171 [0.9530590225127906, 1.1976654385108874] | inconclusive-noisy | - |
| full | aa | `compare_high_1000d_x100000` | 0.989 [0.9169667026566026, 1.0662332653254287] | inconclusive-noisy | - |
| full | aa | `compare_low_1000d_x100000` | 1.009 [0.9294196545583191, 1.090683954081438] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 0.920 [0.8946373397772015, 1.0331232914249966] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 0.984 [0.967597968968264, 1.1655540941638365] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 1.006 [0.9397626041562372, 1.1271277697142512] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 1.002 [0.9075630157358803, 1.0316573642609834] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 0.973 [0.8962680075495124, 1.0019937485019612] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 1.014 [0.9079609190567174, 1.0674228724620818] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 0.898 [0.7578669477543664, 1.0030977626166588] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 1.022 [0.9761941865129866, 1.060133768598655] | inconclusive-noisy | - |
| full | aa | `multiply_dense_10000d_x500` | 0.974 [0.9328446174661803, 1.0511811141434102] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.033 [0.9900392960612475, 1.2878487419214621] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.036 [0.9463283182167812, 1.0856459276808303] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.019 [0.8644647164509567, 1.0266696692835906] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.004 [0.9829155901530271, 1.08895178642373] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 0.998 [0.9808030244063509, 1.0612571821608143] | inconclusive-noisy | - |
| full | aa | `ibase_literal_flip_20000` | 1.012 [0.9284640173580627, 1.117100347322733] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 1.033 [0.9996014564659733, 1.1314114650729978] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 0.896 [0.8179489107641359, 1.1649150638644568] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 1.011 [0.9500931971589252, 1.0700508962898199] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 0.991 [0.9649082457504752, 1.0279165953993519] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.047 [0.970320737063614, 1.1264194876548972] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.935 [0.8734771292103672, 1.0489568836130747] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 0.982 [0.8273493740825196, 1.0911928469543424] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 0.985 [0.9747356606505773, 1.1023235202935862] | inconclusive-noisy | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.946 [0.7678909519697369, 1.0547519059100348] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.994 [0.8523407721796756, 1.0810886775671626] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 1.005 [0.8937577670994843, 1.0310067193006922] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 1.011 [0.8254786464528574, 1.0572115725163238] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 1.009 [0.9753915836246392, 1.0613272413237578] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.011 [0.963410215029673, 1.0337821740900937] | pass | - |
| full | aa | `file_statements_20000` | 1.048 [0.9998109283287862, 1.1466221947541562] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 0.985 [0.9606291863029279, 1.0474050689369543] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.003 [0.9468617421538099, 1.1865547339615976] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.006 [0.9702825966056918, 1.0765762395387217] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.982 [0.9148142170311921, 1.0311488144189696] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.000 [0.9588532639523921, 1.2341251489657752] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.019 [0.9484910561140318, 1.0504264638087688] | inconclusive-noisy | - |
| full | paired | `startup` | 0.905 [0.7879470472624178, 1.2661806625867222] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.967 [0.869167899409395, 1.1231997454885096] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `calls_200000` | 1.021 [0.8598907116627542, 1.0787632570904655] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `array_200000` | 1.108 [0.9199597375806725, 1.2355709135505406] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.959 [0.7811265392888025, 1.0730800047147326] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.957 [0.8929510808490053, 1.123763768205474] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.039 [0.8331434497716351, 1.1652366660859166] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.005 [0.8789429442698199, 1.118955286805207] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.940 [0.8339214211800156, 1.2517316695058525] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.987 [0.820460999692318, 1.1092533829498625] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.017 [0.8525583522339919, 1.1232793716671408] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.125 [0.917158849813824, 1.3134481484817238] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.015 [0.8864033090303176, 1.2478008796627063] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 0.993 [0.9346707900396416, 1.0810450002352285] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.938 [0.8245155590457177, 0.996516140048352] | pass | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.008 [0.8057340654063585, 1.1117226886544516] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.087 [0.9044655553038132, 1.1598214008413334] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.033 [0.8495540508475693, 1.2633772707051847] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.034 [0.7436465085128916, 1.0880895640673378] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.904 [0.7708185999021336, 1.2232179654949848] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.022 [0.8242363231026245, 1.0670394452607201] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.032 [1.0189728945926637, 1.2020451532623422] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.978 [0.8375297682681165, 1.1824656800654776] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.138 [0.9827831044906018, 1.2753852276610558] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.025 [0.9234212433478359, 1.3013533575736616] | inconclusive-noisy | pass |
| full | paired | `decimal_output_200d_x1000` | 1.028 [0.8786245910774128, 1.1655150470804303] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.940 [0.6790449796081526, 1.1078610944175082] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.037 [0.9172085332853913, 1.119819974364455] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.035 [0.9618520386460568, 1.1777275683518131] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 1.087 [0.9182683468123319, 1.3935131477074054] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.869 [0.7666026432404461, 1.0162803472392454] | pass | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.993 [0.7858488885079074, 1.0081888343973857] | pass | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.099 [0.9789711023976008, 1.3546852888706533] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.927 [0.9194616940746354, 1.0850856000984521] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.014 [0.940565607611673, 1.185524837427248] | inconclusive-noisy | pass |
| full | paired | `file_statements_20000` | 0.944 [0.9178778415343942, 1.1559923311824485] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 1.059 [0.9001008478574566, 1.240155696740542] | inconclusive-noisy | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 1.136 [0.9138474139218051, 1.2096741272160774] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.091 [0.8474934968656583, 1.702841517225555] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.033 [0.9638582947554152, 1.4260596373351937] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.071 [0.6604973512507373, 1.1115912793224636] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.943 [0.6081606397973824, 1.101853965903427] | inconclusive-noisy | inconclusive-noisy |
