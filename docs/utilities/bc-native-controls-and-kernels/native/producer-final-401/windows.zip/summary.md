# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.038 [0.9377101681373892, 1.1039902064632379] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.988 [0.979770388786628, 1.004345270377805] | pass | - |
| full | aa | `calls_200000` | 1.001 [0.9773474220459142, 1.00836460339268] | pass | - |
| full | aa | `array_200000` | 1.008 [0.9848380779675835, 1.0565325151512155] | inconclusive-noisy | - |
| full | aa | `compare_high_1000d_x100000` | 0.990 [0.9610392218380928, 0.9949842511464899] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 0.995 [0.9774458823277327, 1.0088651009338636] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 0.982 [0.9402050354233203, 0.9999345129988101] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 0.992 [0.9557074898045644, 1.0098570237884326] | pass | - |
| full | aa | `factorial_1000_x50` | 1.001 [0.9751253624857734, 1.06127990908477] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 0.991 [0.9671381621011539, 1.0060672797940877] | pass | - |
| full | aa | `multiply_10000d_x1000` | 0.996 [0.9895406723181862, 1.0089810057453357] | pass | - |
| full | aa | `divide_scale100_x100000` | 1.000 [0.9872258332583219, 1.0064446487196144] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.006 [0.933971551289715, 1.0144359787046797] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 1.001 [0.9967659821749103, 1.0069460448598637] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 0.995 [0.9919566837037637, 1.017071609976303] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.989 [0.971381599321058, 0.997002757809009] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.993 [0.9577792435720882, 1.0021097835535238] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.9809657553800217, 1.0194402516851648] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.997 [0.987443762695208, 1.0009855142332846] | pass | - |
| full | aa | `power_100d_e17_x1000` | 1.009 [0.9988884938669532, 1.0173946401245857] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.006 [0.9914158121075509, 1.0278970655219566] | pass | - |
| full | aa | `recursion_50_x1000` | 1.005 [0.8606841512751986, 1.0097611162890412] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 0.977 [0.9548327800857408, 0.9931929734732057] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.012 [0.9910173981925784, 1.0253965473108106] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.001 [0.99128329056907, 1.0189810549714144] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.010 [0.9851088487035089, 1.0332760467255713] | pass | - |
| full | aa | `streaming_statements_20000` | 1.026 [0.9944018723236665, 1.0402809150681962] | pass | - |
| full | aa | `square_100d_x100000` | 0.986 [0.9818726128154256, 0.9985351042147502] | pass | - |
| full | aa | `square_10000d_x500` | 0.996 [0.988302722045558, 1.0051785561466615] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.978 [0.9436533267934911, 1.1022632939110082] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.008 [0.9869657511763515, 1.027902119433939] | pass | - |
| full | aa | `octal_output_1000d_x300` | 1.007 [0.988903691462437, 1.0449827599345416] | pass | - |
| full | aa | `binary_input_100000d_x3` | 0.995 [0.9787430948452631, 1.0089627581932321] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.011 [0.9825918501453491, 1.028937860399926] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.993 [0.9742051161950923, 1.0095978796736982] | pass | - |
| full | aa | `file_statements_20000` | 1.016 [0.9819563301266063, 1.0314733747048943] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 0.997 [0.9864591605076912, 1.0033354052245507] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 0.996 [0.9342297573808342, 1.0282103969436023] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.010 [0.9640468312009077, 1.0465271796914177] | pass | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.001 [0.9886000611234227, 1.0141713952505997] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.980 [0.9537360945941621, 0.9915861945625527] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.020 [0.9648781879259274, 1.0302691354604177] | pass | - |
| full | paired | `startup` | 1.010 [0.923938726634599, 1.13138409898152] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.033 [0.9987312318081933, 1.0591156664479189] | inconclusive-noisy | pass |
| full | paired | `calls_200000` | 1.015 [1.004483889588959, 1.083692392194646] | inconclusive-noisy | pass |
| full | paired | `array_200000` | 1.035 [0.9529146174973732, 1.0709144595165705] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.055 [1.0306518190584406, 1.1549232529849638] | inconclusive-noisy | pass |
| full | paired | `compare_low_1000d_x100000` | 1.035 [0.9972468010165338, 1.046907766658993] | pass | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.033 [1.0188346688287275, 1.0938973941527206] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.053 [1.0281078250617524, 1.1138278638776618] | inconclusive-noisy | pass |
| full | paired | `factorial_1000_x50` | 1.099 [0.9636130906050292, 1.1379193063342081] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.018 [1.0004906213846347, 1.0567039366028588] | inconclusive-noisy | pass |
| full | paired | `multiply_10000d_x1000` | 0.990 [0.9751328687466129, 1.003032878954728] | pass | pass |
| full | paired | `divide_scale100_x100000` | 1.107 [1.0660978505379046, 1.1140976022745115] | inconclusive-noisy | pass |
| full | paired | `sqrt_scale100_x5000` | 1.012 [1.0032374817100165, 1.0285982625019012] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 0.977 [0.9638640534979148, 0.9804412237488337] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.000 [0.9732066701718828, 1.0167320572470013] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.003 [0.9925760906461675, 1.0182761024664184] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.999 [0.9575484663114149, 1.0047475788243883] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.023 [1.0107509773628607, 1.0450754602204018] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.004 [0.9974091215575631, 1.0456169386590044] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 1.010 [0.9055488256885706, 1.0262781595488872] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 1.007 [0.9917632374662189, 1.0315445937161054] | pass | pass |
| full | paired | `recursion_50_x1000` | 1.069 [1.0442414088065624, 1.2184671733626897] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.064 [1.0493487038996965, 1.078447311834603] | inconclusive-noisy | pass |
| full | paired | `frontend_definitions_2000` | 1.015 [0.9813063295174813, 1.0248605333804506] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 0.984 [0.9760929280966124, 0.992659622973864] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 1.010 [0.9749523584107337, 1.0390379278369273] | pass | pass |
| full | paired | `streaming_statements_20000` | 0.980 [0.9474225919436908, 1.018788958342658] | pass | pass |
| full | paired | `square_100d_x100000` | 1.042 [1.0155329453379462, 1.0899416500426433] | inconclusive-noisy | pass |
| full | paired | `square_10000d_x500` | 1.003 [0.9771322540498609, 1.0111271254092529] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.004 [0.9243932669554741, 1.0943700969057812] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.010 [0.9934109620477087, 1.0476361667975551] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 1.010 [0.976855493632989, 1.0391081891270701] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.985 [0.9749987950386411, 1.0048616404332416] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.999 [0.9603133155466398, 1.0426426480331656] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.008 [0.9892232891652328, 1.0184629423426141] | pass | pass |
| full | paired | `file_statements_20000` | 1.000 [0.8892141282115289, 1.0561749183603013] | inconclusive-noisy | pass |
| full | paired | `sqrt_large_scale10000_x5` | 0.972 [0.9500696811370906, 0.9803706392546725] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.981 [0.9533415829818284, 0.9905316078509986] | pass | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.994 [0.9467663802648523, 1.1462739374767204] | inconclusive-noisy | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.987 [0.9744415170363597, 0.9989370201514483] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.021 [0.9695752425435612, 1.0540450420366607] | inconclusive-noisy | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.018 [0.9658633326195929, 1.058481850322926] | inconclusive-noisy | pass |
