# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.053 [0.7993023842126299, 1.2681132065072067] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 1.019 [1.0088635984573011, 1.0269984335049738] | pass | - |
| full | aa | `calls_200000` | 0.999 [0.9857450304940097, 1.0056108827323489] | pass | - |
| full | aa | `array_200000` | 1.011 [0.9916635622111222, 1.0183886089052832] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 0.995 [0.9552863475163395, 1.0205398450617231] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.003 [0.9932872653546084, 1.0310748499112767] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 0.992 [0.9469793291112063, 1.0156680253250645] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 0.993 [0.9767528128560765, 0.9997055554507984] | pass | - |
| full | aa | `factorial_1000_x50` | 0.996 [0.9911491161979374, 1.0114868391418987] | pass | - |
| full | aa | `multiply_100d_x100000` | 1.002 [0.9859527044517081, 1.0200217262857345] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9861384609805771, 1.0105951437535015] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.997 [0.9915733411678721, 1.0140646821284096] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.002 [0.9801913909894039, 1.009311572050444] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.002 [0.9975270077275914, 1.0045866014113591] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9058986032581535, 1.014047379160963] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.013 [0.9887812804158608, 1.0154737818712087] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.996 [0.9935884770283189, 0.9991008467559682] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.007 [0.9648058021041597, 1.0086523287282292] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9849957838391924, 1.0059749842349257] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.983 [0.953644552389601, 1.0209236679952016] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 0.995 [0.9701389021064276, 1.0082460597948786] | pass | - |
| full | aa | `recursion_50_x1000` | 0.996 [0.9900512646112947, 1.0148707738030345] | pass | - |
| full | aa | `sparse_array_200000` | 1.005 [0.995287989385559, 1.0178203612371863] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.000 [0.9828658194983899, 1.0073185733970724] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.018 [0.9916466480461054, 1.0447964300979415] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 0.988 [0.8684262186213666, 1.0687679214969512] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.002 [0.997867053660764, 1.0090142216575106] | pass | - |
| full | aa | `square_100d_x100000` | 1.001 [0.9889265375224676, 1.0127920552702963] | pass | - |
| full | aa | `square_10000d_x500` | 1.004 [0.9992342780516563, 1.0182218139457384] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.955 [0.8978877837788533, 1.2130312880105307] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.013 [0.990326572616296, 1.0391855769124982] | pass | - |
| full | aa | `octal_output_1000d_x300` | 0.997 [0.9627441004731015, 1.1266501132121816] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 1.003 [0.9960713399257882, 1.0148775222530622] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.014 [0.988619871497411, 1.0309285082151856] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.995 [0.9838548592617313, 1.0056371539552647] | pass | - |
| full | aa | `file_statements_20000` | 1.003 [0.9861101085262046, 1.015653169678391] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.003 [0.9868427903953548, 1.0155007036790904] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.015 [0.9848910215262429, 1.035604349468646] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.000 [0.9586538659627418, 1.074279307373947] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.998 [0.9880921695268895, 1.0111486334879047] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.970 [0.9389666682374208, 1.0144558222911313] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.947 [0.9240787119281755, 1.0379285544552201] | inconclusive-noisy | - |
| full | paired | `startup` | 1.016 [0.9090331108303855, 1.204724899912444] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.029 [1.003345489936822, 1.0536350172710893] | inconclusive-noisy | pass |
| full | paired | `calls_200000` | 1.036 [1.0287783359057305, 1.0593279182385418] | inconclusive-noisy | pass |
| full | paired | `array_200000` | 1.054 [1.0357510172582935, 1.063330377366569] | inconclusive-noisy | pass |
| full | paired | `compare_high_1000d_x100000` | 1.051 [1.0391486401230736, 1.0638388134444412] | inconclusive-noisy | pass |
| full | paired | `compare_low_1000d_x100000` | 1.007 [0.9777674257704433, 1.0551382635082418] | inconclusive-noisy | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.038 [0.9870300749422796, 1.0537427717937253] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.056 [1.0482965240533986, 1.0699738917965222] | inconclusive-noisy | pass |
| full | paired | `factorial_1000_x50` | 1.012 [1.0073406609919506, 1.0180895717776097] | pass | pass |
| full | paired | `multiply_100d_x100000` | 1.054 [1.0300834883599637, 1.0795923443369189] | inconclusive-noisy | pass |
| full | paired | `multiply_10000d_x1000` | 0.999 [0.983042380094416, 1.0176845938100532] | pass | pass |
| full | paired | `divide_scale100_x100000` | 1.029 [1.009015792203123, 1.047693552832099] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 1.001 [0.9966390791197747, 1.055186525250982] | inconclusive-noisy | pass |
| full | paired | `sqrt_scale5000_x5` | 1.030 [1.0091278742755507, 1.0444667324212014] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.004 [0.9373139178391015, 1.0491298375206066] | pass | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.013 [1.0015485723146893, 1.0398098261199444] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.010 [0.9899072255571082, 1.044909581956565] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.006 [1.0007591503282067, 1.0211798879597516] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.001 [0.9865953781610591, 1.0077514311205298] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.999 [0.9667038352490029, 1.004008079025294] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 1.048 [1.0072600568550074, 1.0630545372802211] | inconclusive-noisy | pass |
| full | paired | `recursion_50_x1000` | 0.995 [0.9603313290614024, 0.9979508688704039] | pass | pass |
| full | paired | `sparse_array_200000` | 1.016 [0.9929324940665789, 1.0411451525743878] | pass | pass |
| full | paired | `frontend_definitions_2000` | 1.015 [1.0006913648882543, 1.0429600006992676] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 0.983 [0.970995829150156, 1.0323257004188562] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 1.033 [0.9042835840012713, 1.102111575144472] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.002 [0.9831403123530449, 1.0304845472442563] | pass | pass |
| full | paired | `square_100d_x100000` | 1.027 [1.013644318086478, 1.0479753791342397] | pass | pass |
| full | paired | `square_10000d_x500` | 0.994 [0.9813444882043154, 1.0118147321872333] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.998 [0.818637376345397, 1.0970726193100977] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.007 [0.9890757021065917, 1.0243671136969366] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 0.999 [0.9754658066980992, 1.015958956589126] | pass | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.013 [0.9793717541584662, 1.0280812995143245] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 1.004 [0.9852959710718596, 1.0085858406098902] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.018 [0.9805140373681475, 1.032395057736058] | pass | pass |
| full | paired | `file_statements_20000` | 0.995 [0.9766185776852128, 1.0055441850212405] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.032 [1.0240110770440358, 1.0555931983557352] | inconclusive-noisy | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 1.015 [0.9716039642042525, 1.0566149334495765] | inconclusive-noisy | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.029 [0.9213225975135452, 1.1822448563086063] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.032 [1.0129520282563362, 1.0388343087010428] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.020 [0.9496555841558157, 1.0821857582598216] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.983 [0.9350617800604899, 1.210644863791698] | inconclusive-noisy | inconclusive-noisy |
