# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.994 [0.8490824923745008, 1.186227628832929] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.989 [0.9563880746516458, 1.0894055665993976] | inconclusive-noisy | - |
| full | aa | `calls_200000` | 1.004 [0.9230454742075949, 1.0810838576310207] | inconclusive-noisy | - |
| full | aa | `array_200000` | 0.999 [0.9647892768021401, 1.05169118975451] | inconclusive-noisy | - |
| full | aa | `compare_high_1000d_x100000` | 1.009 [0.9574708632377872, 1.0316930119434884] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 0.979 [0.9233962633942705, 1.0259717151339054] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.000 [0.9239873534535444, 1.0266204228685534] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 0.941 [0.831679678174342, 1.1070220867733365] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 0.975 [0.8504156812636569, 1.0031847720636289] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 0.979 [0.9113724847896889, 1.0422402108902737] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 0.982 [0.9443070262301032, 1.0170499964502702] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 1.008 [0.9664584932025324, 1.0581537710070328] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 1.033 [0.9298975681809942, 1.052512871702181] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 1.010 [0.9967131392101385, 1.0228236306587406] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.028 [0.8374415835199475, 1.1528591964855217] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.977 [0.8557872996430871, 1.0494823534850264] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.015 [0.942609219555348, 1.1170487809697076] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.991 [0.9488793549822677, 1.0338769642876395] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.977 [0.8014892151929297, 1.0161339204414206] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 1.015 [0.9653104776599192, 1.0403446522900293] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.017 [0.9788044381303723, 1.0957194554715477] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 0.996 [0.9601227884439014, 1.0464080868889742] | pass | - |
| full | aa | `sparse_array_200000` | 0.897 [0.7605151322415975, 1.02152716114503] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 1.002 [0.8982105230006929, 1.0934886872948026] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 0.989 [0.8531235241990944, 1.146184141391908] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 1.015 [0.9455907134555417, 1.1570576550226] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.023 [0.9240974063475551, 1.083708682609442] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 0.949 [0.9014082393390794, 1.018937316711944] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 1.054 [0.9444462298798544, 1.102629448156184] | inconclusive-noisy | - |
| full | aa | `literal_repeat_2000d_x2000` | 1.042 [0.8979510468858584, 1.0507946173985958] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.006 [0.9092727658969576, 1.397720632643716] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 0.979 [0.7772354957621818, 1.0632749099406535] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 0.982 [0.8685188692310517, 1.109242995244573] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 0.983 [0.9372912349421088, 1.0807812525517995] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.999 [0.9556868440065998, 1.0241346087731729] | pass | - |
| full | aa | `file_statements_20000` | 1.033 [0.945551938030495, 1.2238901339299033] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.023 [0.9288648448291077, 1.0617484287030319] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.000 [0.80487160823112, 1.0458878378856566] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.011 [0.966167651079875, 1.0671816949649666] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.954 [0.941309285302469, 1.099718012504365] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.016 [0.902928141763448, 1.170078483341549] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.003 [0.9709675993188245, 1.0669651365995996] | inconclusive-noisy | - |
| full | paired | `startup` | 0.984 [0.6819118583631865, 1.1341502702958026] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.877 [0.7289237563142773, 1.048504524331342] | pass | inconclusive-noisy |
| full | paired | `calls_200000` | 0.978 [0.7860217823981418, 1.1583363302171648] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `array_200000` | 1.106 [1.0581685822141318, 1.1357307426718593] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.172 [1.025930542028804, 1.3116585496918534] | inconclusive-noisy | pass |
| full | paired | `compare_low_1000d_x100000` | 0.975 [0.8460942585396259, 1.1585503955590786] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.004 [0.9708870091401478, 1.1011396709548538] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.084 [0.7619199999869672, 1.2552011041414766] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.070 [0.6134486523268274, 1.2174453992182341] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.069 [0.872595446594092, 1.1692456465455776] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.034 [0.9616147106600917, 1.053589532613615] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.170 [0.9762988641788506, 1.2230176234419843] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.986 [0.8793876839871689, 1.1144184431631847] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 1.018 [0.8945437590508506, 1.100593010176795] | inconclusive-noisy | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.018 [0.943972424403162, 1.0744232516143857] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.896 [0.8020203097107944, 1.2107956574150411] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.916 [0.8706026327098837, 1.0150122354514217] | pass | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.100 [0.7961744840094656, 1.2309798258058653] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.983 [0.942195427820126, 1.3130429088979143] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.011 [0.884553502104696, 1.1242576624849605] | inconclusive-noisy | pass |
| full | paired | `ibase_literal_flip_20000` | 0.904 [0.6847722062549159, 1.1298201101840017] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.999 [0.6879748024338997, 1.4462708796966735] | inconclusive-noisy | pass |
| full | paired | `sparse_array_200000` | 0.895 [0.7663100794664149, 1.2671552698188326] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.991 [0.7523845735678094, 1.2256247390094008] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.015 [0.9153968132461163, 1.0723167698380598] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.025 [0.863420449390055, 1.5789152541451403] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.995 [0.7886148103622166, 1.1286729538816955] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.001 [0.7758977742900662, 1.13116346624684] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.000 [0.8807355752276012, 1.045159413874711] | pass | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 1.162 [0.9476004200014281, 1.4835083463804382] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.015 [0.6806453343796705, 1.3012203320828248] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.085 [0.8005507631140224, 1.2190962441083053] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.008 [0.8964279058179688, 1.2693844291848948] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.994 [0.9150820391386907, 1.3169174297044735] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.061 [0.9259621581929726, 1.1386505275603123] | inconclusive-noisy | pass |
| full | paired | `file_statements_20000` | 1.040 [0.9276952409063228, 1.225117404387043] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 1.012 [0.9353961931610456, 1.0855150212715048] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale1024_x30` | 1.090 [0.9631995941265298, 1.468064907864731] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.983 [0.7156106785359071, 1.4832665090601223] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.034 [0.9107468020980769, 1.1066755437631928] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.077 [0.883772604359859, 1.3819302140510688] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.082 [0.9642883053124112, 1.482393079654125] | inconclusive-noisy | inconclusive-noisy |
