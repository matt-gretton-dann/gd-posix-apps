# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.006 [0.9312012574831222, 1.0918405258664627] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.995 [0.9678569814154758, 1.017013352557582] | pass |
| full | aa | `calls_200000` | 0.990 [0.9841414569210202, 1.0019145042090842] | pass |
| full | aa | `array_200000` | 1.000 [0.9904259663654672, 1.0088026777886099] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.009 [0.9891542662655747, 1.0574626644687117] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.999 [0.9162949272173903, 1.0239461200827555] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.001 [0.9905150002439441, 1.081327075657778] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.993 [0.9771127152148756, 1.002455610452866] | pass |
| full | aa | `factorial_1000_x50` | 1.006 [0.9829805253976467, 1.0323859881032766] | pass |
| full | aa | `multiply_100d_x100000` | 0.996 [0.9897834622932327, 1.023940138651374] | pass |
| full | aa | `multiply_10000d_x1000` | 0.996 [0.9910754840011259, 1.010707399827752] | pass |
| full | aa | `divide_scale100_x100000` | 0.985 [0.9540217640338605, 0.9953970080549489] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.001 [0.9734123548400968, 1.0138849713052998] | pass |
| full | aa | `sqrt_scale5000_x5` | 0.999 [0.9890911100770357, 1.0059319347011664] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.003 [0.9945640074470856, 1.0181722586554862] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9840777700911322, 1.0253097522457268] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.988298664606605, 1.0445473477636324] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.007 [0.9855483561314216, 1.0250852312830154] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.006 [0.9968926756706882, 1.0158663549719205] | pass |
| full | aa | `power_100d_e17_x1000` | 1.007 [0.972520916058227, 1.0196941178089032] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.005 [0.9862465606235445, 1.014900468384968] | pass |
| full | aa | `recursion_50_x1000` | 1.014 [0.987269705435107, 1.0239170693713349] | pass |
| full | aa | `sparse_array_200000` | 1.006 [0.9869954471138027, 1.0324799152862998] | pass |
| full | aa | `frontend_definitions_2000` | 1.010 [0.9602649174461116, 1.0202911794632543] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.011 [0.9889401658345937, 1.0373540922747044] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.012 [0.9546608002584634, 1.0393001182638513] | pass |
| full | aa | `streaming_statements_20000` | 0.995 [0.9376172379682384, 1.006701867807349] | pass |
| full | aa | `square_100d_x100000` | 0.985 [0.9824915036848645, 0.9974438226421181] | pass |
| full | aa | `square_10000d_x500` | 0.997 [0.9929849597656725, 1.0031933240445796] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.017 [0.9382163850956875, 1.0461204370807404] | pass |
| full | aa | `binary_output_1000d_x300` | 0.989 [0.950632174785073, 1.036511405853799] | pass |
| full | aa | `octal_output_1000d_x300` | 1.009 [0.973089136757685, 1.024696467372146] | pass |
| full | aa | `binary_input_100000d_x3` | 0.997 [0.8746490629026329, 1.0087687228116837] | pass |
| full | aa | `hex_input_100000d_x3` | 0.999 [0.9961917625951452, 1.0131853726402884] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.002 [0.9700949950930519, 1.0153044335332115] | pass |
| full | aa | `file_statements_20000` | 1.003 [0.9763600190383029, 1.056060915621815] | inconclusive-noisy |
| full | aa | `sqrt_large_scale10000_x5` | 1.001 [0.9924285778639762, 1.003444061957444] | pass |
| full | aa | `sqrt_tiny_scale1024_x30` | 0.996 [0.9535891453113304, 1.051371891393068] | inconclusive-noisy |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.007 [0.9606893057914642, 1.0386022465786253] | pass |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.002 [0.9946258046734239, 1.008321586280053] | pass |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.988 [0.9619397449924215, 1.0007115591339253] | pass |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.981 [0.9717171107694876, 0.9999785009416149] | pass |
| full | paired | `startup` | 0.992 [0.954849149175955, 1.0162467466337777] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.110 [1.0790109998329886, 1.1284071781716207] | confirmed regression |
| full | paired | `calls_200000` | 1.020 [0.9884584013753713, 1.045502487036293] | pass |
| full | paired | `array_200000` | 1.076 [0.9511450940667232, 1.089395666895452] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.083 [1.0492980416364908, 1.0969757545647265] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.027 [0.9849491956247314, 1.0311593458880983] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.029 [1.023794309027294, 1.0441551188520768] | pass |
| full | paired | `fibonacci_1000_x100` | 1.002 [0.9031307487906604, 1.0128275519534837] | pass |
| full | paired | `factorial_1000_x50` | 1.014 [0.9944966176942768, 1.0236159916712158] | pass |
| full | paired | `multiply_100d_x100000` | 1.014 [0.9185843021896438, 1.0874485253652955] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.990 [0.9743631032392429, 1.0029722792253475] | pass |
| full | paired | `divide_scale100_x100000` | 1.018 [0.8646229620402446, 1.0489005763729382] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.013 [0.9972251510832764, 1.0216551458938339] | pass |
| full | paired | `sqrt_scale5000_x5` | 0.267 [0.26029460460534365, 0.31971404979291157] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.993 [0.9491127101254865, 1.0119455787042908] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.011 [0.9983692021698825, 1.0374003311940205] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.994 [0.9859529650898584, 1.061291033332486] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.006 [0.9678172350473465, 1.03769678758091] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.997 [0.943100190325991, 1.0089592579006141] | pass |
| full | paired | `power_100d_e17_x1000` | 0.994 [0.8821384285522564, 1.0411992868658921] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.054 [1.0201787904551256, 1.0876927307131805] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.998 [0.9779207297601777, 1.0763731024422731] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.013 [0.976446065600927, 1.0483336137545118] | pass |
| full | paired | `frontend_definitions_2000` | 0.997 [0.9588659315407723, 1.2536999578247643] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.991 [0.9713822109903573, 1.0295078230312518] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.985 [0.9557853254624689, 1.1578650852348642] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.038 [0.9778489720934016, 1.0552964575546993] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.022 [0.9048529541154254, 1.0718907769430306] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.997 [0.9920970066740208, 1.0029707636971315] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.001 [0.9859489719892545, 1.0634380888448964] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.001 [0.9935600985449691, 1.0278681312358413] | pass |
| full | paired | `octal_output_1000d_x300` | 0.995 [0.9693627902519134, 1.0489387440903915] | pass |
| full | paired | `binary_input_100000d_x3` | 0.989 [0.878971546306359, 1.0421968941441655] | pass |
| full | paired | `hex_input_100000d_x3` | 0.994 [0.9891067890067402, 1.036115792577494] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.013 [1.0003562433638098, 1.0438870122574015] | pass |
| full | paired | `file_statements_20000` | 1.010 [0.9903704269334718, 1.135843495954487] | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 0.216 [0.2148573296122313, 0.21862212052556548] | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.594 [0.5647590664008231, 0.6740783670705772] | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.707 [0.6416259624152688, 0.9110939060169294] | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.209 [0.20290500766760422, 0.21351370631009375] | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.013 [0.9891086808247157, 1.1590926309437908] | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.009 [0.9860548485417406, 1.0910271008884311] | inconclusive-noisy |
