# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.969 [0.8570108934263899, 1.1609743123628684] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.944 [0.8431756692476458, 1.114669858075855] | inconclusive-noisy | - |
| full | aa | `calls_200000` | 1.090 [0.756133986751611, 1.1759214573932004] | inconclusive-noisy | - |
| full | aa | `array_200000` | 1.014 [0.960339391761542, 1.050035020158254] | inconclusive-noisy | - |
| full | aa | `compare_high_1000d_x100000` | 0.981 [0.665956834290935, 1.0272645261211775] | inconclusive-noisy | - |
| full | aa | `compare_low_1000d_x100000` | 0.972 [0.9209645418061517, 1.1510086045669572] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.009 [0.8411357375990041, 1.165231191820737] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 0.747 [0.6843139827603171, 1.0116076935249285] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 1.012 [0.9252534287018096, 1.1940768851776609] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 0.974 [0.8434038191648563, 1.177791062654793] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 1.041 [0.9209353515500692, 1.1454027927177048] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 1.069 [0.887091727616111, 1.1865340832861322] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 1.021 [0.9215794847500154, 1.136628532083744] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 1.031 [0.9809325998494953, 1.3441211404899147] | inconclusive-noisy | - |
| full | aa | `multiply_dense_10000d_x500` | 1.006 [0.9612932622401357, 1.073824307264628] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.988 [0.8667630851477326, 1.0482738110003118] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.036 [0.880446122385113, 1.1799663894660803] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.020 [0.8904153683708459, 1.087162079175276] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.047 [0.8201135226043595, 1.059743024659119] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 1.011 [0.9027766223773482, 1.0414724289213257] | inconclusive-noisy | - |
| full | aa | `ibase_literal_flip_20000` | 0.972 [0.847488801722141, 1.4554131412883808] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 0.976 [0.8259775593664217, 1.2693517430104893] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 0.958 [0.8092732072763522, 1.0968514653843302] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 1.084 [0.9942988960571764, 1.2717680828332167] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 0.939 [0.898147600193913, 1.0686023469290704] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 0.994 [0.964270916913067, 1.318918078720468] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.016 [1.010613351478395, 1.2590762699161218] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 0.995 [0.9394246570152441, 1.0507053353977132] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 0.993 [0.9408757119536023, 1.0920204565702467] | inconclusive-noisy | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.991 [0.9057370938573325, 1.1991065603511697] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.322 [0.9907733781100381, 1.5818873493589125] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 0.985 [0.8387278402609353, 0.9890536735672607] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 1.017 [0.8498671119491107, 1.1463253558649575] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 1.005 [0.7740721489277141, 1.039921162467153] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.064 [0.8583188299182838, 1.122240593458186] | inconclusive-noisy | - |
| full | aa | `file_statements_20000` | 0.943 [0.89000772897504, 1.0157351043190552] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.024 [0.9352232950900113, 1.1487752343516715] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 0.995 [0.8899507032675394, 1.1235240514956852] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 0.982 [0.9081135411333362, 1.0411486397690473] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.886 [0.8245512690363738, 1.0256088818287226] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.986 [0.84805309262227, 1.2284388897800305] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.002 [0.9449946128283594, 1.3755283125411046] | inconclusive-noisy | - |
| full | paired | `startup` | 0.868 [0.7908398412236128, 1.1470949186180843] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.961 [0.9119846729453842, 1.096140463509966] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `calls_200000` | 1.073 [0.9635725748088856, 1.2264718508161279] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `array_200000` | 1.056 [0.8866446809643782, 1.2120522134331642] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.001 [0.893393659722534, 1.2621845336136461] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.993 [0.7823758007241892, 1.3197728534659237] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.035 [0.9593074022135932, 1.171035725930038] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.984 [0.8137253182329255, 1.2398497407967357] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.039 [0.9605937133617221, 1.141755218796513] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.075 [0.852426325851225, 1.2185197939570294] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.018 [0.8634125074952982, 1.079670271123834] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.077 [0.8472392425219826, 1.2416497740517083] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.963 [0.9342438584206958, 1.1942262755907371] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 1.001 [0.8834610039855528, 1.0829894161139066] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.013 [0.837799412063366, 1.067115563617756] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.979 [0.8646053200815899, 1.037210962461665] | pass | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.948 [0.8034919183884138, 1.2721484009227066] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.085 [0.835104599373784, 1.2730741359147038] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.025 [0.7425243856607386, 1.1567250307788104] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.897 [0.7969612592707963, 0.9943601776264492] | pass | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.989 [0.7583577615966132, 1.0904321855101795] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.980 [0.7572572045500467, 1.0691207939344216] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.000 [0.8466737141802632, 1.1277039508393296] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.220 [0.996496454310865, 1.5730349351350972] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.969 [0.8443112565082072, 1.0673715363566023] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.049 [0.6468487334203017, 1.6979640569616463] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.074 [1.0118659894872302, 1.212784847587619] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.987 [0.8608074478259228, 1.1462922902340111] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.999 [0.8580935998915991, 1.0495596469192545] | pass | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 1.116 [0.8276996743531819, 1.25354249746957] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.967 [0.7516316168256786, 1.0750574784394415] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.997 [0.9381395615902376, 1.2178215294085515] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.993 [0.723902753041342, 1.0439429472087436] | pass | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.998 [0.9900233417021741, 1.1654190383399008] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 0.902 [0.8573765166808293, 1.0318061989324876] | pass | inconclusive-noisy |
| full | paired | `file_statements_20000` | 1.029 [0.765248829119539, 1.2193737074964885] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 1.030 [0.9128395965863695, 1.1605395222060217] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.999 [0.8003492605144273, 1.3544436653226706] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.017 [0.7458962876926916, 1.5577178023309268] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.958 [0.9049035919766287, 1.1469642949828214] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.817 [0.6491266587969219, 1.252492733235465] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.058 [0.8205889791044161, 1.402315981629913] | inconclusive-noisy | inconclusive-noisy |
