# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.068 [0.8455667424525362, 1.3441850899632577] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 1.024 [0.9789072863513931, 1.0486028190867318] | pass | - |
| full | aa | `calls_200000` | 1.009 [0.9301154053585688, 1.0128430477155093] | inconclusive-noisy | - |
| full | aa | `array_200000` | 1.000 [0.957658874643143, 1.0241881203323944] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.017 [0.9736001438707509, 1.087163520252482] | inconclusive-noisy | - |
| full | aa | `compare_low_1000d_x100000` | 0.992 [0.9626082327167242, 1.012756086117715] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 0.985 [0.9623083765505949, 1.028695160252156] | pass | - |
| full | aa | `fibonacci_1000_x100` | 0.997 [0.986141026419869, 1.045754458828307] | pass | - |
| full | aa | `factorial_1000_x50` | 1.007 [0.9817359955497068, 1.032937290586192] | pass | - |
| full | aa | `multiply_100d_x100000` | 1.007 [0.9788908579950519, 1.0374511609032595] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9811647009351024, 1.0682608511777905] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 1.010 [0.9749615075200058, 1.123344419447097] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 1.042 [1.0117060473622004, 1.0587195961450824] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 0.999 [0.9664818961161982, 1.0415076478591292] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 0.997 [0.9939038007937906, 1.013232473625125] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9864575371667439, 1.029372115418674] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.005 [0.986744263320426, 1.037401391092217] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.9709579108811311, 1.028936476516704] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.997 [0.9810801351348616, 1.0315842690654102] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.995 [0.9492339897026294, 1.0102418709387024] | inconclusive-noisy | - |
| full | aa | `ibase_literal_flip_20000` | 1.004 [0.9780541967233335, 1.035122042111758] | pass | - |
| full | aa | `recursion_50_x1000` | 0.993 [0.856185877651468, 1.0328195541749134] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 0.976 [0.9155617936579198, 1.0124199720335116] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 1.003 [0.9848315636814756, 1.0431723205748908] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.013 [0.8520955576218093, 1.0276915703745193] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 0.995 [0.9482849691393231, 1.0554063627550436] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.987 [0.9198766988491975, 1.0588178615923958] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 1.008 [0.8355638898951536, 1.0202411357703358] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 0.995 [0.9904076682389583, 1.025876382895787] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.971 [0.8951559286976891, 1.0880431313881311] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.984 [0.9412260794938433, 1.0045655241220854] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 0.992 [0.9644254253801641, 1.0128002782948384] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.002 [0.9763181289482543, 1.0142441939641242] | pass | - |
| full | aa | `hex_input_100000d_x3` | 0.999 [0.9699927864037031, 1.0337979911722428] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.001 [0.9908360938789726, 1.0248640130794306] | pass | - |
| full | aa | `file_statements_20000` | 1.007 [0.9942789085056403, 1.0257628789356676] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 0.989 [0.9838844159062725, 1.0086349078803083] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.056 [0.9174495543301726, 1.0922921546285989] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.017 [0.9747039009027822, 1.0892919302340713] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.999 [0.9934871467837869, 1.0098423437445052] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.004 [0.9882640540147942, 1.0320488558381389] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.996 [0.9469842198221675, 1.051076786799976] | inconclusive-noisy | - |
| full | paired | `startup` | 0.998 [0.9697055185165736, 1.0561390324084612] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.007 [1.0008802484009234, 1.0430082379635985] | pass | pass |
| full | paired | `calls_200000` | 1.008 [0.9839772646783949, 1.0637020760634046] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `array_200000` | 1.001 [0.969602394429503, 1.0400661065904513] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 1.002 [0.9786936110071893, 1.0302881169146885] | pass | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.008 [0.9921093540582618, 1.0184792294313623] | pass | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.007 [0.9663033937210667, 1.0520103068248037] | inconclusive-noisy | pass |
| full | paired | `fibonacci_1000_x100` | 1.015 [0.9977677929643917, 1.0426222292612128] | pass | pass |
| full | paired | `factorial_1000_x50` | 1.011 [0.9804055542795033, 1.0467216606844458] | pass | pass |
| full | paired | `multiply_100d_x100000` | 0.998 [0.970709173715215, 1.002413781345535] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 1.002 [0.9897692583047327, 1.035436448648123] | pass | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.003 [0.9889263624642527, 1.016777011694123] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.988 [0.9689981780000927, 1.0257034787094328] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 0.997 [0.9893707123979468, 1.0090859986223601] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.988 [0.9635636108658202, 1.011479517421394] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.009 [0.9943249134301385, 1.0368608799057897] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.996 [0.9856803815292758, 1.014141301540948] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.010 [0.972356148500147, 1.0438291225946432] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.000 [0.9792607299865528, 1.0027835293155836] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 1.012 [0.9831379827626158, 1.021042715121477] | pass | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.990 [0.938579583907451, 1.0044516730070308] | pass | pass |
| full | paired | `recursion_50_x1000` | 1.008 [0.9728076411734864, 1.0254291463395748] | pass | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.009 [0.951497666914552, 1.0233059949335288] | pass | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.008 [0.956669402608534, 1.0634614422266828] | inconclusive-noisy | pass |
| full | paired | `decimal_input_4000d_x100` | 0.999 [0.9738333343494444, 1.0381328348445846] | pass | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.055 [0.9666253760394079, 1.0850295624586646] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.006 [0.9681092654069292, 1.0229710009506532] | pass | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.002 [0.9891603050787772, 1.029738319796221] | pass | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.005 [0.9945322339061244, 1.015415545774089] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.989 [0.886857817944129, 1.0275623520935238] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.007 [0.9698461632818877, 1.0321145844031645] | pass | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.982 [0.9721595089635171, 1.0324884420875757] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.991 [0.9842254164021057, 1.0062084537950298] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.999 [0.985726008071212, 1.0163683404094208] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.998 [0.989490437420089, 1.014414030463603] | pass | pass |
| full | paired | `file_statements_20000` | 0.982 [0.8866585823283095, 1.0399546816387395] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 0.994 [0.9835884436994251, 1.0459841393465945] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.927 [0.9126757033374522, 1.0115635446942517] | pass | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.008 [0.9948461740950101, 1.1057913883613382] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.996 [0.9839268706025199, 1.0287845183306348] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.941 [0.903342219910212, 1.0572699504037788] | inconclusive-noisy | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.975 [0.9537970069845458, 0.9989646374366278] | pass | inconclusive-noisy |
