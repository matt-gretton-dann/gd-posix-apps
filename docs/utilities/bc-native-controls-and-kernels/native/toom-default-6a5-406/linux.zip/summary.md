# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.853 [0.7841323996549587, 1.1445618459961073] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.999 [0.9983056616977544, 1.0093943753138608] | pass | - |
| full | aa | `calls_200000` | 0.996 [0.9860617954713328, 1.0089473978775314] | pass | - |
| full | aa | `array_200000` | 1.000 [0.9930283420015874, 1.006527220505848] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.015 [0.9918778760205959, 1.027275793112574] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 0.994 [0.9840389825302172, 1.0231470560714255] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 0.996 [0.9781833499211003, 1.0047633732674075] | pass | - |
| full | aa | `fibonacci_1000_x100` | 1.011 [0.9999933283755326, 1.0242000436244967] | pass | - |
| full | aa | `factorial_1000_x50` | 1.008 [0.9942525184106719, 1.015928252611347] | pass | - |
| full | aa | `multiply_100d_x100000` | 1.005 [0.9856391561655048, 1.0118552317255418] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.002 [0.9948733990795063, 1.0176006795881425] | pass | - |
| full | aa | `divide_scale100_x100000` | 1.003 [0.9866380290161837, 1.0132063280209116] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.005 [0.9951082944970778, 1.0209127291463371] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 0.998 [0.991422879387002, 1.0118475662886344] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.009 [0.9911791713372164, 1.0174342306514075] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.007 [0.9716254901796287, 1.0176192675654518] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.993 [0.9747845866051905, 1.0126464456455877] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.9738662925385638, 1.04442523848412] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.001 [0.9843831061557723, 1.0141455694584598] | pass | - |
| full | aa | `power_100d_e17_x1000` | 1.000 [0.9832104024742941, 1.0143539184070314] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.008 [0.9814284219050685, 1.0476829559104914] | pass | - |
| full | aa | `recursion_50_x1000` | 0.998 [0.9863977550021974, 1.0155987439175935] | pass | - |
| full | aa | `sparse_array_200000` | 0.989 [0.9834982301081368, 1.0109932310893146] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.005 [0.977725794768002, 1.0194594918599786] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9932772657573534, 1.0158896514217821] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 0.997 [0.9226943736784727, 1.0377722464907508] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.998 [0.9799081849360142, 1.0168468020018033] | pass | - |
| full | aa | `square_100d_x100000` | 1.003 [0.9906050832521852, 1.0128542872775506] | pass | - |
| full | aa | `square_10000d_x500` | 0.997 [0.9887676003359736, 1.0121045644592408] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 1.002 [0.8890918406510343, 1.0725026786397431] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.996 [0.9598615481201981, 1.0097914542760855] | pass | - |
| full | aa | `octal_output_1000d_x300` | 0.999 [0.9904593964547798, 1.008940214951757] | pass | - |
| full | aa | `binary_input_100000d_x3` | 0.997 [0.9925003086231339, 1.0106899207684512] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.006 [0.9908825367876704, 1.0117091982748747] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.004 [0.9923693102278868, 1.0075428085401172] | pass | - |
| full | aa | `file_statements_20000` | 0.996 [0.9848595382518464, 1.0305714838066014] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.002 [0.9956760497980448, 1.0051671434332066] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 0.994 [0.9693389788590903, 1.0414050763320215] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 0.997 [0.9754159990341812, 1.043289194426455] | pass | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.000 [0.992464555982417, 1.0189167537610468] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.989 [0.9673038770332094, 0.9978159395458546] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.006 [0.9731839609134746, 1.0273595406782494] | pass | - |
| full | paired | `startup` | 1.039 [0.9379487661497172, 1.0781369149461753] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.006 [0.9941055769541268, 1.018432883185865] | pass | pass |
| full | paired | `calls_200000` | 0.994 [0.9780553627664285, 1.0017241291862928] | pass | pass |
| full | paired | `array_200000` | 1.001 [0.9862503897696725, 1.0091985394031973] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 1.003 [0.9795856871571815, 1.0102061204305997] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 1.001 [0.9931291797648378, 1.0064565344622238] | pass | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.995 [0.9793475108895968, 1.0017941187000723] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 1.002 [0.996512313289825, 1.0152284755692216] | pass | pass |
| full | paired | `factorial_1000_x50` | 1.004 [0.9913783939112101, 1.005652075633606] | pass | pass |
| full | paired | `multiply_100d_x100000` | 1.001 [0.9811249827149996, 1.025801515074882] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 0.987 [0.9448837308017535, 1.0113908066427655] | pass | pass |
| full | paired | `divide_scale100_x100000` | 0.998 [0.9838729172189313, 1.0076373595766555] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 0.998 [0.9831050288890505, 1.0134561470171566] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 0.996 [0.98902354155721, 1.0077848595227537] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.005 [0.991709086976849, 1.0198921436920643] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.978676746935718, 1.006184459078969] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.009 [0.999310497118819, 1.026197001660367] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.003 [0.9833682168439277, 1.0271242118520578] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.994 [0.9850242971649338, 1.00403645051177] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 1.006 [0.9882729327532919, 1.0142831471016038] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 1.004 [0.9735131455352949, 1.0124272733337256] | pass | pass |
| full | paired | `recursion_50_x1000` | 1.004 [0.9871293021955736, 1.0061311858371413] | pass | pass |
| full | paired | `sparse_array_200000` | 1.003 [0.9943607126789612, 1.0159311369170605] | pass | pass |
| full | paired | `frontend_definitions_2000` | 0.994 [0.9760134140159906, 1.0171838784573222] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 1.005 [0.9923843533004008, 1.0254780674517625] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 1.066 [1.034192304340952, 1.1405320124763336] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.004 [0.9875707613800331, 1.022939560791925] | pass | pass |
| full | paired | `square_100d_x100000` | 1.000 [0.986599637005546, 1.0152028193154672] | pass | pass |
| full | paired | `square_10000d_x500` | 1.003 [0.9943090145505065, 1.006878627300059] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.973 [0.8841632388225132, 1.0315291940132743] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.990 [0.9694818305183105, 1.0032138181010894] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 0.983 [0.9510728911966888, 1.011315726553] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.995 [0.979650734304693, 1.0166291500423863] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.998 [0.9802538638329054, 1.0092638840539703] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.007 [0.9840257216138136, 1.0098728261269836] | pass | pass |
| full | paired | `file_statements_20000` | 0.991 [0.9759527413833319, 1.013386884543266] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.001 [0.9879158877863281, 1.004749693718915] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.987 [0.9464157351316372, 1.0224072037297194] | pass | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.995 [0.9465793786278376, 1.0437331804294279] | pass | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.002 [0.9811373759016188, 1.0116077512829764] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.001 [0.8518691145776571, 1.0258094070205512] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.976 [0.9617685771066173, 1.0231202348686217] | pass | pass |
