# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.006 [0.9514849635687195, 1.0368249432479395] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.840 [0.8385137161518448, 0.8576429926769162] | confirmed A/A bias | - |
| full | aa | `calls_200000` | 0.972 [0.966091956019212, 1.0011553289547426] | pass | - |
| full | aa | `array_200000` | 0.855 [0.8374557776265587, 0.8778501374313384] | confirmed A/A bias | - |
| full | aa | `compare_high_1000d_x100000` | 0.922 [0.9078795677727749, 0.9319113756543308] | confirmed A/A bias | - |
| full | aa | `compare_low_1000d_x100000` | 0.931 [0.9200714540145466, 0.9435423079133693] | confirmed A/A bias | - |
| full | aa | `compare_equal_1000d_x100000` | 0.931 [0.9173935388795721, 0.9333624319254982] | confirmed A/A bias | - |
| full | aa | `fibonacci_1000_x100` | 0.958 [0.9533218651934743, 0.969768719010666] | pass | - |
| full | aa | `factorial_1000_x50` | 0.978 [0.9506909789738885, 0.9829698468580716] | pass | - |
| full | aa | `multiply_100d_x100000` | 0.957 [0.9415370039541534, 0.9636585632177207] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 0.997 [0.9848373236470089, 1.008897108362134] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.924 [0.9092209041699063, 0.9417042638023455] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 1.000 [0.990966121285076, 1.0454992909889094] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.001 [0.9972258646703264, 1.0099415630763697] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 0.993 [0.9794744559624848, 1.0089210195650142] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9927669577352225, 1.024429765910438] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.995 [0.9492062108325102, 1.0060759148510625] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.9830356708385277, 1.0095683460294196] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.993 [0.989410996842049, 1.0111819201045527] | pass | - |
| full | aa | `power_100d_e17_x1000` | 1.001 [0.9923039494505814, 1.00964254207396] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 0.930 [0.9217467837664088, 0.9379529287855939] | confirmed A/A bias | - |
| full | aa | `recursion_50_x1000` | 0.982 [0.9752420772120801, 0.9990293889822919] | pass | - |
| full | aa | `sparse_array_200000` | 1.002 [0.9771971637820279, 1.025774885813798] | pass | - |
| full | aa | `frontend_definitions_2000` | 0.985 [0.9516817715109172, 1.0416825409163302] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 0.996 [0.9913738754089308, 1.0184301521454968] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.002 [0.9656794980859281, 1.0166145731579337] | pass | - |
| full | aa | `streaming_statements_20000` | 1.004 [1.000370143419446, 1.035712041626512] | pass | - |
| full | aa | `square_100d_x100000` | 0.980 [0.9742853261375592, 0.9941057891172617] | pass | - |
| full | aa | `square_10000d_x500` | 1.002 [0.997863938649152, 1.009202166599378] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.974 [0.9297127977449314, 1.0196956228405933] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.018 [0.9918910724237388, 1.027637312534752] | pass | - |
| full | aa | `octal_output_1000d_x300` | 1.006 [0.954270009782913, 1.0192992874093405] | pass | - |
| full | aa | `binary_input_100000d_x3` | 0.994 [0.9843400323823902, 1.0017095756018923] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.005 [0.9867331174671438, 1.0121596206288905] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.983 [0.9808369560218392, 0.9880415887767146] | pass | - |
| full | aa | `file_statements_20000` | 1.000 [0.949909635266434, 1.0257414707131256] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 0.999 [0.9978656492493022, 1.0016940192564638] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.007 [0.987429062534051, 1.0212587677190603] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.001 [0.94326571733647, 1.0125763860837436] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.996 [0.9904378125587239, 1.0049931187780243] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.981 [0.9616713489852624, 0.989713297796266] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.997 [0.9764811058013948, 1.0046860804298092] | pass | - |
| full | paired | `startup` | 0.980 [0.9614216058565657, 1.0168149169909246] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.845 [0.8066803331801039, 0.8739823809505607] | pass | confirmed A/A bias |
| full | paired | `calls_200000` | 0.988 [0.9729313929313332, 1.048722322665591] | pass | pass |
| full | paired | `array_200000` | 0.849 [0.8101147376525204, 0.8564483741431483] | pass | confirmed A/A bias |
| full | paired | `compare_high_1000d_x100000` | 0.909 [0.8979002538172124, 0.9251203176214648] | pass | confirmed A/A bias |
| full | paired | `compare_low_1000d_x100000` | 0.927 [0.8808505314859114, 0.9558221743539371] | pass | confirmed A/A bias |
| full | paired | `compare_equal_1000d_x100000` | 0.924 [0.9143889879183432, 0.941562706067825] | pass | confirmed A/A bias |
| full | paired | `fibonacci_1000_x100` | 0.960 [0.948408132553204, 0.9649502393430565] | pass | pass |
| full | paired | `factorial_1000_x50` | 0.978 [0.9634707206538141, 0.9950596387428906] | pass | pass |
| full | paired | `multiply_100d_x100000` | 0.940 [0.9122930344699108, 1.0208057954731278] | pass | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.005 [0.993562787246254, 1.0184308948658929] | pass | pass |
| full | paired | `divide_scale100_x100000` | 0.917 [0.8759879904698881, 0.9289501929160632] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.004 [0.9568071607427935, 1.0142365811569798] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 0.997 [0.9943401664699707, 1.011079966301478] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.979 [0.9665767921033441, 1.0315691023699955] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.7951353675649121, 1.0169162970340169] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.003 [0.9585186385967567, 1.0193990771026518] | pass | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.009 [0.9962148962105776, 1.125166529523171] | inconclusive-noisy | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.002 [0.9881188737660989, 1.0597449742763039] | inconclusive-noisy | pass |
| full | paired | `power_100d_e17_x1000` | 1.002 [0.9867623702303662, 1.0094363357496936] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 0.928 [0.9182031595622129, 0.9411605399881876] | pass | confirmed A/A bias |
| full | paired | `recursion_50_x1000` | 0.965 [0.9237654389146893, 0.9732864131323486] | pass | pass |
| full | paired | `sparse_array_200000` | 0.994 [0.9611000782575254, 1.0119824896761822] | pass | pass |
| full | paired | `frontend_definitions_2000` | 1.004 [0.9644768610412886, 1.0268496757577767] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 0.998 [0.9518196630046506, 1.0034875996431774] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 0.995 [0.9589377025325599, 1.033927900672688] | pass | pass |
| full | paired | `streaming_statements_20000` | 1.001 [0.947379058889742, 1.0315461140007516] | pass | pass |
| full | paired | `square_100d_x100000` | 0.944 [0.9331486684531568, 0.9799039734487539] | pass | pass |
| full | paired | `square_10000d_x500` | 0.999 [0.9944906249381197, 1.006268903446163] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.031 [0.9602861807518429, 1.0541865136326465] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.007 [0.9450746626311274, 1.0157606039188] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 1.008 [0.990825849155851, 1.1522870980476423] | inconclusive-noisy | pass |
| full | paired | `binary_input_100000d_x3` | 1.000 [0.9854824112206171, 1.0074514681553006] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 1.001 [0.9952591116457019, 1.0371158473257867] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.994 [0.9714833849851249, 1.0206470835539818] | pass | pass |
| full | paired | `file_statements_20000` | 1.021 [0.9903680545918646, 1.2630145318468085] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 1.000 [0.9992969188057089, 1.0028665322349393] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 1.013 [0.9705697591930565, 1.0330383708843183] | pass | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.007 [0.9502996502791277, 1.0873493975925965] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.003 [0.9957826890928668, 1.0128845243953315] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.976 [0.9551279438010958, 1.0108498464977431] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.006 [0.9744865899274959, 1.0539887986481873] | inconclusive-noisy | pass |
