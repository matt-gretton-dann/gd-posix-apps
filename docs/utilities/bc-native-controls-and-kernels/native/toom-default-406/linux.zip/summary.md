# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.916 [0.8149954895906599, 1.1499880085653036] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.998 [0.9928606810260099, 1.0135813490444663] | pass | - |
| full | aa | `calls_200000` | 1.014 [1.0051616067141202, 1.0299071079718036] | pass | - |
| full | aa | `array_200000` | 1.005 [0.9888692806746564, 1.0136688703304082] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 0.991 [0.9412736140888575, 1.0085378907906566] | inconclusive-noisy | - |
| full | aa | `compare_low_1000d_x100000` | 1.015 [0.9843042522129644, 1.055283425616082] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.004 [0.9743262007923496, 1.023521587507518] | pass | - |
| full | aa | `fibonacci_1000_x100` | 0.986 [0.9595418537226666, 1.025595525803875] | pass | - |
| full | aa | `factorial_1000_x50` | 1.000 [0.9712631651548307, 1.0272429620133223] | pass | - |
| full | aa | `multiply_100d_x100000` | 0.990 [0.9253501272564969, 1.0076930363996364] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 0.999 [0.9982459381317194, 1.0051775574688466] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.999 [0.9715708441634542, 1.0555338017939178] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 1.003 [0.9425448213570956, 1.0359029517004295] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 1.007 [0.998283486636619, 1.0159617329121962] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.005 [0.8748190176470599, 1.0248228026580706] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.006 [0.9455752007854827, 1.0348594771488817] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9936409696686757, 1.0167113005044064] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.009 [0.9133265089810049, 1.05578511495754] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.023 [1.0026675289228106, 1.0449646403710053] | pass | - |
| full | aa | `power_100d_e17_x1000` | 1.006 [0.9895330452824397, 1.0266549689889568] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.015 [0.9674577955779837, 1.0692958609942165] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 1.019 [0.9325971221910893, 1.0429216182690186] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 1.000 [0.9832490802726991, 1.0179264622197648] | pass | - |
| full | aa | `frontend_definitions_2000` | 0.987 [0.9236162838035153, 1.0546532032018545] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 1.006 [0.999479239148234, 1.0289008361674334] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.014 [0.9207353303039749, 1.105297951368143] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.997 [0.9890884972817418, 1.0358825985484978] | pass | - |
| full | aa | `square_100d_x100000` | 1.003 [0.954594226324915, 1.0197701219240995] | pass | - |
| full | aa | `square_10000d_x500` | 0.988 [0.984314392543876, 0.9951470644498522] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 1.043 [0.9349893825382117, 1.094248837879331] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.988 [0.9414535935930347, 1.0407471567293662] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 0.988 [0.9748996673345831, 1.0371800220159453] | pass | - |
| full | aa | `binary_input_100000d_x3` | 0.998 [0.9426756958188804, 1.0394160597044224] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 1.006 [0.9827089408432784, 1.022464991852049] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.006 [0.9991351902227817, 1.010805104853179] | pass | - |
| full | aa | `file_statements_20000` | 1.000 [0.9539108881624774, 1.0445737309954182] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 0.994 [0.9889497657704044, 1.0085876234642932] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.034 [0.9909460235742645, 1.0646650851782802] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.041 [1.018600113237013, 1.2480007411110303] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.006 [0.956833559421231, 1.0305293512610656] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.981 [0.9530795354125795, 0.998138159562504] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.032 [0.9942945551597235, 1.077548826115272] | inconclusive-noisy | - |
| full | paired | `startup` | 1.033 [0.884740054557193, 1.0643500135725845] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.996 [0.9799521598782864, 1.0117110709196238] | pass | pass |
| full | paired | `calls_200000` | 1.009 [0.9850917031875146, 1.0229992359178626] | pass | pass |
| full | paired | `array_200000` | 0.984 [0.967686701498154, 1.0033767213651938] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 0.987 [0.946506302864741, 1.0048190346477037] | pass | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.999 [0.9555796295058351, 1.052552429463216] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.984 [0.966983321275586, 1.007829422309335] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 1.023 [0.9692022567921001, 1.027115653975545] | pass | pass |
| full | paired | `factorial_1000_x50` | 1.023 [0.9998087658378791, 1.0353279997190825] | pass | pass |
| full | paired | `multiply_100d_x100000` | 1.014 [0.9631801587042643, 1.049787281461792] | pass | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.008 [0.9884255126646505, 1.0275159144586092] | pass | pass |
| full | paired | `divide_scale100_x100000` | 1.006 [0.9809666923516528, 1.0303510910806661] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.983 [0.957790900966748, 0.997509348971704] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 1.004 [0.9956476087522266, 1.0152254280474] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.988 [0.9583700001798062, 1.0216105092902013] | pass | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9726508470055858, 1.0265342214214137] | pass | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.014 [0.9831704106833514, 1.0526047759636628] | inconclusive-noisy | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.018 [0.9603389787423043, 1.110050855561252] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.995 [0.9704289653114465, 1.0340502483434868] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.997 [0.9646351042708211, 1.0465804772860217] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 0.989 [0.9821528543755615, 1.0274537510849717] | pass | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.025 [0.9778093898409036, 1.0547020761400685] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.994 [0.9760312982507612, 1.0135775595610013] | pass | pass |
| full | paired | `frontend_definitions_2000` | 0.986 [0.9442955381990584, 1.0298914137793973] | pass | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.995 [0.9513373444025355, 1.0474102852285212] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 0.994 [0.9698129443275548, 1.0780159978169486] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.994 [0.9625727292770986, 1.0144390780615373] | pass | pass |
| full | paired | `square_100d_x100000` | 1.017 [0.9767927376699211, 1.051394230080016] | inconclusive-noisy | pass |
| full | paired | `square_10000d_x500` | 0.993 [0.9829111531044558, 0.9992666664350685] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.975 [0.8336632586572402, 1.111109887349492] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.031 [0.9839113732780991, 1.0354397521224667] | pass | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.012 [0.9829822155337135, 1.0431060222209247] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.976 [0.96127898076144, 1.027144930384551] | pass | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 1.018 [0.9899711633412954, 1.0321967967280623] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.005 [0.9849695123621613, 1.017944812578406] | pass | pass |
| full | paired | `file_statements_20000` | 1.005 [0.9721513001000179, 1.0418146393185996] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 0.998 [0.9808981181909185, 1.026256740319302] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.971 [0.9187139864688673, 1.0294952945413733] | pass | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.038 [0.8900425707288274, 1.0501137332088533] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.991 [0.9024044278628861, 1.014638140933656] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.984 [0.8970479893455311, 1.0712504530825697] | inconclusive-noisy | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.956 [0.940520184897805, 0.9811820563196246] | pass | inconclusive-noisy |
