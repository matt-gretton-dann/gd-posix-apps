# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.902 [0.7906542894807325, 1.1302704934930181] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.968 [0.8457986644949639, 1.1274062084495018] | inconclusive-noisy | - |
| full | aa | `calls_200000` | 1.063 [1.0146928764389351, 1.3990215546996998] | inconclusive-noisy | - |
| full | aa | `array_200000` | 1.027 [0.9926942633438156, 1.123001153803414] | inconclusive-noisy | - |
| full | aa | `compare_high_1000d_x100000` | 0.945 [0.8267504808993128, 0.990330225009033] | inconclusive-noisy | - |
| full | aa | `compare_low_1000d_x100000` | 1.006 [0.8535503482646842, 1.1811799847311164] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.029 [0.9316149109726849, 1.1701434397648312] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 1.018 [0.9174900969102566, 1.078796478679939] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 0.932 [0.9019712426832465, 1.0944282699030334] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 1.071 [0.9738081071592799, 1.200874848447976] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 0.985 [0.9019314631765503, 1.1528740077054158] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 0.980 [0.8772415085152642, 1.0745140372769921] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 1.015 [0.9663658218816115, 1.0327885197448428] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.025 [0.8739114800929358, 1.129985488149301] | inconclusive-noisy | - |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9303911062120119, 1.0987803382988546] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.977 [0.8792677575196497, 1.1466816174605459] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9415573214952576, 1.0483964697723596] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.973 [0.8396580079275182, 1.1050617925046526] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.995 [0.9602344984824657, 1.1756129122859833] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 1.020 [0.9455131467342325, 1.085043727442365] | inconclusive-noisy | - |
| full | aa | `ibase_literal_flip_20000` | 0.911 [0.7436240853481481, 1.0212686001752012] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 0.998 [0.758918961088226, 1.3118863694103755] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 0.945 [0.8508212123052201, 1.1949403254526587] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 1.044 [0.888582587545023, 1.220389918600222] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 1.065 [0.9372443041451171, 1.2032162663324313] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 1.396 [0.977754331971941, 1.6856453636014024] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.005 [0.9322239174829628, 1.446223892324837] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 1.005 [0.9556114914207849, 1.1399130797562942] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 1.068 [1.0430742894152933, 1.104630124091516] | inconclusive-noisy | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.943 [0.6841673279891082, 1.0892616792668508] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.966 [0.639653491123063, 1.0321026415226735] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 0.996 [0.9871945898815533, 1.051886144452372] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 1.071 [0.8827373039442015, 1.1857679850026654] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 1.022 [0.9796149167142487, 1.0628014496575726] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.978 [0.897362942965391, 1.100331202879903] | inconclusive-noisy | - |
| full | aa | `file_statements_20000` | 0.997 [0.9147754574401932, 1.4097767950465985] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.011 [0.9883112753256434, 1.0973991141523596] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.034 [0.7641268707822684, 1.116133412775245] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.031 [0.7966258683881081, 1.185530539649943] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.005 [0.9105554758006841, 1.050160586538396] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.082 [0.8868123753030618, 1.2770692779184738] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.984 [0.6598704530216775, 1.0266692796465022] | inconclusive-noisy | - |
| full | paired | `startup` | 0.922 [0.7088233239449864, 1.0247227068904672] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.059 [0.9893935677734469, 1.1885717017483879] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `calls_200000` | 1.009 [0.9703463112106792, 1.0800211271309614] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `array_200000` | 0.949 [0.8451891457313038, 1.141881556055832] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.012 [0.9564732287991199, 1.3040556733518576] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.981 [0.720632606004379, 1.0914667847840827] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.998 [0.9506627248722163, 1.072404493627349] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.017 [0.8057433087384801, 1.284618057465894] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.986 [0.9143412582657506, 1.1002874749116416] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.996 [0.7586157072015857, 1.043137099697416] | pass | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.062 [0.962415377513818, 1.0955250100523903] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.007 [0.727184211675595, 1.3967557357168972] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.066 [0.9946282305422198, 1.2104144575746574] | inconclusive-noisy | pass |
| full | paired | `sqrt_scale5000_x5` | 0.945 [0.829486651208606, 1.0196981982320192] | pass | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.000 [0.9832730947705467, 1.02042952987782] | pass | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.931 [0.7931364840690938, 1.0212208239554923] | pass | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.019 [0.9391206327791013, 1.1424077492131397] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.023 [1.0079960685320046, 1.0438552071349971] | pass | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.907 [0.4197740039729433, 1.0023453605580457] | pass | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.015 [0.9622931302470934, 1.0602569589578303] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.058 [0.950205876945313, 1.266144366514854] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.009 [0.8624874097842913, 1.0112056782490524] | pass | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.931 [0.8397672094188487, 1.0163831996069157] | pass | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.016 [0.8028014708193497, 1.3053358864886409] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.991 [0.8434380917694123, 1.086264021804069] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.183 [1.0172057097872664, 1.265625204221144] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.976 [0.9433940053341197, 1.1616538052608567] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.034 [0.8375834500505928, 1.1300974461237803] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.965 [0.9383819640999154, 1.158774227985665] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 1.004 [0.8337335763463715, 1.0900887344415273] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.021 [0.8452896639833016, 1.1030892584926064] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.969 [0.9370007512692226, 1.0426207562183816] | pass | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.064 [0.9032720228173646, 1.2768481875190318] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.967 [0.8273542814230027, 0.9923905970303691] | pass | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 0.995 [0.9587212436992986, 1.104905122528632] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `file_statements_20000` | 0.975 [0.88427880620591, 1.0771446595955045] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 1.037 [1.0004665814319558, 1.0732118318463746] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale1024_x30` | 1.056 [0.5404706809133888, 1.1208722860663696] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.996 [0.8131353040315512, 1.1096672671452263] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.991 [0.9225553475359607, 1.0453161917459504] | pass | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.020 [0.9523755259265454, 1.122344479096618] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.985 [0.8443044766824889, 1.162647226897973] | inconclusive-noisy | inconclusive-noisy |
