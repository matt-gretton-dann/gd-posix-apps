# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.925 [0.7269360786930743, 1.108434129044861] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.951 [0.9031543032827027, 1.0028879518979275] | inconclusive-noisy | - |
| full | aa | `calls_200000` | 1.068 [0.983740818593777, 1.1993496221808373] | inconclusive-noisy | - |
| full | aa | `array_200000` | 0.996 [0.8493033203496789, 1.0869005401358969] | inconclusive-noisy | - |
| full | aa | `compare_high_1000d_x100000` | 0.999 [0.8981978182910099, 1.0189826567095777] | inconclusive-noisy | - |
| full | aa | `compare_low_1000d_x100000` | 1.012 [0.9580867255076807, 1.104522259435116] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.004 [0.9124453120626536, 1.0199547717155795] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 0.989 [0.8609097197332063, 1.067980211070059] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 0.982 [0.8111786101413536, 1.0844464333580897] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 0.991 [0.7076806357579245, 1.0231908585653724] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 0.993 [0.9177886328068566, 1.079827235315829] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 0.974 [0.934078250063964, 1.1718149289661919] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 0.948 [0.8815149757230057, 1.0150492918400444] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 1.028 [0.9724389865212628, 1.0729967496353214] | inconclusive-noisy | - |
| full | aa | `multiply_dense_10000d_x500` | 1.010 [0.9371893551268724, 1.0730326139027906] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.051 [1.0232657982721935, 1.1753402801664363] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.8436583057568312, 1.024825545305852] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.989 [0.8922495916794643, 1.0057943406095597] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.005 [0.9876712755949804, 1.1500724866240832] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 1.009 [0.9894089859245088, 1.0787542475921266] | inconclusive-noisy | - |
| full | aa | `ibase_literal_flip_20000` | 1.076 [0.7482462047383379, 1.4282398816823376] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 1.031 [0.6843359136901478, 1.112889263450822] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 1.005 [0.8952206552636023, 1.0997999983717484] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 0.972 [0.7431446601919568, 1.0213578515662405] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 0.989 [0.878349035829837, 1.3504578188004421] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 1.019 [0.7770134801248316, 1.2432152436709314] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.043 [0.9477681581633859, 1.2752821180535667] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 1.047 [0.8505809184636889, 1.130388278421267] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 1.033 [0.9663531240614003, 1.084916376046351] | inconclusive-noisy | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.951 [0.8848422889037184, 1.2016477835356345] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.963 [0.8644428158686027, 1.0135236490263473] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 0.961 [0.8748503531778508, 1.0256485260041392] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 1.039 [0.9943730327927762, 1.079075696865406] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 1.060 [1.0077002778411233, 1.1483987764913768] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.990 [0.9325138933446777, 1.0475367754264964] | inconclusive-noisy | - |
| full | aa | `file_statements_20000` | 0.948 [0.8581879179047238, 1.1421666829926418] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.051 [0.9780618140841849, 1.1224592887583207] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 0.975 [0.8532616684785971, 1.0290239170517272] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.070 [0.8841347284829456, 1.5665657689629937] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.047 [0.9645821540091927, 1.1984770293390483] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.006 [0.9787793759974667, 1.273828252851965] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.974 [0.7770960228335922, 1.1588392314383706] | inconclusive-noisy | - |
| full | paired | `startup` | 1.047 [0.8463836720403711, 1.2068320227321117] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.994 [0.9138264644666436, 1.125217330669061] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `calls_200000` | 0.991 [0.8400274992985548, 1.1101636172864449] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `array_200000` | 1.091 [0.9718712986561847, 1.1837080016333306] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.001 [0.7419157371875379, 1.0753581245856534] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.999 [0.9213928467351755, 1.116590185244537] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.906 [0.8753854791912823, 1.1729991103654795] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.197 [1.052838466268216, 1.354813039007241] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.004 [0.9120283884683559, 1.0805141779238867] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.011 [0.9484760233243301, 1.3011047126639672] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.005 [0.9174759847407463, 1.0829820351076955] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.029 [0.9018190981051245, 1.2065339213375306] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.037 [1.0012583320752326, 1.1051698915466346] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 0.957 [0.9299501280639316, 1.0426588397957552] | pass | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.001 [0.9536532575076014, 1.088921075710262] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.910 [0.8456024739525954, 1.251984548482423] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.009 [0.8962760840273285, 1.3277707492262278] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.876 [0.8095861288300072, 1.1210270582072486] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.983 [0.8658427306264697, 1.075704823140861] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.915 [0.7701341302299377, 1.1191846965436214] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.037 [0.9175941860221568, 1.2937215705516543] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.018 [0.8757624657159588, 1.1972109209896735] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.044 [0.8344594369453914, 1.182153277811386] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.960 [0.7529087516945024, 1.055797154031787] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.083 [0.8677245598860863, 1.2523532096197396] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.923 [0.7899325779202008, 1.188650196467013] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.930 [0.8772800404681079, 0.9929227658312301] | pass | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.081 [0.8191060722959214, 1.1325953813822647] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.040 [0.9683401863325758, 1.0900527121627728] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.946 [0.8096710711285047, 1.142802248083369] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.139 [0.946747466900932, 1.3796066776494191] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.016 [0.8473851712267011, 1.10514768300765] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.062 [0.7827441536403656, 1.2349868151870473] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.971 [0.9607247111731819, 1.0557058325598638] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.014 [0.9149682886615376, 1.1897045593520128] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `file_statements_20000` | 1.001 [0.8831142747649128, 1.1401966489277358] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 0.987 [0.8706511907425235, 1.0569564776276454] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.927 [0.6516621587754976, 1.3030842134810383] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.196 [0.828453220840805, 1.2592771658403912] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.005 [0.8586563864584333, 1.1583872560955075] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.955 [0.9406860011182407, 1.0416278291022514] | pass | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.989 [0.8882485398678931, 1.0536836241627134] | inconclusive-noisy | inconclusive-noisy |
