# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.037 [0.8717953305256075, 1.0863965938719693] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.791 [0.7679527169419637, 0.812615718060038] | confirmed A/A bias | - |
| full | aa | `calls_200000` | 0.796 [0.7857473568777918, 0.8064158767396716] | confirmed A/A bias | - |
| full | aa | `array_200000` | 0.854 [0.8413641276379616, 0.9038989667490736] | confirmed A/A bias | - |
| full | aa | `compare_high_1000d_x100000` | 0.840 [0.8333424828996978, 0.8604291661988652] | confirmed A/A bias | - |
| full | aa | `compare_low_1000d_x100000` | 0.872 [0.8584129046035673, 0.9634351914979111] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 0.870 [0.8274781951821483, 0.8862420654729672] | confirmed A/A bias | - |
| full | aa | `fibonacci_1000_x100` | 0.850 [0.8469957923502724, 0.8591151038741379] | confirmed A/A bias | - |
| full | aa | `factorial_1000_x50` | 0.935 [0.9132021776798754, 0.9500545355381346] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 0.912 [0.894211764240381, 0.9294648548904114] | confirmed A/A bias | - |
| full | aa | `multiply_10000d_x1000` | 1.004 [0.9798892001334496, 1.0211391322000904] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.882 [0.86634544791807, 0.8902802283352313] | confirmed A/A bias | - |
| full | aa | `sqrt_scale100_x5000` | 0.982 [0.9795176500730045, 1.0023119139565957] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 0.989 [0.9815299601971278, 0.9994961099052757] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 0.995 [0.9856632957153662, 1.0000708565498102] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.005 [0.9890805904704665, 1.0328279685870574] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.989 [0.9681890786175854, 1.0110087466755833] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.999 [0.9557810391228666, 1.0130650181914513] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.992 [0.9778327057927146, 1.010446821900183] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.982 [0.9618468653284941, 0.9951307755351593] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 0.873 [0.820258524791478, 0.8796799318241447] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 0.908 [0.9013571545793886, 0.9508949998024907] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 0.830 [0.8254400385151679, 0.8427969384226026] | confirmed A/A bias | - |
| full | aa | `frontend_definitions_2000` | 0.988 [0.9748814436966872, 1.0204507316532077] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.016 [0.9878082200521732, 1.031472375593486] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.013 [0.9483030004901121, 1.089289160503197] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.992 [0.9852278660320153, 1.0024764564810995] | pass | - |
| full | aa | `square_100d_x100000` | 0.914 [0.889876606784631, 1.0236730460398875] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 0.998 [0.9791288931552176, 1.024067476128432] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.961 [0.8397609607205477, 1.0992692267078477] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.997 [0.9514970336236261, 1.0147493286863796] | pass | - |
| full | aa | `octal_output_1000d_x300` | 0.994 [0.9638827287070796, 1.0366989317917639] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.006 [0.9894963095153098, 1.0302523684425424] | pass | - |
| full | aa | `hex_input_100000d_x3` | 0.991 [0.978898921007043, 0.9983328802767955] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.978 [0.964832654778358, 0.9952354803887885] | pass | - |
| full | aa | `file_statements_20000` | 0.989 [0.9543335728146273, 1.0070756680266837] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.011 [0.9933091576248274, 1.0340110099744095] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.092 [0.8571139854434368, 1.142688477460261] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.040 [0.947339942413233, 1.12594463080956] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.035 [0.9469990187577342, 1.120367877970916] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.940 [0.9163174287763414, 1.0196116296539632] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.967 [0.9035226712295581, 1.0303368485779143] | inconclusive-noisy | - |
| full | paired | `startup` | 1.002 [0.9432245922474157, 1.022677368039432] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.741 [0.7221164914082264, 0.7446141459797535] | pass | confirmed A/A bias |
| full | paired | `calls_200000` | 0.813 [0.7577972692827357, 0.8679009779293546] | pass | confirmed A/A bias |
| full | paired | `array_200000` | 0.819 [0.768886424420484, 0.9987590133280545] | pass | confirmed A/A bias |
| full | paired | `compare_high_1000d_x100000` | 0.820 [0.807477744123237, 0.8517916589555696] | pass | confirmed A/A bias |
| full | paired | `compare_low_1000d_x100000` | 0.839 [0.829361539441337, 0.8586109187895358] | pass | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.843 [0.8074155800455259, 0.8825969265762841] | pass | confirmed A/A bias |
| full | paired | `fibonacci_1000_x100` | 0.835 [0.7971383405772234, 0.8419070849242285] | pass | confirmed A/A bias |
| full | paired | `factorial_1000_x50` | 0.915 [0.8886915185807395, 0.9412440381349796] | pass | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.940 [0.916625875121409, 0.9518212859938756] | pass | confirmed A/A bias |
| full | paired | `multiply_10000d_x1000` | 1.004 [0.9296887039696424, 1.0147618561815916] | pass | pass |
| full | paired | `divide_scale100_x100000` | 0.871 [0.8589790970112654, 0.9504715975734311] | pass | confirmed A/A bias |
| full | paired | `sqrt_scale100_x5000` | 0.989 [0.9575637639289398, 1.0049949170737085] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 0.993 [0.9720403624063572, 1.0179538674942084] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.995 [0.9798128666216537, 1.0243342984831443] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9623231282060013, 1.0137461863628783] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.006 [0.9947354296565775, 1.015824863077289] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.009 [0.9544548470414499, 1.0362463768055998] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.996 [0.9821062366796742, 1.061341291854385] | inconclusive-noisy | pass |
| full | paired | `power_100d_e17_x1000` | 1.006 [0.9867378986247008, 1.1322969311616602] | inconclusive-noisy | pass |
| full | paired | `ibase_literal_flip_20000` | 0.850 [0.8487600185143309, 0.882142559027328] | pass | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.910 [0.8914120086050247, 0.9310481607633225] | pass | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.829 [0.7756568684309345, 0.837894353792388] | pass | confirmed A/A bias |
| full | paired | `frontend_definitions_2000` | 1.011 [0.9907662685417825, 1.0559661041028838] | inconclusive-noisy | pass |
| full | paired | `decimal_input_4000d_x100` | 0.993 [0.9519732014663588, 1.0711516882601206] | inconclusive-noisy | pass |
| full | paired | `decimal_output_200d_x1000` | 1.035 [0.9737108933116684, 1.1527359781227569] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.020 [0.9771317177330789, 1.0261440866924616] | pass | pass |
| full | paired | `square_100d_x100000` | 0.896 [0.8895031571222239, 0.9234292915241598] | pass | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.007 [0.9771852128486214, 1.0243189328298319] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.941 [0.9183300606272397, 1.0094071707454744] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.005 [0.9905630362271901, 1.0434660037429377] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 0.981 [0.9637086767876885, 1.0073592850085524] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.992 [0.9745471688181858, 1.0009242144140456] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.998 [0.9918623604915757, 1.0064722752056712] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.983 [0.942859537486766, 0.9955830563256907] | pass | pass |
| full | paired | `file_statements_20000` | 0.988 [0.9527105348614464, 1.042030407890521] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.021 [1.0005037968055408, 1.055849855780466] | inconclusive-noisy | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.869 [0.8084935511219457, 0.9476927939205091] | pass | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.012 [0.9656055058355281, 1.1412790030952369] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.054 [0.9164243984754528, 1.0949219280246316] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.980 [0.8919594541580282, 1.0145423340945332] | pass | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.933 [0.8826091723765196, 0.9543706880591374] | pass | inconclusive-noisy |
