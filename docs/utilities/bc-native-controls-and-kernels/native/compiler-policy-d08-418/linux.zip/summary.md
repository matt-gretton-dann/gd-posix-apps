# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.037 [0.7950878971282735, 1.3276171278318731] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.984 [0.9732036341704517, 1.0122754885642264] | pass | - |
| full | aa | `calls_200000` | 1.009 [0.996853622341752, 1.0362424084155133] | pass | - |
| full | aa | `array_200000` | 0.993 [0.9584753688350423, 1.0018041370701265] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.016 [0.9996718729151873, 1.0384112177572091] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.004 [0.988604822521068, 1.0076794411584724] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 1.003 [0.9967558097283926, 1.011761595767584] | pass | - |
| full | aa | `fibonacci_1000_x100` | 1.006 [0.997764515828049, 1.0113487488855684] | pass | - |
| full | aa | `factorial_1000_x50` | 1.002 [0.9922831857239959, 1.0068785672704037] | pass | - |
| full | aa | `multiply_100d_x100000` | 1.000 [0.9880962269653929, 1.0091018393295712] | pass | - |
| full | aa | `multiply_10000d_x1000` | 0.999 [0.9968172255039752, 1.0539005323012467] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 0.998 [0.9824321435692016, 1.0185965769883611] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.002 [0.998322045094121, 1.0068153450495332] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 0.998 [0.9939307068342901, 1.003944644711386] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 0.997 [0.9522438312834837, 0.9997063430328573] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.8776604476714976, 1.020388660066011] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.9525030986847407, 1.0019526329738433] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.017 [0.9815197964416043, 1.0489618982202618] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.996 [0.9897406960720084, 1.0042732067476483] | pass | - |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9873426175378972, 1.0145562792345746] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.005 [0.9882645663556824, 1.06515962499254] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 0.999 [0.9828505021611879, 1.0146494103004837] | pass | - |
| full | aa | `sparse_array_200000` | 0.986 [0.9719667621705711, 0.9967604889888239] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.005 [0.9799933234670906, 1.0210230975789436] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.011 [1.0027649218302874, 1.025589348154014] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.035 [0.9589617639609712, 1.1937670686866844] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.005 [0.9930953019134839, 1.0181243140384402] | pass | - |
| full | aa | `square_100d_x100000` | 1.003 [0.9937841615617079, 1.0272433853191671] | pass | - |
| full | aa | `square_10000d_x500` | 1.000 [0.9987492073052615, 1.00389167783432] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.925 [0.84577846864188, 1.0972624956309052] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.002 [0.9895984814029485, 1.0195535941607525] | pass | - |
| full | aa | `octal_output_1000d_x300` | 0.987 [0.9711078699061958, 1.0068162400826999] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.001 [0.9930673367158261, 1.0209252133078257] | pass | - |
| full | aa | `hex_input_100000d_x3` | 0.991 [0.9873706396324919, 1.003324568270936] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.000 [0.9928959079055945, 1.0073804540877318] | pass | - |
| full | aa | `file_statements_20000` | 1.009 [0.9896281819220403, 1.0266103778872129] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.000 [0.9985982037354547, 1.0019124646642872] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.065 [0.8212367532093078, 1.2184944229912087] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.011 [0.9028731456045115, 1.1455433605369314] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.020 [0.9784285268061478, 1.0977635210934007] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.988 [0.9434364189213273, 1.0311587967334361] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.997 [0.9282808388557218, 1.0717338510121852] | inconclusive-noisy | - |
| full | paired | `startup` | 1.021 [0.9002901477092383, 1.1568648869171516] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.985 [0.9406179675032911, 0.9943028139384545] | pass | pass |
| full | paired | `calls_200000` | 0.999 [0.9357817847764197, 1.0163134025783442] | pass | pass |
| full | paired | `array_200000` | 0.997 [0.9909218613557347, 1.0133530502350259] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 0.996 [0.9927656544331548, 1.016609968608488] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 0.999 [0.9872676544759409, 1.0089565323540586] | pass | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.001 [0.9869707135553464, 1.0095830685585183] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 1.001 [0.9831264706704321, 1.0067143935061627] | pass | pass |
| full | paired | `factorial_1000_x50` | 0.989 [0.9839561075694422, 0.9999470695696674] | pass | pass |
| full | paired | `multiply_100d_x100000` | 0.998 [0.9459156754699919, 1.012503393335733] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 1.003 [0.9946025617333372, 1.0041144598969618] | pass | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.999 [0.9797544708507372, 1.017036752198703] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 1.005 [0.9885840277189972, 1.0166230160829959] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 0.998 [0.988024458364132, 1.0006924891049138] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.002 [1.0001800402037309, 1.0057755512705286] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9971469855181176, 1.0076089428040576] | pass | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.002 [0.9992562795286364, 1.0108819444357515] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.007 [0.9898551143822455, 1.0232155862650152] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.997 [0.9927817186253085, 1.0035772271067693] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.996 [0.9876614208062068, 1.0043470713149711] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 0.981 [0.954753154742954, 1.0290401195986043] | pass | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.003 [0.9912152340602891, 1.0178101039444334] | pass | pass |
| full | paired | `sparse_array_200000` | 0.993 [0.9910502929531567, 1.0436549844186749] | pass | pass |
| full | paired | `frontend_definitions_2000` | 1.004 [0.9857628535683467, 1.0111493425555047] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 1.001 [0.9572547680280488, 1.0350561952729227] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 1.103 [1.0207780109231845, 1.1682398982630957] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.000 [0.9700834522875769, 1.0051198392347276] | pass | pass |
| full | paired | `square_100d_x100000` | 0.992 [0.9819749561746928, 0.9945915589255565] | pass | pass |
| full | paired | `square_10000d_x500` | 1.000 [0.9994473723886269, 1.0008406695233016] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.973 [0.8475571879361876, 1.104732642861184] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.999 [0.9942146268274211, 1.0260242544362128] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 0.996 [0.9735316155286274, 1.0016205290631166] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.997 [0.9846921063140619, 1.0053100194885296] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.996 [0.9916424180002625, 1.006563049558524] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.002 [0.9899264865872993, 1.0128342427124815] | pass | pass |
| full | paired | `file_statements_20000` | 1.001 [0.9914607509366882, 1.0133574958055132] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.000 [0.999555051877553, 1.00296413010046] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.830 [0.7740175408041108, 0.9139884844281867] | pass | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.027 [0.7956938939067294, 1.2184954034834334] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.022 [0.9153061887211799, 1.1175801489579178] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.991 [0.9472306121244884, 1.0551741439229192] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.957 [0.9422665298617444, 1.008865424623482] | pass | inconclusive-noisy |
