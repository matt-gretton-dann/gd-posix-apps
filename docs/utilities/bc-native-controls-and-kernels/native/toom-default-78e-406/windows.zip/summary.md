# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.035 [0.9804206429593846, 1.072394442615613] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 1.138 [1.1135867567541535, 1.160398499124032] | confirmed A/A bias | - |
| full | aa | `calls_200000` | 1.016 [0.978354510942085, 1.0351328052073296] | pass | - |
| full | aa | `array_200000` | 1.149 [1.124375659043513, 1.1777440338544158] | confirmed A/A bias | - |
| full | aa | `compare_high_1000d_x100000` | 1.082 [1.0585759982063616, 1.101481741778618] | confirmed A/A bias | - |
| full | aa | `compare_low_1000d_x100000` | 1.067 [1.0593159807419088, 1.0744605051041758] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.066 [1.0599766992499207, 1.0779281669823328] | confirmed A/A bias | - |
| full | aa | `fibonacci_1000_x100` | 1.021 [0.9835446789982765, 1.0285902531222217] | pass | - |
| full | aa | `factorial_1000_x50` | 1.004 [0.9892378540186012, 1.0257834886921344] | pass | - |
| full | aa | `multiply_100d_x100000` | 1.025 [0.9747499454447757, 1.0473481653928194] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9913736148580446, 1.0043938597765723] | pass | - |
| full | aa | `divide_scale100_x100000` | 1.067 [1.035562284182973, 1.0713741280540356] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 1.004 [0.9963321430298819, 1.057468101279695] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 0.999 [0.9892980691623493, 1.002967884514742] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.002 [0.9944130650256824, 1.0235600430719842] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9967737592692109, 1.0183287309418771] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9865831880820969, 1.0066067555190659] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.9847687784556216, 1.0275169359931937] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.013 [0.9910186330678683, 1.0253375643247304] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.994 [0.971101421317925, 1.0126341972063126] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.057 [1.0321297358004797, 1.0844024922923292] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 1.024 [1.0121669505059336, 1.0315601653166642] | pass | - |
| full | aa | `sparse_array_200000` | 1.014 [0.9977861346719317, 1.0607493653247706] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 1.000 [0.9717637068107989, 1.0190259398746517] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.002 [0.9722367324716006, 1.0060575051047393] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.038 [0.9803334321486658, 1.0577343936205732] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.993 [0.9840651862886067, 1.0366841690853483] | pass | - |
| full | aa | `square_100d_x100000` | 1.039 [1.027004785544485, 1.1477714468294071] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 1.002 [0.9974962539654891, 1.0093289656608349] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.996 [0.9775774138689127, 1.0276362652715822] | pass | - |
| full | aa | `binary_output_1000d_x300` | 0.981 [0.8636363636357951, 0.998379944808857] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 1.011 [0.9985484865748444, 1.0482530187580796] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.012 [1.0045519587479839, 1.0214814456443415] | pass | - |
| full | aa | `hex_input_100000d_x3` | 0.997 [0.9557740893373116, 1.0031205654812454] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.010 [0.996618309533338, 1.0113902065136513] | pass | - |
| full | aa | `file_statements_20000` | 1.014 [0.9895349687424447, 1.0729923016801672] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.001 [0.9994135723436045, 1.0020801758264326] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.020 [0.9907410041285429, 1.0521742268391139] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.017 [0.974606618754936, 1.023610873656269] | pass | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.995 [0.9893621634408778, 1.004905850231194] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.013 [0.9723613882770857, 1.0489784756620106] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.017 [1.0049114291276382, 1.0613562970929227] | inconclusive-noisy | - |
| full | paired | `startup` | 1.018 [0.9950680888542073, 1.0766492945191448] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.152 [1.139975406270522, 1.1759687249837705] | confirmed regression | confirmed A/A bias |
| full | paired | `calls_200000` | 1.015 [0.9979863898003455, 1.0186344942565118] | pass | pass |
| full | paired | `array_200000` | 1.158 [1.1375262556814012, 1.1853782714168895] | confirmed regression | confirmed A/A bias |
| full | paired | `compare_high_1000d_x100000` | 1.068 [1.0583101073432701, 1.0817180624562925] | confirmed regression | confirmed A/A bias |
| full | paired | `compare_low_1000d_x100000` | 1.046 [1.0041882411627585, 1.268066643127263] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.067 [1.0562673206585642, 1.0974266792036262] | confirmed regression | confirmed A/A bias |
| full | paired | `fibonacci_1000_x100` | 1.037 [1.020959798780148, 1.0917186770255063] | inconclusive-noisy | pass |
| full | paired | `factorial_1000_x50` | 1.018 [0.9789942789795458, 1.0274256490553582] | pass | pass |
| full | paired | `multiply_100d_x100000` | 1.033 [0.9764407229375955, 1.2337399740391348] | inconclusive-noisy | pass |
| full | paired | `multiply_10000d_x1000` | 0.999 [0.9853909137135289, 1.0063722095782455] | pass | pass |
| full | paired | `divide_scale100_x100000` | 1.066 [1.0410452421343217, 1.1127648952057771] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.000 [0.9964605671762382, 1.0295884728851974] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 1.001 [0.9934127913909149, 1.0079014904739871] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.001 [0.9946556493391799, 1.0262657266300363] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.015 [0.8594176441884143, 1.0481426665058773] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.000 [0.9786389266739332, 1.0577496459779618] | inconclusive-noisy | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.996 [0.9882985452282547, 1.010918624878588] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.008 [0.9887309531083569, 1.019739461857918] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 1.016 [1.0001312644238398, 1.1055214462577627] | inconclusive-noisy | pass |
| full | paired | `ibase_literal_flip_20000` | 1.059 [1.0493003488227104, 1.072300327576588] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.012 [1.008605143580022, 1.0183339215692067] | pass | pass |
| full | paired | `sparse_array_200000` | 1.008 [1.0030292047341118, 1.0172747769536872] | pass | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.988 [0.951594912430935, 1.0542056368834105] | inconclusive-noisy | pass |
| full | paired | `decimal_input_4000d_x100` | 1.001 [0.7647492719975485, 1.0195262569811847] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 1.007 [0.9382155056520863, 1.044146195572612] | pass | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.983 [0.9711864294605712, 1.0092970110639121] | pass | pass |
| full | paired | `square_100d_x100000` | 1.045 [1.0196665556702476, 1.0608359107046719] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.999 [0.9961823090285271, 1.0039135473384262] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.999 [0.9588053342135289, 1.0229393637014248] | pass | pass |
| full | paired | `binary_output_1000d_x300` | 1.005 [0.9885347849808876, 1.0485519271815928] | pass | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.005 [0.9869389042951638, 1.0161695583986587] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 1.005 [0.9853561271263641, 1.0212810752060402] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 1.003 [0.9485646125206862, 1.0218200059651599] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.012 [0.991530553293158, 1.0318091935613531] | pass | pass |
| full | paired | `file_statements_20000` | 0.988 [0.9258610746953242, 1.032218833169925] | pass | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 1.001 [0.9994291178444219, 1.0024171606174084] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.996 [0.9728193874433311, 1.0724871175248036] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.983 [0.9700786131786401, 1.0352648376911222] | pass | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.001 [0.9875155881141965, 1.0147441612043093] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.015 [0.9976826981798321, 1.0331602615948134] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.012 [0.983762977617824, 1.0407072487190052] | pass | inconclusive-noisy |
