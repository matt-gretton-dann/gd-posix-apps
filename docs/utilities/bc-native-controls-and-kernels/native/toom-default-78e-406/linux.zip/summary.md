# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.958 [0.7517807322030012, 1.3187970078464994] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.995 [0.9615452369824252, 1.0333306886006473] | pass | - |
| full | aa | `calls_200000` | 0.999 [0.9843593521008398, 1.012724180049847] | pass | - |
| full | aa | `array_200000` | 0.999 [0.9666545670602079, 1.005204567915981] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 0.984 [0.9640287581469149, 1.0022424245557984] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 0.985 [0.97769738355818, 1.0110822857127169] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 0.984 [0.955032733140408, 0.995144238275458] | pass | - |
| full | aa | `fibonacci_1000_x100` | 0.973 [0.9504398884199117, 0.998924300790995] | pass | - |
| full | aa | `factorial_1000_x50` | 0.986 [0.97738006096179, 1.0017089809157766] | pass | - |
| full | aa | `multiply_100d_x100000` | 0.986 [0.9649823941245428, 1.0284351944346088] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9975013932705156, 1.0045120286131655] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.993 [0.9885769881292708, 1.0034451781693816] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.9871832269359844, 1.0017787134240006] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 0.999 [0.9972371543775754, 1.0042984783118905] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9953798220078477, 1.006370266778472] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.006 [1.00275879498644, 1.01078163367419] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9929545623938394, 1.0028085990312827] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.9902826362505949, 1.0117580691337529] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.995 [0.9549693716911317, 1.001585292529463] | pass | - |
| full | aa | `power_100d_e17_x1000` | 1.009 [0.9749562912219719, 1.024545707184284] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.031 [1.0235661539008265, 1.0530529950144814] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 1.005 [0.9720632749958817, 1.0163510737903458] | pass | - |
| full | aa | `sparse_array_200000` | 0.999 [0.9936611902090263, 1.009793608152379] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.002 [0.994483296885612, 1.018576066061362] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.024 [1.0091523497805477, 1.0775265257933146] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 1.074 [0.8969217251785051, 1.1222811139373712] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.006 [0.9818368020934212, 1.0098670609957043] | pass | - |
| full | aa | `square_100d_x100000` | 0.987 [0.9819264433037723, 0.9972913248772135] | pass | - |
| full | aa | `square_10000d_x500` | 1.000 [0.9993503955683947, 1.0014189779014135] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.967 [0.8852530350395069, 1.14220968900158] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.996 [0.9267300398910737, 1.0827012905111773] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 1.002 [0.9768090040989981, 1.0153890445744531] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.000 [0.9713775138959837, 1.0078806046854034] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.004 [0.9909189451216197, 1.0233393001366424] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.000 [0.996715749879411, 1.009683504056142] | pass | - |
| full | aa | `file_statements_20000` | 1.003 [0.9926080764162274, 1.0170481464606835] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.000 [0.9925456838976964, 1.0001556219721093] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 0.998 [0.9646284246459602, 1.0651462445350859] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.020 [0.971223226499701, 1.07739061123794] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.999 [0.9939995638812374, 1.004152939503324] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.985 [0.9709282570041643, 1.0125658734288652] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.990 [0.9499815101047321, 1.0643061159785847] | inconclusive-noisy | - |
| full | paired | `startup` | 1.013 [0.9243556433406923, 1.1789376583905617] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.990 [0.9730685479157329, 1.0189031063454634] | pass | pass |
| full | paired | `calls_200000` | 1.006 [0.9884868947014434, 1.0112602124715924] | pass | pass |
| full | paired | `array_200000` | 0.999 [0.9859107339963122, 1.0170958255380111] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 0.990 [0.9802172514169257, 1.0048553640811009] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 0.996 [0.9831042237751205, 1.0203787076946724] | pass | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.992 [0.9807019876931188, 1.0170597972361985] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 0.987 [0.9815051359018506, 0.9927165807860575] | pass | pass |
| full | paired | `factorial_1000_x50` | 0.982 [0.9721665948687979, 0.9906091453332713] | pass | pass |
| full | paired | `multiply_100d_x100000` | 0.987 [0.9780944184123737, 1.0020666130826974] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 0.999 [0.980135481514839, 1.0019219272887445] | pass | pass |
| full | paired | `divide_scale100_x100000` | 0.997 [0.9889112636386367, 1.018983406444355] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 1.004 [0.9955863514743678, 1.0064754661937705] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 1.001 [0.9992527221475567, 1.0012176971462297] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.998 [0.966962837893861, 1.0008908276962794] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.011 [1.0010741121941962, 1.0868960430088856] | inconclusive-noisy | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.999 [0.9951620828680486, 1.0012428830128792] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.9894997741975581, 1.0108322642492096] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.996 [0.9926927418366079, 1.0028898457688893] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.999 [0.994218509895758, 1.0086559278630083] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 1.006 [0.9855063777064199, 1.0198148375068607] | pass | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.990 [0.9756790056656187, 0.9924370457068081] | pass | pass |
| full | paired | `sparse_array_200000` | 0.998 [0.9807005561162017, 1.0135857121730492] | pass | pass |
| full | paired | `frontend_definitions_2000` | 1.009 [0.9866623107486755, 1.014604049365266] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 0.997 [0.9956852396481884, 1.0267212593652644] | pass | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.086 [0.9696416724775581, 1.107784083406816] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.001 [0.9852079627885093, 1.0190332500894395] | pass | pass |
| full | paired | `square_100d_x100000` | 0.986 [0.980101389462837, 0.9925991116200277] | pass | pass |
| full | paired | `square_10000d_x500` | 1.000 [0.9991679993153809, 1.0007122629287293] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.010 [0.8155810565376943, 1.074340005483239] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.004 [1.0024677691162889, 1.0232984274390422] | pass | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.995 [0.9862396876033391, 1.0290251178686594] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 1.000 [0.9758617082748445, 1.0231414687300675] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 1.002 [0.9845826407279854, 1.0076854560141202] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.999 [0.995110131870495, 1.0092465869927818] | pass | pass |
| full | paired | `file_statements_20000` | 1.010 [1.0003946437927433, 1.0145925700050131] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.000 [0.9993233479500997, 1.0001704967681173] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.948 [0.9334127145996527, 0.9884952231725243] | pass | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.998 [0.927763309389365, 1.0921318419073651] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.999 [0.9956750798651364, 1.0052468652186262] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.980 [0.9540706968177957, 1.05832838088665] | inconclusive-noisy | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.971 [0.9483872479492874, 1.0041530000211396] | pass | inconclusive-noisy |
