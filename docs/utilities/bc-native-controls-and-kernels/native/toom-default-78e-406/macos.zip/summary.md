# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.099 [0.7380905895678365, 1.3099487141624624] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 1.000 [0.9298939649591835, 1.0875090846204938] | inconclusive-noisy | - |
| full | aa | `calls_200000` | 1.053 [0.9305175561620774, 1.1240039406229496] | inconclusive-noisy | - |
| full | aa | `array_200000` | 1.007 [0.871251666312804, 1.130928501609029] | inconclusive-noisy | - |
| full | aa | `compare_high_1000d_x100000` | 0.976 [0.8934307849350829, 1.0750930735422008] | inconclusive-noisy | - |
| full | aa | `compare_low_1000d_x100000` | 0.996 [0.885744232824592, 1.0365512708226639] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.023 [0.8897876379957766, 1.130884966562444] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 1.011 [0.9109433442705372, 1.1560724327610663] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 1.009 [0.8705688579964933, 1.6380241308354366] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 1.003 [0.8227067829833222, 1.17631088584016] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 0.975 [0.9461110755359032, 1.044058255766796] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 1.031 [0.9312600728640016, 1.245532203445886] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 1.007 [0.9260079547179115, 1.0246002650197454] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 0.986 [0.9527275597901756, 1.0633378692499391] | inconclusive-noisy | - |
| full | aa | `multiply_dense_10000d_x500` | 0.989 [0.8676979391363874, 1.0926164774620257] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.985 [0.837020390375959, 1.022754487981702] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.993 [0.891569566476848, 1.073243162105294] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.871 [0.6555619984517772, 1.0613558017015494] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.006 [0.8077104932537236, 1.039087603502708] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 1.005 [0.7829658337695038, 1.013992021979886] | inconclusive-noisy | - |
| full | aa | `ibase_literal_flip_20000` | 1.077 [0.9380934100216647, 1.2185017694171387] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 1.022 [0.9559248605475669, 1.1579588082596304] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 0.875 [0.8234203168160474, 0.9936423926485451] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 1.030 [0.918460470086353, 1.34376842807] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 1.017 [0.8826192165353126, 1.1555054378942922] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 1.020 [0.8521198168120718, 1.3385255484287313] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.101 [0.753838795146949, 1.2425474451870941] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 1.153 [0.8439700201744315, 1.2490286773953339] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 0.981 [0.9142556862921862, 1.0443727826159122] | inconclusive-noisy | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.916 [0.7185506336159744, 1.0274198825746432] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.955 [0.7862300327331512, 1.1981831133622136] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 1.001 [0.8004020039582991, 1.631705028416736] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 0.965 [0.7723969537913914, 1.0513434665055654] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 0.923 [0.8444140999826978, 1.217376113737313] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.019 [0.9048889579302137, 1.3360138440801743] | inconclusive-noisy | - |
| full | aa | `file_statements_20000` | 1.023 [0.866438482295911, 1.2758987304462728] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 0.967 [0.91106126523759, 1.041561571060583] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.041 [0.7443572940861822, 1.2120888920222557] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.092 [0.9509479027896053, 1.3668767189225601] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.982 [0.854673518982111, 1.0058161567990167] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.026 [0.9759616606197972, 1.5574610047755892] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.996 [0.7635133163050954, 1.1126168488511612] | inconclusive-noisy | - |
| full | paired | `startup` | 1.046 [0.736207193682764, 1.2146088798734427] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.050 [0.8377954033868719, 1.1181953369930677] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `calls_200000` | 0.943 [0.8638789983764837, 1.0770651928154957] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `array_200000` | 0.913 [0.8453942016229724, 1.0176287487035336] | pass | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.954 [0.8813737018028797, 1.053370818530587] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.155 [0.9870925761454966, 1.2053979393212801] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.977 [0.6410547497944843, 1.1303123561041981] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.922 [0.7254539766611384, 1.482433591735096] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.914 [0.8001581965442669, 1.075074854611345] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.076 [0.9998632661739183, 1.363805752685017] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.995 [0.9637051958076394, 1.0195249406544562] | pass | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.023 [0.9188922370597074, 1.2884189302061124] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.957 [0.8880416268253762, 1.0521943576257613] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 1.010 [0.8539737406053611, 1.1264189848197244] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.035 [0.9357476046122899, 1.0434209323570731] | pass | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.921 [0.7781594345696045, 1.238010614010804] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.943 [0.831021943160081, 1.1922140841620172] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.045 [0.8793118819874489, 1.7464892807186232] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.937 [0.8284536089306922, 1.1627660008905403] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.037 [0.8425947263600991, 1.1724348855382005] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.004 [0.9275063291136901, 1.3695875623266764] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.045 [0.7592570090144811, 1.2792302603325654] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.018 [0.9222677585609589, 1.3050069539859719] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.957 [0.7845729793488236, 1.0628130756584973] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.105 [0.8558814377797492, 1.3225619499528507] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.991 [0.875298850100263, 1.731694842367935] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.875 [0.7972833717655481, 1.04218825489593] | pass | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.026 [0.9442866733102936, 1.174749672536357] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.042 [0.879124705708879, 1.201345121936457] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.999 [0.8276651071268639, 1.199002646036689] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.138 [0.9442118892742628, 1.1920341598271944] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.121 [0.8656186075812328, 1.1849787548736108] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.037 [0.9352818313924558, 1.2624972642393537] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.986 [0.8465473575842208, 1.099267825301786] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.066 [1.0165612397130661, 1.2148889504662077] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `file_statements_20000` | 1.007 [0.9382242677183386, 1.4728604253057795] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 0.984 [0.9289053379576608, 1.126917735195881] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.984 [0.7880597125405938, 1.2312153682303486] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.871 [0.7140704504453278, 1.2705926616637604] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.052 [1.010667234240203, 1.1216429082504233] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.019 [0.9063899274911523, 1.3151211616588496] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.917 [0.4971189300194834, 1.1066840775136397] | inconclusive-noisy | inconclusive-noisy |
