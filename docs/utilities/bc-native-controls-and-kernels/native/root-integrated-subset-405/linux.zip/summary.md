# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.252 [0.8221994154159183, 1.3078391580280666] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.986 [0.9511655769541437, 1.0307221501863049] | pass | - |
| full | aa | `calls_200000` | 1.003 [0.9921921559007325, 1.0506079587318526] | inconclusive-noisy | - |
| full | aa | `array_200000` | 0.992 [0.9774330117375274, 1.0397711000419916] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.019 [0.956168233985872, 1.032772726589352] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.018 [0.9891841083627241, 1.0297920004680357] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 1.012 [1.0020461151386308, 1.0365359135829202] | pass | - |
| full | aa | `fibonacci_1000_x100` | 1.001 [0.9849436064096686, 1.0306685178044754] | pass | - |
| full | aa | `factorial_1000_x50` | 1.008 [1.0047676965888996, 1.0210801769192441] | pass | - |
| full | aa | `multiply_100d_x100000` | 0.984 [0.9727357867562065, 0.9952705178544914] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.002 [0.9967058876644024, 1.0053732701139295] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.991 [0.9682868005917166, 0.9981794966519147] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 0.996 [0.9881261958348779, 1.0100252754759786] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 0.999 [0.9981571005209361, 1.00233747826852] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9967263975036869, 1.0036067715194785] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.994 [0.9497557152116723, 1.0142760950542913] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9939273387750516, 1.005662839672434] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.010 [0.9928916923013944, 1.0162088174734887] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.999 [0.9863199769094553, 1.001420222556381] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.998 [0.9814491639868124, 1.0217723668956329] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 0.997 [0.9812297264214829, 1.020486682525136] | pass | - |
| full | aa | `recursion_50_x1000` | 0.991 [0.9696424689379722, 1.0145787314557029] | pass | - |
| full | aa | `sparse_array_200000` | 0.999 [0.9744773816892297, 1.0234427814798979] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.007 [0.9834013636244232, 1.0229099881085957] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9717095509500389, 1.0303289948065892] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 0.998 [0.9168425111146311, 1.1956447817032148] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.021 [0.9922232303323197, 1.0364941478719736] | pass | - |
| full | aa | `square_100d_x100000` | 0.983 [0.9722629673283613, 0.9911316702071287] | pass | - |
| full | aa | `square_10000d_x500` | 1.001 [0.9986801014253329, 1.001577449292971] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.966 [0.8485566734000107, 1.1602038648450945] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.993 [0.9853885900546167, 1.0083679233393201] | pass | - |
| full | aa | `octal_output_1000d_x300` | 1.003 [0.9953324484883869, 1.031131376473891] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.010 [0.9961415923607781, 1.021897499786553] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.001 [0.9980282899977472, 1.0095448680228984] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.995 [0.9896692701716375, 1.0017696244954208] | pass | - |
| full | aa | `file_statements_20000` | 1.007 [0.9851867956561867, 1.0123840855824235] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.000 [1.0000746695980245, 1.0023486377115305] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.027 [0.9476604567409072, 1.0447450877878326] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.015 [0.9506300682207437, 1.0769639963864872] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.999 [0.9959647432010882, 1.0024531040964408] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.975 [0.9472540339742841, 1.0064619188382458] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.990 [0.9550424126229977, 1.031798051239731] | pass | - |
| full | paired | `startup` | 1.092 [0.9464878985765943, 1.1634435539362251] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.024 [1.010388542917971, 1.0275219307893864] | pass | pass |
| full | paired | `calls_200000` | 1.014 [0.9922244329950841, 1.0450430689628873] | pass | inconclusive-noisy |
| full | paired | `array_200000` | 1.014 [1.0026062715649042, 1.0325834742547115] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 1.009 [1.0021542086064852, 1.0172941661023949] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 0.999 [0.9875503892062112, 1.0098750562724772] | pass | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.013 [0.9611669019706688, 1.0218946828915236] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 1.012 [1.005877157807073, 1.0362007345649482] | pass | pass |
| full | paired | `factorial_1000_x50` | 0.992 [0.969405182892915, 1.0002033356080382] | pass | pass |
| full | paired | `multiply_100d_x100000` | 0.995 [0.9901856232327068, 1.004589531281607] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 0.998 [0.9873692674382626, 1.001183929484694] | pass | pass |
| full | paired | `divide_scale100_x100000` | 0.993 [0.9708429662694996, 1.0207648212507208] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 1.006 [1.001973839717464, 1.0098323063607328] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 0.238 [0.23621995393424647, 0.23871677324207796] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.996 [0.9936493813065168, 1.1319599339977797] | inconclusive-noisy | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9452946352796112, 1.0119465772768685] | pass | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.987 [0.9663805337984527, 0.9972299198094179] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.9892478868156266, 1.027504386388139] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.001 [0.9931478740577812, 1.0042648004326797] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.995 [0.9919644225508134, 1.003914235579967] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 0.998 [0.9621831012642456, 1.021031742460545] | pass | pass |
| full | paired | `recursion_50_x1000` | 1.003 [0.9868879111133302, 1.018400406893141] | pass | pass |
| full | paired | `sparse_array_200000` | 0.994 [0.9784059348330539, 1.0160419631781294] | pass | pass |
| full | paired | `frontend_definitions_2000` | 1.009 [0.9960692665532542, 1.0317207184802513] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 1.034 [1.0262801007551867, 1.1053057823329944] | inconclusive-noisy | pass |
| full | paired | `decimal_output_200d_x1000` | 1.048 [0.8832943724264969, 1.1612193955155017] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.015 [1.0095082904483745, 1.0299392692798415] | pass | pass |
| full | paired | `square_100d_x100000` | 0.965 [0.9563652259739938, 0.9680740705563655] | pass | pass |
| full | paired | `square_10000d_x500` | 0.996 [0.9946063568093724, 0.9965258186151197] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.974 [0.8730596900762373, 1.066525633009154] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.996 [0.9893335408504396, 1.013877981180546] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 0.988 [0.9759277393794972, 0.9970527054008075] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.998 [0.9872622272778591, 1.0239435897011249] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 1.005 [0.9652660151526865, 1.0136158207839268] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.000 [0.993800178316969, 1.0116899616511854] | pass | pass |
| full | paired | `file_statements_20000` | 1.017 [1.004266295722814, 1.0270901439508158] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 0.210 [0.20968465308382425, 0.21040703788630608] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.348 [0.3355862753355545, 0.39781620936981665] | pass | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.389 [0.35427366929605536, 0.4164066786725832] | pass | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.102 [0.09495551254786014, 0.10363696846960124] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.993 [0.964141774848479, 1.0350136550030504] | pass | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.972 [0.9536621206236335, 1.0151259043284744] | pass | pass |
