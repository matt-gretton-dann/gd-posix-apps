# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.030 [0.9393120461289428, 1.0618088781552582] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 1.007 [1.003244336665036, 1.0472659753905909] | pass | - |
| full | aa | `calls_200000` | 0.990 [0.9505135117268191, 1.0145747277865405] | pass | - |
| full | aa | `array_200000` | 1.005 [0.9596333975900303, 1.0184067519325306] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.008 [0.9880115124489063, 1.02325521885243] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.005 [0.9984867372091452, 1.008007023041435] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 0.992 [0.968015066251976, 0.9997313264659399] | pass | - |
| full | aa | `fibonacci_1000_x100` | 0.958 [0.8730518568702302, 0.9929521999354065] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 1.017 [0.9918131030677971, 1.0377121357916206] | pass | - |
| full | aa | `multiply_100d_x100000` | 0.969 [0.9612477902632242, 0.9908653926427277] | pass | - |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.9921742896702411, 1.0097837000839085] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.994 [0.9565274563446818, 0.9988117963569537] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9847040137837488, 1.003697972848469] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.001 [0.9923979111981143, 1.0037169430114508] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.009 [0.9948927904179334, 1.0317807217921775] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.005 [0.9955961660174977, 1.011852388591671] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.996 [0.9651503596531374, 1.0002526307031594] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.999 [0.9692578130937005, 1.018642187132196] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.008 [0.9984349127469662, 1.0164693975832362] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.993 [0.9886128364441094, 1.0100141958306148] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.013 [0.9668187014717866, 1.0342655298936396] | pass | - |
| full | aa | `recursion_50_x1000` | 1.006 [1.0001279401641654, 1.024338078569524] | pass | - |
| full | aa | `sparse_array_200000` | 0.994 [0.9575236053692732, 1.027458869809339] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.001 [0.9933337586118051, 1.0178530939247914] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.006 [0.9817530397003509, 1.0535907133565006] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 1.016 [0.944788292766365, 1.0542689976469901] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.994 [0.8681582318862027, 1.008307721260306] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 0.976 [0.9707353291938563, 0.9870669620728832] | pass | - |
| full | aa | `square_10000d_x500` | 1.002 [0.9925230239926291, 1.008647029040916] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.965 [0.9352742165329891, 1.0805973348657671] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.995 [0.9713585097862042, 1.159688690743865] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 1.013 [0.9875647619841593, 1.0515375959304172] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 1.014 [0.9950495339328753, 1.0183000716439703] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.004 [0.9722011866908523, 1.0719340381643945] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.004 [0.9883461601452296, 1.0242463998645506] | pass | - |
| full | aa | `file_statements_20000` | 1.016 [0.997742413482995, 1.1027430711215527] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.001 [0.9990630885276929, 1.001941485422368] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.003 [0.9586459160073226, 1.0439021842873997] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 0.985 [0.9678384263850239, 1.037462463127662] | pass | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.001 [0.991015040302182, 1.0119881808368896] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.992 [0.9505700553066739, 1.0279380617719192] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.992 [0.9715499314187053, 1.0295175767164824] | pass | - |
| full | paired | `startup` | 1.006 [0.8841884367216007, 1.0187430620617608] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.976 [0.9409583841782525, 1.0105985479294175] | pass | pass |
| full | paired | `calls_200000` | 0.938 [0.899752174184879, 0.9572460680583341] | pass | pass |
| full | paired | `array_200000` | 0.959 [0.8704575066325928, 0.9936232571372509] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 0.960 [0.8986611379042657, 0.995099825727346] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 0.929 [0.8581029446619693, 1.0928792791165467] | inconclusive-noisy | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.933 [0.9208210935017143, 0.9754540437116258] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 0.962 [0.9479794955438944, 0.9816975659817258] | pass | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.008 [0.9445866227432725, 1.0293893089284447] | pass | pass |
| full | paired | `multiply_100d_x100000` | 0.920 [0.8743043454504258, 0.9281094999056676] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 0.992 [0.981590088021177, 1.0111972283303619] | pass | pass |
| full | paired | `divide_scale100_x100000` | 0.965 [0.9470809931190043, 0.9850829848509781] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 1.001 [0.984496248209544, 1.0148280418177045] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 0.268 [0.2591506152882915, 0.2723469866592656] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.998 [0.9828728888372864, 1.0004761405654077] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9955629087497971, 1.0062136352868876] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.002 [0.9507073362947727, 1.0348176710830164] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.979905066209733, 1.0304072884281077] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.991 [0.8788797935784683, 1.0100743392432585] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.999 [0.9738421562149016, 1.0622025727334494] | inconclusive-noisy | pass |
| full | paired | `ibase_literal_flip_20000` | 1.023 [0.9805622408090713, 1.1906791657473257] | inconclusive-noisy | pass |
| full | paired | `recursion_50_x1000` | 1.005 [0.9985534709473755, 1.0255293759507524] | pass | pass |
| full | paired | `sparse_array_200000` | 0.964 [0.957477833316242, 0.9724310616404889] | pass | pass |
| full | paired | `frontend_definitions_2000` | 1.000 [0.9754604920474956, 1.0595798681686255] | inconclusive-noisy | pass |
| full | paired | `decimal_input_4000d_x100` | 1.111 [1.0871195431536016, 1.1444255253119007] | confirmed regression | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.993 [0.9571325841622487, 1.0637434217326054] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.993 [0.9864580707697981, 1.0166404449784388] | pass | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.944 [0.9257911108527893, 1.017492896286331] | pass | pass |
| full | paired | `square_10000d_x500` | 0.999 [0.9881638120415769, 1.0227273600770928] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.963 [0.9433666337064491, 1.0328509288610002] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.003 [0.9703504484591384, 1.0295782274523884] | pass | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.979 [0.9749126636607285, 0.9862632276875894] | pass | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.110 [1.0711643964769728, 1.1456632102743265] | confirmed regression | pass |
| full | paired | `hex_input_100000d_x3` | 1.033 [1.022521632781845, 1.0517987659215662] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 0.992 [0.9818661672058124, 0.9974274221296839] | pass | pass |
| full | paired | `file_statements_20000` | 0.994 [0.8931266295413515, 1.0106700683900263] | pass | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 0.217 [0.21596903921386854, 0.21976268350506228] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.606 [0.5759023430288999, 0.6280315929550417] | pass | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.711 [0.6472125435566447, 0.7847106395801573] | pass | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.207 [0.19927270078321202, 0.22360070546049682] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.980 [0.9286838191433038, 0.9944691380963249] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.972 [0.9563833498046593, 1.0031141767775662] | pass | pass |
