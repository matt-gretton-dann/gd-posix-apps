# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.035 [0.9436332581595532, 1.1350135589621992] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.990 [0.958822514356962, 1.0155567273265347] | pass | - |
| full | aa | `calls_200000` | 0.995 [0.9387271525357146, 1.0768488184422336] | inconclusive-noisy | - |
| full | aa | `array_200000` | 1.000 [0.8445072415610522, 1.0409438313018893] | inconclusive-noisy | - |
| full | aa | `compare_high_1000d_x100000` | 1.000 [0.9678232119790202, 1.0512950091579922] | inconclusive-noisy | - |
| full | aa | `compare_low_1000d_x100000` | 0.965 [0.9264322024949724, 1.0483396154242088] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 0.997 [0.9646199930191641, 1.0720135934370565] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 1.007 [0.9739046028904818, 1.1073209516332883] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 1.005 [0.981366416316683, 1.1034022812030995] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 1.007 [0.9618935240869323, 1.0456702167750467] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.008 [0.9756015534337169, 1.0406504816950655] | pass | - |
| full | aa | `divide_scale100_x100000` | 1.040 [0.9760445606573959, 1.1365930466581091] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 0.954 [0.8436742485594364, 0.9977469975392429] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 0.989 [0.9697501227586852, 1.0086720499466042] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 0.995 [0.9696016913024154, 1.0270239930193743] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.003 [0.9512461537815976, 1.0135120507186464] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.003 [0.8684689558399697, 1.0194325584993842] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.991 [0.9462202434647263, 1.0349228652988194] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.986 [0.9451115746769185, 1.001539667586197] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 1.007 [0.999358203103747, 1.1243441970799934] | inconclusive-noisy | - |
| full | aa | `ibase_literal_flip_20000` | 1.010 [0.9498640943895388, 1.0113473355892342] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 0.986 [0.9236949462079557, 1.032309800450634] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 1.001 [0.9883363490196921, 1.0344400345995723] | pass | - |
| full | aa | `frontend_definitions_2000` | 0.998 [0.9571255013686897, 1.0052431184080501] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.084 [0.9984880284408929, 1.168662281051255] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 1.007 [0.9551734499869627, 1.1030600753758182] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.998 [0.9674303502149687, 1.0283304337080585] | pass | - |
| full | aa | `square_100d_x100000` | 1.000 [0.9198877785565492, 1.046140133516733] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 1.005 [0.9543385993509217, 1.0396964533841397] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.961 [0.897823653826124, 1.127694445411043] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.029 [0.8601995367688574, 1.1030810575674073] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 0.999 [0.8525730487562515, 1.0111020455710995] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 1.003 [0.95994103969743, 1.0153479334691262] | pass | - |
| full | aa | `hex_input_100000d_x3` | 0.974 [0.8026776119624427, 0.983240770009866] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.990 [0.9728089122584933, 1.02578662357509] | pass | - |
| full | aa | `file_statements_20000` | 0.999 [0.979330995499743, 1.0005629234389672] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 0.980 [0.8727621125245355, 0.9948878160934577] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.003 [0.9631071532066013, 1.0270590397290729] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.018 [0.9674042444008496, 1.1732660037838414] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.001 [0.9208731938097028, 1.0061518627707573] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.990 [0.9189471389406583, 1.0208874928630356] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.003 [0.9646512520017752, 1.0680353365056168] | inconclusive-noisy | - |
| full | paired | `startup` | 1.133 [0.8293024650283913, 1.2011201203240245] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.052 [0.9268301425954405, 1.3629091426835762] | inconclusive-noisy | pass |
| full | paired | `calls_200000` | 0.956 [0.7839283686370694, 1.1227596304261716] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `array_200000` | 1.034 [0.850361399224492, 1.0748733441275595] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.015 [0.8453710155845113, 1.1085964333146308] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.101 [0.9503477962963304, 1.3180415291405811] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.009 [0.9352947399234867, 1.3063225457347445] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.979 [0.8494317031805945, 1.1812956928073974] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.974 [0.7481203839133109, 1.1001127049609123] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.934 [0.8577820664074767, 1.0967603396026262] | inconclusive-noisy | pass |
| full | paired | `multiply_10000d_x1000` | 0.967 [0.8000726336437058, 1.0427528850390235] | pass | pass |
| full | paired | `divide_scale100_x100000` | 0.971 [0.7334307542877628, 1.3560547580883522] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.009 [0.9539955958074622, 1.2989362146348926] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 0.238 [0.2130139142017492, 0.25614993644568473] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.063 [0.8968739942194992, 1.4556868213099408] | inconclusive-noisy | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.045 [0.8431354737562792, 1.2484556934631748] | inconclusive-noisy | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.986 [0.9450599502353552, 1.1294487945999785] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.939 [0.7974679222792737, 1.078356604188781] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.877 [0.8209410481088693, 1.2649119011933196] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.090 [0.8685819950979009, 1.284803188523039] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.013 [0.9288133625038234, 1.5370773275799356] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.063 [0.7692916881659604, 1.2192295577085708] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.010 [0.8769601780106073, 1.1974439889161066] | inconclusive-noisy | pass |
| full | paired | `frontend_definitions_2000` | 1.041 [0.8410605739134434, 1.2664150405776005] | inconclusive-noisy | pass |
| full | paired | `decimal_input_4000d_x100` | 0.989 [0.8739813904986187, 1.0833728494864532] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.028 [0.6526085915106384, 1.543000337994347] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.870 [0.7964167875767258, 1.0405382122464786] | pass | pass |
| full | paired | `square_100d_x100000` | 1.006 [0.9333616796616997, 1.3284135744493555] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.031 [0.9432016435987652, 1.0781118070141793] | inconclusive-noisy | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.930 [0.5557884052521409, 1.037963905598168] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.014 [0.8485835816443101, 1.3661784428354373] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.047 [0.8415805959204172, 1.2011107484351238] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.051 [0.9388368798235109, 1.1152390090728401] | inconclusive-noisy | pass |
| full | paired | `hex_input_100000d_x3` | 1.058 [0.9670267813889252, 1.2223662191111129] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.045 [0.9258541853675031, 1.2986538165762573] | inconclusive-noisy | pass |
| full | paired | `file_statements_20000` | 1.035 [0.809836111799259, 1.2506432382696537] | inconclusive-noisy | pass |
| full | paired | `sqrt_large_scale10000_x5` | 0.211 [0.19418125596464034, 0.2126534197808588] | pass | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.421 [0.4059854115469533, 0.5881926781794777] | pass | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.591 [0.512739770437549, 0.6753205464877633] | pass | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.157 [0.14581982205057403, 0.19589069484871335] | pass | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.091 [0.9165021990092983, 1.351736818631443] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.007 [0.7493514654489414, 1.3085748185049664] | inconclusive-noisy | inconclusive-noisy |
