# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.037 [0.9217951916385602, 1.105873544357754] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 1.017 [0.9672967714624097, 1.0558193012172705] | inconclusive-noisy | - |
| full | aa | `calls_200000` | 0.999 [0.9765912402378673, 1.0039318554083851] | pass | - |
| full | aa | `array_200000` | 0.994 [0.9784451308528168, 1.0081177745038363] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.005 [0.9987656488205027, 1.0222234772547307] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 0.996 [0.9641414148444195, 1.0155684694933527] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 1.008 [0.9869540219920083, 1.0166273749456014] | pass | - |
| full | aa | `fibonacci_1000_x100` | 0.999 [0.9699621344179055, 1.0275179795953568] | pass | - |
| full | aa | `factorial_1000_x50` | 1.005 [0.9922696430109412, 1.0117248219573602] | pass | - |
| full | aa | `multiply_100d_x100000` | 1.009 [0.994861383926607, 1.1021566553224267] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 1.010 [1.0005113545286852, 1.0164293455689308] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.992 [0.9699990705595164, 1.0075305613452918] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 0.990 [0.9659674728009862, 1.0119823606615472] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.001 [0.9893301371955063, 1.0076838529389738] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.9774121574356093, 1.0080253786182505] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9803943389834722, 1.015881844928902] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.002 [0.9975598966672121, 1.051297194278007] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.006 [0.9755657809197763, 1.0989497331644522] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.005 [0.9939376411513208, 1.0720325122128866] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 0.993 [0.9758331311809011, 1.010361754349065] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 0.995 [0.9851421380665585, 1.010696464366601] | pass | - |
| full | aa | `recursion_50_x1000` | 1.004 [1.00082850041383, 1.021295047451562] | pass | - |
| full | aa | `sparse_array_200000` | 1.026 [0.9877439358576889, 1.0471966077518406] | pass | - |
| full | aa | `frontend_definitions_2000` | 0.970 [0.9478137161191698, 0.9939844200430268] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 1.007 [0.9847099942484283, 1.018690532690524] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.000 [0.9728839738710492, 1.04917230694385] | pass | - |
| full | aa | `streaming_statements_20000` | 1.005 [0.9932310838796127, 1.0270675219338703] | pass | - |
| full | aa | `square_100d_x100000` | 1.002 [0.9747009575531027, 1.0622784749813903] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 0.997 [0.9956612266903949, 1.0048576111084562] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.977 [0.9583509344844651, 1.0682985425889633] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.008 [0.9744424166472724, 1.0410542302700385] | pass | - |
| full | aa | `octal_output_1000d_x300` | 0.991 [0.9868910923926643, 1.0048260712437969] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.008 [0.989710776865419, 1.0514866952095996] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 0.998 [0.9472538277399316, 1.009025901925615] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.007 [0.9894314670178848, 1.0132123862070295] | pass | - |
| full | aa | `file_statements_20000` | 1.002 [0.99140688483041, 1.013648131883556] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.000 [0.9981367574859632, 1.0021876901940612] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.011 [0.9754619148466666, 1.046104880269257] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.023 [0.9736673143535438, 1.0471195090494134] | pass | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.003 [0.9935982582459958, 1.0150270326508817] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.973 [0.9600512320090987, 0.9980013324458749] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.980 [0.9597767147557388, 1.0645885900677163] | inconclusive-noisy | - |
| full | paired | `startup` | 1.027 [0.9458013134045139, 1.0656634114717036] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.998 [0.9521213545929997, 1.0098574324736602] | pass | inconclusive-noisy |
| full | paired | `calls_200000` | 1.012 [0.9686470951263939, 1.0441970841540298] | pass | pass |
| full | paired | `array_200000` | 0.975 [0.9482597451066869, 0.9882809056972452] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 0.985 [0.979452290019008, 1.004277466078316] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 1.007 [0.9893028913785088, 1.0187734070863854] | pass | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.971 [0.9335284468122839, 1.012481222940077] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 1.008 [0.9573478160882499, 1.0242394423947592] | pass | pass |
| full | paired | `factorial_1000_x50` | 0.989 [0.9615544762709788, 1.0202542555485437] | pass | pass |
| full | paired | `multiply_100d_x100000` | 0.986 [0.9825849095423902, 0.9971729152364818] | pass | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.993 [0.981513265607498, 1.0337952594041986] | pass | pass |
| full | paired | `divide_scale100_x100000` | 1.003 [0.9874680380794375, 1.1517565650677857] | inconclusive-noisy | pass |
| full | paired | `sqrt_scale100_x5000` | 0.993 [0.9813268706460264, 1.0214486156070846] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 0.999 [0.9915370492871601, 1.008531423591153] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.024 [0.9540314285009622, 1.0841950765688952] | inconclusive-noisy | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.996 [0.9256459822851163, 1.0067417442512296] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.997 [0.9750446315918783, 1.041296567789121] | pass | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.999 [0.9594029647767097, 1.0123357805735673] | pass | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.000 [0.9898521611702326, 1.0516412578230778] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.003 [0.9847304043658843, 1.05614032050733] | inconclusive-noisy | pass |
| full | paired | `ibase_literal_flip_20000` | 0.998 [0.94603364903927, 1.0172230011742591] | pass | pass |
| full | paired | `recursion_50_x1000` | 1.002 [0.9660489013059482, 1.1463279702378493] | inconclusive-noisy | pass |
| full | paired | `sparse_array_200000` | 0.994 [0.9728607631793007, 1.0280344932574528] | pass | pass |
| full | paired | `frontend_definitions_2000` | 0.993 [0.9600539218455226, 1.0092527151169852] | pass | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.013 [1.003476461736322, 1.02201530276716] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 1.038 [0.9286480525328726, 1.0442795926867139] | pass | pass |
| full | paired | `streaming_statements_20000` | 1.007 [0.9850982157937006, 1.0630349157458685] | inconclusive-noisy | pass |
| full | paired | `square_100d_x100000` | 0.998 [0.9816621621256199, 1.1014512129075642] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.997 [0.9902333691844194, 1.0050749815490025] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.005 [0.9640178870633964, 1.039011847913828] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.003 [0.9706321266596065, 1.023137164463645] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 0.997 [0.9436477609407964, 1.0195571561804655] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 1.001 [0.9867857505876177, 1.1105046017147633] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.997 [0.9780322224991383, 1.165501871536017] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 0.999 [0.9897603216213537, 1.024870935962879] | pass | pass |
| full | paired | `file_statements_20000` | 0.984 [0.9703322107419736, 1.048751126049537] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.001 [0.9902979156823103, 1.0038790858451074] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.967 [0.9272078810716491, 1.022760776734388] | pass | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.980 [0.9553003207228098, 1.0361353045089159] | pass | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.998 [0.9899645540622014, 1.0195777428977884] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.038 [0.9945594181674441, 1.0452962729714186] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.011 [0.9787114973104296, 1.0323144036404388] | pass | inconclusive-noisy |
