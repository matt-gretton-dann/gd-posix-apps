# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.973 [0.8689412353664951, 1.1805527123781787] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.981 [0.9134370964964459, 1.062795228879967] | inconclusive-noisy | - |
| full | aa | `calls_200000` | 1.000 [0.9188233310305053, 1.0655414403549424] | inconclusive-noisy | - |
| full | aa | `array_200000` | 1.012 [0.9683455427548816, 1.0311523702335819] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.033 [0.9574540484163822, 1.0767745777038649] | inconclusive-noisy | - |
| full | aa | `compare_low_1000d_x100000` | 0.998 [0.9723693185426927, 1.0825075827580029] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.004 [0.9763499104793554, 1.0959386225108452] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 0.977 [0.9040396426995896, 1.002633159626595] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 0.987 [0.9214478727291384, 1.0086966905954777] | inconclusive-noisy | - |
| full | aa | `multiply_100d_x100000` | 1.004 [0.9274822852598353, 1.0160872582107197] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 0.977 [0.925261032877863, 1.0378632033583872] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 1.015 [0.9988497249653684, 1.1021062520962468] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 1.013 [0.8952214678716894, 1.0673368137794026] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 1.032 [0.978330743900073, 1.0623718710998793] | inconclusive-noisy | - |
| full | aa | `multiply_dense_10000d_x500` | 1.021 [0.9418760575957699, 1.0492593887166106] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.989 [0.9588418557028289, 1.014832590941053] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.994 [0.9782967990680103, 1.0795350946621405] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.056 [0.945306824376761, 1.0826567166845094] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.933 [0.8214755667025372, 1.00743710630227] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 1.001 [0.9693981219189732, 1.0093171659091515] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.024 [0.953429389927355, 1.0477656725676636] | pass | - |
| full | aa | `recursion_50_x1000` | 1.019 [1.0007707515300885, 1.1159416330336183] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 0.997 [0.9597109024761379, 1.0665362137577203] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 1.007 [0.7457419797576234, 1.1569890472219153] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 0.995 [0.9566025668358059, 1.0613938123773137] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 1.013 [0.9222288372889299, 1.2700576808351531] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.030 [0.95082334719612, 1.1022145245290345] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 1.000 [0.9796833930996997, 1.1929119289269428] | inconclusive-noisy | - |
| full | aa | `square_10000d_x500` | 1.023 [0.9689964009787044, 1.034922227760936] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.942 [0.9135816723162301, 1.0098015618858855] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.006 [0.9662426765254382, 1.0069357938170262] | pass | - |
| full | aa | `octal_output_1000d_x300` | 0.996 [0.9368113884049122, 1.0616982684472684] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 1.006 [0.9690080015381951, 1.0196135473779377] | pass | - |
| full | aa | `hex_input_100000d_x3` | 0.991 [0.9631016447843451, 1.070605837469498] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.005 [0.9470551972231214, 1.055173289762343] | inconclusive-noisy | - |
| full | aa | `file_statements_20000` | 0.998 [0.8921798121534038, 1.0696317712632792] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 0.998 [0.9730735281399796, 1.0105929400351483] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.026 [1.0070388121871354, 1.0433888933873852] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.007 [0.9671803359346764, 1.1371931715024828] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.991 [0.9688009351238752, 1.0323607202858214] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.960 [0.9054035078209166, 1.0609775488885977] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.036 [0.9608193632561494, 1.1854496837903294] | inconclusive-noisy | - |
| full | paired | `startup` | 1.056 [0.9707420828736361, 1.1630858104918533] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.994 [0.9497788263591885, 1.0712207909740608] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `calls_200000` | 1.032 [0.9972114025942045, 1.1098017247602798] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `array_200000` | 1.015 [0.9996143675374467, 1.0440547251162717] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 1.052 [0.9497469478513461, 1.1649931971149043] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.003 [0.980612853772416, 1.0135929518469355] | pass | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.003 [0.9005936678609081, 1.0475907714806059] | pass | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.014 [0.9904383451033085, 1.0350381128372463] | pass | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.996 [0.9471585293532532, 1.0745044315191328] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.017 [0.9909309720945509, 1.0314830214738562] | pass | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.988 [0.9682838799364447, 1.0215287639818738] | pass | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.010 [0.9982349277810598, 1.0520471340661905] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.023 [0.9126438354062649, 1.0302356444353757] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 1.014 [0.9545457292349157, 1.0404440577691352] | pass | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.989 [0.965842073858466, 1.0644090595708375] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.981 [0.9651098621178289, 1.010738408259834] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.972 [0.9520938602432283, 1.052425948067439] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.979 [0.9388544736154646, 1.0054580498600294] | pass | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.997 [0.936512000468088, 1.042442609275835] | pass | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.994 [0.882007071525933, 1.040821673888668] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 1.002 [0.9641351355361704, 1.0305899358683261] | pass | pass |
| full | paired | `recursion_50_x1000` | 0.992 [0.9380065035409755, 1.0234070356492586] | pass | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.967 [0.9203602049072211, 1.0290286574105014] | pass | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.011 [0.987561034322399, 1.0872795365984367] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.008 [0.9921834100716712, 1.1218782019113183] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.974 [0.8524078929174803, 1.1566942111867777] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.987 [0.864069698734202, 1.1457903429124086] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.019 [0.97371623227828, 1.531228513795866] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.988 [0.9598821360476153, 1.110455344975874] | inconclusive-noisy | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.968 [0.9142015622982511, 1.0140326091197422] | pass | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.979 [0.859072902912265, 0.9985179760565024] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 1.007 [0.9858423421697845, 1.1245124297844533] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.996 [0.7543489783384058, 1.0684936960325604] | inconclusive-noisy | pass |
| full | paired | `hex_input_100000d_x3` | 0.984 [0.9593613579633663, 1.0032437192279333] | pass | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 0.997 [0.9613949632839606, 1.0531555338758056] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `file_statements_20000` | 0.976 [0.9301806248173623, 1.0299500834234938] | pass | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 1.003 [0.9705453267047554, 1.0284092935215652] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.971 [0.8978596456872232, 1.4335576764254374] | inconclusive-noisy | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.976 [0.797390030639018, 1.0648609344734015] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.018 [0.9289116388019687, 1.0316636346940822] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.048 [1.008310727246637, 1.0612900306543167] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.012 [0.9489835888706414, 1.073018654375698] | inconclusive-noisy | inconclusive-noisy |
