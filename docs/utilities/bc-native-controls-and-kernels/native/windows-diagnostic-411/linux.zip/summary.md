# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.071 [0.8182550978961538, 1.1093601522794738] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.990 [0.974293078503414, 1.017735964384102] | pass | - |
| full | aa | `calls_200000` | 0.986 [0.9669581063451488, 1.0233320524820029] | pass | - |
| full | aa | `array_200000` | 1.004 [0.9819718846107014, 1.019466515335602] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.014 [0.9881580519703622, 1.0411329024649463] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.014 [1.0064344212606473, 1.020351179020174] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 1.006 [1.004576434447405, 1.025828921276315] | pass | - |
| full | aa | `fibonacci_1000_x100` | 0.994 [0.9518906583681507, 1.0147210458138518] | pass | - |
| full | aa | `factorial_1000_x50` | 1.003 [0.9884978875060203, 1.0072666953572105] | pass | - |
| full | aa | `multiply_100d_x100000` | 0.999 [0.9800176531018315, 1.0144950854470465] | pass | - |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.9961614529176002, 1.005482396155069] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.995 [0.9928937687937806, 1.006923421843087] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.002 [1.000339696532238, 1.0064897793693515] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.001 [1.0002163905613912, 1.0025313409094732] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.9970609573268544, 1.0020942219605482] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.007 [0.9858331792371067, 1.014313299430786] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9967530861394698, 1.0423759465225457] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.005 [0.9888540487583132, 1.0113488250309202] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.998 [0.9914980445884957, 1.0019535642270703] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.993 [0.9737479692167079, 1.0092148169107187] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.008 [0.9823720801997522, 1.0725701218335815] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 1.009 [1.0003468926265722, 1.0331776621035678] | pass | - |
| full | aa | `sparse_array_200000` | 0.999 [0.9869507827994454, 1.009194718376737] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.001 [0.9888596799931614, 1.0051688021462941] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.001 [0.9913604722371622, 1.0723516762710272] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 1.027 [0.9875835426283387, 1.149368878466423] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.994 [0.9755391211250345, 1.0036535932850488] | pass | - |
| full | aa | `square_100d_x100000` | 1.003 [0.9903398967457788, 1.0247915757570258] | pass | - |
| full | aa | `square_10000d_x500` | 1.001 [0.9957170857855806, 1.0026441599887896] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.974 [0.8854732273955421, 1.0425609279330073] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.997 [0.9770373110448349, 1.0105563858824949] | pass | - |
| full | aa | `octal_output_1000d_x300` | 0.995 [0.9507906910550399, 1.0189133778502668] | pass | - |
| full | aa | `binary_input_100000d_x3` | 1.003 [0.9860807784987733, 1.0092425719384097] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.003 [0.9842086387610357, 1.0054777925224276] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.006 [0.991032368894617, 1.0115415095794087] | pass | - |
| full | aa | `file_statements_20000` | 1.000 [0.9915390944649422, 1.0021485449434113] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.001 [0.9993014240969, 1.0017474298651128] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.012 [0.9975873366146794, 1.0297110793353794] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.005 [0.9945858320593675, 1.0591826090722] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.000 [0.9981122632387569, 1.0035330703042076] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.988 [0.9743825068405996, 1.0240064043326835] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.006 [0.9684543193199846, 1.0368742859084457] | pass | - |
| full | paired | `startup` | 1.011 [0.9079195210628735, 1.0868667111821317] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.028 [0.9889831094375569, 1.0348462292978855] | pass | pass |
| full | paired | `calls_200000` | 1.007 [0.9600630808275595, 1.0266103622997376] | pass | pass |
| full | paired | `array_200000` | 0.999 [0.9914145999651172, 1.009671021532202] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 1.018 [1.0164635613368822, 1.0232809391845048] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 1.019 [1.0008770879657582, 1.0564944269678818] | inconclusive-noisy | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.023 [1.0139634072533534, 1.0418055855801631] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 1.014 [0.9992466564696382, 1.025315643129161] | pass | pass |
| full | paired | `factorial_1000_x50` | 1.017 [1.0040030948290506, 1.0276351572147477] | pass | pass |
| full | paired | `multiply_100d_x100000` | 1.008 [0.9643255909550091, 1.0200766308952631] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 1.000 [0.9968751958586507, 1.0602108590909303] | inconclusive-noisy | pass |
| full | paired | `divide_scale100_x100000` | 1.003 [0.9930576603185541, 1.0180144121880106] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 1.005 [0.9982823761557863, 1.0077891906988523] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 1.000 [0.998444684033928, 1.0044671387962831] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.997 [0.9950007969030623, 1.0055134052587233] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9906798333726214, 1.015455524258773] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.999 [0.9197681104881479, 1.0029289449820615] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.005 [0.9895388032725356, 1.0180576882579013] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.997 [0.9938830592703874, 1.0089923110452632] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.995 [0.9852883726688973, 1.006325056021788] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 0.997 [0.985649988674701, 1.0312098820435724] | pass | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.011 [0.9809695179627325, 1.0230653081836996] | pass | pass |
| full | paired | `sparse_array_200000` | 0.991 [0.979959903856807, 1.0071034314611558] | pass | pass |
| full | paired | `frontend_definitions_2000` | 1.011 [0.9820083092062439, 1.0290361371581411] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 0.990 [0.9705033308117799, 1.0350075627251059] | pass | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.064 [0.9497614265228718, 1.1354455464353046] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.997 [0.9930517543471502, 1.0115129163815033] | pass | pass |
| full | paired | `square_100d_x100000` | 1.011 [1.0034312110042465, 1.0304514530918216] | pass | pass |
| full | paired | `square_10000d_x500` | 1.001 [0.9990707605624585, 1.0015472706862796] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.996 [0.867235349822809, 1.0804063446590881] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.006 [1.0012899920809775, 1.0122830535501246] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 1.003 [0.9967290143329121, 1.011707703788601] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 0.990 [0.9829689120943688, 1.0060212578676844] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.996 [0.9931585595560696, 1.0104068606435075] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.006 [0.9958553426540271, 1.0132690996203675] | pass | pass |
| full | paired | `file_statements_20000` | 0.987 [0.9825842186284628, 1.0018370155785767] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.000 [0.9999437843508164, 1.000895471207331] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.953 [0.9335015812300917, 0.9921898473216612] | pass | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.990 [0.9162844903352184, 1.0687500511275128] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.000 [0.9968404556130287, 1.0026719300015494] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 0.996 [0.9239068808464693, 1.0278275674792527] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.993 [0.9413454226405048, 1.0160191935649379] | pass | pass |
