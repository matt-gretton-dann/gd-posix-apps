# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.016 [0.9158102229420769, 1.1183964257752723] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.002 [0.9856515268684103, 1.0188223639761467] | pass |
| full | aa | `calls_200000` | 1.006 [0.9876099917993272, 1.0282724751414989] | pass |
| full | aa | `array_200000` | 0.982 [0.9653604324870424, 1.0349699186276153] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.994 [0.9886922829273341, 0.9986353300916424] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.999 [0.9639160057727971, 1.0400505881531228] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.998 [0.8156193185049098, 1.0055535938921452] | pass |
| full | aa | `fibonacci_1000_x100` | 0.988 [0.9820127677462043, 1.0019059481328405] | pass |
| full | aa | `factorial_1000_x50` | 1.002 [0.9163402551434361, 1.0331049644244201] | pass |
| full | aa | `multiply_100d_x100000` | 0.992 [0.9780294793290287, 1.000891573235766] | pass |
| full | aa | `multiply_10000d_x1000` | 0.992 [0.9774690192032621, 1.000868813340184] | pass |
| full | aa | `divide_scale100_x100000` | 0.989 [0.9611254911119751, 1.0027658683219853] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.994 [0.9913655025625019, 1.00678835919009] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9763826017146927, 1.0236484715564578] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.008 [0.9949450457755985, 1.1956122677418306] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.013 [0.9800459249457483, 1.0587656857270045] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.016 [0.9875566074442271, 1.0552124915146464] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.994 [0.9754305959161527, 0.9985100130114055] | pass |
| full | aa | `power_100d_e17_x1000` | 1.009 [0.9726460260625449, 1.015702625655519] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.997 [0.9934470710185345, 1.0287111674647929] | pass |
| full | aa | `recursion_50_x1000` | 1.008 [0.9917991063841718, 1.0236036221906857] | pass |
| full | aa | `sparse_array_200000` | 0.986 [0.9653294557708517, 1.021072105508033] | pass |
| full | aa | `frontend_definitions_2000` | 0.999 [0.9884476462935256, 1.0355403344793062] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.003 [0.9847071424441403, 1.0410643729708715] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.997 [0.9660564198836623, 1.1224121056940914] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.994 [0.9729397103638743, 1.0523590878212377] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.003 [0.9041447521951569, 1.0153147017849267] | pass |
| full | aa | `square_10000d_x500` | 1.002 [0.9945801980905778, 1.0032755698023592] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.947 [0.8880508553404338, 1.0780435753566946] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.997 [0.9660758802796486, 1.039970621967314] | pass |
| full | aa | `octal_output_1000d_x300` | 0.996 [0.9867219198905114, 1.0141747645326433] | pass |
| full | aa | `binary_input_100000d_x3` | 1.005 [0.9993786718157824, 1.0104608686587084] | pass |
| full | aa | `hex_input_100000d_x3` | 0.998 [0.9499815386799958, 1.008206877510865] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.001 [0.9961882376051292, 1.0023444287092436] | pass |
| full | paired | `startup` | 1.028 [0.9876175501112785, 1.0809970272178984] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.037 [1.0004555085436608, 1.0561170923889684] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.016 [0.9815119822360008, 1.0608798884902175] | inconclusive-noisy |
| full | paired | `array_200000` | 0.996 [0.988447365737394, 1.0728623999791858] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.014 [1.0000019476222342, 1.031599972586026] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.017 [1.0118876809004398, 1.0372067439773405] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.019 [1.0054969896653752, 1.031848017239365] | pass |
| full | paired | `fibonacci_1000_x100` | 1.000 [0.9817323394271867, 1.0293777036006295] | pass |
| full | paired | `factorial_1000_x50` | 0.995 [0.9944326410843172, 1.0068771782584633] | pass |
| full | paired | `multiply_100d_x100000` | 0.990 [0.9276206590616727, 0.9969392533780173] | pass |
| full | paired | `multiply_10000d_x1000` | 1.008 [1.001450344445997, 1.0148071719001515] | pass |
| full | paired | `divide_scale100_x100000` | 0.998 [0.9883386937076529, 1.1134734667882398] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.007 [1.0002155894200369, 1.0177859707101924] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.9853408143577038, 1.020365626898672] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.007 [0.990429490182923, 1.0103270096756507] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.963 [0.9510301844943801, 1.0462949545168063] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.008 [0.9600819099842193, 1.013833484841308] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.002 [0.9939428831216601, 1.0123689158626372] | pass |
| full | paired | `power_100d_e17_x1000` | 1.001 [0.9706744130942873, 1.0083537479867326] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.026 [1.009963159977954, 1.0372925707069405] | pass |
| full | paired | `recursion_50_x1000` | 0.999 [0.9829762602859954, 1.1235295013233635] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.008 [0.9654060004467044, 1.0350811641611661] | pass |
| full | paired | `frontend_definitions_2000` | 0.980 [0.8797286042663043, 1.0258997653994442] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.018 [0.9856227521529496, 1.019847757678885] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.003 [0.9720316263016344, 1.031904818278919] | pass |
| full | paired | `streaming_statements_20000` | 1.031 [0.9821737517097794, 1.0465919655885876] | pass |
| full | paired | `square_100d_x100000` | 0.989 [0.9188065233704703, 0.9983896598003663] | pass |
| full | paired | `square_10000d_x500` | 0.996 [0.9941924706101865, 1.003994778083353] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.988 [0.8880654919241217, 1.0939158416411976] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.993 [0.9398648347517109, 1.0152186965960892] | pass |
| full | paired | `octal_output_1000d_x300` | 1.004 [0.9822987098487591, 1.0189497122019033] | pass |
| full | paired | `binary_input_100000d_x3` | 1.004 [0.9948459283111928, 1.0216308399165674] | pass |
| full | paired | `hex_input_100000d_x3` | 0.998 [0.986143878813949, 1.0312663705220602] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.000 [0.9975825811600912, 1.0169909101394743] | pass |
