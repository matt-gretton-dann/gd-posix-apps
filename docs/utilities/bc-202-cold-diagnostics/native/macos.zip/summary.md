# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.033 [0.8889607056311102, 1.0979207043191066] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.941 [0.8948893984963875, 0.9758485399467778] | pass |
| full | aa | `calls_200000` | 0.970 [0.9458215486987698, 1.0172648739706174] | pass |
| full | aa | `array_200000` | 0.986 [0.8365783321852055, 1.0659740188235671] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.982 [0.7447357841552619, 1.0557899802621165] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.943 [0.8583818667202371, 1.15612616056921] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.014 [0.980861613638363, 1.1248679701035484] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.000 [0.8278401301976288, 1.0888001752302559] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.062 [0.9917487217288721, 1.1795020072354079] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.983 [0.7146892523677857, 1.0007045128333163] | pass |
| full | aa | `multiply_10000d_x1000` | 0.994 [0.8892677651700988, 1.0213229596257674] | pass |
| full | aa | `divide_scale100_x100000` | 0.871 [0.8060943666499724, 1.0720934942450089] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.991 [0.7623125286407649, 1.0553681066466853] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.034 [0.9513473633215318, 1.1333930703976758] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.016 [0.992453595546616, 1.3162727427163625] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 0.921 [0.8166942039518836, 1.0344708562083724] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.052 [0.988376870269407, 1.2128728394822943] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.981 [0.8623184564305956, 1.1575620074506483] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.833 [0.7661726918022966, 0.9884466725558555] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.948 [0.7683735642450138, 1.097755854028364] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.811 [0.7822481050617183, 1.0743321565810688] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.060 [0.870712014871795, 1.0945798351114353] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 1.101 [0.8053349381409838, 1.1652323574002053] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.015 [0.9733314051351226, 1.0779582549592404] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 0.839 [0.742698546383581, 0.9151600027462109] | pass |
| full | aa | `streaming_statements_20000` | 0.981 [0.8579339117336526, 1.1109590640020888] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.954 [0.8894892116414722, 1.0833244778741276] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.992 [0.9768513009432078, 1.0673139832244831] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 1.020 [0.9049290053658448, 1.0731172191339897] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.973 [0.6607057383812173, 1.2463201997151432] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 1.180 [0.9690638266049746, 1.2830895305495262] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 0.997 [0.7319858039429239, 1.1848342644090986] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 1.001 [0.9461310674148107, 1.0760317322747945] | inconclusive-noisy |
| full | aa | `temporary_chain_1000d_x50000` | 1.008 [0.9957406014477812, 1.1880599455039407] | inconclusive-noisy |
| full | paired | `startup` | 1.041 [0.9773646138732189, 1.4212911367226773] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.937 [0.8331806311039603, 1.076767487707668] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.989 [0.8720376339365545, 1.2389115651357958] | inconclusive-noisy |
| full | paired | `array_200000` | 0.923 [0.7335483235159989, 1.2200032662333076] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.983 [0.8825588121821666, 1.190778126933493] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.969 [0.7242319741472164, 1.1862265496926567] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.070 [0.7978211956709018, 1.165822926539854] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.923 [0.8658951303973585, 1.0971589413649965] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.042 [0.8267998372056585, 1.1762642030237085] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.061 [0.8255489918681035, 1.2048408743109376] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.039 [0.9554606977248812, 1.0927517889412732] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.128 [0.9692809515491673, 1.1972195101791911] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.924 [0.8648802885460906, 0.9952647384535952] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.005 [0.8324147313192399, 1.1407826724882677] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.990 [0.9393855513093813, 1.1425893742653013] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.012 [0.8172390525794083, 1.0941864443223825] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.995 [0.7632008147898215, 1.050266116336533] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.043 [0.7440092838644765, 1.1475952934859361] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.010 [0.8106852891161455, 1.0770538268896508] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.916 [0.8340400262880818, 1.060706333283874] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.050 [0.8465318783438144, 1.2827747173193371] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.992 [0.9169485377022758, 1.2510919893646804] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.188 [0.8572855077621785, 1.3904463723865144] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.043 [0.931520556327677, 1.4530425330635548] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.981 [0.7421225780388806, 1.151965316731458] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.913 [0.8407111988691728, 0.9712939351533059] | pass |
| full | paired | `square_100d_x100000` | 1.082 [0.9637091126917798, 1.246679110039711] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.989 [0.9748384481282804, 1.0381963326737238] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.996 [0.8024466912972089, 1.4673125641450697] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.064 [0.7106912924697101, 1.4598984693442396] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.025 [0.6963365135641499, 1.3065276783074702] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.961 [0.8763611148859429, 1.1969780984413796] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.925 [0.8549543410021115, 1.0281869965689432] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.024 [0.8329991097782955, 1.1023214434013076] | inconclusive-noisy |
