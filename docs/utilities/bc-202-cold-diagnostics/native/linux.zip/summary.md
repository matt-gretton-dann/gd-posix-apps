# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.099 [0.8214014098598922, 1.2461429430584097] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.996 [0.9815524299918154, 1.009347606017028] | pass |
| full | aa | `calls_200000` | 0.996 [0.9666790832696044, 1.0769382318058212] | inconclusive-noisy |
| full | aa | `array_200000` | 0.997 [0.9913239344089428, 1.0189517716073304] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.996 [0.9551077619289364, 1.0097822191611956] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.999 [0.9908868907900862, 1.01035117296976] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.993 [0.9812615443365446, 1.0139468943609327] | pass |
| full | aa | `fibonacci_1000_x100` | 0.999 [0.9823591341895228, 1.004978839519152] | pass |
| full | aa | `factorial_1000_x50` | 0.996 [0.9856007840796144, 1.0022481612004166] | pass |
| full | aa | `multiply_100d_x100000` | 0.986 [0.9710610043238046, 1.001775600820779] | pass |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.9952752123795198, 1.0016925128201637] | pass |
| full | aa | `divide_scale100_x100000` | 1.011 [0.996203997303742, 1.02937736681495] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.000 [0.9964332473562173, 1.0031307796574696] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.997 [0.993901301153897, 1.005936378079488] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9966959485992861, 1.0107593891916797] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [1.0000513946262317, 1.0064397077634768] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.012 [0.9906133315998588, 1.0278017723171848] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9742634850738288, 1.0089719187581148] | pass |
| full | aa | `power_100d_e17_x1000` | 1.002 [0.9979698600766588, 1.0098689065820485] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.012 [0.980358890350852, 1.0218914341831653] | pass |
| full | aa | `recursion_50_x1000` | 1.000 [0.9938153604494201, 1.0201218357140447] | pass |
| full | aa | `sparse_array_200000` | 1.000 [0.9884397345220852, 1.0345132752182258] | pass |
| full | aa | `frontend_definitions_2000` | 1.004 [0.9904143402784648, 1.0219772469152417] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.010 [0.9774211038253556, 1.0213196010787062] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.997 [0.8704682662071622, 1.1198459932760543] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.995 [0.9886073626715322, 1.0083083479151533] | pass |
| full | aa | `square_100d_x100000` | 0.990 [0.9680071498932863, 1.0251046674056359] | pass |
| full | aa | `square_10000d_x500` | 0.999 [0.9983980221519722, 1.0009988114101915] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.894 [0.8432814739222525, 1.0984203087406874] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.002 [0.9818270798846717, 1.0221541987268759] | pass |
| full | aa | `octal_output_1000d_x300` | 1.004 [0.9774122590110578, 1.0125279871901784] | pass |
| full | aa | `binary_input_100000d_x3` | 1.002 [0.9820193589252063, 1.0052059628491774] | pass |
| full | aa | `hex_input_100000d_x3` | 0.998 [0.9898451235009292, 1.0135813786140497] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.999 [0.9950648154918036, 1.0065511466574382] | pass |
| full | paired | `startup` | 1.111 [0.8898733009469654, 1.2110493082303082] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.012 [0.9993671462411805, 1.0394212894106605] | pass |
| full | paired | `calls_200000` | 0.986 [0.9756401599416784, 1.0141317100452896] | pass |
| full | paired | `array_200000` | 0.970 [0.9662675188483484, 0.9863190927832614] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.019 [1.0036345837362641, 1.0354032035888172] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.014 [0.9780520833851457, 1.038843989090106] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.021 [0.9996316614385297, 1.0397579964647083] | pass |
| full | paired | `fibonacci_1000_x100` | 1.000 [0.9883724827165854, 1.0364122925549337] | pass |
| full | paired | `factorial_1000_x50` | 0.985 [0.9719566909445949, 0.9930180280309949] | pass |
| full | paired | `multiply_100d_x100000` | 0.992 [0.9811868689822097, 1.0269359362276194] | pass |
| full | paired | `multiply_10000d_x1000` | 0.998 [0.8881422822837255, 1.000707894349951] | pass |
| full | paired | `divide_scale100_x100000` | 1.045 [1.020515491549342, 1.0519000105818919] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.003 [0.9984654790700417, 1.0325441972589964] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.997 [0.9715029217882866, 1.0005711519736806] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.996 [0.9900100872283075, 1.0054135598691338] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.985 [0.9825879524956163, 0.990811283832285] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.9876630061367847, 1.023006599291877] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.004 [0.9889339509984056, 1.0068257369331437] | pass |
| full | paired | `power_100d_e17_x1000` | 1.011 [0.9844900902071219, 1.0165122194631855] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.989 [0.9792636176139118, 1.01723656253034] | pass |
| full | paired | `recursion_50_x1000` | 1.008 [1.0021641730019553, 1.020317938535113] | pass |
| full | paired | `sparse_array_200000` | 1.046 [1.0299876899135179, 1.0544769782709724] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.003 [0.9882391948531026, 1.0077966704887065] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.983 [0.9659942110901668, 0.9934274144207457] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.005 [0.8972943768479672, 1.1210273485862234] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.993 [0.9814720198407686, 1.0059460828246827] | pass |
| full | paired | `square_100d_x100000` | 0.993 [0.9765935038225697, 1.0063329566508485] | pass |
| full | paired | `square_10000d_x500` | 0.995 [0.9939802170002758, 0.9956671003380091] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.965 [0.8744971126158395, 1.1501520120514377] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.976 [0.9463843485919906, 1.0066026600300957] | pass |
| full | paired | `octal_output_1000d_x300` | 0.993 [0.9888524742205402, 1.0013593117836115] | pass |
| full | paired | `binary_input_100000d_x3` | 0.989 [0.9771455433850108, 1.0003096102849731] | pass |
| full | paired | `hex_input_100000d_x3` | 0.997 [0.9940146646921573, 1.0016728617064594] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.985 [0.977605078264445, 0.9888725090442281] | pass |
