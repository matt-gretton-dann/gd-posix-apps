# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.959 [0.8751238617357071, 1.020544758384209] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.997 [0.9506303698468669, 1.0168503614060198] | pass |
| full | aa | `calls_200000` | 1.000 [0.8320287349501527, 1.1629069676554047] | inconclusive-noisy |
| full | aa | `array_200000` | 0.970 [0.9610630136966938, 1.1051152511113487] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.999 [0.9855853959416487, 1.2962758833658863] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.005 [0.9693334539196116, 1.0327652206397517] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.090 [0.9921137353391489, 1.1558225438147358] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.002 [0.9621761787141994, 1.1118966653117817] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 0.996 [0.8194908777331619, 0.9992955981261253] | pass |
| full | aa | `multiply_100d_x100000` | 1.000 [0.8789430125225711, 1.2348172202615313] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.992 [0.9884941166451942, 1.0355268394739843] | pass |
| full | aa | `divide_scale100_x100000` | 0.997 [0.876201111833861, 1.03318860550507] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.9820985697176658, 1.0787682174313766] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 0.970 [0.9054970421341995, 1.0111858069800843] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.8831028235869429, 1.2799050226165922] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9623919114286182, 1.0806994808582622] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.915 [0.7626522223193011, 1.0079810634865898] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.973 [0.9524018375134123, 1.0337709693562103] | pass |
| full | aa | `power_100d_e17_x1000` | 0.991 [0.7590593560596617, 1.033643877039605] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.008 [1.0006344877930191, 1.1211242947648816] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.992 [0.9818031595245498, 1.0896727504252028] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.951 [0.9214607373321381, 1.108630246961377] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.961 [0.9254519704891121, 1.0384476071706539] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.015 [0.9676512189802335, 1.0577392428712282] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 0.984 [0.9373315849799319, 1.0992223716760183] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.031 [0.9055349292138192, 1.047944918354532] | pass |
| full | aa | `square_100d_x100000` | 0.956 [0.9131663737017863, 1.1865765845214034] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.994 [0.9230771841884605, 1.0371863694001129] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.992 [0.8511942145215257, 1.1197418206112482] | inconclusive-noisy |
| full | paired | `startup` | 1.019 [0.8633610059710896, 1.2482193039450098] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.005 [0.9058260092237723, 1.1411290490533967] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.803 [0.743152607878767, 0.9692850055563398] | pass |
| full | paired | `array_200000` | 1.008 [0.9715525105655796, 1.0675139344319202] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.040 [0.8822378820861174, 1.2613264487044633] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.039 [0.9296301938809781, 1.1550089541456388] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.056 [0.9722815123755453, 1.1935164562119958] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.054 [0.8447780891672244, 1.2221459917172137] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.017 [0.9400871057283089, 1.1755279785915203] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.004 [0.9045164824570288, 1.2170919158177194] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.8912833051680503, 1.0810780673636817] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.026 [0.7963437622358365, 1.0890793251693802] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.985 [0.9246683732874798, 1.2437736016605907] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.018 [0.9404665687814829, 1.0471021257230504] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.050 [0.8956032975347431, 1.0802765189870207] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.960 [0.9017843082801265, 1.4298553505832674] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.057 [0.965200770654632, 1.3436825450430008] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.979 [0.8860223532640037, 1.034724037989669] | pass |
| full | paired | `power_100d_e17_x1000` | 0.933 [0.7960593417940622, 1.2495570151336726] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.825 [0.7435056151153926, 0.9765853751984789] | pass |
| full | paired | `recursion_50_x1000` | 0.735 [0.6025195799187956, 0.9271044194029455] | pass |
| full | paired | `sparse_array_200000` | 1.031 [0.9305667897844403, 1.2117903793251368] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.985 [0.8611947223090937, 1.1017314469324249] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.019 [0.914872472643682, 1.431300158318677] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.980 [0.7760925893005599, 1.0636614014485553] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.043 [0.9885092202776877, 1.102831103096076] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.021 [0.8641410883056962, 1.3884912563842826] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.000 [0.8800811494997296, 1.0159238002008057] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.980 [0.9339895960866552, 1.2085041715318026] | inconclusive-noisy |
