# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.966 [0.940291295646146, 1.009066155543709] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.993 [0.9822656448849798, 1.0000208776528299] | pass |
| full | aa | `calls_200000` | 1.009 [0.9831063452896481, 1.024292500203718] | pass |
| full | aa | `array_200000` | 1.022 [0.972171160534339, 1.03700545820263] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.999 [0.9883830859085168, 1.0119729412196243] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.999 [0.9462924943337504, 1.0511927199870434] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.002 [0.9956555519225384, 1.0085775104688246] | pass |
| full | aa | `fibonacci_1000_x100` | 0.997 [0.9819190823584301, 1.0153609902151355] | pass |
| full | aa | `factorial_1000_x50` | 0.993 [0.9788406816906154, 1.0042285578320775] | pass |
| full | aa | `multiply_100d_x100000` | 1.002 [0.9440517712416281, 1.017841188471878] | pass |
| full | aa | `multiply_10000d_x1000` | 1.002 [0.9921404432925752, 1.0121082809468864] | pass |
| full | aa | `divide_scale100_x100000` | 1.009 [0.9935311393720663, 1.0307748383604163] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9861525254057476, 0.9996965957786081] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.022 [0.9968258659415136, 1.0334855169007942] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9862680099256964, 1.019517227934913] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.008 [1.0019817283338424, 1.0143103507265723] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.983 [0.9679917545833141, 1.0041706191285409] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.995 [0.9900227635081829, 1.0141829382094891] | pass |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9874181918141344, 1.0190150072515565] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.023 [1.007782040607684, 1.030069951000044] | pass |
| full | aa | `recursion_50_x1000` | 1.028 [0.9893400409351102, 1.054032718141841] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.998 [0.9602998418251555, 1.0115631206954083] | pass |
| full | aa | `frontend_definitions_2000` | 1.019 [0.9956655732989778, 1.1233752407059916] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.984 [0.9787515031327336, 1.0070399072296774] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.992 [0.9823681248289244, 1.0068258717197949] | pass |
| full | aa | `streaming_statements_20000` | 0.986 [0.9703461184468873, 1.0381007593909994] | pass |
| full | aa | `square_100d_x100000` | 1.014 [1.0005402324117572, 1.0153915691014561] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9966329828232944, 1.004893322572261] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.952 [0.9198453038650303, 1.026736965176974] | pass |
| full | paired | `startup` | 1.001 [0.8997052540476622, 1.0774751313733382] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.993 [0.9577322430954022, 1.0072587022727746] | pass |
| full | paired | `calls_200000` | 0.695 [0.6238798238969002, 0.6998357552979653] | pass |
| full | paired | `array_200000` | 0.994 [0.9782675536014611, 1.0088886249785722] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.997 [0.8131222375476379, 1.0036470841091647] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.996 [0.9698553147682094, 1.0853042306626046] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.991 [0.9654454275909938, 1.02230183270723] | pass |
| full | paired | `fibonacci_1000_x100` | 1.024 [1.0219245492674738, 1.101389402147303] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.009 [0.9953007918689739, 1.114483856297215] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.000 [0.9796265613269488, 1.002728957675051] | pass |
| full | paired | `multiply_10000d_x1000` | 0.972 [0.9530569865651184, 0.9944923905914863] | pass |
| full | paired | `divide_scale100_x100000` | 0.997 [0.9809104439745561, 1.0119961764956384] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.004 [0.9978251543971478, 1.042564501907976] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.975 [0.9715052401399008, 0.9927758576337171] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.973 [0.9608992952392583, 0.9964344775503571] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.966 [0.9324615897516918, 1.0060872976794324] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.990 [0.9721009951906637, 1.031041730632874] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.997 [0.9844584959737093, 1.0059613407031773] | pass |
| full | paired | `power_100d_e17_x1000` | 0.986 [0.9752971780878475, 1.0058425552000556] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.696 [0.6878704424350579, 0.725084593746312] | pass |
| full | paired | `recursion_50_x1000` | 0.390 [0.38679640019366296, 0.4016967025899942] | pass |
| full | paired | `sparse_array_200000` | 0.974 [0.9630372072785192, 0.9866773653355672] | pass |
| full | paired | `frontend_definitions_2000` | 0.950 [0.9300918684704622, 0.9863122987468368] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.952 [0.9112601341239233, 0.9877195487633228] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.994 [0.9891298867807695, 1.0349262425672958] | pass |
| full | paired | `streaming_statements_20000` | 0.925 [0.8775556297416343, 0.947272513651348] | pass |
| full | paired | `square_100d_x100000` | 0.992 [0.9873382385440902, 1.0109179134656716] | pass |
| full | paired | `square_10000d_x500` | 0.999 [0.9890953971592487, 1.002736925244833] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.966 [0.9218072289103473, 1.016392653386576] | pass |
