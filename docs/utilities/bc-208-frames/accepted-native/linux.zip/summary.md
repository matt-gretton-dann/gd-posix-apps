# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.980 [0.9346865095551594, 1.0249292498961327] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.010 [1.0048665606439673, 1.0732204783124462] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.995 [0.986840415658346, 1.0224793348461818] | pass |
| full | aa | `array_200000` | 0.992 [0.9774854280414846, 1.0012415406868598] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.997 [0.9786073672039797, 1.0135428987428534] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.999 [0.9789800188025012, 1.0429025391259186] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.993 [0.970794766293566, 1.0451245700154106] | pass |
| full | aa | `fibonacci_1000_x100` | 1.008 [0.9890504642963598, 1.0253175791378881] | pass |
| full | aa | `factorial_1000_x50` | 0.997 [0.9891450447117724, 1.0036701231316363] | pass |
| full | aa | `multiply_100d_x100000` | 0.973 [0.9608481723071189, 0.9801454356993573] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9833764414769831, 1.0138084619543832] | pass |
| full | aa | `divide_scale100_x100000` | 0.980 [0.9699537990486783, 1.0553866670430698] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.982 [0.9800070846610891, 0.9959078160098795] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.992 [0.9708388344486001, 1.043134325751588] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9758055958078803, 1.01032730444569] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9884844871765892, 1.0156581476766764] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.9938013865982112, 1.1297378014022454] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 1.003 [0.9914096119256667, 1.0057965446440722] | pass |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9931913147254039, 1.0179459526446029] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.005 [0.9878181331359183, 1.009704906778733] | pass |
| full | aa | `recursion_50_x1000` | 0.994 [0.9816839895381818, 1.003984160995674] | pass |
| full | aa | `sparse_array_200000` | 0.988 [0.9746540506402582, 1.0025160479114765] | pass |
| full | aa | `frontend_definitions_2000` | 1.004 [0.9890650863280018, 1.0212603589371323] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.992 [0.958804406764385, 0.999440972488618] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.996 [0.9805546767103296, 1.018114598987558] | pass |
| full | aa | `streaming_statements_20000` | 0.999 [0.9797080327258088, 1.0153475935336347] | pass |
| full | aa | `square_100d_x100000` | 0.979 [0.9660544353291036, 1.0181698597137523] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9951728829939136, 1.0132518862669653] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.989 [0.9264617895304432, 1.0646810057309795] | inconclusive-noisy |
| full | paired | `startup` | 1.182 [0.6273769782149458, 1.4300228558969728] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.006 [0.9799729175318903, 1.024714372775057] | pass |
| full | paired | `calls_200000` | 0.945 [0.9331900002577587, 0.9499249939153652] | pass |
| full | paired | `array_200000` | 1.005 [0.9858394161141457, 1.0442238736480391] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.006 [0.98291067087918, 1.0139479360980848] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.996 [0.9685913897163476, 1.0091635314146696] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.040 [1.0063564863843204, 1.0643505467222163] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.966 [0.9343761635172021, 1.0201931980854864] | pass |
| full | paired | `factorial_1000_x50` | 1.004 [0.9773422417111048, 1.016575853293598] | pass |
| full | paired | `multiply_100d_x100000` | 0.941 [0.9248115321514686, 0.9731523427031621] | pass |
| full | paired | `multiply_10000d_x1000` | 0.998 [0.9844819961208582, 1.012670147340294] | pass |
| full | paired | `divide_scale100_x100000` | 0.970 [0.9543782796623542, 0.9754747373776543] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.993 [0.9755942856030843, 1.0030268287216624] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.002 [0.9656720115551216, 1.0543231489634155] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9958372164219765, 1.027939506475724] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.003 [0.974335938686054, 1.012101150608404] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.994 [0.969268904744767, 1.0015204236616915] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.997 [0.9924698912404192, 1.000494400574624] | pass |
| full | paired | `power_100d_e17_x1000` | 1.003 [0.9799452335585896, 1.0108740708185113] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.899 [0.877926865795211, 0.923721037228694] | pass |
| full | paired | `recursion_50_x1000` | 0.648 [0.6382245400420609, 0.657735139804593] | pass |
| full | paired | `sparse_array_200000` | 0.972 [0.9610455209043889, 1.0104783923995801] | pass |
| full | paired | `frontend_definitions_2000` | 1.000 [0.9824017359407013, 1.0039907781794515] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.994 [0.9664803006510669, 1.066353952524294] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.981 [0.8514930341843225, 0.9918705080864836] | pass |
| full | paired | `streaming_statements_20000` | 1.012 [0.9856691741079311, 1.0269635093610092] | pass |
| full | paired | `square_100d_x100000` | 0.972 [0.9547115939917878, 0.980644924849089] | pass |
| full | paired | `square_10000d_x500` | 0.982 [0.9782497856955863, 1.0037864958607674] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.960 [0.8485215510789219, 1.0251454307805568] | pass |
