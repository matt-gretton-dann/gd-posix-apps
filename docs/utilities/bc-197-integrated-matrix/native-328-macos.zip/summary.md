# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.981 [0.9325286143999468, 1.0178583128686158] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.008 [0.9827776080288616, 1.0718578841821207] | inconclusive-noisy |
| full | aa | `calls_200000` | 1.003 [0.9917264031344777, 1.0324342878882764] | pass |
| full | aa | `array_200000` | 1.008 [0.9701059636006155, 1.0294613594288369] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.018 [0.9792525084919143, 1.0800267523328875] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.996 [0.9670072166630188, 1.0184327316639517] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.993 [0.9641133310556184, 1.002796407028477] | pass |
| full | aa | `fibonacci_1000_x100` | 1.001 [0.9881805948829024, 1.0567713970798034] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.003 [0.9968155520180104, 1.0405395139230569] | pass |
| full | aa | `multiply_100d_x100000` | 0.999 [0.9468849126046812, 1.0372084968222934] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9917458046630809, 1.0338568446369794] | pass |
| full | aa | `divide_scale100_x100000` | 1.002 [0.8158891192816389, 1.0142631639817428] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.007 [0.9445428498461652, 1.089986108844134] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 0.996 [0.9245083064735955, 1.0248126813498188] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.993405442674942, 1.0144804906089895] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.992 [0.9552156626413408, 1.024144310925941] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.972 [0.9480824013536837, 1.0368280113981065] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.004 [0.9758352100489476, 1.0266544546215315] | pass |
| full | aa | `power_100d_e17_x1000` | 0.983 [0.9081883105011193, 1.018709198912064] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.017 [0.9931977184220491, 1.019435787061191] | pass |
| full | aa | `recursion_50_x1000` | 0.994 [0.9661794131734772, 1.0098658994100527] | pass |
| full | aa | `sparse_array_200000` | 1.008 [0.9853478135419377, 1.039261538487435] | pass |
| full | aa | `frontend_definitions_2000` | 1.015 [0.9982507428195329, 1.0356791243182035] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.992 [0.9778458742648807, 1.0379214138597437] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.015 [0.937589748158205, 1.0955887536867954] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.961 [0.9369887562020591, 1.0422109915045907] | pass |
| full | aa | `square_100d_x100000` | 1.001 [0.9227099303871413, 1.01052863905857] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9893081504850851, 1.0440969606757031] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.997 [0.934766663621897, 1.0623970850695221] | inconclusive-noisy |
| full | paired | `startup` | 1.012 [0.9028762323847898, 1.385069920540869] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.882 [0.8719803239080697, 0.9517381487475085] | pass |
| full | paired | `calls_200000` | 0.907 [0.8942906216548291, 0.9453645864475673] | pass |
| full | paired | `array_200000` | 0.918 [0.796983021837303, 0.9947515460051144] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.945 [0.9372730387419018, 0.9623417855128467] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.945 [0.658287762893024, 0.9568502078786804] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.946 [0.8701094547332717, 0.9506327319035336] | pass |
| full | paired | `fibonacci_1000_x100` | 0.936 [0.8747344831228353, 0.9564047001292442] | pass |
| full | paired | `factorial_1000_x50` | 0.994 [0.9426701393248302, 1.0569324025777433] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.958 [0.8766633562349178, 1.0334458455401183] | pass |
| full | paired | `multiply_10000d_x1000` | 0.998 [0.909446271479066, 1.0411993842247877] | pass |
| full | paired | `divide_scale100_x100000` | 1.005 [0.9477365661843811, 1.074354676421104] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.986 [0.9176475664317507, 1.1526252981411886] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.989 [0.9606454065930953, 1.0395106716751925] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.995 [0.9408167369141458, 1.00796306509658] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.997 [0.9616232686034303, 1.0354644457183009] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.957 [0.9296494524059435, 1.1452403070637878] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.971 [0.9104964998455569, 0.9808496376038441] | pass |
| full | paired | `power_100d_e17_x1000` | 1.003 [0.9814536845121629, 1.0658768319921574] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.953 [0.8979364601292296, 0.9812646659750259] | pass |
| full | paired | `recursion_50_x1000` | 0.954 [0.9328103940099958, 1.0683018793320407] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.891 [0.8638749739414107, 1.0191714236244922] | pass |
| full | paired | `frontend_definitions_2000` | 0.998 [0.9511637544215261, 1.0099688537988574] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.993 [0.9900782276586105, 1.0073586443204343] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.010 [0.9375946907381056, 1.0170250766031554] | pass |
| full | paired | `streaming_statements_20000` | 0.997 [0.9146944450818632, 1.024599976151793] | pass |
| full | paired | `square_100d_x100000` | 0.960 [0.9059443986576389, 1.0428351712175945] | pass |
| full | paired | `square_10000d_x500` | 1.006 [0.9857392876851413, 1.0186406538717172] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.968 [0.9097791193301042, 1.0220792370289258] | pass |
