# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.927 [0.8126352156288272, 1.0245159442000855] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.002 [0.9936919063016264, 1.0150107450252868] | pass |
| full | aa | `calls_200000` | 0.995 [0.9736757987611833, 1.0178198510118632] | pass |
| full | aa | `array_200000` | 1.001 [0.9795821744698573, 1.015756865630201] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.999 [0.9925783656581578, 1.006615440083619] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.000 [0.9834118271102953, 1.0071475705297988] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.008 [0.9953958026209404, 1.0174476379270265] | pass |
| full | aa | `fibonacci_1000_x100` | 1.004 [0.9783109581569726, 1.0126204270264265] | pass |
| full | aa | `factorial_1000_x50` | 1.004 [0.9938409593501909, 1.0108541475001522] | pass |
| full | aa | `multiply_100d_x100000` | 0.990 [0.9815929459462656, 0.997891189139275] | pass |
| full | aa | `multiply_10000d_x1000` | 0.996 [0.948723762864976, 1.0008954514555712] | pass |
| full | aa | `divide_scale100_x100000` | 1.002 [0.9921131900371156, 1.01922858889984] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9931193775257114, 1.000865727393529] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.995221360924951, 1.004009186542489] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.994430213122396, 1.0100968519740714] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9941182623664188, 1.0026989241107944] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.994 [0.9815980682758862, 1.0322213675067395] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.996 [0.9882363614400463, 1.0078590346918923] | pass |
| full | aa | `power_100d_e17_x1000` | 1.007 [0.9854464509585817, 1.0176192631876564] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.007 [0.9613487468444982, 1.0115900094182388] | pass |
| full | aa | `recursion_50_x1000` | 1.001 [0.968567875934229, 1.0122124633827658] | pass |
| full | aa | `sparse_array_200000` | 1.009 [0.9698013171802996, 1.019455324322261] | pass |
| full | aa | `frontend_definitions_2000` | 1.008 [1.0028172226727694, 1.0347079527124061] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9981409387648342, 1.001820758021404] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.010 [0.9773372319299964, 1.0538597171790167] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.001 [0.9914552124703144, 1.0181296577609305] | pass |
| full | aa | `square_100d_x100000` | 0.999 [0.9947590580567688, 1.0025689976564367] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9979624112804278, 1.0012014521918382] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.962 [0.8897365266840569, 1.067592670280569] | inconclusive-noisy |
| full | paired | `startup` | 0.989 [0.7758148902884103, 1.314906255931133] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.997 [0.9706670266591677, 1.0210991629020243] | pass |
| full | paired | `calls_200000` | 0.980 [0.9594057741435633, 1.0066634267344008] | pass |
| full | paired | `array_200000` | 0.995 [0.9786108954040736, 1.0209659910429565] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.008 [0.995652014803137, 1.0205002831620689] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.992 [0.9901247043650464, 1.0106986746181887] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.981 [0.9705380065618074, 0.9930968579485695] | pass |
| full | paired | `fibonacci_1000_x100` | 0.973 [0.9671028488290796, 0.9932744116609136] | pass |
| full | paired | `factorial_1000_x50` | 0.979 [0.9746660724017145, 0.9921474033044191] | pass |
| full | paired | `multiply_100d_x100000` | 0.987 [0.9710900169546508, 0.992025992525127] | pass |
| full | paired | `multiply_10000d_x1000` | 0.942 [0.9342395225350726, 0.9450181945931633] | pass |
| full | paired | `divide_scale100_x100000` | 0.984 [0.9564853017805374, 0.9874829313629686] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.003 [0.9968928984805752, 1.022530101881511] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.887 [0.8834803944489881, 0.9046289629460156] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.685 [0.6802660795633642, 0.7846428424723443] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.808 [0.8003061158347077, 0.811679117685717] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.981 [0.9651983064674694, 1.0031644290175492] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.996 [0.9913414524776418, 1.0032009279934107] | pass |
| full | paired | `power_100d_e17_x1000` | 0.995 [0.9859667662754458, 1.0046197910653822] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.949 [0.944356936653179, 0.9751992651788594] | pass |
| full | paired | `recursion_50_x1000` | 0.990 [0.981661527191169, 0.9929547109617356] | pass |
| full | paired | `sparse_array_200000` | 0.985 [0.9616101759441323, 1.0082637363053415] | pass |
| full | paired | `frontend_definitions_2000` | 1.023 [1.017212548246548, 1.0299788564639676] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.060 [0.059289072153518946, 0.060830482499097754] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.959 [0.9545018748552824, 1.0327096673182972] | pass |
| full | paired | `streaming_statements_20000` | 0.996 [0.9747740796304942, 1.0062592124498069] | pass |
| full | paired | `square_100d_x100000` | 0.988 [0.9686799874105232, 1.0161342432102323] | pass |
| full | paired | `square_10000d_x500` | 0.952 [0.9501529251239036, 0.9570316398303175] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.819 [0.7378310791268629, 0.8751631009253824] | pass |
