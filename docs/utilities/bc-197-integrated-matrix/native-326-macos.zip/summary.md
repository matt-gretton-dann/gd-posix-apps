# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.992 [0.8864616668900506, 1.0527302314066516] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.998 [0.9623265796782284, 1.007470325895572] | pass |
| full | aa | `calls_200000` | 1.070 [0.9450369968006053, 1.1667679129539343] | inconclusive-noisy |
| full | aa | `array_200000` | 0.977 [0.9518143127865812, 1.0207742001552047] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.987 [0.9287328911738268, 1.1360824261344626] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.980 [0.9428935420965266, 1.0349350943503233] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.025 [0.9277006641000063, 1.0690728876464293] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.017 [0.9185454003597285, 1.0768788387910788] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 0.998 [0.9016292474058966, 1.0489727044636623] | pass |
| full | aa | `multiply_100d_x100000` | 0.974 [0.8796571472459628, 1.0053004348983134] | pass |
| full | aa | `multiply_10000d_x1000` | 1.034 [1.0106803460142721, 1.062048405211359] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.004 [0.9891751311679257, 1.174619075838883] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9840603826541269, 1.0925176159781278] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.017 [0.96661718232711, 1.0652853555540147] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.992 [0.8482514206598477, 1.0250396250335898] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.991 [0.9592001552297025, 1.05185548759649] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.995 [0.9180396937665967, 1.066139466368814] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.995 [0.9435090483777793, 1.0287011549227258] | pass |
| full | aa | `power_100d_e17_x1000` | 1.004 [0.9643281367810034, 1.1756177048263745] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 1.009 [0.9843246925671897, 1.1962140863823831] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.991 [0.8755341202392037, 1.0020979456336698] | pass |
| full | aa | `sparse_array_200000` | 1.001 [0.9705035007129167, 1.0435517174354965] | pass |
| full | aa | `frontend_definitions_2000` | 1.020 [0.9771985576197504, 1.1005235167081178] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.995 [0.9092522458950199, 1.0521167547416816] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.000 [0.9944630558462568, 1.0320271592853114] | pass |
| full | aa | `streaming_statements_20000` | 1.029 [0.94496153628109, 1.10177998828813] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.957 [0.7741096981550564, 1.0115063608813766] | pass |
| full | aa | `square_10000d_x500` | 1.022 [0.9827196912365301, 1.0639680546330035] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.964 [0.7543799763168566, 1.1641387731730837] | inconclusive-noisy |
| full | paired | `startup` | 1.038 [0.8797745738624597, 1.6048238386561466] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.076 [0.9885851115065468, 1.1971381164047334] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.798 [0.7313468167545801, 0.8474220323661057] | pass |
| full | paired | `array_200000` | 1.054 [0.8364978100424498, 1.1916717752570392] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.018 [0.9159325842707855, 1.1237308189712192] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.990 [0.8462463472678844, 1.125714419980314] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.089 [1.0059041247607146, 1.1704600489836954] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.044 [0.818347793998717, 1.1564809138240144] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.082 [0.9239098541884261, 1.1213732386070419] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.018 [0.9668193432513353, 1.2557042756659764] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.971 [0.8625718563063446, 1.0564931149973809] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.989 [0.8646830230387564, 1.0939519411152596] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.989 [0.9385309959768025, 1.028541204747197] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.879 [0.7653712348471785, 0.8860194304855823] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.676 [0.6196153373594907, 0.8261290663214937] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.852 [0.7236417676494953, 0.9092624969757798] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.041 [0.8196988849226444, 1.1058232560862533] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.005 [0.8920136789209497, 1.1199184159926774] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.993 [0.9122847525516137, 1.1106675345060077] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.844 [0.7803606521380326, 0.9897036378614166] | pass |
| full | paired | `recursion_50_x1000` | 0.763 [0.535251936498298, 1.0551081614728126] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.059 [1.0051828300757588, 1.229249181622677] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.984 [0.9113756224329153, 1.1555904408169726] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.170 [0.1343306319565538, 0.20994539842665016] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.997 [0.7853322764851551, 1.0323638257759562] | pass |
| full | paired | `streaming_statements_20000` | 1.126 [0.9513355636327522, 1.3260964635288062] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.086 [1.037287975303549, 1.190328126620671] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.950 [0.9392945373188772, 0.9763034638000143] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.884 [0.7581120519839865, 0.9285429587436019] | pass |
