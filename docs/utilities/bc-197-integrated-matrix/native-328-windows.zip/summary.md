# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.989 [0.9809585756588024, 1.074117389092563] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.010 [0.9954590429461461, 1.0293798074490057] | pass |
| full | aa | `calls_200000` | 1.014 [0.9619497216634093, 1.03586947601686] | pass |
| full | aa | `array_200000` | 1.016 [0.9977748769520607, 1.0347726811281128] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.987 [0.8857261117503649, 1.029018458179701] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.006 [0.9660549892814014, 1.0384410162141267] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.018 [0.9959651595534328, 1.0276174267245672] | pass |
| full | aa | `fibonacci_1000_x100` | 1.016 [0.9777695742593424, 1.022772747362745] | pass |
| full | aa | `factorial_1000_x50` | 0.992 [0.9717173181915194, 0.9984189600540698] | pass |
| full | aa | `multiply_100d_x100000` | 0.991 [0.9805226924818888, 1.0544526375496321] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.003 [0.9949230091078077, 1.0102614115763946] | pass |
| full | aa | `divide_scale100_x100000` | 1.004 [0.9931743847276904, 1.0811847527298841] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.036 [1.0314124634601685, 1.0444745219876361] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9848017896026927, 1.006875619858824] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9940877307498831, 1.0181602525305316] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.996 [0.9687946906695453, 1.0162670696652698] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.993 [0.9797814584562737, 0.9983608081474016] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.998 [0.9970625392519069, 1.0077305054852876] | pass |
| full | aa | `power_100d_e17_x1000` | 1.000 [0.9839875209785601, 1.0098206422240923] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.020 [1.0074266444699909, 1.0382095795277655] | pass |
| full | aa | `recursion_50_x1000` | 0.992 [0.9872257104071663, 0.9927514489207099] | pass |
| full | aa | `sparse_array_200000` | 1.003 [0.9632195463608794, 1.0493892035896297] | pass |
| full | aa | `frontend_definitions_2000` | 1.003 [0.9849770212293717, 1.0313178174014108] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.001 [0.9729073258541077, 1.0206816244882186] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.001 [0.9890827648643918, 1.0172760108073158] | pass |
| full | aa | `streaming_statements_20000` | 0.986 [0.9683997127755035, 1.0035191842506974] | pass |
| full | aa | `square_100d_x100000` | 0.993 [0.9872160237416595, 0.9993518637632638] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9981479512890711, 1.003166823395441] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.010 [0.9697203719812137, 1.0332484076362862] | pass |
| full | paired | `startup` | 0.988 [0.9508896797123304, 1.0618269692896414] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.805 [0.771353318528116, 0.8224577917923316] | pass |
| full | paired | `calls_200000` | 0.851 [0.8476991821697153, 0.9029327398873006] | pass |
| full | paired | `array_200000` | 0.893 [0.8748393407564784, 0.91195772639934] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.832 [0.7117125888422616, 0.8461654185869681] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.843 [0.8294020717757449, 0.8473902467227589] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.831 [0.7758876783442484, 0.8433640089048142] | pass |
| full | paired | `fibonacci_1000_x100` | 0.884 [0.8755674941726808, 0.9005984107394475] | pass |
| full | paired | `factorial_1000_x50` | 0.942 [0.9226431456698093, 0.9533147350381008] | pass |
| full | paired | `multiply_100d_x100000` | 0.919 [0.904909845327346, 0.9966656728978265] | pass |
| full | paired | `multiply_10000d_x1000` | 0.995 [0.9886956479817175, 1.000197890551651] | pass |
| full | paired | `divide_scale100_x100000` | 0.910 [0.8916540816224852, 0.9803619436988075] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.999 [0.9707928756821089, 1.0290088477445827] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.001 [0.9951346304136431, 1.0199738105870422] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9866495140097451, 1.0033184044945] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.994 [0.9785829047442479, 1.00627148293415] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.990 [0.969983493240242, 1.0038028128258736] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.998 [0.9926210267583649, 1.0098508509589534] | pass |
| full | paired | `power_100d_e17_x1000` | 0.997 [0.9922859400291483, 1.0171826356520863] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.882 [0.8704814726878407, 0.8940009639991839] | pass |
| full | paired | `recursion_50_x1000` | 0.916 [0.9023992208819337, 0.9287210551853373] | pass |
| full | paired | `sparse_array_200000` | 0.872 [0.8518156538160762, 0.8997675330129447] | pass |
| full | paired | `frontend_definitions_2000` | 1.028 [0.9919581635271794, 1.0673498939222767] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.967 [0.9517976087055147, 0.9848811107471488] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.003 [0.9891670353775636, 1.0362232349515728] | pass |
| full | paired | `streaming_statements_20000` | 1.003 [0.9799453665559325, 1.0217725635388124] | pass |
| full | paired | `square_100d_x100000` | 0.908 [0.8977796031068502, 0.9381122927427176] | pass |
| full | paired | `square_10000d_x500` | 1.003 [0.9979510832909319, 1.0067578290419836] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.958 [0.919157894748532, 1.0058822875204945] | pass |
