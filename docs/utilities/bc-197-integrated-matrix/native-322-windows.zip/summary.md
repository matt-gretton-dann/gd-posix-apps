# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.962 [0.9220976529702658, 1.0136277458637633] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.000 [0.9808094915003448, 1.0149884145794212] | pass |
| full | aa | `calls_200000` | 0.998 [0.9826229186611686, 1.0038700121584503] | pass |
| full | aa | `array_200000` | 1.000 [0.9876228080555274, 1.0078669271321605] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.998 [0.9825481434983541, 1.0030392258145158] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.997 [0.9788280910496558, 1.0098039753704384] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.989 [0.9710789303646126, 0.9969113771147646] | pass |
| full | aa | `fibonacci_1000_x100` | 1.005 [0.9909031858766517, 1.0257803048637109] | pass |
| full | aa | `factorial_1000_x50` | 1.005 [0.9936405435053065, 1.0124316095285402] | pass |
| full | aa | `multiply_100d_x100000` | 1.005 [0.9921330749816056, 1.0180765163049956] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9960382333613108, 1.0175196607741495] | pass |
| full | aa | `divide_scale100_x100000` | 0.998 [0.9695854335377061, 1.022393372948525] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.991 [0.9844286520193544, 0.9939501975131736] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9806293956544321, 1.0077333544818123] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9889879714516607, 1.0029318607311672] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.004 [0.9768398809714409, 1.0198466406249644] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.988 [0.9603678247804043, 1.0382515908202112] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.002 [0.9897267007459785, 1.0179500591917312] | pass |
| full | aa | `power_100d_e17_x1000` | 0.990 [0.9202646307133907, 1.0110612129893808] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.010 [0.7764215218075567, 1.0134332408004305] | pass |
| full | aa | `recursion_50_x1000` | 1.026 [0.9591125629051991, 1.0562077808523318] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.001 [0.9914779128602288, 1.0134501372042322] | pass |
| full | aa | `frontend_definitions_2000` | 1.027 [1.0008076749263988, 1.0906707973760517] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.998 [0.9959944023949135, 1.0045225450911863] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.016 [0.981858036291299, 1.0295021282748689] | pass |
| full | aa | `streaming_statements_20000` | 1.003 [0.9416445319983762, 1.0172563019080658] | pass |
| full | aa | `square_100d_x100000` | 0.999 [0.9493517663580726, 1.0052771016869715] | pass |
| full | aa | `square_10000d_x500` | 0.999 [0.9935826772314515, 1.0015453694260075] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.011 [0.9402617319221961, 1.0278334846219188] | pass |
| full | paired | `startup` | 0.998 [0.9143504790538954, 1.0965847999507956] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.996 [0.9699043670004328, 1.0054373328095267] | pass |
| full | paired | `calls_200000` | 1.000 [0.9690995140811851, 1.0171045972667179] | pass |
| full | paired | `array_200000` | 0.998 [0.9785735613835221, 1.0033546499053083] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.991 [0.9580650982707425, 1.0072322339172053] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.985 [0.9524621513742778, 1.0049036834835845] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.995 [0.9573114003256684, 1.003190747517405] | pass |
| full | paired | `fibonacci_1000_x100` | 0.988 [0.9791807766862883, 1.009681792781949] | pass |
| full | paired | `factorial_1000_x50` | 0.990 [0.9748300157953923, 1.001657376807266] | pass |
| full | paired | `multiply_100d_x100000` | 0.998 [0.9902569150412216, 1.0065682812326564] | pass |
| full | paired | `multiply_10000d_x1000` | 0.953 [0.9490130761917227, 0.961263218655165] | pass |
| full | paired | `divide_scale100_x100000` | 0.998 [0.9822874493924129, 1.0085801797178653] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.999 [0.9955862087504781, 1.0070113346759413] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.904 [0.9014539190624351, 0.9233083600167113] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.725 [0.7187453613327962, 0.7337009953234547] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.815 [0.8095350198732858, 0.835565750117263] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.999 [0.961651016366194, 1.0247281207913383] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.994 [0.9881348872175304, 1.0153801222962124] | pass |
| full | paired | `power_100d_e17_x1000` | 0.996 [0.9846801252251569, 1.0032363840697907] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.008 [0.9901779664934339, 1.1440870131732854] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.014 [0.979239485943281, 1.0317682762644096] | pass |
| full | paired | `sparse_array_200000` | 1.002 [0.9956079313000887, 1.0361489987123322] | pass |
| full | paired | `frontend_definitions_2000` | 1.005 [0.9837935972394547, 1.0096281783052472] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.082 [0.08102832745300394, 0.08221046740539938] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.996 [0.9732223875706447, 1.0267074433189478] | pass |
| full | paired | `streaming_statements_20000` | 0.987 [0.8844933160331208, 1.0082765566606713] | pass |
| full | paired | `square_100d_x100000` | 0.998 [0.9883342994777377, 1.037737718703588] | pass |
| full | paired | `square_10000d_x500` | 0.949 [0.9391646421246751, 0.95142541197286] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.889 [0.8657873780491915, 0.9381024370856407] | pass |
