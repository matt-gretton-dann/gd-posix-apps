# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.850 [0.7952613584453948, 1.012279946067045] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.997 [0.9840295018982397, 1.0097950417218087] | pass |
| full | aa | `calls_200000` | 0.991 [0.9783746445881172, 1.0131866276707133] | pass |
| full | aa | `array_200000` | 1.008 [0.9730725994300189, 1.0176699204526265] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.997 [0.9922776091083043, 1.0240487987216547] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.003 [0.9960087961649395, 1.0069375269371594] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.004 [0.9919776188639804, 1.0107664596415247] | pass |
| full | aa | `fibonacci_1000_x100` | 0.990 [0.9757022673999138, 1.0056461530312537] | pass |
| full | aa | `factorial_1000_x50` | 1.000 [0.9960913608062225, 1.0033200313295227] | pass |
| full | aa | `multiply_100d_x100000` | 0.997 [0.9631275559750054, 1.013453064185961] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9947319800132952, 1.0011610377905755] | pass |
| full | aa | `divide_scale100_x100000` | 1.006 [0.9954168911307418, 1.033737917873919] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.004 [0.9997997475984965, 1.0089841894849378] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.9967288370084928, 1.0073116790450853] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.003 [0.997146200347313, 1.0125405627164248] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9966675051227609, 1.0059324184097673] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.998 [0.9840534156204371, 1.0353377906539694] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9949572063467812, 1.0143113218944018] | pass |
| full | aa | `power_100d_e17_x1000` | 1.001 [0.9879705197672012, 1.02313140161308] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.998 [0.9898220096711303, 1.0426054645950737] | pass |
| full | aa | `recursion_50_x1000` | 0.996 [0.9876535008506567, 1.0128676253905793] | pass |
| full | aa | `sparse_array_200000` | 0.998 [0.9907094777023691, 1.017529565194566] | pass |
| full | aa | `frontend_definitions_2000` | 1.001 [0.991025323087432, 1.0075987529979462] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.992 [0.9586579242616537, 1.0194570831020355] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.970 [0.9468043923578209, 1.0081721726247215] | pass |
| full | aa | `streaming_statements_20000` | 1.005 [0.9992483237049632, 1.0289330635571357] | pass |
| full | aa | `square_100d_x100000` | 1.004 [0.9993246928870069, 1.0065372466141385] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.99923168617575, 0.9999244453279507] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.886 [0.8709836590500477, 1.1488323087033798] | inconclusive-noisy |
| full | paired | `startup` | 1.029 [0.7669568312318793, 1.3530025187653238] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.830 [0.8203994245397068, 0.8493993711145297] | pass |
| full | paired | `calls_200000` | 0.874 [0.8487707471035959, 0.8826897148036141] | pass |
| full | paired | `array_200000` | 0.907 [0.8871195078312664, 0.9252072098843643] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.814 [0.8005733666978586, 0.8294920881394016] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.840 [0.8284946215077417, 0.851812430081215] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.848 [0.8367087469710403, 0.8509201883352705] | pass |
| full | paired | `fibonacci_1000_x100` | 0.837 [0.8284901855814334, 0.846351702156224] | pass |
| full | paired | `factorial_1000_x50` | 0.950 [0.9388130089613499, 0.961177300998303] | pass |
| full | paired | `multiply_100d_x100000` | 0.877 [0.8618629574098525, 0.88133356570727] | pass |
| full | paired | `multiply_10000d_x1000` | 1.003 [0.9992125797876449, 1.0319148596188463] | pass |
| full | paired | `divide_scale100_x100000` | 0.933 [0.9295669167196724, 0.9395711683005026] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.991 [0.9896211237383229, 0.9965885780410024] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.002 [0.9952070981451491, 1.0057275214725563] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9789845443013425, 1.0663092542263066] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.000 [0.9917758758497642, 1.0231365717791225] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.967 [0.9566866332985207, 1.0044728684959234] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.989 [0.9848400722983677, 0.9982346403680095] | pass |
| full | paired | `power_100d_e17_x1000` | 0.989 [0.9852287170357565, 0.9937140521418676] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.866 [0.8488533591454661, 0.8688726498112955] | pass |
| full | paired | `recursion_50_x1000` | 0.922 [0.9178540886599239, 0.9341186219925103] | pass |
| full | paired | `sparse_array_200000` | 0.895 [0.8930666078497713, 0.900158344151574] | pass |
| full | paired | `frontend_definitions_2000` | 0.995 [0.9843134948804474, 1.0007748772636007] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.989 [0.9783139309846098, 1.0294409354512966] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.968 [0.9555996127975177, 1.0228623538235393] | pass |
| full | paired | `streaming_statements_20000` | 0.997 [0.9931122121091214, 1.0103880075907672] | pass |
| full | paired | `square_100d_x100000` | 0.898 [0.8878441003062679, 0.9484573264434475] | pass |
| full | paired | `square_10000d_x500` | 1.002 [1.0010365771134404, 1.002601136145389] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.864 [0.7975069398862215, 1.0331864938911126] | pass |
