# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.867 [0.7453884624660633, 1.2274178614477542] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.999 [0.9899687700575425, 1.009034528536166] | pass |
| full | aa | `calls_200000` | 1.001 [0.9976607106049028, 1.015885366365375] | pass |
| full | aa | `array_200000` | 1.005 [0.9906378685495698, 1.0289389285826636] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.996 [0.9932429113862736, 1.0080605158495382] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.000 [0.9903480221439329, 1.0113960980578212] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.997 [0.994784155783986, 1.0091091855090026] | pass |
| full | aa | `fibonacci_1000_x100` | 1.008 [0.9965456697439045, 1.0163227857013588] | pass |
| full | aa | `factorial_1000_x50` | 0.999 [0.9937902708933034, 1.008035072353591] | pass |
| full | aa | `multiply_100d_x100000` | 0.995 [0.9919056544966742, 1.0042840596862057] | pass |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.9217609987933508, 1.0001419145957442] | pass |
| full | aa | `divide_scale100_x100000` | 0.999 [0.9907259885717206, 1.007530561947278] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.000 [0.9936442977100279, 1.00180593986554] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9982330766860283, 1.0012070900855345] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9912159180227516, 1.0082738070915496] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9973072496508026, 1.004089664167956] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.996 [0.9817670253867335, 1.0120089204172948] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.998 [0.9904954259826625, 0.9993945164901482] | pass |
| full | aa | `power_100d_e17_x1000` | 0.998 [0.9846631195510273, 1.007055150194531] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.006 [0.9918575148881735, 1.0222269410065998] | pass |
| full | aa | `recursion_50_x1000` | 0.996 [0.9907503992650316, 0.9988129280587071] | pass |
| full | aa | `sparse_array_200000` | 1.001 [0.9928094343335466, 1.0075372489367376] | pass |
| full | aa | `frontend_definitions_2000` | 0.996 [0.9828016174331896, 1.0120890758171557] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.999 [0.9969398564669953, 1.0015146212337591] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.989 [0.9181397305753737, 1.0059189769022692] | pass |
| full | aa | `streaming_statements_20000` | 1.004 [0.9882446038666717, 1.0220500638817267] | pass |
| full | aa | `square_100d_x100000` | 0.994 [0.9865135285720268, 1.0061986551288442] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9989498513904473, 1.0009968890906162] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.912 [0.8595759579412845, 1.0671912346905554] | inconclusive-noisy |
| full | paired | `startup` | 1.007 [0.7458239243607762, 1.32772508634613] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.990 [0.9879399907518146, 0.9947154363607407] | pass |
| full | paired | `calls_200000` | 0.839 [0.8352160365524678, 0.8451086209282788] | pass |
| full | paired | `array_200000` | 1.015 [1.0076202056440167, 1.0270023805437385] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.987 [0.980201215705645, 0.9902713655980652] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.965 [0.9561970513410151, 0.9782218104389105] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.948 [0.9459142044419595, 0.9565215126208977] | pass |
| full | paired | `fibonacci_1000_x100` | 1.002 [0.9982953129198229, 1.0168610059078835] | pass |
| full | paired | `factorial_1000_x50` | 1.002 [0.9924495507564963, 1.0118626631094485] | pass |
| full | paired | `multiply_100d_x100000` | 0.989 [0.9720391528164221, 1.0101366054278997] | pass |
| full | paired | `multiply_10000d_x1000` | 0.944 [0.943255521255549, 0.9459424564395508] | pass |
| full | paired | `divide_scale100_x100000` | 0.988 [0.9860862205223629, 0.9906900691449896] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.000 [0.9953812693411156, 1.014167072045566] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.891 [0.8903231285365052, 0.8951790718867281] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.672 [0.6603134108192474, 0.6769616516785223] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.811 [0.8092413196398819, 0.8205256502672252] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.991 [0.971825254521348, 1.0088262520317672] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.991 [0.9882440861501536, 0.9985171357532031] | pass |
| full | paired | `power_100d_e17_x1000` | 1.001 [0.9822147633691556, 1.0111576027070037] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.860 [0.847668929495834, 0.8680757818763013] | pass |
| full | paired | `recursion_50_x1000` | 0.650 [0.6411892791024886, 0.6550067530924818] | pass |
| full | paired | `sparse_array_200000` | 0.994 [0.9922741541121027, 0.9963986488077041] | pass |
| full | paired | `frontend_definitions_2000` | 0.992 [0.9898132873344168, 1.010712083847152] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.057 [0.056805554743649955, 0.05789325582581618] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.985 [0.9670647363115706, 1.0682695257877386] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.999 [0.9922549123663018, 1.0081791003323588] | pass |
| full | paired | `square_100d_x100000` | 0.992 [0.988389818763838, 0.9998520546756993] | pass |
| full | paired | `square_10000d_x500` | 0.947 [0.9466453591472294, 0.9484820468371908] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.779 [0.7411981806619852, 0.8467489756677697] | pass |
