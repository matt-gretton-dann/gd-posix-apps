# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.760 [0.7049037796075134, 0.9752502251954117] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.015 [0.8706551280315676, 1.092827418735804] | inconclusive-noisy |
| full | aa | `calls_200000` | 1.008 [1.000242385688473, 1.098407559806621] | inconclusive-noisy |
| full | aa | `array_200000` | 0.946 [0.9139402200408981, 1.022411744559809] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.010 [0.9929771206603167, 1.022370813553821] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.005 [0.9568476000956612, 1.2554182592672203] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.002 [0.9878602527888061, 1.0368701716047546] | pass |
| full | aa | `fibonacci_1000_x100` | 0.998 [0.8131920433033195, 1.032042960277977] | pass |
| full | aa | `factorial_1000_x50` | 1.023 [0.8107048371778699, 1.0768892714210114] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.022 [0.9781365005051328, 1.1519562944123807] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.997 [0.9902477461653173, 1.041919664431578] | pass |
| full | aa | `divide_scale100_x100000` | 1.008 [0.9835555918362858, 1.0284386100102538] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.979 [0.9001370578605691, 1.0610373163369926] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.9306463335608393, 1.0801705240363084] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9410153479884406, 1.0644377987577684] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 0.994 [0.921152315562918, 1.0205299550003717] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.983 [0.9080394946283606, 1.2118548844704442] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.995 [0.8682356218372825, 1.160992413267754] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.008 [0.939194190526522, 1.0410935549288451] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.016 [0.993523525787575, 1.0371008004706108] | pass |
| full | aa | `recursion_50_x1000` | 0.987 [0.8772688278370917, 1.056877233372354] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.002 [0.9301196828083718, 1.1782643300702984] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.987 [0.7223662532481459, 1.233881655880114] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.007 [0.9838649426936635, 1.0504292330917422] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.010 [0.9857151404465612, 1.0606886671078375] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.032 [0.8873365611525781, 1.1813656096271068] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.075 [0.940624910446733, 1.2608998487249694] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.025 [0.9627735718461421, 1.0683649596030904] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.978 [0.9605357419897093, 1.059649122815435] | inconclusive-noisy |
| full | paired | `startup` | 1.008 [0.928556634400338, 1.1805468520922484] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.037 [0.9303149642524913, 1.0774239732277529] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.004 [0.9029978978855141, 1.1976834914731274] | inconclusive-noisy |
| full | paired | `array_200000` | 0.888 [0.7915698466357494, 1.0682782709159293] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.026 [0.9629251265513963, 1.1747238850072534] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.049 [0.9260122836367105, 1.1534389086513812] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.016 [0.9364493113977574, 1.2244638786149644] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.981 [0.7334143941932307, 1.1196941001442033] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.984 [0.88779522271915, 1.1962612185688024] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.973 [0.9323310462461777, 1.221934978726372] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.917 [0.8478634002947707, 0.9574929422679197] | pass |
| full | paired | `divide_scale100_x100000` | 1.045 [0.8673763252288446, 1.1333587884379746] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.057 [0.9792561201212311, 1.0881741941800978] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.865 [0.7641228687641879, 0.9118379932398921] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.693 [0.5741313708564921, 0.7593694447190956] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.757 [0.7168593188797336, 0.8333113645752585] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.005 [0.8186813822991299, 1.1811174022789976] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.989 [0.8853797982294809, 1.1267179322975296] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.047 [0.9889310024634601, 1.1683466311865784] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.032 [0.8653662792424276, 1.3211069353143157] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.895 [0.8126452061386913, 1.0849439987441132] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.013 [0.8705692601964314, 1.105456497767855] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.013 [0.9773465316444774, 1.1476422115684815] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.154 [0.1332157943922307, 0.17348164921073614] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.030 [0.8482502335186634, 1.1844185963216192] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.064 [0.9766727522548578, 1.1326850850737498] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.009 [0.8731128170127921, 1.1328571849752789] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.983 [0.9560243500404751, 1.0106456584789227] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.882 [0.577038687192452, 0.9381225253300596] | pass |
