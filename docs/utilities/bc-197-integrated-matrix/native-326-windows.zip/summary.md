# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.004 [0.9378243023433915, 1.014921882999712] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.014 [0.9812352151795777, 1.066164838210019] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.996 [0.9580274177160014, 1.0283516330530709] | pass |
| full | aa | `array_200000` | 1.018 [0.9856088048679782, 1.050431525255082] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 1.043 [0.9592345639326522, 1.0828338023031074] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.081 [1.0237747729105946, 1.1443800460891118] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.022 [0.8790308927554263, 1.1231968550290903] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.017 [0.9927507458840669, 1.1108211975339621] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.017 [0.8984530955735698, 1.0503415029574645] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.059 [0.9587473943883034, 1.3742435743307069] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9715667117230431, 1.0405454271354724] | pass |
| full | aa | `divide_scale100_x100000` | 1.010 [1.0014888863810782, 1.049196252649436] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.998 [0.9032350842199179, 1.1170967792427735] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.017 [0.9851244442125796, 1.059760478789561] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.012 [0.966953870977015, 1.0481030405298852] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.987 [0.9440992708429946, 1.0244570568225682] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.007 [0.9801852869797776, 1.038575249895469] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.010 [0.9419350559225795, 1.1257644085984526] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.991 [0.9672918220301723, 1.0483752238444748] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.015 [0.989011612902818, 1.1723324603379959] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.985 [0.9059163958376143, 1.0191489823760138] | pass |
| full | aa | `sparse_array_200000` | 1.000 [0.9641391224205232, 1.0858113140199916] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.985 [0.8946639677243325, 1.1134027849352786] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.004 [0.9952552850880382, 1.0114733220414693] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.003 [0.9512757952938942, 1.099734725712342] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.065 [0.9439924890653072, 1.1710734149821558] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.023 [0.9250208003112173, 1.100694717283547] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.012 [0.9995193048199796, 1.0433778473473858] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.065 [0.9631376029067316, 1.170240709206014] | inconclusive-noisy |
| full | paired | `startup` | 1.010 [0.926293115754613, 1.0676022465779886] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.059 [1.0434572472632024, 1.0647654871884968] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.701 [0.69644825826974, 0.7165792465887173] | pass |
| full | paired | `array_200000` | 1.044 [1.021230584943818, 1.0682418796955138] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.059 [1.0424705591697978, 1.073224271415508] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.114 [1.0909390545202535, 1.1465884868799647] | confirmed regression |
| full | paired | `compare_equal_1000d_x100000` | 1.110 [1.0951051896361568, 1.1743982019356838] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.027 [0.936859637611571, 1.039569950931601] | pass |
| full | paired | `factorial_1000_x50` | 1.005 [0.9824637428139998, 1.0718115086226065] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.983 [0.9714017581922714, 1.0266943415771683] | pass |
| full | paired | `multiply_10000d_x1000` | 0.922 [0.9193725685438839, 0.9338496517950455] | pass |
| full | paired | `divide_scale100_x100000` | 1.026 [1.0129637498677484, 1.107143863141612] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.004 [0.9918819328261982, 1.0054262972383359] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.877 [0.8640936785302183, 0.8974505175519815] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.709 [0.7048445539906508, 0.7184217611459448] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.803 [0.7921987397379795, 0.8181203015465611] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.986 [0.969637322226401, 1.0221128543479188] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.997 [0.9872022659494941, 1.0009347857126845] | pass |
| full | paired | `power_100d_e17_x1000` | 0.986 [0.9802796111923051, 1.0064675777551997] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.722 [0.7158260538404109, 0.7304505555382197] | pass |
| full | paired | `recursion_50_x1000` | 0.375 [0.362832765273249, 0.38098587928866046] | pass |
| full | paired | `sparse_array_200000` | 0.996 [0.9722420622954946, 1.0214695897104629] | pass |
| full | paired | `frontend_definitions_2000` | 0.950 [0.9341724315183559, 0.9605649278144175] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.085 [0.08277696234419947, 0.08607400356269175] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.006 [0.9843666914781142, 1.0350783791742815] | pass |
| full | paired | `streaming_statements_20000` | 0.920 [0.8761107998951646, 0.9673156714550349] | pass |
| full | paired | `square_100d_x100000` | 0.989 [0.957794598133507, 1.0084793105577088] | pass |
| full | paired | `square_10000d_x500` | 0.955 [0.9455968935322141, 0.9572898456134492] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.917 [0.8726189600661011, 0.9895685709559233] | pass |
