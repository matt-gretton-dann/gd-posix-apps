# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.934 [0.9161814533394408, 1.0364122375160534] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.068 [0.8375438756970457, 1.0758425746914377] | inconclusive-noisy |
| full | aa | `calls_200000` | 1.026 [0.8644948646308428, 1.1702392712045218] | inconclusive-noisy |
| full | aa | `array_200000` | 0.916 [0.8500854983815024, 1.134793078964221] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.990 [0.9437975060323375, 1.0423540286717115] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.117 [0.9784176480344267, 1.216144248692376] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.959 [0.931707654455326, 1.004115226173112] | pass |
| full | aa | `fibonacci_1000_x100` | 0.997 [0.7870105501653599, 1.0161719828368305] | pass |
| full | aa | `factorial_1000_x50` | 0.922 [0.8295736330703012, 1.0426214748892748] | pass |
| full | aa | `multiply_100d_x100000` | 0.948 [0.8575782178354294, 0.9980191422167923] | pass |
| full | aa | `multiply_10000d_x1000` | 0.986 [0.9110871756850971, 1.0875464213644752] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 0.943 [0.824433148028049, 0.9977431246530736] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.953 [0.8696011112923479, 1.0506342976751086] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.003 [0.863760389815841, 1.1467043179613472] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.984 [0.9413089257335754, 1.1321137991537837] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 0.995 [0.8904556129487964, 1.0603628173789745] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.040 [0.9360432727007922, 1.085183687133545] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.989 [0.9167827456979459, 1.10079589878965] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.995 [0.9265841824363162, 1.1216563675067852] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 1.025 [0.9107527224436388, 1.2963309402236518] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 1.014 [0.9613748045920564, 1.0784733110879354] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.999 [0.8875023744234546, 1.137055639490029] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 1.017 [0.9774021092769972, 1.2043219015218503] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.035 [0.9759465910036874, 1.1971326071643373] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 0.995 [0.9049613031736591, 1.0088664816113155] | pass |
| full | aa | `streaming_statements_20000` | 0.963 [0.7835245456886232, 1.0637382042503523] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.011 [0.8769254434924373, 1.0438375597689329] | pass |
| full | aa | `square_10000d_x500` | 1.018 [0.9993282798135565, 1.0523014649113638] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.910 [0.744827199001518, 1.1642341502796723] | inconclusive-noisy |
| full | paired | `startup` | 0.921 [0.7352428998336431, 0.9929616294148301] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.005 [0.8477966253489264, 1.0360111422350335] | pass |
| full | paired | `calls_200000` | 1.022 [0.8943595160362421, 1.1878969111343203] | inconclusive-noisy |
| full | paired | `array_200000` | 0.759 [0.6687829105158275, 0.9145964546175352] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.016 [0.9170205999986867, 1.244890752219348] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.953 [0.7289368908397453, 1.191613738459763] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.045 [0.9885063737502743, 1.278584225409093] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.978 [0.7946686894032683, 1.5158935173357362] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.981 [0.923168887325425, 1.534721308700183] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.006 [0.8416210843550871, 1.1557940909283058] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9879030624252378, 1.042747223444766] | pass |
| full | paired | `divide_scale100_x100000` | 1.107 [0.9244629634363282, 1.2284420795540878] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.950 [0.853760897993554, 1.0850324946399263] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.970 [0.8463038694148796, 1.1999279188471161] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.973 [0.7585627216673866, 1.1826289661117824] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.985 [0.6205059466737102, 1.3908260917156774] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.114 [0.8541939658521309, 1.163767986498924] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.005 [0.932753603496349, 1.0748973152146541] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.012 [0.7275874021514431, 1.2206882194769184] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.828 [0.7091890971953859, 1.1325158298666629] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.016 [0.7992788659066306, 1.4073412211628318] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.973 [0.8589897228994778, 1.1698518836324365] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.879 [0.5575499903919379, 1.0132355960683084] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.986 [0.8375646319754937, 1.1765012021641024] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.853 [0.6995894264583833, 1.4814343367380418] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.023 [0.9592793558778284, 1.0833282051365225] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.998 [0.8299126655940189, 1.3646285525123656] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.017 [0.9581375168024298, 1.1048429700410558] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 1.049 [0.4700921779558351, 1.2153524244041432] | inconclusive-noisy |
