# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.939 [0.9051460508317521, 1.0428837124189214] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.003 [0.9744596428943548, 1.039343724625639] | pass |
| full | aa | `calls_200000` | 1.001 [0.9986356051759971, 1.0368983378490193] | pass |
| full | aa | `array_200000` | 0.997 [0.9894658834072259, 1.0058510598651504] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.993 [0.9415640513394361, 1.035709321070672] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.000 [0.9874674815217089, 1.0043439867615784] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.005 [0.9830790660946703, 1.0093302601782368] | pass |
| full | aa | `fibonacci_1000_x100` | 0.993 [0.9846323292057243, 1.0020268461501338] | pass |
| full | aa | `factorial_1000_x50` | 1.009 [0.9979405782300842, 1.0173840578965652] | pass |
| full | aa | `multiply_100d_x100000` | 0.998 [0.994672406834075, 1.0053435135268622] | pass |
| full | aa | `multiply_10000d_x1000` | 0.997 [0.9875721981806461, 1.0091570246626143] | pass |
| full | aa | `divide_scale100_x100000` | 0.998 [0.991240861346417, 1.0144278621624843] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.002 [0.993798188847064, 1.021639919861219] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.010 [0.9997108542773313, 1.0188043664892672] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9905155876872361, 1.0073276588021185] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9900519869255585, 1.0125434318321185] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.994 [0.980543209368026, 1.0172220417001083] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9874855706675689, 1.0106542935233267] | pass |
| full | aa | `power_100d_e17_x1000` | 1.001 [0.9376656121561419, 1.0075260266040504] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.006 [0.8312131489389076, 1.0258777492255857] | pass |
| full | aa | `recursion_50_x1000` | 0.999 [0.9741122319689993, 1.0073915235878217] | pass |
| full | aa | `sparse_array_200000` | 0.995 [0.9892930408011258, 1.0413460800418295] | pass |
| full | aa | `frontend_definitions_2000` | 1.009 [0.9905106869720345, 1.0217661605943245] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.992 [0.9833179502950711, 1.0087873837078727] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.009 [0.998256554683876, 1.0133403366233689] | pass |
| full | aa | `streaming_statements_20000` | 0.996 [0.9604800012015529, 1.041785356087065] | pass |
| full | aa | `square_100d_x100000` | 1.007 [0.9364862233965174, 1.0185960279391153] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9961117326801432, 1.0043108679833435] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.010 [0.8861440691590797, 1.0983029751796656] | inconclusive-noisy |
| full | paired | `startup` | 0.982 [0.8810195790585313, 1.0890117093449267] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.987 [0.9786108133015758, 1.0970055130265237] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.978 [0.9754408469456188, 1.0348729184929104] | pass |
| full | paired | `array_200000` | 0.746 [0.7177389383921638, 0.7938024162736232] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.970 [0.8198208033229009, 0.9870916633388511] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.007 [1.0054514239189947, 1.1998289594742182] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.984 [0.9717946566510118, 1.058679212396841] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.991 [0.9787715282755761, 1.1427381167744033] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.011 [0.9704070714854482, 1.0673469672036917] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.995 [0.9872845929880627, 1.0267601496196723] | pass |
| full | paired | `multiply_10000d_x1000` | 0.996 [0.9798213593600896, 1.0077298089917313] | pass |
| full | paired | `divide_scale100_x100000` | 0.984 [0.9813079638272235, 1.0038979975709617] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.004 [0.9946894183037687, 1.0530473007288252] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.019 [0.9478775669293701, 1.106876796931675] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.990689543834127, 1.0210007475230483] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.996 [0.949365144230407, 1.0210491059148135] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.996 [0.9870645812309922, 1.0413125391543574] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.008 [0.9934254233552674, 1.0112242445175943] | pass |
| full | paired | `power_100d_e17_x1000` | 0.998 [0.9738619122580817, 1.0021101253389915] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.989 [0.8726022700591263, 1.0094374320802546] | pass |
| full | paired | `recursion_50_x1000` | 0.987 [0.9351148264491489, 0.9974936269045838] | pass |
| full | paired | `sparse_array_200000` | 0.981 [0.8698111958364282, 0.9930395834417926] | pass |
| full | paired | `frontend_definitions_2000` | 0.999 [0.9137478108596947, 1.0264284642627215] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.016 [0.9815548786927769, 1.2705373072800143] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.013 [0.9450937076878859, 1.0347039362647306] | pass |
| full | paired | `streaming_statements_20000` | 1.016 [0.9720109188329706, 1.1012755672107928] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.990 [0.9322223783278086, 1.0091382916246925] | pass |
| full | paired | `square_10000d_x500` | 1.001 [0.9908484291763457, 1.007380358791956] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.960 [0.900267093432504, 1.031602182846118] | pass |
