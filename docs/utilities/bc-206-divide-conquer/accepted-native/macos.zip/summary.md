# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.031 [0.9820235600517614, 1.148473802040105] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.030 [0.9295876092459113, 1.063942336673209] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.962 [0.8718124527134223, 1.16615447779203] | inconclusive-noisy |
| full | aa | `array_200000` | 1.025 [0.9433325336557888, 1.1429008910671545] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.989 [0.8794215277656784, 1.094702768210096] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.002 [0.8731074816635479, 1.106852992898358] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.991 [0.904348621364911, 1.0468377225390566] | pass |
| full | aa | `fibonacci_1000_x100` | 1.022 [0.975684126683768, 1.06142077308777] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.024 [0.9641474966005965, 1.102291781350973] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.986 [0.9262190795139973, 0.998002896063172] | pass |
| full | aa | `multiply_10000d_x1000` | 0.955 [0.9271629388696617, 1.1292425189805348] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 0.999 [0.9133908810078122, 1.065147183305275] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.963 [0.8974665307836265, 1.0439654280180932] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.014 [0.9436932976916256, 1.0381400728496424] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.054 [1.0366859971078526, 1.12317936225373] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.018 [0.970664361642986, 1.0814766781277356] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.979 [0.8683081325424417, 1.1415610737080275] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 1.015 [1.004167321154111, 1.1028918423504106] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.032 [0.7875763099539406, 1.1189631770693387] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 0.969 [0.9202958761206529, 1.1064744524622465] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 1.034 [0.9863720437644048, 1.2241977675581834] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.996 [0.9455591595834548, 1.02595779893358] | pass |
| full | aa | `frontend_definitions_2000` | 0.997 [0.958862244466848, 1.1644209165066293] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.062 [0.9766488931765177, 1.257543473357353] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.102 [0.9234151834667426, 1.13685869123474] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.051 [0.9220134430563361, 1.1292788413388979] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.027 [0.9845549365969551, 1.2110705085889515] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.981 [0.925971106933419, 1.119774642322227] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.987 [0.8635021418132802, 1.0814593964453592] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.982 [0.9147389661833341, 1.0207531341525549] | pass |
| full | aa | `octal_output_1000d_x300` | 0.960 [0.8356827937197905, 1.0225878208273174] | pass |
| full | aa | `binary_input_100000d_x3` | 1.036 [1.007816567812733, 1.118350632501161] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 1.099 [0.9601919185361733, 1.142205212398815] | inconclusive-noisy |
| full | paired | `startup` | 1.052 [1.0213479653420783, 1.4261685174610683] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.031 [0.6873801231739208, 1.1586023929065552] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.000 [0.921365932186907, 1.0950619032192972] | inconclusive-noisy |
| full | paired | `array_200000` | 0.961 [0.7867025275207238, 1.2113076363896287] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.982 [0.9527265703519047, 1.152806329077281] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.005 [0.9623780172277756, 1.1882648511013305] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.986 [0.9474998353030551, 1.071789901942395] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.024 [0.7887464977166957, 1.23980634079363] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.988 [0.7268092364886937, 1.10645750412491] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.932 [0.8004567040574319, 1.031991229647907] | pass |
| full | paired | `multiply_10000d_x1000` | 1.019 [0.9370424323040867, 1.0938409256971657] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.000 [0.7997010743204119, 1.2046963219917772] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.911 [0.7114695224078861, 0.9679507428005051] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.037 [0.9426330424469891, 1.1401199861751279] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.8306092107489792, 1.0599827554033907] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.951 [0.8435327635996911, 1.0513833508823653] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.989 [0.7609033392876482, 1.4536750525248634] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.003 [0.8345716458294108, 1.0814620495362866] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.953 [0.8651012541507542, 1.053329487878851] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.076 [0.9695450610566734, 1.252486085309522] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.065 [0.8939596108667145, 1.278289777089075] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.035 [0.8983703649851964, 1.063961647962251] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.027 [0.8897515791851217, 1.1750648053091701] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.993 [0.9625059238026701, 1.053526955470827] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.964 [0.8019878861329149, 1.0826262740846613] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.975 [0.8015700658407398, 1.218765748988946] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.101 [0.9260626921362525, 1.307256675994869] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.998 [0.9106049277567559, 1.1266959867051667] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.979 [0.6564296977613727, 1.5531390665642413] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.043 [0.7989128272152011, 1.2747776376963975] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.002 [0.8011122784425511, 1.1755935477299675] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.505 [0.4128481512659169, 0.5359533875462785] | pass |
| full | paired | `hex_input_100000d_x3` | 0.170 [0.15609848556782077, 0.18288104667894683] | pass |
