# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.981 [0.8990704082870178, 1.0790363150327624] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.979 [0.955132226943275, 1.0139371917988202] | pass |
| full | aa | `calls_200000` | 1.000 [0.9754815438257424, 1.0194078276560319] | pass |
| full | aa | `array_200000` | 1.002 [0.9932322028639265, 1.0290455441696458] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.966 [0.9453630784229637, 1.0138560422115894] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.999 [0.9451828747925883, 1.011113535384809] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.997 [0.9873713988744749, 1.003343009066481] | pass |
| full | aa | `fibonacci_1000_x100` | 0.998 [0.9736880777924029, 1.018638631916348] | pass |
| full | aa | `factorial_1000_x50` | 0.994 [0.988538809306169, 1.0078414873668797] | pass |
| full | aa | `multiply_100d_x100000` | 0.996 [0.8819418738281763, 1.0108171540988642] | pass |
| full | aa | `multiply_10000d_x1000` | 1.008 [0.9991398528304924, 1.016229480138091] | pass |
| full | aa | `divide_scale100_x100000` | 0.984 [0.9657849327647309, 1.007059223880339] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.988 [0.9723129861974412, 1.0059415906374947] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9943862608274614, 1.0194988302406682] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9773816207842831, 1.000790708844907] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9678706937261643, 1.0086914647041743] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.004 [0.9738028460345443, 1.0158916896485135] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.005 [0.9926685988695257, 1.0154235932084976] | pass |
| full | aa | `power_100d_e17_x1000` | 0.997 [0.9908579495805891, 0.9998110339012483] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.973 [0.9446813962297452, 1.022176394474751] | pass |
| full | aa | `recursion_50_x1000` | 0.987 [0.9798212872659942, 1.0272874658033828] | pass |
| full | aa | `sparse_array_200000` | 0.991 [0.9630879867028288, 1.0069034645790516] | pass |
| full | aa | `frontend_definitions_2000` | 0.995 [0.9846060864618046, 1.013953209396683] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.004 [0.9872294166118345, 1.0413517623322008] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.993 [0.9478365472233449, 1.0491854965861256] | pass |
| full | aa | `streaming_statements_20000` | 0.985 [0.9217004497370307, 1.0229426067358365] | pass |
| full | aa | `square_100d_x100000` | 0.989 [0.9352702266518645, 1.1067807877674452] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.002 [0.9991375555180411, 1.004223673780581] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.997 [0.9515411586152205, 1.107004076950371] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.996 [0.9829773185902113, 1.0242775929769694] | pass |
| full | aa | `octal_output_1000d_x300` | 1.001 [0.978687827187181, 1.0143989456368676] | pass |
| full | aa | `binary_input_100000d_x3` | 0.998 [0.9937720235342447, 1.0042350878933934] | pass |
| full | aa | `hex_input_100000d_x3` | 1.000 [0.9991734956417128, 1.00157994801597] | pass |
| full | paired | `startup` | 1.015 [0.9238007965475057, 1.0367611821113392] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.969 [0.9392819172852244, 0.9805079490701752] | pass |
| full | paired | `calls_200000` | 0.972 [0.9499290245854396, 0.9932919434304559] | pass |
| full | paired | `array_200000` | 0.992 [0.9624362434749856, 1.026239589584434] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.982 [0.965489206276227, 0.9997307914473915] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.927 [0.89406918990023, 0.9581388605315054] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.926 [0.9162524395949817, 0.9453025905508082] | pass |
| full | paired | `fibonacci_1000_x100` | 0.991 [0.9787669123637661, 1.0081742891257908] | pass |
| full | paired | `factorial_1000_x50` | 0.984 [0.9455596357144842, 1.015484582198435] | pass |
| full | paired | `multiply_100d_x100000` | 0.999 [0.9927028030855476, 1.0113359689403363] | pass |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9967620734045343, 1.0201308398043636] | pass |
| full | paired | `divide_scale100_x100000` | 0.948 [0.9389494583637448, 0.9784508208738223] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.996 [0.9912393240110386, 1.008870333514853] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.996 [0.9847109182807222, 0.9989547254907452] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.996 [0.9811530526706655, 1.008249822243032] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.994 [0.990334736595476, 1.0005600884584818] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.005 [0.98511093633183, 1.0195425392638504] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.006 [1.000567893316062, 1.0128199429231608] | pass |
| full | paired | `power_100d_e17_x1000` | 0.990 [0.9432389037254656, 1.005955303480548] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.992 [0.9724125505996843, 1.012972169841267] | pass |
| full | paired | `recursion_50_x1000` | 1.006 [0.9885563937317403, 1.0294450122844392] | pass |
| full | paired | `sparse_array_200000` | 0.953 [0.9265071986390215, 0.985326046906793] | pass |
| full | paired | `frontend_definitions_2000` | 1.000 [0.9872087233139821, 1.024034825124293] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.001 [0.9961926558909903, 1.0374299188118894] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.984 [0.9376920174654878, 1.028052191958113] | pass |
| full | paired | `streaming_statements_20000` | 0.997 [0.9721074535036264, 1.0091791352073067] | pass |
| full | paired | `square_100d_x100000` | 0.990 [0.9709939985734627, 1.0176733732642487] | pass |
| full | paired | `square_10000d_x500` | 1.000 [0.9931222281004072, 1.0014851856497557] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.022 [1.0081683849781287, 1.1028139743899303] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.992 [0.9101384056554458, 1.0101295576017861] | pass |
| full | paired | `octal_output_1000d_x300` | 0.997 [0.9722692859102564, 1.04473920168154] | pass |
| full | paired | `binary_input_100000d_x3` | 0.474 [0.46518272316454395, 0.47771339039923993] | pass |
| full | paired | `hex_input_100000d_x3` | 0.170 [0.16944508177282164, 0.171514435178902] | pass |
