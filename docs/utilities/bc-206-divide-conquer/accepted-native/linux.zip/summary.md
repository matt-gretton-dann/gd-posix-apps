# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.994 [0.9552785382799247, 1.023638971494908] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.000 [0.9958526822598922, 1.0093001385389275] | pass |
| full | aa | `calls_200000` | 0.996 [0.9872471604554857, 1.0012310617792441] | pass |
| full | aa | `array_200000` | 0.998 [0.9925187247854428, 1.0045715828958788] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.002 [0.9692558957534795, 1.027333295427125] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.977 [0.9357088233569494, 1.0065817864559201] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.978 [0.9622976625021092, 1.074258424341781] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.006 [0.9950852976877183, 1.0082291772900178] | pass |
| full | aa | `factorial_1000_x50` | 0.999 [0.9932617860907199, 1.0067565089084667] | pass |
| full | aa | `multiply_100d_x100000` | 1.006 [0.9999905013451144, 1.0118478723401425] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9887721496452581, 1.0617622948656704] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.003 [0.9937421566196322, 1.0060550692355281] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.9916151801056213, 1.0059990282434135] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.9866330630231887, 1.002450861888149] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9474559529711915, 1.0620133287188036] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9764698209932439, 1.0065523557156135] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.9948374613230625, 1.0198921388271092] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.002 [0.9644158430812482, 1.005211301619563] | pass |
| full | aa | `power_100d_e17_x1000` | 0.999 [0.9968768011359662, 1.0048018855744965] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.996 [0.9875291888048572, 1.0015485218373206] | pass |
| full | aa | `recursion_50_x1000` | 1.001 [0.9923782397150773, 1.0062322238766597] | pass |
| full | aa | `sparse_array_200000` | 1.002 [0.9950364554243828, 1.0075366404133264] | pass |
| full | aa | `frontend_definitions_2000` | 0.998 [0.9819913761919584, 1.0002257433676662] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.997 [0.9898578480162801, 1.0042351019920182] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.001 [0.9695494893106779, 1.0181085169951] | pass |
| full | aa | `streaming_statements_20000` | 0.999 [0.9847558490803953, 1.0023155026222699] | pass |
| full | aa | `square_100d_x100000` | 1.017 [1.014757484992318, 1.0258923760702774] | pass |
| full | aa | `square_10000d_x500` | 0.999 [0.998580063004702, 1.0015488400889712] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.004 [0.9977252803830914, 1.0210293975926874] | pass |
| full | aa | `binary_output_1000d_x300` | 1.003 [0.9787174637360228, 1.0389968350720626] | pass |
| full | aa | `octal_output_1000d_x300` | 0.999 [0.9948310225678505, 1.0010211209082989] | pass |
| full | aa | `binary_input_100000d_x3` | 0.999 [0.9984098548338044, 1.0003512643492805] | pass |
| full | aa | `hex_input_100000d_x3` | 1.000 [0.9988474263383738, 1.000203877977429] | pass |
| full | paired | `startup` | 0.997 [0.957174428491331, 1.02015512364215] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.982 [0.9651456410943573, 0.9849973945417794] | pass |
| full | paired | `calls_200000` | 1.033 [0.9957397562042709, 1.0365475769868877] | pass |
| full | paired | `array_200000` | 0.987 [0.9788834282837969, 0.9976736355737165] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.974 [0.9616314457092368, 0.9930815518890042] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.021 [1.0059327816620218, 1.0541500111028044] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.018 [0.9984383457144734, 1.0348691300175172] | pass |
| full | paired | `fibonacci_1000_x100` | 0.978 [0.9736496321905748, 0.9814475599677622] | pass |
| full | paired | `factorial_1000_x50` | 0.983 [0.9745096382306423, 0.9955370179750687] | pass |
| full | paired | `multiply_100d_x100000` | 0.997 [0.984386206229866, 1.0064668059294255] | pass |
| full | paired | `multiply_10000d_x1000` | 0.998 [0.9707196062948827, 1.0032220410976476] | pass |
| full | paired | `divide_scale100_x100000` | 0.994 [0.9794414953977711, 0.9999227303187793] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.998 [0.9946563424678141, 1.0124935196777685] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.001 [0.9868207523590322, 1.005407058792459] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.997955061524112, 1.0059841536738026] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.997 [0.9815603874472171, 1.0040383145329212] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.9999587018358839, 1.0069448806618146] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.999 [0.9940625782950269, 1.005478565831205] | pass |
| full | paired | `power_100d_e17_x1000` | 0.990 [0.9847716254898479, 0.9928424706153728] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.022 [1.0175409084531974, 1.029668434743008] | pass |
| full | paired | `recursion_50_x1000` | 0.990 [0.9811468857870426, 0.9927752579073812] | pass |
| full | paired | `sparse_array_200000` | 1.018 [1.0115259306387416, 1.023423927096927] | pass |
| full | paired | `frontend_definitions_2000` | 0.998 [0.9902170353266748, 1.004775897966376] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.001 [0.9666542801851941, 1.034582213729766] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.996 [0.9915522191907434, 1.004553449741724] | pass |
| full | paired | `streaming_statements_20000` | 0.990 [0.9853317260069315, 0.9994590303524785] | pass |
| full | paired | `square_100d_x100000` | 1.026 [1.0091713322776452, 1.0275864688789578] | pass |
| full | paired | `square_10000d_x500` | 1.001 [0.9976947056682167, 1.0031661702182368] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.999 [0.9946187300231984, 1.0209150480503542] | pass |
| full | paired | `binary_output_1000d_x300` | 1.007 [0.973042859098226, 1.0284096024113791] | pass |
| full | paired | `octal_output_1000d_x300` | 1.001 [0.9941443104909408, 1.0550814054775897] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.350 [0.34818481206084295, 0.3535482440871845] | pass |
| full | paired | `hex_input_100000d_x3` | 0.127 [0.1259097019648156, 0.12806365321006088] | pass |
