# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.018 [0.9371470588127233, 1.1486455263581112] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.998 [0.9572892010632018, 1.004071793129386] | pass |
| full | aa | `calls_200000` | 0.994 [0.952893869791002, 0.9951222302745218] | pass |
| full | aa | `array_200000` | 1.003 [0.9978335250875894, 1.0316828989446531] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.005 [0.9911011953634027, 1.0833127588084752] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.997 [0.9751204969759986, 1.0264100068651745] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.997 [0.9762188811833152, 1.0088730805637038] | pass |
| full | aa | `fibonacci_1000_x100` | 1.012 [0.9566541188897747, 1.1232925770627957] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.996 [0.9783397500241654, 1.001011163634659] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9808547329043227, 1.0178164080684806] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.998 [0.949416836792273, 1.0197991715671357] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9824416549720566, 1.050264617759427] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9221978161563391, 1.0148596356523674] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.9351341360672657, 1.0055873614629431] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.993 [0.9772313888549183, 1.024366262224911] | pass |
| full | aa | `power_100d_e17_x1000` | 0.983 [0.9466666863059829, 1.0130383447138958] | pass |
| full | aa | `sparse_array_200000` | 0.995 [0.9616799550687155, 1.010100626265396] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.008 [0.990949768636523, 1.0871486460206838] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.000 [0.968762122489828, 1.130288178686794] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.994 [0.9389770960340437, 1.0131667558652977] | pass |
| full | aa | `square_10000d_x500` | 1.005 [0.9759412665746948, 1.01951133943766] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.026 [0.9660193066887712, 1.2760842790424054] | inconclusive-noisy |
| full | paired | `startup` | 0.980 [0.8362998394058117, 1.0228015610215746] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.010 [0.9654282058227984, 1.0552472361924705] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.007 [0.9848350180116437, 1.084625899028493] | inconclusive-noisy |
| full | paired | `array_200000` | 1.016 [0.9670821403488761, 1.0625648973145092] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.007 [0.9878442881074222, 1.0237534912198694] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.002 [0.943048274019674, 1.0833620560587258] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.006 [0.9986285803965618, 1.032575562918586] | pass |
| full | paired | `fibonacci_1000_x100` | 0.987 [0.9377701983992609, 1.0001549273977197] | pass |
| full | paired | `multiply_100d_x100000` | 1.008 [0.984845677148678, 1.0161686108390946] | pass |
| full | paired | `multiply_10000d_x1000` | 0.983 [0.9676526446735744, 1.0683971441600308] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.979 [0.9443127023116454, 1.0063147036483522] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.961 [0.9266055861964612, 0.9916404792538155] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.892 [0.8784478531053117, 0.9544804167112658] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.914 [0.8818139936527369, 0.9683435183897412] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.996 [0.9471604577573315, 1.0413500794641746] | pass |
| full | paired | `power_100d_e17_x1000` | 0.995 [0.9769681133752471, 1.0092095441601592] | pass |
| full | paired | `sparse_array_200000` | 0.998 [0.9732681696220788, 1.0458918381960456] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.145 [0.14199665591172703, 0.14676570735709468] | pass |
| full | paired | `streaming_statements_20000` | 1.017 [0.9848428506113988, 1.0360885498010732] | pass |
| full | paired | `square_100d_x100000` | 1.006 [0.9948275815733866, 1.0219821729210405] | pass |
| full | paired | `square_10000d_x500` | 0.963 [0.9526490610438996, 0.9778863490494116] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.921 [0.7450390326816775, 0.9847221927043153] | pass |
