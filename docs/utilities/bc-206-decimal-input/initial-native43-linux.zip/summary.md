# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.001 [0.7740249647050559, 1.2609683925515085] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.999 [0.993038520499119, 1.0079293792373172] | pass |
| full | aa | `calls_200000` | 1.006 [1.0012602309758738, 1.0128218023538125] | pass |
| full | aa | `array_200000` | 1.011 [0.9931756436812292, 1.0116505044039708] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.002 [0.9753490315628783, 1.01454731294648] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.987 [0.9444345488035782, 1.04388691944351] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.971 [0.8995938614827146, 0.9986178676711446] | pass |
| full | aa | `fibonacci_1000_x100` | 0.996 [0.9817673780681435, 1.0103115016038282] | pass |
| full | aa | `multiply_100d_x100000` | 1.002 [0.9886979321071456, 1.0071031611477261] | pass |
| full | aa | `multiply_10000d_x1000` | 1.004 [0.9816316306880898, 1.019406425430658] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.992 [0.9823109941181528, 1.006404007302383] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.9925230526274187, 1.0095117072896749] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.008 [0.9724610174149925, 1.0165682598732695] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.006 [0.9978013325999724, 1.0132228768500282] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.987 [0.9763180532108365, 1.0259307798773882] | pass |
| full | aa | `power_100d_e17_x1000` | 1.004 [0.9873718996134454, 1.011990311130134] | pass |
| full | aa | `sparse_array_200000` | 1.015 [0.9985720151804459, 1.0459607485032618] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.998 [0.9863740170013401, 0.9983825172672335] | pass |
| full | aa | `streaming_statements_20000` | 1.004 [0.982000960684048, 1.0117234798532675] | pass |
| full | aa | `square_100d_x100000` | 0.990 [0.9793711070463926, 1.0184191071890163] | pass |
| full | aa | `square_10000d_x500` | 1.003 [0.9905795330781366, 1.0116144721800624] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.959 [0.8873035979602408, 1.1173090677706674] | inconclusive-noisy |
| full | paired | `startup` | 0.972 [0.8949188157977497, 1.059512619563576] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.030 [1.0040235407821267, 1.0401439082120134] | pass |
| full | paired | `calls_200000` | 0.997 [0.9777652122226883, 1.0128730087877547] | pass |
| full | paired | `array_200000` | 0.990 [0.9704246828048089, 1.0282481193475506] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.986 [0.9690354763618844, 0.9884138397554683] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.968 [0.950061836205579, 1.0492428871128008] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.971 [0.9667880624904637, 1.064954032919027] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.011 [1.000720387000673, 1.0282972965537662] | pass |
| full | paired | `multiply_100d_x100000` | 1.021 [0.9848453790341251, 1.0349727928608878] | pass |
| full | paired | `multiply_10000d_x1000` | 0.972 [0.9607918616281906, 0.9821957911717519] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.014 [1.0098056756787104, 1.0193338245436272] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.946 [0.8896884841375915, 0.9606409069471327] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.825 [0.8169781023177645, 0.8336208710135992] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.884 [0.8642654753891785, 0.892748917791993] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.992 [0.9801410313193609, 1.0087713141796975] | pass |
| full | paired | `power_100d_e17_x1000` | 1.006 [0.9874117914732872, 1.0232484927227037] | pass |
| full | paired | `sparse_array_200000` | 1.004 [0.9948085160143963, 1.0162681027421838] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.048 [0.045709549900058224, 0.04883822618285828] | pass |
| full | paired | `streaming_statements_20000` | 1.000 [0.9887719132307908, 1.0213806128104226] | pass |
| full | paired | `square_100d_x100000` | 1.045 [1.0175341327789684, 1.049371186775391] | pass |
| full | paired | `square_10000d_x500` | 0.949 [0.9302950402592425, 0.9565057095332024] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.811 [0.7059490893626943, 0.9356460739661591] | pass |
