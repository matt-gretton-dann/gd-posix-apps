# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.998 [0.9332287957983318, 1.100507729718134] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.985 [0.9746464261249885, 1.0145490562478745] | pass |
| full | aa | `calls_200000` | 1.027 [1.0205654676499347, 1.0446798729771982] | pass |
| full | aa | `array_200000` | 0.996 [0.9928425795530043, 1.0207684082173798] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.007 [1.0036748264049504, 1.0169203476732056] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.005 [0.9993854698631142, 1.009409125100344] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.009 [0.9962764516380804, 1.009506300809042] | pass |
| full | aa | `fibonacci_1000_x100` | 1.013 [1.0012297700566826, 1.0247202800920958] | pass |
| full | aa | `multiply_100d_x100000` | 1.005 [0.9993456289712316, 1.0095623561707425] | pass |
| full | aa | `multiply_10000d_x1000` | 0.999 [0.9975574413041914, 1.0038295839694535] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.998 [0.9774715558987034, 1.0323850490340067] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9985740858752338, 1.0034646463896701] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9994227769754684, 1.0074248418005551] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.9947015371928178, 1.0067589395156795] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.995 [0.9778124953802413, 1.0160410472540866] | pass |
| full | aa | `power_100d_e17_x1000` | 1.004 [0.9943592626921443, 1.009996839903655] | pass |
| full | aa | `sparse_array_200000` | 0.996 [0.9638939232711621, 1.019711997486679] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.001 [0.9941527859248995, 1.008980659414012] | pass |
| full | aa | `streaming_statements_20000` | 1.009 [0.9696018606142098, 1.1173258373445445] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.021 [0.9392049794239548, 1.0514026974336759] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.000 [0.9961796960293051, 1.0059068573313952] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.958 [0.9364405120790266, 1.020555821266263] | pass |
| full | paired | `startup` | 1.014 [0.9422473968784688, 1.0706053141000775] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.003 [0.993696270354006, 1.0420812963055603] | pass |
| full | paired | `calls_200000` | 0.989 [0.9686626460449268, 1.0156188667366055] | pass |
| full | paired | `array_200000` | 0.983 [0.9680228803319354, 0.9994509778554321] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.987 [0.9716313973205313, 0.9923539669263878] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.991 [0.9863382556085017, 1.0009108310718249] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.985 [0.9853279654103639, 0.9918199635657897] | pass |
| full | paired | `fibonacci_1000_x100` | 1.010 [1.0067095475347652, 1.022275100901177] | pass |
| full | paired | `multiply_100d_x100000` | 0.990 [0.9837384957281191, 1.0136789441680414] | pass |
| full | paired | `multiply_10000d_x1000` | 0.977 [0.9750935149370619, 0.9769345795667802] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.000 [0.9935765224422344, 1.0129491005756] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.954 [0.9518775253640427, 0.9555818201481119] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.839 [0.8295918583464403, 0.8434384826812537] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.900 [0.891094102819923, 0.9052932746094122] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.9883221984113774, 1.020749556873658] | pass |
| full | paired | `power_100d_e17_x1000` | 1.004 [0.9932393855613048, 1.0101954224387604] | pass |
| full | paired | `sparse_array_200000` | 0.993 [0.980436008605818, 0.9940882974334891] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.085 [0.08416358886254725, 0.0859379404527513] | pass |
| full | paired | `streaming_statements_20000` | 0.990 [0.9499177820176743, 1.00881580894741] | pass |
| full | paired | `square_100d_x100000` | 0.999 [0.9830939564529472, 1.0052542965469116] | pass |
| full | paired | `square_10000d_x500` | 0.953 [0.9494699763654112, 0.9598430256602648] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.928 [0.8852602896291175, 0.9487787261278143] | pass |
