# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.975 [0.8307694706085964, 1.0987306234343417] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.979 [0.9443232358354531, 1.0516708802601982] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.998 [0.9501529647463688, 1.0432383853724454] | pass |
| full | aa | `array_200000` | 1.012 [0.9304496708667352, 1.0786664157372285] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.982 [0.9409684874626082, 1.054122378808384] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.012 [0.9454155448405949, 1.0823077334642301] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.043 [0.8880855610647027, 1.0915494931064929] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.999 [0.8968200938147532, 1.0752495572950747] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 0.974 [0.9275088942974333, 1.001031406823921] | pass |
| full | aa | `multiply_100d_x100000` | 0.965 [0.9065882385892877, 0.9975310871730564] | pass |
| full | aa | `multiply_10000d_x1000` | 1.006 [0.9756424435232945, 1.1096437494052813] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 0.997 [0.9139008342191992, 1.0484487095209818] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.963 [0.9309363778664468, 0.9896904576155021] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.997 [0.9504166763262702, 1.038249899972509] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.993 [0.9178464225702482, 0.9975201527024079] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.994 [0.941606605466894, 1.0913227372755463] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.016 [0.9087725780945443, 1.0301171933171707] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.019 [0.9545924670349792, 1.1316036792297854] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.026 [0.9331625745439271, 1.0347773598038983] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.006 [0.9390897643767276, 1.0309001023728064] | pass |
| full | aa | `recursion_50_x1000` | 0.985 [0.8896536827034331, 1.0877571437395694] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.038 [0.9427608086279682, 1.0935737822310394] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.967 [0.9525281245974989, 1.0154460789502666] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.007 [0.9817942639324108, 1.1371571734037513] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.005 [0.9634650718053253, 1.0733807221126186] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.986 [0.9636788692738152, 1.044160435278497] | pass |
| full | aa | `square_100d_x100000` | 1.036 [0.9705939296604421, 1.0436441584821081] | pass |
| full | aa | `square_10000d_x500` | 0.972 [0.9008551780301801, 1.0803226612275616] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.992 [0.6907764543368567, 1.02458689305773] | pass |
| full | paired | `startup` | 0.979 [0.9025974118098374, 1.122616957062102] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.019 [0.9972714596775543, 1.0295669147988902] | pass |
| full | paired | `calls_200000` | 1.002 [0.9716732634195072, 1.0067288096958857] | pass |
| full | paired | `array_200000` | 1.001 [0.9395178199032695, 1.0068569256664073] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.012 [0.9718301494007461, 1.0218572029500526] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.009 [0.9949944622893421, 1.0994265284239548] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.997 [0.9277779677782574, 0.9997436547012414] | pass |
| full | paired | `fibonacci_1000_x100` | 1.007 [0.93140209068832, 1.0216332390923286] | pass |
| full | paired | `factorial_1000_x50` | 1.003 [0.9917277002784431, 1.0293803752647723] | pass |
| full | paired | `multiply_100d_x100000` | 1.003 [0.9657735926129348, 1.0241784166412358] | pass |
| full | paired | `multiply_10000d_x1000` | 0.986 [0.9720769824659687, 1.0227851377590964] | pass |
| full | paired | `divide_scale100_x100000` | 1.010 [0.9981982023939237, 1.0123982100869793] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.995 [0.976732198951592, 1.0004557685069453] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.955 [0.9248569156823816, 0.9606287021415548] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.875 [0.8622048849384227, 0.9430743668899051] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.910 [0.8459222517267712, 0.9211190271559109] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.069 [0.9535698259275833, 1.1198774932606457] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.999 [0.9886484417749124, 1.0202155523910268] | pass |
| full | paired | `power_100d_e17_x1000` | 0.995 [0.9924083702494838, 1.006894825975382] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.023 [0.9995285203313885, 1.0498145653571351] | pass |
| full | paired | `recursion_50_x1000` | 1.001 [0.9892273186557661, 1.0144527244631583] | pass |
| full | paired | `sparse_array_200000` | 1.006 [0.9879905180236415, 1.0828296886388098] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.994 [0.9852967963863541, 1.206125395584422] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.151 [0.1403636610601137, 0.15388066216350105] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.017 [0.9942799797910272, 1.0460052544298228] | pass |
| full | paired | `streaming_statements_20000` | 0.997 [0.9518309199655586, 1.0103380450737849] | pass |
| full | paired | `square_100d_x100000` | 1.003 [0.9901772702839143, 1.0112009995731037] | pass |
| full | paired | `square_10000d_x500` | 0.960 [0.9533629330380343, 0.9839084804962684] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.858 [0.8324848057821761, 0.9398516760709446] | pass |
