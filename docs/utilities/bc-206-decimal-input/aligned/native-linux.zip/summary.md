# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.812 [0.7265112971402079, 1.0449176904647335] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.997 [0.9947850384950288, 1.007786064993403] | pass |
| full | aa | `calls_200000` | 1.007 [0.9927544728999323, 1.020990548237188] | pass |
| full | aa | `array_200000` | 1.004 [0.983022663371808, 1.2154471563733427] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 1.002 [0.9799640050289672, 1.0354761880760628] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.000 [0.9632662670488022, 1.0561819385431845] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.974 [0.9152580920103828, 1.026142340072535] | pass |
| full | aa | `fibonacci_1000_x100` | 0.997 [0.9805900059470725, 1.0253072699917565] | pass |
| full | aa | `factorial_1000_x50` | 0.996 [0.9927137046374072, 1.0164883446383577] | pass |
| full | aa | `multiply_100d_x100000` | 0.991 [0.9779423090776884, 1.0247523393803688] | pass |
| full | aa | `multiply_10000d_x1000` | 0.995 [0.9702914855059469, 1.016690726640459] | pass |
| full | aa | `divide_scale100_x100000` | 1.001 [0.9797298927060576, 1.0101400583299216] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.011 [0.9997736471040201, 1.0199444888069282] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9798663353192527, 1.0010902538843403] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9930278054464885, 1.009974260872434] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.004 [0.992164670662929, 1.021427706338545] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.993 [0.9842206902391291, 1.0389417029529338] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.006 [0.9922956645769524, 1.0188747946950405] | pass |
| full | aa | `power_100d_e17_x1000` | 1.006 [0.9949661599906386, 1.020257215300449] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.006 [0.985116361035681, 1.0259742192820003] | pass |
| full | aa | `recursion_50_x1000` | 0.992 [0.987205075391824, 1.007338412094673] | pass |
| full | aa | `sparse_array_200000` | 1.002 [0.973472889345579, 1.0171432408541845] | pass |
| full | aa | `frontend_definitions_2000` | 0.987 [0.9649648610435888, 1.0203856914099967] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.004 [0.9948449698711006, 1.0104154125792828] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.004 [0.8045685873478602, 1.1111976951526792] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.983 [0.972722654849289, 1.0009326211881173] | pass |
| full | aa | `square_100d_x100000` | 1.006 [0.9781678639616898, 1.0348965060484874] | pass |
| full | aa | `square_10000d_x500` | 0.993 [0.9910689135873566, 1.003465071698815] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.969 [0.9229658563164977, 1.0356505292351048] | pass |
| full | paired | `startup` | 0.830 [0.647299309783682, 1.410825029286943] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.002 [0.9949081019589057, 1.0125582585194342] | pass |
| full | paired | `calls_200000` | 0.982 [0.9719500693471379, 0.9961572524838358] | pass |
| full | paired | `array_200000` | 1.004 [0.989087110320451, 1.0279002977940497] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.995 [0.9878305929800104, 1.0203337382484836] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.967 [0.9128774531471648, 1.0094211651962401] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.943 [0.9144457405759203, 0.9861815850152418] | pass |
| full | paired | `fibonacci_1000_x100` | 1.017 [0.9911681771280658, 1.0311766197379801] | pass |
| full | paired | `factorial_1000_x50` | 1.009 [1.003276713095526, 1.0198026467877777] | pass |
| full | paired | `multiply_100d_x100000` | 1.005 [0.9986592014383492, 1.0418506436517443] | pass |
| full | paired | `multiply_10000d_x1000` | 0.975 [0.9618823478815847, 0.9941060408401985] | pass |
| full | paired | `divide_scale100_x100000` | 1.015 [1.0036169003605357, 1.0277159205114812] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.000 [0.9810018683455694, 1.0033605427100853] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.941 [0.8971750810074394, 0.951795254769136] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.809 [0.7928712570294468, 0.8190440677857793] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.887 [0.8787158575494897, 0.9009975505034697] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.989 [0.8925021549479648, 1.0181653528027335] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.002 [0.9805997398852133, 1.0205053653679446] | pass |
| full | paired | `power_100d_e17_x1000` | 0.990 [0.9796532760551193, 1.0086749186474437] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.958 [0.9441308497472065, 0.9790228772987675] | pass |
| full | paired | `recursion_50_x1000` | 1.015 [0.9946772077407157, 1.0344519088584616] | pass |
| full | paired | `sparse_array_200000` | 1.005 [0.982931124803829, 1.0333522036698835] | pass |
| full | paired | `frontend_definitions_2000` | 0.992 [0.9841058583647614, 1.022745461038976] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.048 [0.04742283259124598, 0.04918206360310302] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.004 [0.9227782164004498, 1.0512110703702875] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.986 [0.9463783538842784, 0.9994110869864136] | pass |
| full | paired | `square_100d_x100000` | 1.024 [1.0065573353550363, 1.0387624164447875] | pass |
| full | paired | `square_10000d_x500` | 0.954 [0.9231949603310697, 0.9646029080903991] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.817 [0.7771296751046879, 0.8955126887164959] | pass |
