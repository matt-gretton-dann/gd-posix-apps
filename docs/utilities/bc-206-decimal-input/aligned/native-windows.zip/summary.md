# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.943 [0.9135616725075363, 1.0018497965177116] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.000 [0.9814631105494609, 1.0186753960161532] | pass |
| full | aa | `calls_200000` | 0.984 [0.9802523831936522, 0.9917897863431816] | pass |
| full | aa | `array_200000` | 0.998 [0.9876628036263738, 1.0434855844061828] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.004 [0.9991019009494932, 1.0421537946945416] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.985 [0.8687109565597192, 1.002088103209968] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.010 [0.9950987012471723, 1.0239386012746585] | pass |
| full | aa | `fibonacci_1000_x100` | 1.000 [0.9936251554969064, 1.0146089592480507] | pass |
| full | aa | `factorial_1000_x50` | 0.985 [0.9223784382762834, 1.0140880913850585] | pass |
| full | aa | `multiply_100d_x100000` | 0.989 [0.9122053984370075, 0.9958182995843615] | pass |
| full | aa | `multiply_10000d_x1000` | 0.999 [0.9978070187080099, 1.0008048529098048] | pass |
| full | aa | `divide_scale100_x100000` | 0.991 [0.9817949017665041, 1.0098447759238567] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.004 [0.9885044000912936, 1.0114556790751807] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.996394291995943, 1.0028935497232294] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.006 [0.9833096929586888, 1.0181909799425313] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9914424629007573, 1.0058229599440685] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.990 [0.976528667938866, 1.0034297108678063] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.997 [0.9928919750275215, 1.0407125581961816] | pass |
| full | aa | `power_100d_e17_x1000` | 1.005 [0.9975473169790475, 1.0103825697173938] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.003 [0.9830972361633159, 1.0192646866552324] | pass |
| full | aa | `recursion_50_x1000` | 1.015 [0.9848736027511836, 1.0711171307737974] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.987 [0.9724089561655846, 0.9942681990368822] | pass |
| full | aa | `frontend_definitions_2000` | 1.009 [1.0018496235881877, 1.0314769540518942] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.999 [0.9932074332302493, 1.0030377772538086] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.009 [0.9980304627929014, 1.0178953137866904] | pass |
| full | aa | `streaming_statements_20000` | 0.924 [0.8994393510253966, 0.9913800539656621] | pass |
| full | aa | `square_100d_x100000` | 0.989 [0.9686432754407789, 0.9962930860065955] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9942283662626924, 1.0081450644899197] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.033 [0.9567471195597059, 1.062927893554582] | inconclusive-noisy |
| full | paired | `startup` | 0.971 [0.9155796272245961, 1.084439006356855] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.995 [0.9533003987197036, 0.9976147185517956] | pass |
| full | paired | `calls_200000` | 0.970 [0.9264059903193953, 1.0910962360918732] | inconclusive-noisy |
| full | paired | `array_200000` | 0.984 [0.9569036850808078, 1.0137114126995619] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.988 [0.9024224305320483, 1.0088601991395316] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.998 [0.8865059568778825, 1.1460841448670782] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.993 [0.9830089066722915, 1.0016832083133629] | pass |
| full | paired | `fibonacci_1000_x100` | 0.998 [0.9025989520683728, 1.0942037688427328] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.011 [0.9292525919307377, 1.0211992338484466] | pass |
| full | paired | `multiply_100d_x100000` | 1.000 [0.9538785125050925, 1.0178100021254366] | pass |
| full | paired | `multiply_10000d_x1000` | 0.977 [0.9631045253102499, 0.9823628729325625] | pass |
| full | paired | `divide_scale100_x100000` | 1.023 [0.9614728651111643, 1.1687162854101412] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.007 [1.000586596076658, 1.0282299586691594] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.953 [0.9510542370634113, 0.9589288147985776] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.842 [0.8373735252008262, 0.9097829436323405] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.886 [0.8800275792799578, 0.8992190489926043] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.9873908495031473, 1.02486628982556] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.998 [0.9848655748523072, 1.0968644308184778] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.005 [0.9564577893592543, 1.016693244665938] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.000 [0.9497589842069929, 1.0167462514914083] | pass |
| full | paired | `recursion_50_x1000` | 1.016 [0.9579566124148885, 1.050257713042833] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.005 [0.9822957866418944, 1.0426992824118544] | pass |
| full | paired | `frontend_definitions_2000` | 0.992 [0.8916924408079593, 1.0358439164934536] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.085 [0.08286628532733743, 0.09178507396695401] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.005 [0.9760111312531924, 1.0174524714787412] | pass |
| full | paired | `streaming_statements_20000` | 0.957 [0.9193659180976848, 1.0774075963772636] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.003 [0.9691353180643532, 1.1622760365448523] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.957 [0.9487943444610212, 0.9630739199011178] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.932 [0.900318987830277, 1.1104658769516769] | inconclusive-noisy |
