# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.845 [0.7652474234334637, 1.1089066277286117] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.012 [0.9844300628001719, 1.015405976642394] | pass |
| full | aa | `calls_200000` | 0.987 [0.9655992886902525, 1.0087588247212738] | pass |
| full | aa | `array_200000` | 0.992 [0.983551698658933, 1.0126373028461648] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.009 [0.9973894444459559, 1.0182208920805211] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.999 [0.9365050924559644, 1.00527722776054] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.997 [0.9967118413346234, 1.009243272598387] | pass |
| full | aa | `fibonacci_1000_x100` | 0.996 [0.983327136067963, 1.0039852117912276] | pass |
| full | aa | `factorial_1000_x50` | 0.994 [0.9861776406369088, 1.0101720247297157] | pass |
| full | aa | `multiply_100d_x100000` | 0.987 [0.9704615248374668, 1.023987209561675] | pass |
| full | aa | `multiply_10000d_x1000` | 1.003 [0.9969081800947817, 1.003088641267607] | pass |
| full | aa | `divide_scale100_x100000` | 1.002 [0.9591838327239566, 1.0092365010550786] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.002 [0.9993534016185602, 1.0090252292141406] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.9961299377289157, 1.0045852210997968] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9827067621742795, 1.0149848925882605] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.997202178724465, 1.0070346315700731] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.988 [0.9848268870797617, 1.034632111825933] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9980172199675508, 1.0049318308305197] | pass |
| full | aa | `power_100d_e17_x1000` | 1.009 [0.9906148057225339, 1.0245188783568142] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.004 [0.9843121607225116, 1.018782820752187] | pass |
| full | aa | `recursion_50_x1000` | 0.999 [0.9882736291302721, 1.008344141255483] | pass |
| full | aa | `sparse_array_200000` | 0.992 [0.9866502249520908, 1.0079293097906319] | pass |
| full | aa | `frontend_definitions_2000` | 1.012 [0.9994213260892999, 1.028602857398102] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.994 [0.9908540383617355, 1.0096362214909673] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.983 [0.9519807838458534, 1.0396036928358223] | pass |
| full | aa | `streaming_statements_20000` | 0.995 [0.9814583153149021, 1.0022793166211785] | pass |
| full | aa | `square_100d_x100000` | 0.999 [0.9894761955252445, 1.0172808949366634] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9993426100458033, 0.9999911070010701] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.954 [0.8669285063971819, 1.1591730001040708] | inconclusive-noisy |
| full | paired | `startup` | 1.039 [0.8374128308029213, 1.2543376268681004] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.019 [1.0149399242729562, 1.035951527753632] | pass |
| full | paired | `calls_200000` | 1.018 [0.9822840545018915, 1.066108479308506] | inconclusive-noisy |
| full | paired | `array_200000` | 1.022 [0.965151299341414, 1.0429876792094468] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.027 [1.0184853617453278, 1.0404545586724028] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.006 [0.9849014161407837, 1.0313284435838341] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.029 [1.0044932480272228, 1.0403799306914119] | pass |
| full | paired | `fibonacci_1000_x100` | 1.044 [1.024783771522134, 1.0513889798996277] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.030 [1.0175623483403218, 1.0642867153918558] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.039 [1.0038876442521436, 1.0655479578006082] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9970792877080016, 1.0031270326776993] | pass |
| full | paired | `divide_scale100_x100000` | 1.011 [0.9576591452964144, 1.028565144204173] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.995 [0.9899832645402765, 1.0064105431215165] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.9946168566053448, 1.001800186846413] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.994 [0.9826123683032444, 1.069397381653452] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.986 [0.9256630378248933, 0.9921157769421796] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.011 [0.9912778362601826, 1.0199583271457986] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.010 [1.0076644192679967, 1.0322384491403025] | pass |
| full | paired | `power_100d_e17_x1000` | 0.997 [0.9920015226072934, 1.0071489501315332] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.042 [1.0278482221192704, 1.0958250888772054] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.009 [1.004002440671115, 1.0231442499256562] | pass |
| full | paired | `sparse_array_200000` | 1.046 [1.0265239613152466, 1.0672473222646752] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.014 [1.0001984259686738, 1.021556625820572] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.011 [0.9859043327944529, 1.0207884458706737] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.599 [0.5760588126802094, 0.6488411036094373] | pass |
| full | paired | `streaming_statements_20000` | 0.995 [0.9865985511991229, 1.007422587449444] | pass |
| full | paired | `square_100d_x100000` | 1.028 [0.9949224063819054, 1.0543725454116235] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.000 [0.9984812223075862, 1.0002907625768616] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.916 [0.8676014418467646, 1.0540114669027218] | inconclusive-noisy |
