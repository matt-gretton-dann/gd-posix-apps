# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.980 [0.9237654990965503, 1.0586468022061135] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.018 [0.9872922724606036, 1.03860731163443] | pass |
| full | aa | `calls_200000` | 1.000 [0.9986920637096905, 1.0280378327550286] | pass |
| full | aa | `array_200000` | 0.990 [0.9630413695158323, 1.0421241170010858] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.001 [0.9153505708557025, 1.0177590877986005] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.009 [1.005343309125475, 1.0992792055597136] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.996 [0.9552919875033793, 1.0164359246890617] | pass |
| full | aa | `fibonacci_1000_x100` | 1.001 [0.999810080969652, 1.0092108418494268] | pass |
| full | aa | `factorial_1000_x50` | 1.003 [0.976258928170817, 1.0246922997832868] | pass |
| full | aa | `multiply_100d_x100000` | 0.984 [0.944647658213203, 1.0119459922083678] | pass |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.9949097352889366, 1.0433593751305623] | pass |
| full | aa | `divide_scale100_x100000` | 1.027 [1.0222757754506417, 1.1582058207202575] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.001 [0.9773968572962403, 1.0213683564852367] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.987 [0.9787537792468525, 1.0096238949509995] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.014 [0.989796503432444, 1.1749801042886014] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.9666911306866909, 1.011412539633387] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.9946412881343788, 1.0105023943680946] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.001 [0.9780126674425479, 1.0041858121242175] | pass |
| full | aa | `power_100d_e17_x1000` | 1.003 [1.000173221362607, 1.0584880177301212] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 1.003 [0.8333354489440127, 1.026898641155777] | pass |
| full | aa | `recursion_50_x1000` | 1.010 [0.9968131692898873, 1.0270393006490532] | pass |
| full | aa | `sparse_array_200000` | 1.009 [0.9798165086025841, 1.102466973487876] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 1.000 [0.8573576916537641, 1.0081042563303948] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.006 [0.9866725715735438, 1.0289316910618662] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.994 [0.9858798774399651, 0.9968872567152001] | pass |
| full | aa | `streaming_statements_20000` | 0.994 [0.9714658654257249, 1.0289258144365936] | pass |
| full | aa | `square_100d_x100000` | 0.999 [0.9801198717440771, 1.0194543724554923] | pass |
| full | aa | `square_10000d_x500` | 0.999 [0.9821727205736901, 1.0030881279098742] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.010 [0.916920100903956, 1.15873959572227] | inconclusive-noisy |
| full | paired | `startup` | 0.991 [0.9365395095328206, 1.080637084426615] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.000 [0.9803538650588349, 1.0210201900007705] | pass |
| full | paired | `calls_200000` | 1.013 [1.007317827944988, 1.0333982400643895] | pass |
| full | paired | `array_200000` | 1.006 [0.9538383608251764, 1.048013085638655] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.007 [1.0006706793776563, 1.0108697313607928] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.976 [0.9684946519776, 0.9947181177928616] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.966 [0.9555940553044874, 1.0212670202614302] | pass |
| full | paired | `fibonacci_1000_x100` | 0.995 [0.9645477009247173, 1.0116799368852993] | pass |
| full | paired | `factorial_1000_x50` | 1.011 [0.9838848249999731, 1.0185083049954753] | pass |
| full | paired | `multiply_100d_x100000` | 1.004 [0.9780047830085663, 1.0393843544207098] | pass |
| full | paired | `multiply_10000d_x1000` | 1.003 [0.9963636527778655, 1.0093496297000315] | pass |
| full | paired | `divide_scale100_x100000` | 1.014 [1.0050081002418634, 1.0472415955743433] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.009 [1.0065576401744802, 1.0225325423725775] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.9919527662977382, 1.0057172595526376] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9846023042667298, 1.0122178618146913] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.988 [0.9684064248336222, 1.00171102942258] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.015 [0.9989428638217668, 1.0249585605027798] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.999 [0.9893960741505952, 1.0238862236360868] | pass |
| full | paired | `power_100d_e17_x1000` | 0.989 [0.975706054159208, 1.0073961474914475] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.972 [0.947232602361323, 1.018298685053142] | pass |
| full | paired | `recursion_50_x1000` | 1.040 [1.0284705195140595, 1.0590017137531387] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.031 [0.9879411592054411, 1.0778473469311172] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.002 [0.9631469236353746, 1.018942430661995] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.003 [0.988218655688874, 1.0227981185232493] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.718 [0.7027039616171797, 0.7272899242373199] | pass |
| full | paired | `streaming_statements_20000` | 1.009 [0.9831661329894272, 1.0517755199625995] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.994 [0.9714562193681683, 1.0032477821134247] | pass |
| full | paired | `square_10000d_x500` | 0.998 [0.9963111151203442, 1.0023157020333355] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.967 [0.952021491520031, 1.0544364675512983] | inconclusive-noisy |
