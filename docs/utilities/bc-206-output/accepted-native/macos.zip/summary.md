# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.016 [0.6847822142798121, 1.0934941351661434] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.963 [0.8955567255713832, 1.0969031694862375] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.993 [0.9400829898359845, 1.035166504737774] | pass |
| full | aa | `array_200000` | 1.047 [1.0041280571591356, 1.1218635499043477] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 1.034 [0.9523012034401196, 1.1477453047666788] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.027 [0.8292413836997163, 1.1540047138782124] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.030 [0.9048423018048729, 1.136842410802431] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.965 [0.8500730916040269, 1.0954866831448893] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.087 [0.9430256312451555, 1.1564989871096578] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.028 [0.9698837605086801, 1.1656502120140853] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.997 [0.9619187393582241, 1.07942558435778] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 0.988 [0.7963881520894398, 1.1689205374352962] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.956 [0.8571617069743706, 1.3262483413034865] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.036 [1.0192423995160593, 1.164042169109742] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.033 [0.9581405600552334, 1.1129858504773333] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.011 [0.949599592995992, 1.095475771362956] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.021 [0.8321660886000122, 1.1579210823639154] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.995 [0.8142840939776562, 1.0428636925682397] | pass |
| full | aa | `power_100d_e17_x1000` | 1.019 [0.9147676067589557, 1.1345369469338762] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 0.916 [0.8044167717555173, 0.991795107438157] | pass |
| full | aa | `recursion_50_x1000` | 1.053 [0.7420480177381106, 1.1405873517544245] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.069 [1.0278663515418096, 1.1591474206393027] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 1.044 [0.9310659394307736, 1.0966693500760982] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.967 [0.8211036724257325, 1.040750842785803] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.919 [0.8868917370133121, 1.163876915417762] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.969 [0.9020687248748888, 1.0418796229049354] | pass |
| full | aa | `square_100d_x100000` | 0.976 [0.907640563564552, 1.0019064878592774] | pass |
| full | aa | `square_10000d_x500` | 1.013 [0.9168874118086939, 1.14399820015283] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.954 [0.7197251937085082, 1.0753267476324178] | inconclusive-noisy |
| full | paired | `startup` | 1.019 [0.9885493083945216, 1.1606041224519301] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.000 [0.9876650922840182, 1.0121433874131827] | pass |
| full | paired | `calls_200000` | 0.995 [0.9797453369850784, 1.103877760439041] | inconclusive-noisy |
| full | paired | `array_200000` | 0.993 [0.925579777813877, 1.0022495983236708] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.992 [0.9565950334936091, 1.0082221841890542] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.009 [0.9798984082077523, 1.0416536499008255] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.991 [0.9567828645964064, 1.0102590494450512] | pass |
| full | paired | `fibonacci_1000_x100` | 0.992 [0.983912103238175, 1.0233823361500178] | pass |
| full | paired | `factorial_1000_x50` | 0.997 [0.968393976352681, 1.0272608515662318] | pass |
| full | paired | `multiply_100d_x100000` | 1.000 [0.975162579643289, 1.0033617515217745] | pass |
| full | paired | `multiply_10000d_x1000` | 0.997 [0.991693265616673, 1.0041924860995608] | pass |
| full | paired | `divide_scale100_x100000` | 1.004 [0.9725546105826023, 1.5196570278612118] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.992 [0.9915242536781685, 1.0129010483946643] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.990 [0.9678965007381232, 1.0317909849196918] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.992 [0.960488061962589, 1.0648367101591274] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.992 [0.9744420965827328, 1.0222378216873953] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.046 [1.0133095271971955, 1.092190026740521] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.019 [0.9919519456746525, 1.138129311050143] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.992 [0.9601591497116759, 1.0086263625277068] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.014 [0.9818533192816865, 1.0432730506543637] | pass |
| full | paired | `recursion_50_x1000` | 1.004 [0.9532145722591011, 1.0340012129673848] | pass |
| full | paired | `sparse_array_200000` | 0.999 [0.9944455504612933, 1.0230211870001718] | pass |
| full | paired | `frontend_definitions_2000` | 0.995 [0.9467332045052744, 1.007103125454283] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.998 [0.9737718915182074, 1.0283504086341855] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.498 [0.47186902161884486, 0.5127350767743003] | pass |
| full | paired | `streaming_statements_20000` | 0.993 [0.9304016605181845, 1.0085992674838926] | pass |
| full | paired | `square_100d_x100000` | 0.998 [0.9887316270360855, 1.0223089811957429] | pass |
| full | paired | `square_10000d_x500` | 0.981 [0.9723024704609196, 0.9960735015059687] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.941 [0.7108684826869764, 1.0889498233448165] | inconclusive-noisy |
