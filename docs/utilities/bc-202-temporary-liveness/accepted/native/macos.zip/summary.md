# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.967 [0.8271240009067284, 1.6224898724945411] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.970 [0.7960629761284915, 1.0289235909304175] | pass |
| full | aa | `calls_200000` | 0.916 [0.8957519651005373, 0.9716234225139353] | pass |
| full | aa | `array_200000` | 1.008 [0.9069066608821507, 1.177279648500477] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 1.034 [0.9809494375382787, 1.1382898909396528] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.853 [0.7818713297780986, 0.9657820897380014] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.975 [0.8912965495311053, 1.2345646052073618] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.008 [0.7826724485219181, 1.1019114824879952] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 0.978 [0.815188270900723, 1.0483746641168632] | pass |
| full | aa | `multiply_100d_x100000` | 0.875 [0.7813431154514775, 0.9881737592061836] | pass |
| full | aa | `multiply_10000d_x1000` | 1.060 [0.975928238243593, 1.091379283388375] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.110 [0.7642177871024628, 1.3646568536080623] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.947 [0.8846126308710589, 0.9871973093419131] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.067 [1.0234194884953993, 1.0927348993608992] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.973403253354416, 1.1113609233752069] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.040 [0.9573390604186569, 1.0843596225412413] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.034 [0.9984994884548066, 1.121424272428643] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 1.025 [0.9352175035347324, 1.1307051102672727] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.970 [0.8883434953346401, 1.5078224172961294] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 0.985 [0.962501974918322, 1.138522058776606] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.965 [0.8975448285273254, 1.1636691129815373] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.986 [0.7772322970827866, 1.2522300116026213] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.994 [0.8328523884685075, 1.2922935912425892] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.875 [0.762332183179751, 1.1922452630184885] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 0.959 [0.5580415997067584, 0.993067764749422] | pass |
| full | aa | `streaming_statements_20000` | 0.979 [0.8964695772717275, 1.0358765347763992] | pass |
| full | aa | `square_100d_x100000` | 0.942 [0.8097863814873892, 1.0574159784794985] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.009 [0.9636540509040746, 1.0824168344954284] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.776 [0.7088108886271434, 1.0408645016802374] | pass |
| full | aa | `binary_output_1000d_x300` | 0.921 [0.765112680393201, 1.150179901677349] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 1.179 [0.8848084043848272, 1.3045153366521964] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 1.002 [0.8904411702711382, 1.1174449745717747] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 1.001 [0.9401266408176464, 1.0788275783617907] | inconclusive-noisy |
| full | aa | `temporary_chain_1000d_x50000` | 0.985 [0.699000874261236, 1.1234065363761623] | inconclusive-noisy |
| full | paired | `startup` | 0.996 [0.7048970032742494, 1.196553558813544] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.979 [0.8752466049423889, 1.08278747832396] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.006 [0.7860701213567608, 1.2207022837620767] | inconclusive-noisy |
| full | paired | `array_200000` | 0.956 [0.7800132561153663, 1.058792569127609] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.013 [0.9486588075472048, 1.0582342974904004] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.096 [0.9597342230984696, 1.1897189908147292] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.042 [0.9898976148401687, 1.1051249422271208] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.035 [0.7725954047451259, 1.319947411796155] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.960 [0.9405324336485946, 1.0647973199008354] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.041 [0.8853617563567534, 1.1881712689455026] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.990 [0.881386078616164, 1.0798186247307309] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.949 [0.9005257849311911, 1.0127502684629595] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.942 [0.8650943477237361, 1.065821837267962] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.004 [0.8593210962629552, 1.1475356813902875] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.011 [0.8736511216075215, 1.126228496469962] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.009 [0.969923296068102, 1.040636765124093] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.029 [0.7572184693254095, 1.2577632502596248] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.055 [0.8847993234281448, 1.3308265196465743] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.994 [0.923961156905391, 1.1118242928670337] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.011 [0.7258629872758421, 1.0157852244702326] | pass |
| full | paired | `recursion_50_x1000` | 0.905 [0.5920615938279108, 1.2413075112658718] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.025 [0.9411660722175806, 1.1561498656714895] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.006 [0.9398020370909319, 1.2379327434712695] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.032 [0.7944953877312637, 1.242367721203017] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.188 [0.9782939250433149, 1.767162797180022] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.090 [0.7819947831568599, 1.2919792568992865] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.031 [0.8535204420103765, 1.2635491208378637] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.991 [0.8153775798074847, 1.1204130729349018] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 1.037 [0.8108179187321802, 1.2898510353084258] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.988 [0.7352456324968328, 1.5852185066970783] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.859 [0.7220086532980234, 1.1161320005025397] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.984 [0.9158861937693545, 1.2773637862245433] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.991 [0.9014255508805533, 1.0760754052606614] | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 0.800 [0.7321685934917985, 0.8564688976313273] | pass |
