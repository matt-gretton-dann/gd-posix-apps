# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.128 [0.7671498831550495, 1.3200492618284279] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.993 [0.9853280274391436, 1.0140110615093583] | pass |
| full | aa | `calls_200000` | 1.000 [0.9898934670080809, 1.0132098415765498] | pass |
| full | aa | `array_200000` | 1.003 [0.9881273187300346, 1.0131259877105343] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.002 [0.976600308096541, 1.0149753816119185] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.994 [0.9817474306783113, 1.013214913034369] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.988 [0.9626655908505686, 0.9999483641526338] | pass |
| full | aa | `fibonacci_1000_x100` | 1.012 [0.9890827624410162, 1.0275788746875179] | pass |
| full | aa | `factorial_1000_x50` | 1.002 [0.9979650688553375, 1.019181719351478] | pass |
| full | aa | `multiply_100d_x100000` | 1.007 [0.9925184776522761, 1.0241530306133426] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9776155561082587, 1.0701365353350865] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 0.999 [0.9822279781907787, 1.0070974353176398] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.003 [0.9985884170756822, 1.0062767245328081] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.9968508189723778, 1.0033657010007715] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9898617736598945, 1.005137496989303] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9939754019307624, 1.0036489471993175] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.008 [0.9887293454753935, 1.0329114910678074] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.002 [0.9934723652391054, 1.0100143397736665] | pass |
| full | aa | `power_100d_e17_x1000` | 0.998 [0.9969839211714959, 1.0141865091752003] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.009 [0.9846102730300819, 1.0250802722229937] | pass |
| full | aa | `recursion_50_x1000` | 1.003 [0.9954169794420347, 1.0173440756160714] | pass |
| full | aa | `sparse_array_200000` | 0.996 [0.9788866079693647, 1.020364863512726] | pass |
| full | aa | `frontend_definitions_2000` | 1.003 [0.9861226192483473, 1.0160600628891676] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.014 [0.9889393357406125, 1.0165955207553024] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.917 [0.8291972920215723, 1.1911523073321728] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.004 [0.9934389840115646, 1.0128816657529107] | pass |
| full | aa | `square_100d_x100000` | 1.000 [0.9886856592369531, 1.018680121873614] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9985553943468726, 1.0047680652731568] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.890 [0.8290626553982113, 1.107582188566871] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.027 [0.9875531422708304, 1.0567354306125165] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 1.007 [0.999653479191229, 1.0174812244323241] | pass |
| full | aa | `binary_input_100000d_x3` | 1.011 [0.9902614706841274, 1.020104288609754] | pass |
| full | aa | `hex_input_100000d_x3` | 1.002 [0.9956729066691418, 1.0039553913626602] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.007 [0.9917773992312005, 1.0138143142769402] | pass |
| full | paired | `startup` | 1.126 [0.8279664307524781, 1.305818087289187] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.962 [0.9447261370015979, 0.9925941296351936] | pass |
| full | paired | `calls_200000` | 0.968 [0.9350727224368026, 0.9983674198874051] | pass |
| full | paired | `array_200000` | 0.982 [0.9789777274566709, 0.995548811524228] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.955 [0.950083389645077, 0.9889166666957023] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.974 [0.9541901855106655, 1.003968258989167] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.976 [0.9518660203689414, 0.9831927067677306] | pass |
| full | paired | `fibonacci_1000_x100` | 0.981 [0.9683274967069799, 1.004402220244246] | pass |
| full | paired | `factorial_1000_x50` | 0.976 [0.9702188870821233, 0.9856364760375086] | pass |
| full | paired | `multiply_100d_x100000` | 0.960 [0.9530638077491892, 0.9711436413528075] | pass |
| full | paired | `multiply_10000d_x1000` | 1.000 [0.9986490830598052, 1.0053228269718961] | pass |
| full | paired | `divide_scale100_x100000` | 0.966 [0.9438625729463883, 0.974564153066733] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.996 [0.9899015608958937, 1.0012882143694999] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.004 [1.0016814518189885, 1.0098825146857302] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.995 [0.9906909556263557, 1.02407046199935] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.011 [1.0079457183381886, 1.018220624250173] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.007 [0.9797666616709073, 1.0135200943895004] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.000 [0.9862549314088473, 1.0054119365298186] | pass |
| full | paired | `power_100d_e17_x1000` | 0.995 [0.9864862809777469, 1.0125123583343738] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.978 [0.9577462076172127, 1.0115917516451833] | pass |
| full | paired | `recursion_50_x1000` | 0.949 [0.9306224947927764, 0.9660251323246226] | pass |
| full | paired | `sparse_array_200000` | 0.947 [0.9136003356475813, 0.9514698008720208] | pass |
| full | paired | `frontend_definitions_2000` | 1.046 [1.0336452819782243, 1.0571238836219858] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.019 [0.9327355200519244, 1.0434758776157713] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.003 [0.8961958285396535, 1.0631658760018612] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.020 [1.0038427286412541, 1.0233216490184267] | pass |
| full | paired | `square_100d_x100000` | 0.966 [0.9481841692341558, 0.9691282106831438] | pass |
| full | paired | `square_10000d_x500` | 1.003 [1.0024424048347065, 1.0035226982945378] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.927 [0.8590222716984984, 1.1010383223620483] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.011 [0.9544939398012321, 1.0304805573405376] | pass |
| full | paired | `octal_output_1000d_x300` | 1.004 [0.9924453938878374, 1.0193603227492845] | pass |
| full | paired | `binary_input_100000d_x3` | 1.010 [0.9954298864120494, 1.0145428855615088] | pass |
| full | paired | `hex_input_100000d_x3` | 1.001 [0.991419041041102, 1.0136848412955601] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.906 [0.9006106823051415, 0.9135973786910894] | pass |
