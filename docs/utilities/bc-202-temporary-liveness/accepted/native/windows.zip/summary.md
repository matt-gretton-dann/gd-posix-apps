# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.004 [0.9599513085864142, 1.0423517687966868] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.981 [0.9735846751053346, 1.0200246582087766] | pass |
| full | aa | `calls_200000` | 1.021 [1.0133057519243904, 1.0922027572479642] | inconclusive-noisy |
| full | aa | `array_200000` | 0.992 [0.9867441705254112, 1.058553465816099] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.997 [0.9962168954494494, 1.0085569057892334] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.992 [0.9618074536861615, 0.9993302425266211] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.998 [0.9740163565897074, 1.0115854388675667] | pass |
| full | aa | `fibonacci_1000_x100` | 1.000 [0.890735495876413, 1.0056703555782203] | pass |
| full | aa | `factorial_1000_x50` | 1.000 [0.9936117356701317, 1.0039752422237278] | pass |
| full | aa | `multiply_100d_x100000` | 1.007 [0.9869393643538211, 1.019266149508494] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9853610665089525, 1.0012576533222628] | pass |
| full | aa | `divide_scale100_x100000` | 0.989 [0.9802912952987061, 0.9948246642070044] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.9957743873842902, 1.007139607747634] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.007 [0.9997779830891759, 1.0161128513600852] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9931039723389753, 1.2404838823742197] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.9809360187423077, 1.0296562433839067] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.009 [0.9856394161097106, 1.0294856621773554] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.003 [0.9423479286365081, 1.0163501416058924] | pass |
| full | aa | `power_100d_e17_x1000` | 0.990 [0.9626800242220179, 1.0105835727117922] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.000 [0.9851615549029648, 1.0408643210545678] | pass |
| full | aa | `recursion_50_x1000` | 1.008 [0.9971575117152608, 1.0171245412226784] | pass |
| full | aa | `sparse_array_200000` | 0.992 [0.9547066841230927, 1.0044065525136787] | pass |
| full | aa | `frontend_definitions_2000` | 1.002 [0.9853839633530194, 1.0295399391824593] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.997 [0.9456186299159557, 1.0143401957569622] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.967 [0.9174716486813317, 0.9974607345161299] | pass |
| full | aa | `streaming_statements_20000` | 0.996 [0.9681282709884163, 1.0190401709430392] | pass |
| full | aa | `square_100d_x100000` | 1.017 [1.0066587688522375, 1.0192947187171153] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9973355697745543, 1.0068941783050682] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.993 [0.9798072011749059, 1.0283117562294337] | pass |
| full | aa | `binary_output_1000d_x300` | 0.978 [0.9745257733747993, 1.0084858289179948] | pass |
| full | aa | `octal_output_1000d_x300` | 1.001 [0.9923401834023102, 1.023157592053895] | pass |
| full | aa | `binary_input_100000d_x3` | 0.993 [0.9906459671269613, 1.0060971492178603] | pass |
| full | aa | `hex_input_100000d_x3` | 0.995 [0.9796689762021162, 1.015233997306453] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.008 [0.9973822570974238, 1.0292302274791914] | pass |
| full | paired | `startup` | 1.002 [1.000926829282591, 1.072015123781125] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.968 [0.9372847358908123, 0.9727244176340407] | pass |
| full | paired | `calls_200000` | 1.001 [0.9189903548659009, 1.0104069939349776] | pass |
| full | paired | `array_200000` | 0.972 [0.9383439115406413, 0.9842610336204494] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.006 [0.9595413850334769, 1.0209765453798665] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.944 [0.9396462376169156, 0.9623719997834147] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.936 [0.9274075503144331, 0.9459299859580397] | pass |
| full | paired | `fibonacci_1000_x100` | 0.971 [0.8355380378256942, 0.9757837497334743] | pass |
| full | paired | `factorial_1000_x50` | 0.988 [0.9707246159668694, 0.9945340181858998] | pass |
| full | paired | `multiply_100d_x100000` | 0.969 [0.9494039600643843, 0.981859549284969] | pass |
| full | paired | `multiply_10000d_x1000` | 1.007 [1.0013174775571347, 1.0167618566692087] | pass |
| full | paired | `divide_scale100_x100000` | 0.960 [0.9520580274268065, 0.9720476267986556] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.995 [0.9922151517963099, 1.0071636466194003] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.008 [0.9991572230820343, 1.0269649912451506] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.007 [0.9753611777500193, 1.165047621536762] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.999 [0.9952569415040107, 1.0055625803203696] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.000 [0.9014199542265943, 1.0357353809796552] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.007 [0.992728850069366, 1.0604360755758684] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.014 [0.9994801044058819, 1.0225144079719866] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.990 [0.9717918188268482, 1.0137505022415776] | pass |
| full | paired | `recursion_50_x1000` | 0.987 [0.9812560395888255, 1.0003555507636732] | pass |
| full | paired | `sparse_array_200000` | 0.970 [0.9605410260210616, 0.9829842487994113] | pass |
| full | paired | `frontend_definitions_2000` | 0.972 [0.9484037723683378, 0.9789099222022711] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.973 [0.9568346779150442, 1.029416003977898] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.977 [0.9680233124834688, 1.0335584222921408] | pass |
| full | paired | `streaming_statements_20000` | 0.998 [0.939772653706098, 1.0224058511523932] | pass |
| full | paired | `square_100d_x100000` | 0.984 [0.9015953605023147, 1.0480748120695238] | pass |
| full | paired | `square_10000d_x500` | 1.007 [1.0049169851188768, 1.0125699968254604] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.976 [0.9644241147032538, 1.0179529052432243] | pass |
| full | paired | `binary_output_1000d_x300` | 1.000 [0.964693003090145, 1.031864466918191] | pass |
| full | paired | `octal_output_1000d_x300` | 0.995 [0.9633882130374212, 1.0239793668949249] | pass |
| full | paired | `binary_input_100000d_x3` | 0.987 [0.9775182803399546, 0.9977322622540366] | pass |
| full | paired | `hex_input_100000d_x3` | 0.997 [0.9691678101335115, 1.0064506268636655] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.848 [0.8432411753058107, 0.8513986635949194] | pass |
