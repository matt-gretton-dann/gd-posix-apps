# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.225 [0.8287182060967301, 1.2592653936319327] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.004 [0.9628344284806227, 1.017764364716119] | pass |
| full | aa | `calls_200000` | 1.083 [1.0451005947088525, 1.1239454729650749] | inconclusive-noisy |
| full | aa | `array_200000` | 0.997 [0.9864575193544555, 1.0037719921496773] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.003 [0.9846841723335494, 1.00945160504719] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.008 [0.9997659654727838, 1.0458457523469753] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.002 [1.0001193944209605, 1.011633779221779] | pass |
| full | aa | `fibonacci_1000_x100` | 1.007 [0.9724890806813455, 1.024997638710883] | pass |
| full | aa | `factorial_1000_x50` | 1.001 [0.991853057556475, 1.0108782883254204] | pass |
| full | aa | `multiply_100d_x100000` | 0.982 [0.9691437558481408, 1.0000417766447347] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9962793642304796, 1.0047888405178127] | pass |
| full | aa | `divide_scale100_x100000` | 1.001 [0.9811842960033391, 1.013776512376985] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.9958517361678145, 1.0038816791386367] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [1.0003359834023544, 1.0022837309607495] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.006 [0.9908518554085772, 1.021458710312914] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.002 [1.0001691423243164, 1.027504437997913] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.011 [0.9725012638509967, 1.0304055631625801] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.006 [1.0001550158311836, 1.0126888559458342] | pass |
| full | aa | `power_100d_e17_x1000` | 0.999 [0.9884976989808404, 1.0080399749321225] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.994 [0.982464115811586, 1.0178006551494752] | pass |
| full | aa | `recursion_50_x1000` | 1.025 [1.0098549106375707, 1.0281577583812318] | pass |
| full | aa | `sparse_array_200000` | 0.991 [0.9804073671620696, 1.0062091069614654] | pass |
| full | aa | `frontend_definitions_2000` | 0.985 [0.9804577732185435, 0.9885651392365038] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.015 [0.9902629713854078, 1.0486024392660214] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.965 [0.8328863239110894, 1.1282959472390561] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.999 [0.9842722803241271, 1.0047969335805536] | pass |
| full | aa | `square_100d_x100000` | 0.994 [0.9848666282648241, 1.0178427284023825] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9980544933150551, 1.0006592373896828] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.870 [0.8373235869549529, 1.1353049697965873] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.014 [0.999265460225108, 1.0553684377626114] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 0.996 [0.973767879451158, 1.017744921384917] | pass |
| full | aa | `binary_input_100000d_x3` | 1.006 [0.9964821554294153, 1.013180482855422] | pass |
| full | aa | `hex_input_100000d_x3` | 1.001 [1.0002431518236812, 1.0190021179112119] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.003 [0.9977755943320014, 1.0071088889314126] | pass |
| full | paired | `startup` | 1.132 [0.9937515996684576, 1.182821858709998] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.017 [1.0046691709537385, 1.0405040660882177] | pass |
| full | paired | `calls_200000` | 1.038 [1.0304401286368956, 1.0535717525814983] | inconclusive-noisy |
| full | paired | `array_200000` | 1.006 [0.9816160464461199, 1.0160438277428123] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.009 [0.9889219972817573, 1.0550115122126835] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.012 [1.0071935981223095, 1.0147612693893335] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.003 [0.999588161311719, 1.0195995641164113] | pass |
| full | paired | `fibonacci_1000_x100` | 1.011 [0.996146909559984, 1.0262437418517338] | pass |
| full | paired | `factorial_1000_x50` | 0.998 [0.9871974910809095, 1.0027417449136913] | pass |
| full | paired | `multiply_100d_x100000` | 0.980 [0.9596190740698836, 0.988476275067592] | pass |
| full | paired | `multiply_10000d_x1000` | 1.002 [1.0009763321581084, 1.0062922219177926] | pass |
| full | paired | `divide_scale100_x100000` | 0.982 [0.9660837033795804, 0.9954869324960078] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.007 [0.9921850214310846, 1.0092787539775685] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.005 [0.9968167967473676, 1.0952801541469188] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.012 [1.0095782419310018, 1.0887602873229185] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.019 [1.0126723971353644, 1.0203337927661786] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.9789173899172073, 1.0084030640697637] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.000 [0.9935030216272365, 1.0022280586710672] | pass |
| full | paired | `power_100d_e17_x1000` | 1.003 [0.9913056078190196, 1.0121603944249646] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.994 [0.9752904946076757, 1.010638719442328] | pass |
| full | paired | `recursion_50_x1000` | 1.014 [1.0046342022020034, 1.0184868908887101] | pass |
| full | paired | `sparse_array_200000` | 0.980 [0.9786449996186877, 0.9931420372219262] | pass |
| full | paired | `frontend_definitions_2000` | 1.057 [1.0543369526133188, 1.066915191312341] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.981 [0.9637576216787602, 1.0023900684968208] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.000 [0.8759379222090362, 1.1078942339877658] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.020 [1.006411498215857, 1.030246403898552] | pass |
| full | paired | `square_100d_x100000` | 0.976 [0.9611125329131829, 0.9854449957961913] | pass |
| full | paired | `square_10000d_x500` | 1.004 [1.002683604172644, 1.0047152171595857] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.941 [0.8633249963328312, 1.1797224723326964] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.012 [0.9678515031830467, 1.0370704321522402] | pass |
| full | paired | `octal_output_1000d_x300` | 1.021 [1.0133915687585702, 1.033057500180828] | pass |
| full | paired | `binary_input_100000d_x3` | 0.993 [0.9862654552830512, 1.0076913210936642] | pass |
| full | paired | `hex_input_100000d_x3` | 0.994 [0.9782139826021365, 0.9983042347067412] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.910 [0.9033355798456034, 0.929249268479349] | pass |
