# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.043 [0.9049049354288329, 1.101209420754266] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.004 [1.0002238679840083, 1.0170021189737022] | pass |
| full | aa | `calls_200000` | 0.994 [0.9810808663073357, 1.0035201143228716] | pass |
| full | aa | `array_200000` | 0.998 [0.9810204252976494, 1.0036687162767493] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.004 [0.953016511463353, 1.0126516911965404] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.000 [0.9902331404820596, 1.0122193017693717] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.009 [0.9895583123355733, 1.039242404634922] | pass |
| full | aa | `fibonacci_1000_x100` | 0.992 [0.9806862321977415, 1.0025952143013008] | pass |
| full | aa | `factorial_1000_x50` | 1.000 [0.978264130074643, 1.0028628109565767] | pass |
| full | aa | `multiply_100d_x100000` | 0.996 [0.9733812427275207, 1.007941229444858] | pass |
| full | aa | `multiply_10000d_x1000` | 1.004 [0.9720419459543319, 1.0094252607055396] | pass |
| full | aa | `divide_scale100_x100000` | 0.996 [0.959679180247574, 1.0341799227184711] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.988 [0.9784496306103111, 1.0017073384064323] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.997 [0.9684214141796014, 1.005637520034665] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9782072329255792, 1.0123615217746178] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9894839660350968, 1.0254279882010153] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.005 [0.9718263376311597, 1.0301838992958032] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.001 [0.9954489764591526, 1.004851617897399] | pass |
| full | aa | `power_100d_e17_x1000` | 0.994 [0.9781432927527864, 1.010697314924194] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.981 [0.9632640833794417, 1.043411473986531] | pass |
| full | aa | `recursion_50_x1000` | 0.997 [0.9727133739605015, 1.1576147984174354] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.001 [0.9134944536083782, 1.0180268615621835] | pass |
| full | aa | `frontend_definitions_2000` | 1.006 [0.9947954366032943, 1.0274036542718434] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.011 [0.9764873487058662, 1.0321495553234592] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.970 [0.9213280261416277, 1.0271222951140018] | pass |
| full | aa | `streaming_statements_20000` | 0.995 [0.9855419073867726, 1.0232522961637212] | pass |
| full | aa | `square_100d_x100000` | 1.005 [0.9841074928140242, 1.036497507144588] | pass |
| full | aa | `square_10000d_x500` | 1.005 [0.9971192453633552, 1.0137372709004446] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.963 [0.8791261625352771, 1.0285977121905594] | pass |
| full | aa | `binary_output_1000d_x300` | 0.993 [0.9770469569361969, 1.030412025511778] | pass |
| full | aa | `octal_output_1000d_x300` | 1.005 [0.9848124660534567, 1.014911411906315] | pass |
| full | aa | `binary_input_100000d_x3` | 0.996 [0.9783538122303592, 1.0032552255454106] | pass |
| full | aa | `hex_input_100000d_x3` | 0.994 [0.9674551080010406, 1.0284235870417793] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.000 [0.9861531872742836, 1.0146854342752432] | pass |
| full | paired | `startup` | 0.988 [0.9384768577002163, 1.1088929965117817] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.026 [1.0050628128085548, 1.0596861801514132] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.083 [1.0492747028240774, 1.1661421292704137] | inconclusive-noisy |
| full | paired | `array_200000` | 1.021 [0.9621399591322523, 1.067482428347769] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.990 [0.9711377786275766, 1.006817444717427] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.921 [0.908555027616097, 0.9406710612151975] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.944 [0.8791485214999658, 0.9655127606033072] | pass |
| full | paired | `fibonacci_1000_x100` | 0.983 [0.9492137087136958, 0.9901634756055514] | pass |
| full | paired | `factorial_1000_x50` | 1.001 [0.9943200784712852, 1.01676705701994] | pass |
| full | paired | `multiply_100d_x100000` | 0.993 [0.9704025110784775, 1.0008581599550468] | pass |
| full | paired | `multiply_10000d_x1000` | 1.003 [0.9954231809376756, 1.0098205911989693] | pass |
| full | paired | `divide_scale100_x100000` | 1.021 [0.9693171434796524, 1.048316678188818] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.002 [0.9937712021681697, 1.0180954821016337] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.006 [0.9885430165748811, 1.0146612302205598] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.014 [0.9917302600308063, 1.0494521070182432] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.001 [0.9825205427894176, 1.0121531811576516] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.998 [0.983459248705607, 1.0102208531800445] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.004 [0.9935447670916091, 1.0095662915537194] | pass |
| full | paired | `power_100d_e17_x1000` | 1.004 [0.9873568130907092, 1.0171646563332946] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.021 [1.0091774185718363, 1.0664583924989182] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.022 [1.0070999542316803, 1.0555211385509626] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.017 [0.9840441417405131, 1.0215258252075328] | pass |
| full | paired | `frontend_definitions_2000` | 0.963 [0.9502757554701549, 0.9795464693885413] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.014 [0.9883657130060735, 1.033102763732303] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.986 [0.9445934639291447, 0.9908343532200978] | pass |
| full | paired | `streaming_statements_20000` | 1.004 [0.9954923423825902, 1.0350735638793138] | pass |
| full | paired | `square_100d_x100000` | 0.998 [0.9733534351875468, 1.014279584030829] | pass |
| full | paired | `square_10000d_x500` | 1.003 [0.9765605348193408, 1.007266209455413] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.964 [0.9244509168803327, 1.044520774153881] | pass |
| full | paired | `binary_output_1000d_x300` | 1.007 [0.9796819161974042, 1.044587639780007] | pass |
| full | paired | `octal_output_1000d_x300` | 0.993 [0.975828248810322, 1.0378050011339064] | pass |
| full | paired | `binary_input_100000d_x3` | 1.010 [0.9856821058330191, 1.0206426750067423] | pass |
| full | paired | `hex_input_100000d_x3` | 1.008 [0.9876020264563514, 1.0266166576191151] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.842 [0.8228569998776982, 0.8468242167106497] | pass |
