# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.038 [0.7294078356305648, 1.4272164820603992] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.981 [0.9335914742275423, 1.0948258524222636] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.921 [0.8263029311807846, 1.1058904126837372] | inconclusive-noisy |
| full | aa | `array_200000` | 0.918 [0.817536784016605, 1.0596699234139237] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.934 [0.8719979943933241, 1.0709196811637256] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.023 [0.9954494104642234, 1.1322400867604137] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.999 [0.7551400980895522, 1.1603520784054275] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.001 [0.7191980280357096, 1.125819017148772] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 0.961 [0.7534299082676496, 1.1329020146507394] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.960 [0.9055882951019212, 1.0231069278348124] | pass |
| full | aa | `multiply_10000d_x1000` | 0.985 [0.918467701785635, 1.0205678164700362] | pass |
| full | aa | `divide_scale100_x100000` | 1.105 [0.8148635819331297, 1.1925031170479428] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.023 [0.8935487724552074, 1.1702877941775425] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.006 [0.9281070248631472, 1.0352046085689215] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.978 [0.8422027727721899, 1.0900429093733222] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.053 [0.97425714775522, 1.202953751832956] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.038 [0.8636206185618752, 1.1115800335385093] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.922 [0.7751767908647311, 1.1394082145140203] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.017 [1.0129293519774252, 1.288833100104376] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 0.992 [0.7413223838228397, 1.2493863598490742] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.996 [0.8760347687346912, 1.2340639894277068] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.998 [0.8624284156925208, 1.2707397750452396] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.990 [0.9572699725009786, 1.231100141055627] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.994 [0.7080141937056067, 1.171097484808955] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 0.997 [0.8046723937893218, 1.334284702593875] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.985 [0.9034377505587411, 1.0670147954743223] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.021 [0.8426403231632963, 1.1678918783082333] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.924 [0.8448115150359811, 0.9964928132947106] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.925 [0.7543939516767919, 1.0220266710375043] | pass |
| full | aa | `binary_output_1000d_x300` | 1.116 [0.9344975783298679, 1.3446946065624779] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 1.049 [0.9406997895634676, 1.1509525305444124] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 0.999 [0.9182244940174332, 1.0567972198276752] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 1.002 [0.9037627664858584, 1.0858289883994756] | inconclusive-noisy |
| full | aa | `temporary_chain_1000d_x50000` | 1.013 [0.9316360184672529, 1.0954433460361421] | inconclusive-noisy |
| full | paired | `startup` | 0.916 [0.7373425193360044, 1.2514329735942469] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.000 [0.8352729348330512, 1.1533090898896636] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.903 [0.8037390452408583, 1.0725747978192066] | inconclusive-noisy |
| full | paired | `array_200000` | 0.953 [0.9237915506935641, 1.1112199451082194] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.042 [0.8117410711063885, 1.3826830033146524] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.976 [0.812139302955313, 1.2389389044837908] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.025 [0.903929265974638, 1.157811834578607] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.988 [0.7679394552036528, 1.0474663831949942] | pass |
| full | paired | `factorial_1000_x50` | 1.094 [0.9387661865025768, 1.2241695794366478] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.936 [0.8720232327206885, 1.1926077805291913] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.967 [0.8803705865676745, 1.0334555745380944] | pass |
| full | paired | `divide_scale100_x100000` | 0.972 [0.9319007072878867, 1.2863097721516281] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.998 [0.8169114598008466, 1.1809599775272641] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.983 [0.8921825745318757, 1.1165708443657343] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.978 [0.8028331818861084, 1.206624282999191] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.096 [0.8972962041716062, 1.2260163619925748] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.034 [0.7302039782165171, 1.1381868616390902] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.001 [0.9355843186202747, 1.271499080211715] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.031 [0.8611307676760644, 1.3983428525699841] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.073 [0.8950725996283098, 1.2426972229688071] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.879 [0.764364466947549, 1.0469712803746756] | pass |
| full | paired | `sparse_array_200000` | 0.982 [0.766634552947647, 1.0715201892065505] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.138 [0.7349733675492945, 1.513020396948646] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.055 [0.9332729187984792, 1.1513203224295032] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.110 [0.8527381920650826, 1.17097331530968] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.060 [0.8596137311460885, 1.23858539730176] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.018 [0.9357845482820044, 1.2729440308026088] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.995 [0.9660617225816992, 1.1485040579462178] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 1.238 [0.9948894074504271, 1.4977925345755367] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.021 [0.8960655782115964, 1.2798182785375907] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.063 [0.9101374062080282, 1.2927482006223538] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.966 [0.8937973462556832, 1.4020123227727426] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 1.026 [0.8255536688202911, 1.1239919214014202] | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 0.892 [0.7811667987677327, 1.0192809140639665] | pass |
