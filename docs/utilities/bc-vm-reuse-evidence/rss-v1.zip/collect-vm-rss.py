#!/usr/bin/env python3
"""Keep whole-process RSS distinct from native acceptance timing."""
import hashlib, importlib.util, json, os, platform, re, shutil, subprocess
from pathlib import Path
SOURCE=Path('/private/tmp/gd-posix-vm-divisor-reuse')
OUT=Path('/private/tmp/bc-423-vm-rss-v1')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def load(name):
    spec=importlib.util.spec_from_file_location(name.replace('-','_'),SOURCE/'src/bc/scripts'/ (name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def save(path,value): path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def main():
    OUT.mkdir(exist_ok=False)
    revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=str(SOURCE),universal_newlines=True).strip()
    subprocess.run(['git','diff','--quiet','HEAD'],cwd=str(SOURCE),check=True)
    builder=load('build-gd-bc');helper=builder.helpers();bench=load('bench-bc')
    runner=helper.Builder(OUT,120)
    cc=builder.compiler_identity(helper,runner,'cc');cxx=builder.compiler_identity(helper,runner,'c++')
    roles=[]
    env={k:v for k,v in os.environ.items() if not k.startswith(('BC_','DC_','GD_BC_PROFILE_'))}
    env['LC_ALL']='C'
    for mode in ('off','on'):
        destination=OUT/mode;destination.mkdir()
        build=SOURCE/('build-reuse-cost-'+mode)
        metadata=builder.build_metadata(helper,destination,SOURCE,build,revision,126,cc,cxx,prepared_mode=mode.upper())
        shutil.copy2(build/'CMakeCache.txt',destination/'CMakeCache.txt')
        binary=destination/'bc';shutil.copy2(build/'src/bc/bc',binary)
        metadata['binary_sha256']=sha(binary)
        save(destination/'metadata.json',metadata)
        for phase in ('configure','build'):
            shutil.copy2(Path('/private/tmp')/('bc-423-cost-'+mode+'-'+phase+'.log'),destination/(phase+'.log'))
        check=subprocess.run(['python3',str(SOURCE/'src/bc/test-divisor-reuse-cli.py'),str(binary)],
                             stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=60)
        (destination/'guard.stdout').write_bytes(check.stdout);(destination/'guard.stderr').write_bytes(check.stderr)
        assert check.returncode==0,(mode,check.stderr)
        roles.append(dict(name=mode,argv=[str(binary)],metadata=metadata))
    snapshot=subprocess.check_output(['git','archive','--format=tar','HEAD','src','libgdsup','cmake','CMakeLists.txt'],cwd=str(SOURCE))
    (OUT/'source.tar').write_bytes(snapshot)
    fixtures=[]
    groups={'divide_multilimb','modulo','modulo_scaled_numerator','modulo_scaled_divisor'}
    for preset,seed in (('full',197200),('holdout',197201)):
        for case in bench.corpus(preset,seed=seed):
            if case['group'] in groups or case['group'].startswith('divisor_'):
                case['preset']=preset;fixtures.append(case)
    manifest=dict(schema=1,source_revision=revision,platform=platform.platform(),roles=roles,
                  fixtures=fixtures,adoption_accepted=False,observations=[],
                  protocol='Three fixed RSS samples; alternate OFF/ON order by trial; builds and guards completed before all measurements',
                  limitations=['Unisolated local host; process RSS includes startup, parsing and output',
                               'Raw time fields are retained resource outputs, not native timing samples',
                               'Same-source mode comparison, not an immutable-main baseline comparison'])
    for case in fixtures:
        folder=OUT/'samples'/case['name'];folder.mkdir(parents=True)
        (folder/'input.bc').write_text(case['program'])
        for trial in range(3):
            for role in (roles if trial%2==0 else list(reversed(roles))):
                stem=folder/('{}-{}'.format(trial,role['name']))
                resource=Path(str(stem)+'.resource')
                argv=['/usr/bin/time','-l','-o',str(resource),role['argv'][0]]
                child=subprocess.run(argv,input=case['program'].encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=60)
                Path(str(stem)+'.stdout').write_bytes(child.stdout);Path(str(stem)+'.stderr').write_bytes(child.stderr)
                assert child.returncode==0 and child.stderr==b'',(case['name'],role['name'],child.stderr)
                assert bench.canonical_output(child.stdout)==bench.canonical_output(('\n'.join(case['expected'])+'\n').encode()),case['name']
                match=re.search(r'^\s*(\d+)\s+maximum resident set size\s*$',resource.read_text(),re.M);assert match
                manifest['observations'].append(dict(case=case['name'],preset=case['preset'],mode=role['name'],trial=trial,
                    rss_bytes=int(match.group(1)),returncode=child.returncode,checked=True,
                    stdout=str(Path(str(stem)+'.stdout').relative_to(OUT)),stderr=str(Path(str(stem)+'.stderr').relative_to(OUT)),
                    resource=str(resource.relative_to(OUT)),argv=argv))
    load('collect-bc-codegen').collect(roles,OUT/'codegen')
    shutil.copy2(__file__,OUT/'collect-vm-rss.py')
    for name in ('bench-bc','build-gd-bc','collect-bc-codegen'):
        shutil.copy2(SOURCE/'src/bc/scripts'/(name+'.py'),OUT/(name+'.py'))
    manifest['files']={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()}
    save(OUT/'manifest.json',manifest)
    print(json.dumps(dict(checked=len(manifest['observations']),fixtures=len(fixtures),manifest_sha256=sha(OUT/'manifest.json'))))
if __name__=='__main__': main()
