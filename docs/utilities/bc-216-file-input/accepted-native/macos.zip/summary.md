# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.862 [0.7693733042151125, 1.6530116571229718] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.927 [0.8644669399422927, 1.044717728582987] | pass |
| full | aa | `calls_200000` | 1.113 [0.9271850900839637, 1.1765295992376914] | inconclusive-noisy |
| full | aa | `array_200000` | 1.057 [0.9854019143295851, 1.1370181429197623] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 1.079 [0.9190943196682418, 1.2521881522724856] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.914 [0.7866168594064806, 1.039119445899025] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.015 [0.8849357984362066, 1.0813807095001085] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.863 [0.643381353895859, 1.0904115759790076] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.071 [0.8589774444775365, 1.2607997144294516] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.033 [0.9607505953455175, 1.2642987719464314] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.039 [0.9528160798963634, 1.1307561068161678] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.023 [0.7959619658938446, 1.2807675963148126] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.038 [0.8502395457255355, 1.172233771575392] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.066 [0.9707845975089111, 1.1609285635862039] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.985 [0.9520670356052326, 1.1782188125419655] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.032 [0.9841654636812258, 1.11509274420497] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.039 [0.766263075690131, 3.0586800839496138] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.919 [0.8874882184594042, 1.0099862887024391] | pass |
| full | aa | `power_100d_e17_x1000` | 0.999 [0.8429929303179212, 1.1007898477476616] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 1.071 [0.7963268395389591, 1.263110190666589] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.879 [0.8303979884656839, 1.316874576986286] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.037 [0.8738839139663197, 1.235721496688045] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.990 [0.8824167082354986, 1.137355103915393] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.973 [0.8872777708805695, 1.036438262614083] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.945 [0.8032168447497829, 1.5863891608649352] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.944 [0.8948342064294517, 1.2477402680573737] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.056 [0.9712639680574003, 1.147356179614167] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.985 [0.9645508547987922, 1.0629528928958234] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 1.067 [0.7807466483720314, 1.5243398511940929] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.100 [0.739031784242355, 1.4464226196888412] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 1.090 [0.9611414421743015, 1.1679559352472475] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 1.074 [0.8852278425114071, 1.1898713385046096] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 0.980 [0.8941909928267682, 1.1228999031184872] | inconclusive-noisy |
| full | aa | `temporary_chain_1000d_x50000` | 1.075 [0.9901827278118949, 1.1673624762334023] | inconclusive-noisy |
| full | aa | `file_statements_20000` | 0.842 [0.8163801025933273, 0.9799524871007491] | pass |
| full | paired | `startup` | 1.080 [0.6505734223674686, 1.4725077909298718] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.001 [0.8869012428434228, 1.121475608184353] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.010 [0.6555497037363934, 1.138393560831367] | inconclusive-noisy |
| full | paired | `array_200000` | 1.042 [0.9906499675720024, 1.2697105333951335] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.152 [1.04047522245573, 1.406066784253595] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.055 [0.912757122181851, 1.1886456035586095] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.874 [0.8076279553434343, 1.0357197447802755] | pass |
| full | paired | `fibonacci_1000_x100` | 0.802 [0.643586135484368, 1.127599211255205] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.042 [0.907992436423157, 1.1083005496623037] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.001 [0.817642844797236, 1.3046937076308998] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.940 [0.8429899338411788, 1.0109824057983794] | pass |
| full | paired | `divide_scale100_x100000` | 0.898 [0.778228345608665, 1.2465606914059493] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.087 [0.8723504282083696, 1.2511089910614919] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.952 [0.7891062173419768, 1.206796329103558] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.961 [0.9221919783619021, 1.125844568781699] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.959 [0.8747844827366575, 1.2082970675802729] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.776 [0.45276229907332227, 1.2777437897469266] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.053 [0.8246928644495238, 1.165519974471231] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.011 [0.874692740032755, 1.1513832580928445] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.012 [0.7734336825558163, 1.2381766994436094] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.059 [0.6966287142100275, 1.2013395001382516] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.970 [0.8653534250408992, 1.0450071802546919] | pass |
| full | paired | `frontend_definitions_2000` | 0.979 [0.820269125334784, 1.3286793370961107] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.901 [0.7612452607449083, 1.194863104024122] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.049 [0.8174255398054509, 1.2300252983081759] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.080 [0.8758056995537719, 1.2074876315791496] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.958 [0.9074406676855125, 1.0714427654907994] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.040 [0.8769168196565282, 1.1844140360412587] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.972 [0.8614379823554178, 1.2807039599202044] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.234 [0.8889343450942095, 1.359100854053144] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.893 [0.748501629079911, 1.1092126994265492] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.162 [0.8244668665211162, 1.5081827130060252] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 1.002 [0.8115634962071774, 1.2252257841237284] | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.119 [0.9481740110243896, 1.161237654686799] | inconclusive-noisy |
| full | paired | `file_statements_20000` | 1.038 [0.8688245090200652, 1.3864041769013273] | inconclusive-noisy |
