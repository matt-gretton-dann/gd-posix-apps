# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.916 [0.8286494213605022, 1.203264590326375] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.004 [0.9841639062269506, 1.0144884651815407] | pass |
| full | aa | `calls_200000` | 1.009 [0.9683450151835018, 1.0122898649353065] | pass |
| full | aa | `array_200000` | 0.994 [0.9883602964173989, 1.005177025340963] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.003 [0.9758110665477524, 1.0150233284218513] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.001 [0.9936832042392196, 1.0154916101144005] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.003 [0.9935005614529144, 1.0249202191458275] | pass |
| full | aa | `fibonacci_1000_x100` | 0.992 [0.9859759344836546, 1.0077463684097065] | pass |
| full | aa | `factorial_1000_x50` | 1.008 [0.9979741503214978, 1.0130925693363508] | pass |
| full | aa | `multiply_100d_x100000` | 1.002 [0.9884844036735946, 1.0097944426417356] | pass |
| full | aa | `multiply_10000d_x1000` | 0.999 [0.9964409228784671, 1.0023797322227703] | pass |
| full | aa | `divide_scale100_x100000` | 0.999 [0.9587509692408643, 1.0068433625023554] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.007 [1.0000473077990062, 1.0135207553127403] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9978958106740794, 1.0166601594283273] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9893912345147113, 1.02125514343558] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9803050159065119, 1.009552004186685] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.993 [0.9787220588587712, 1.0190530466967924] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9977706414824902, 1.0033191747757413] | pass |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9966986813413607, 1.0213570321231915] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.000 [0.9902608935894209, 1.0299657696630515] | pass |
| full | aa | `recursion_50_x1000` | 0.993 [0.9631006959484248, 1.0091160931269663] | pass |
| full | aa | `sparse_array_200000` | 1.002 [0.9854895784350954, 1.0187316779835554] | pass |
| full | aa | `frontend_definitions_2000` | 1.012 [1.0039810071296127, 1.0167935097106626] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.999 [0.9964274450352376, 1.0123494653966598] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.989 [0.8917345904999053, 1.0024840903527041] | pass |
| full | aa | `streaming_statements_20000` | 1.010 [1.0015517901043018, 1.0403265063665548] | pass |
| full | aa | `square_100d_x100000` | 0.994 [0.9861913235862425, 1.0025968134183172] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9989039303678307, 1.0020448478966426] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.962 [0.901711219632537, 1.0358830996917197] | pass |
| full | aa | `binary_output_1000d_x300` | 1.004 [0.9962318363596936, 1.0199267114958928] | pass |
| full | aa | `octal_output_1000d_x300` | 0.988 [0.9725539472371243, 1.0090373328499644] | pass |
| full | aa | `binary_input_100000d_x3` | 0.997 [0.9819306678102575, 1.003255786223486] | pass |
| full | aa | `hex_input_100000d_x3` | 0.997 [0.988944913465402, 1.008742902498263] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.000 [0.9901636671172406, 1.0087947655366238] | pass |
| full | aa | `file_statements_20000` | 1.013 [1.003238043780794, 1.0211549517965026] | pass |
| full | paired | `startup` | 0.936 [0.8055319989521424, 1.1169559348849631] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.984 [0.9578955529220858, 0.9975481051643682] | pass |
| full | paired | `calls_200000` | 1.002 [0.9861264793654837, 1.0322903704400799] | pass |
| full | paired | `array_200000` | 0.989 [0.9706036751688912, 1.007841626974421] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.000 [0.9792016029890732, 1.052702368033866] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.999 [0.9922040273814181, 1.0121386127884393] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.996 [0.9891744002990517, 1.0032019524244689] | pass |
| full | paired | `fibonacci_1000_x100` | 0.986 [0.9605088326864374, 1.001504991886827] | pass |
| full | paired | `factorial_1000_x50` | 1.010 [0.9980883566265434, 1.0134877016109372] | pass |
| full | paired | `multiply_100d_x100000` | 1.003 [0.988464250379246, 1.0261165178870588] | pass |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9402954038771222, 1.0018034358413739] | pass |
| full | paired | `divide_scale100_x100000` | 1.000 [0.9947876565779653, 1.036050529228521] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.998 [0.9910525172192735, 1.0012219525119204] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.000 [0.9955825560134317, 1.0029996094371327] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9834281108886851, 1.0088697081070455] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.000 [0.9919254768498599, 1.034996783232677] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.005 [0.9832172876042146, 1.0225475994864588] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.001 [0.9974239718888108, 1.0027011393993077] | pass |
| full | paired | `power_100d_e17_x1000` | 1.002 [0.9991163812833765, 1.008031386582061] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.996 [0.9749870498905261, 1.0114636133625796] | pass |
| full | paired | `recursion_50_x1000` | 0.999 [0.9868855242831884, 1.0081391555157089] | pass |
| full | paired | `sparse_array_200000` | 0.996 [0.9777375323835416, 1.0133366922492915] | pass |
| full | paired | `frontend_definitions_2000` | 0.993 [0.9795211287801919, 1.000643783387411] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.995 [0.9806358414551722, 1.0182565852572731] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.949 [0.9442439115084897, 1.2753807447203998] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.002 [0.9875318821810736, 1.010377488587442] | pass |
| full | paired | `square_100d_x100000` | 1.014 [0.9960689002711132, 1.0197985840303339] | pass |
| full | paired | `square_10000d_x500` | 1.001 [1.0000297389481458, 1.0017801491457896] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.035 [1.013587775373539, 1.1225301096981553] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.016 [0.9514208635747724, 1.036951789599142] | pass |
| full | paired | `octal_output_1000d_x300` | 1.001 [0.9825392233377301, 1.0149717896851276] | pass |
| full | paired | `binary_input_100000d_x3` | 0.996 [0.9775684427012293, 1.0171917888103956] | pass |
| full | paired | `hex_input_100000d_x3` | 1.002 [0.9995662143231039, 1.0269749649173823] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.003 [0.9945093690578597, 1.0105086228836306] | pass |
| full | paired | `file_statements_20000` | 0.997 [0.9722883014739205, 1.009767431861198] | pass |
