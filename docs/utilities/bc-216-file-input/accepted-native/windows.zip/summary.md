# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.957 [0.9280816232659178, 1.071620659078201] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.002 [0.9787440946693355, 1.018000959335124] | pass |
| full | aa | `calls_200000` | 0.994 [0.9852638915974649, 1.0191955810430295] | pass |
| full | aa | `array_200000` | 1.009 [0.9996419395693782, 1.012399856386633] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.996 [0.9739673071081882, 1.0182600518387184] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.994 [0.9491888506499687, 1.0203193698344992] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.985 [0.9766074571538916, 1.0265639217273168] | pass |
| full | aa | `fibonacci_1000_x100` | 0.991 [0.88457369134551, 1.014425141859566] | pass |
| full | aa | `factorial_1000_x50` | 0.999 [0.988021905672694, 1.0102202490351686] | pass |
| full | aa | `multiply_100d_x100000` | 1.004 [0.9944715246149205, 1.0146491052966973] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9977627461706597, 1.0121606200642217] | pass |
| full | aa | `divide_scale100_x100000` | 0.999 [0.9929882855646907, 1.0123328027758791] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.009 [1.001378578861688, 1.0144135195534454] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.995 [0.9675235856964743, 1.0036414652662031] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.994743444832253, 1.009258339257399] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.996 [0.9869921734402118, 1.000857859161427] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.9712178485291645, 1.0449582898849874] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.997 [0.9883309681949244, 1.054883695443423] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.005 [0.8949447181312434, 1.0206059535374692] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.996 [0.985521151708358, 1.0025884044732642] | pass |
| full | aa | `recursion_50_x1000` | 1.002 [0.9915338437513734, 1.012893683514106] | pass |
| full | aa | `sparse_array_200000` | 1.006 [0.9656206752507208, 1.0137733889329723] | pass |
| full | aa | `frontend_definitions_2000` | 0.991 [0.9298396712335221, 1.0600642782435166] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9880890447741426, 1.0191347536252] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.966 [0.9469290033470058, 1.0494810337375642] | pass |
| full | aa | `streaming_statements_20000` | 0.993 [0.9759981181625932, 1.1720963226825638] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.004 [0.9759050106397499, 1.0133627342231843] | pass |
| full | aa | `square_10000d_x500` | 0.997 [0.9929748172408991, 1.0033199788647855] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.972 [0.9439194018658498, 1.0765620709405919] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.982 [0.9568981851702715, 0.9994702442382102] | pass |
| full | aa | `octal_output_1000d_x300` | 1.003 [0.9819889397799705, 1.0307808189042205] | pass |
| full | aa | `binary_input_100000d_x3` | 1.011 [0.9825750351585972, 1.1794260797555862] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 0.995 [0.9883967245467108, 1.0074370063807556] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.002 [0.9686468288446186, 1.0135403905707543] | pass |
| full | aa | `file_statements_20000` | 1.046 [1.006800466359151, 1.169451958784705] | inconclusive-noisy |
| full | paired | `startup` | 0.966 [0.9301169665989274, 1.044440035714406] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.967 [0.9411946249701998, 1.0058012587886405] | pass |
| full | paired | `calls_200000` | 0.993 [0.9281779540405037, 1.002736185110518] | pass |
| full | paired | `array_200000` | 0.989 [0.9853616978396998, 1.003800527896583] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.002 [0.9854275639616304, 1.0240699669444584] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.994 [0.9780017760863317, 1.09240533467946] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.966 [0.9242248882746169, 1.054903524060044] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.993 [0.9771580349886777, 1.0970575983648159] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.995 [0.9914372588542074, 1.023726969085487] | pass |
| full | paired | `multiply_100d_x100000` | 0.994 [0.9910821796227314, 1.0528504985065732] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.995 [0.984622507489664, 1.0061226030314179] | pass |
| full | paired | `divide_scale100_x100000` | 1.012 [0.9590839288461595, 1.0795738881222527] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.999 [0.9909673446043703, 1.012688802293311] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.005 [0.9949207652339741, 1.0350648486385994] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9570175074622036, 1.087683025806725] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.998 [0.9736513478197656, 1.0229383522004085] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.026 [0.9639022329149834, 1.035291912073881] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.003 [0.9881996152201266, 1.0893013051541693] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.999 [0.9729652108328747, 1.0327461397464133] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.003 [0.9709343535664151, 1.0122098754391906] | pass |
| full | paired | `recursion_50_x1000` | 0.999 [0.9735007892368741, 1.016952909496097] | pass |
| full | paired | `sparse_array_200000` | 0.987 [0.9416978989467446, 0.9947686371480005] | pass |
| full | paired | `frontend_definitions_2000` | 0.926 [0.8848525643283079, 1.1178543441176343] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.013 [0.9973614775762564, 1.1113604810625364] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.979 [0.9303996268083538, 1.0562410645606448] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.024 [0.9430310164683176, 1.0719893768546167] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.991 [0.979199025257163, 1.0003561945467554] | pass |
| full | paired | `square_10000d_x500` | 1.000 [0.9793211289999897, 1.0195348517105423] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.028 [0.9545640941526381, 1.0785940932402855] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.995 [0.9734611773364898, 1.0399824845080192] | pass |
| full | paired | `octal_output_1000d_x300` | 1.015 [0.986138994849723, 1.02903123639015] | pass |
| full | paired | `binary_input_100000d_x3` | 1.005 [0.9971083503396839, 1.040534719308715] | pass |
| full | paired | `hex_input_100000d_x3` | 1.002 [0.9963523125071252, 1.015150052809185] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.000 [0.9964255889169199, 1.0262529735326869] | pass |
| full | paired | `file_statements_20000` | 0.987 [0.8712612644205284, 1.0149291518333818] | pass |
