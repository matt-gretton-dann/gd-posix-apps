# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.075 [0.9877840707984735, 1.175629728410046] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.967 [0.9382090393426641, 0.9969616169282538] | pass |
| full | aa | `calls_200000` | 1.012 [0.9590369301854799, 1.0346626856712076] | pass |
| full | aa | `array_200000` | 1.006 [0.9597755927637653, 1.1900207591190137] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 1.025 [1.0008439115316619, 1.1290436104274182] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.003 [0.8510232270663227, 1.0362816832593458] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.986 [0.9371442049238302, 1.1287096296137484] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.982 [0.9332250143334828, 1.0360495858056067] | pass |
| full | aa | `factorial_1000_x50` | 0.994 [0.8679015201305482, 1.0127291702251089] | pass |
| full | aa | `multiply_100d_x100000` | 0.918 [0.8476039241321792, 1.0015506301824055] | pass |
| full | aa | `multiply_10000d_x1000` | 0.958 [0.8573451754253274, 1.0590840908049572] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 0.946 [0.8620660181125653, 1.0990241533227096] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.007 [0.9388650072061794, 1.1499228942963724] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.010 [0.8453944416016477, 1.1168819936931713] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.926 [0.8565037797735945, 1.0031053899828606] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.043 [0.952625821702512, 1.1028061000902236] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.8782847561398405, 1.0256775058502945] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.999 [0.9602190585312166, 1.1579393889076506] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.010 [0.9148398921200493, 1.1018780597509468] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 0.978 [0.9252808205093983, 1.0874285911777408] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 1.020 [0.9407016205158014, 1.1001644158023056] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.002 [0.8950052541546578, 1.0514103055857187] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 1.007 [0.924788174787215, 1.0840988207429376] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.047 [0.9218147591005187, 1.13551911025069] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 0.978 [0.8161914875762146, 1.0757059841921306] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.976 [0.9120132803954092, 1.1328946826074842] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.016 [0.9995238923689737, 1.093295856606164] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.001 [0.9306198361471901, 1.0299880405067947] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.023 [0.8375853566063557, 1.1585657350391505] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.011 [0.9515814578808122, 1.0909075107497672] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 1.027 [0.9991204650712149, 1.1227822409226007] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 0.994 [0.9799108889930344, 1.1479779003340511] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 0.996 [0.963076834595959, 1.032197324356747] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 1.026 [0.9731738746747244, 1.1485055902804762] | inconclusive-noisy |
| full | paired | `startup` | 0.871 [0.6500482766688109, 1.1464111577697307] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.091 [0.963958331272262, 1.1663868430038213] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.924 [0.6727015264984938, 1.1746856155425136] | inconclusive-noisy |
| full | paired | `array_200000` | 0.877 [0.7329055661649512, 1.0652699007760713] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.978 [0.7495040298197122, 1.400919406635342] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.166 [0.968274337546913, 1.3013140561258305] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.039 [0.8958160384319512, 1.0744243816088659] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.119 [0.8715443771444165, 1.431341921867375] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.994 [0.8051457015126744, 1.0981858786140288] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.002 [0.7330013014963559, 1.1555833208005253] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.028 [0.8384514195719935, 1.1502443602470793] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.002 [0.9499525771426971, 1.2266260957462003] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.074 [0.9282785075602694, 1.39128710685246] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.945 [0.8502341012178458, 1.078715764590817] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.103 [0.9427147882825646, 1.221170963800166] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.090 [0.9547867586618106, 1.2564277595561695] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.046 [0.9798297230709343, 1.1490928500293518] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.976 [0.9297308133905123, 1.6978936369953554] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.972 [0.9252171138735648, 1.010711579451814] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.987 [0.8617027357018574, 1.0070522696385031] | pass |
| full | paired | `recursion_50_x1000` | 0.990 [0.8782582589785263, 1.3506754220318316] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.942 [0.8905690982650762, 1.2414942271071734] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.028 [0.8006593728814317, 1.3631355056475272] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.979 [0.8119555907774327, 1.26039231497038] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.059 [0.814811879432746, 1.2880311803459696] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.899 [0.7728593660829527, 1.1021020944035096] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.994 [0.747653518109053, 1.0604012667895617] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.042 [0.9523693648507513, 1.1260933785750686] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.799 [0.5121049493121644, 1.0401444606208887] | pass |
| full | paired | `binary_output_1000d_x300` | 1.170 [0.793452287774096, 1.453273013039974] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.981 [0.8410684250595701, 1.755941428465454] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.090 [0.869848732978979, 1.2365626055549084] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.943 [0.8995699053227152, 1.0876992721285672] | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.040 [0.8795234234879058, 1.2181147613436345] | inconclusive-noisy |
