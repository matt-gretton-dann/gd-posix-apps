# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.228 [0.7098701452730831, 1.3969814914401668] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.007 [0.9827137869225371, 1.0196544109882633] | pass |
| full | aa | `calls_200000` | 1.023 [1.0007431673406553, 1.0737574452971463] | inconclusive-noisy |
| full | aa | `array_200000` | 1.007 [0.9899972620591201, 1.0103005376675611] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.998 [0.9972783169964438, 1.0042861893812751] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.019 [0.9951756344260613, 1.0391876313031907] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.002 [0.9601684681888557, 1.0127773111068865] | pass |
| full | aa | `fibonacci_1000_x100` | 1.004 [0.9893123215905074, 1.0474615342290414] | pass |
| full | aa | `factorial_1000_x50` | 1.004 [0.9944671563577646, 1.0122360232135739] | pass |
| full | aa | `multiply_100d_x100000` | 1.007 [0.9885548227004172, 1.0270463572885158] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9982802377933352, 1.0042241227973474] | pass |
| full | aa | `divide_scale100_x100000` | 0.999 [0.9836347141586848, 1.0055838327719193] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.002 [0.9935342931467285, 1.003589902376277] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9978102892785015, 1.0012560310863723] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.996 [0.9810307706238857, 1.01718121251937] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9979481334380216, 1.002796031069669] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.031 [0.9715831322988543, 1.0346658847075898] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.002 [0.9988732066246752, 1.0121944436288035] | pass |
| full | aa | `power_100d_e17_x1000` | 1.000 [0.9916712539206187, 1.0109600766870503] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.002 [0.9998250424235323, 1.038856437873211] | pass |
| full | aa | `recursion_50_x1000` | 1.005 [0.9905995965635113, 1.0177219419831036] | pass |
| full | aa | `sparse_array_200000` | 1.002 [0.9977182718090174, 1.0077479846568542] | pass |
| full | aa | `frontend_definitions_2000` | 1.007 [0.9874713549989815, 1.015044925344649] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.004 [0.9794180627893114, 1.0306357777091217] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.949 [0.7950402340023704, 1.0889367107824122] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.990 [0.9767780376320534, 1.001966763190357] | pass |
| full | aa | `square_100d_x100000` | 0.996 [0.9827272303113068, 1.0245455098281384] | pass |
| full | aa | `square_10000d_x500` | 0.999 [0.997931974882865, 1.001739974899915] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.888 [0.7784989718147043, 1.1710737560816746] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.008 [0.9774989916516511, 1.0510937165419447] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 0.997 [0.9924035677901727, 1.0281583229879157] | pass |
| full | aa | `binary_input_100000d_x3` | 1.010 [0.9826795246372796, 1.0285911262234098] | pass |
| full | aa | `hex_input_100000d_x3` | 0.995 [0.9898455659183419, 0.9992624636824159] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.999 [0.9911068783882031, 1.0057538243718904] | pass |
| full | paired | `startup` | 1.178 [0.8199269585446471, 1.3712753968768068] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.025 [1.0144050731734047, 1.0376755824000643] | pass |
| full | paired | `calls_200000` | 1.005 [0.9983449752819809, 1.0173661248148542] | pass |
| full | paired | `array_200000` | 1.011 [1.0001852841257524, 1.0221151736046392] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.020 [0.9759909191574776, 1.0321916135990568] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.063 [1.0337712672195145, 1.0696430217992325] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.027 [0.9682731508143667, 1.0331529987249695] | pass |
| full | paired | `fibonacci_1000_x100` | 1.025 [1.0152067275640986, 1.042008578532331] | pass |
| full | paired | `factorial_1000_x50` | 1.016 [1.0003084499370196, 1.0162911650883744] | pass |
| full | paired | `multiply_100d_x100000` | 1.043 [1.0229708137762097, 1.053737347044007] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.003 [1.0006235295771262, 1.00583532383884] | pass |
| full | paired | `divide_scale100_x100000` | 1.044 [1.0378641284350107, 1.0560556659842653] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.000 [0.9935495664788866, 1.0066933418981991] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.002 [1.000559764060909, 1.0031461511246131] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9931099188273701, 1.0172394354450243] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.014 [1.0129871454292, 1.0172675024797915] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.000 [0.970953922550088, 1.0244676396883798] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.005 [1.0010939791275881, 1.0073762722154402] | pass |
| full | paired | `power_100d_e17_x1000` | 1.003 [0.9887327362589458, 1.0270002126344748] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.027 [0.9925701894627604, 1.0444464828022453] | pass |
| full | paired | `recursion_50_x1000` | 0.998 [0.9560610827322293, 1.0184175626455148] | pass |
| full | paired | `sparse_array_200000` | 1.015 [1.000284483938597, 1.0177953075289579] | pass |
| full | paired | `frontend_definitions_2000` | 0.905 [0.8924628134010538, 0.9240993551810107] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.996 [0.9657271432637189, 1.0240087836900698] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.961 [0.876158444476422, 1.2326627505506906] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.942 [0.9277146356746939, 0.9479274384986716] | pass |
| full | paired | `square_100d_x100000` | 1.021 [1.015386334734774, 1.0331727717751635] | pass |
| full | paired | `square_10000d_x500` | 1.002 [1.000279100708543, 1.0032720916887186] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.906 [0.8302958474516875, 1.238818387512721] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.989 [0.9637457918537948, 1.0126692469456202] | pass |
| full | paired | `octal_output_1000d_x300` | 1.011 [1.0022156944652425, 1.0239956507010664] | pass |
| full | paired | `binary_input_100000d_x3` | 1.003 [0.984878770677539, 1.014999172369269] | pass |
| full | paired | `hex_input_100000d_x3` | 1.001 [0.9945231651613112, 1.0054944165787463] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.999 [0.9948889817604192, 1.0035102920091887] | pass |
