# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.012 [0.975082877400014, 1.0628546861557997] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.002 [0.9961936371236748, 1.0292755051453304] | pass |
| full | aa | `calls_200000` | 1.017 [0.968529483190089, 1.0447918916094514] | pass |
| full | aa | `array_200000` | 0.986 [0.9661399319914983, 1.011870424077432] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.988 [0.979183904542333, 0.9993111492074965] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.005 [0.9900336046405016, 1.02767267993268] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.004 [0.9890680210225322, 1.009708233828284] | pass |
| full | aa | `fibonacci_1000_x100` | 1.004 [0.9057452838993276, 1.0209873297743126] | pass |
| full | aa | `factorial_1000_x50` | 1.013 [0.9946535542470052, 1.023071375871745] | pass |
| full | aa | `multiply_100d_x100000` | 1.016 [1.002902369238695, 1.0192842739715613] | pass |
| full | aa | `multiply_10000d_x1000` | 1.003 [0.9899874651217698, 1.0100486754042628] | pass |
| full | aa | `divide_scale100_x100000` | 0.993 [0.966173209145498, 1.022357242471702] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.004 [0.9954392995721222, 1.00806594430542] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.003 [0.9749977489780987, 1.0287699201121216] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9896595177219843, 1.0040603446999203] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.993 [0.9473250196433968, 1.0069215182309632] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.004 [0.9552068177073428, 1.0264550537986232] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.009 [0.997140030040175, 1.0839687532073121] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.998 [0.9910544463517778, 1.013105790555151] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.021 [1.0009464125842784, 1.0296667541565292] | pass |
| full | aa | `recursion_50_x1000` | 1.002 [0.9948585720566036, 1.028754359481719] | pass |
| full | aa | `sparse_array_200000` | 0.990 [0.9355971029831306, 0.9974728588141355] | pass |
| full | aa | `frontend_definitions_2000` | 0.998 [0.982481416723446, 1.0172884239106537] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.997 [0.9842745344560371, 1.0139874546870884] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.004 [0.9198278481088377, 1.047442058930754] | pass |
| full | aa | `streaming_statements_20000` | 1.004 [0.9777933921726109, 1.0378219646756504] | pass |
| full | aa | `square_100d_x100000` | 1.018 [0.9982811563178378, 1.0314285957877058] | pass |
| full | aa | `square_10000d_x500` | 0.998 [0.9922214807006262, 1.0093180722355515] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.978 [0.9348764221230356, 1.053462104309758] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.002 [0.9914482800262282, 1.033549360623454] | pass |
| full | aa | `octal_output_1000d_x300` | 0.992 [0.9665728154915736, 1.0429807477116042] | pass |
| full | aa | `binary_input_100000d_x3` | 0.999 [0.9547985052664966, 1.0047605067883967] | pass |
| full | aa | `hex_input_100000d_x3` | 0.998 [0.9963242662532661, 1.006984626459463] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.995 [0.9865167206765628, 0.9997681210927077] | pass |
| full | paired | `startup` | 1.009 [0.9323133308046266, 1.0428043975422248] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.002 [0.9784217936876058, 1.0159908253237315] | pass |
| full | paired | `calls_200000` | 1.006 [0.9896554481718843, 1.01247478405555] | pass |
| full | paired | `array_200000` | 1.008 [0.9929469880835463, 1.058207808390128] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.993 [0.9879650837409458, 1.0260689153975147] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.008 [0.9780530727562172, 1.012033358315786] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.007 [0.9878063065915419, 1.011455668276687] | pass |
| full | paired | `fibonacci_1000_x100` | 1.005 [0.9996501481728369, 1.0245291031819168] | pass |
| full | paired | `factorial_1000_x50` | 0.997 [0.9947913690210471, 1.0479917296756656] | pass |
| full | paired | `multiply_100d_x100000` | 0.985 [0.9671885513248714, 1.0942566185895484] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.992 [0.9714133001864601, 1.0059167511738936] | pass |
| full | paired | `divide_scale100_x100000` | 0.991 [0.9788756007614813, 1.0348588835121666] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.995 [0.984128776336432, 0.9990154678794682] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.998 [0.9716767774381154, 1.0051774689371218] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9933973607756652, 1.0200354583654336] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.022 [0.9923546385053477, 1.0581316510038905] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.005 [0.9845572556614077, 1.0175454679716607] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.995 [0.9877729919301622, 1.006237714294208] | pass |
| full | paired | `power_100d_e17_x1000` | 1.000 [0.9876545793174832, 1.0160999985598038] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.017 [0.9732747191346435, 1.0630259467042957] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.000 [0.9711626861198195, 1.016190278230481] | pass |
| full | paired | `sparse_array_200000` | 1.005 [0.988642721528084, 1.0487193161507062] | pass |
| full | paired | `frontend_definitions_2000` | 0.939 [0.9027415305813765, 0.9639223677334211] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.993 [0.9742738289662417, 0.9998790360500049] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.024 [0.9907709527899293, 1.0429653531074363] | pass |
| full | paired | `streaming_statements_20000` | 0.884 [0.8515309461501992, 1.0074719696560295] | pass |
| full | paired | `square_100d_x100000` | 1.004 [0.9964576430751053, 1.0098304418450135] | pass |
| full | paired | `square_10000d_x500` | 0.998 [0.987054240353115, 1.004258073963525] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.997 [0.9363466915234223, 1.048859288335367] | pass |
| full | paired | `binary_output_1000d_x300` | 1.009 [0.936383573395978, 1.0432923611158336] | pass |
| full | paired | `octal_output_1000d_x300` | 1.007 [0.9946500140671748, 1.0285075973642046] | pass |
| full | paired | `binary_input_100000d_x3` | 0.991 [0.9811176422101542, 1.0062163863134852] | pass |
| full | paired | `hex_input_100000d_x3` | 0.993 [0.936403852114674, 0.9967765648323694] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.002 [0.9986316986038128, 1.0145736293099257] | pass |
