# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.879 [0.5664374185139804, 0.9319411017004818] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.962 [0.9199342218002776, 1.2849394722950818] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.984 [0.9366343188979663, 1.0548910083397738] | inconclusive-noisy |
| full | aa | `array_200000` | 1.093 [1.0029126147423266, 1.187526917525379] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.930 [0.8528321618300465, 1.0427637118719466] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.026 [0.8787117323257878, 1.2148422372179213] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.970 [0.8347410429613364, 1.1346653963022628] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.016 [0.9661819710552397, 1.2248954152643687] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.066 [0.9904531190042606, 1.196414781412613] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.042 [0.9002566979996149, 1.1163770575283711] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.985 [0.8436696528591054, 1.2230294072520005] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.035 [0.8759941619267777, 1.0851989609938728] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.984 [0.8688485628843188, 1.1213567369098583] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9138777433077049, 1.1114529038282641] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.942 [0.7551745865343719, 1.3416445024654617] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.030 [0.9175407243556518, 1.093464463548787] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.952 [0.850105950554521, 1.1999607421602576] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.987 [0.9738424755374343, 1.0749294741081554] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.996 [0.7790767055065443, 1.147282862888131] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.038 [0.8802302484394252, 1.1906979877633306] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.990 [0.9393856989962793, 1.15621055118718] | inconclusive-noisy |
| full | paired | `startup` | 1.012 [0.9575740736545028, 1.6841076582360879] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.025 [0.9311680919870677, 1.075062695303807] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.096 [0.8794252910817604, 1.118758974268912] | inconclusive-noisy |
| full | paired | `array_200000` | 1.090 [0.9080264987956064, 1.1701520949817619] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.065 [0.9210508305488292, 1.3382323998909458] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.062 [0.9660275787630337, 1.0751451287445748] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.904 [0.7118255703836177, 1.0091597929969338] | pass |
| full | paired | `fibonacci_1000_x100` | 1.062 [0.84751980091842, 1.225166543722218] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.111 [0.9961918104964341, 1.180814652729987] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.027 [1.0002179352910554, 1.071400881506543] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.977 [0.9071286515499639, 1.0887573878573045] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.021 [0.9130392868890169, 1.078509115424433] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.979 [0.8638841809490493, 1.0359353193066063] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.037 [0.9599108248965382, 1.118789857005625] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.029 [0.8001058774277945, 1.2538765948758066] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.682 [0.48884405632890526, 0.8177871141937765] | pass |
| full | paired | `sparse_array_200000` | 0.923 [0.7798759026977337, 1.0943476014113145] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.997 [0.9471479073062552, 1.1316774222686055] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.913 [0.8395809335361744, 1.0619086162286884] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.752 [0.6851154331846232, 0.8651904058391994] | pass |
| full | paired | `square_10000d_x500` | 0.515 [0.506212123542291, 0.5572130009173999] | pass |
