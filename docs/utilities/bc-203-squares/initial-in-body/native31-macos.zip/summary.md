# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.943 [0.8108990225981084, 1.077909841135892] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.019 [0.9781981758923824, 1.0976806493085858] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.973 [0.9314832233444349, 1.0561522097398233] | inconclusive-noisy |
| full | aa | `array_200000` | 0.990 [0.9212520381257434, 1.109818929734233] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.984 [0.8539425330760406, 1.05783355183066] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.966 [0.8950199295040963, 1.0047575559518929] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.959 [0.9037356097903496, 1.0267327707654017] | pass |
| full | aa | `fibonacci_1000_x100` | 0.993 [0.9237758067813931, 1.0485252494917932] | pass |
| full | aa | `multiply_100d_x100000` | 0.987 [0.8011807656854847, 1.0942083000937175] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.967 [0.9258019899197796, 1.096289808291945] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.933 [0.7910669675862282, 1.0998675269059757] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.005 [0.9126292569097332, 1.013997535278267] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.967 [0.878891747847287, 1.0262805560682207] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.944 [0.8849436205909027, 1.0093092369957444] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.017 [0.845924486204535, 1.070891735993615] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.009 [0.9369630580391247, 1.0667079028616409] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.034 [0.9402949058968052, 1.2274523286390449] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.011 [0.9986150541738887, 1.061644376265059] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.076 [0.9694127443714141, 1.186573538759921] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.932 [0.8828356887456047, 1.023513692019226] | pass |
| full | aa | `square_10000d_x500` | 0.991 [0.9873362047829731, 1.0388663647132306] | pass |
| full | paired | `startup` | 1.371 [0.9579153806862531, 1.5258995304040839] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.025 [0.9431809402562613, 1.144705300083942] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.942 [0.887376182663481, 1.0201586813025731] | pass |
| full | paired | `array_200000` | 1.006 [0.9186120951744935, 1.0823874964103184] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.988 [0.923575933629019, 1.442168117819769] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.959 [0.9005513043114809, 1.0235400281250333] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.992 [0.8951421209963709, 1.2244729134415722] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.211 [0.8077581632748521, 1.4117801568217372] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.111 [0.8725551089568359, 1.20897499586005] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.963 [0.9433744557374913, 1.018243293662373] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.050 [0.9294388021727628, 1.1780233010893764] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.024 [0.9308935886778378, 1.0977905001035628] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.965 [0.9180907078507876, 1.0785083493984016] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.952 [0.9066015444841113, 1.0061743580341658] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.098 [1.0180840791341488, 1.2360619468282057] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.612 [0.5244864175230076, 0.7921466368267146] | pass |
| full | paired | `sparse_array_200000` | 1.008 [0.8608175738899648, 1.1245360757963687] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.037 [0.8989548500088232, 1.0589042785021492] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.942 [0.8676893274815921, 1.094578997993981] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.780 [0.7125004239160686, 0.8126931742917594] | pass |
| full | paired | `square_10000d_x500` | 0.528 [0.47068905520542503, 0.5778103627992295] | pass |
