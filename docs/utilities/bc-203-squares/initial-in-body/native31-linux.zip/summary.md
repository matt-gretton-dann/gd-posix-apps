# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.990 [0.9060151715231162, 1.0436741691183706] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.994 [0.9853160533871744, 1.0098246932106665] | pass |
| full | aa | `calls_200000` | 1.014 [0.9881872989842899, 1.0301192671185115] | pass |
| full | aa | `array_200000` | 1.003 [0.9922222507320134, 1.0070111087667757] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.998 [0.9910616515691695, 1.0179453944950068] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.008 [1.0008323464061593, 1.0166245069259945] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.000 [0.9923422483592873, 1.0116140040614048] | pass |
| full | aa | `fibonacci_1000_x100` | 0.996 [0.9739867311918229, 1.012394224516085] | pass |
| full | aa | `multiply_100d_x100000` | 0.998 [0.9914954600174546, 1.0069536762616356] | pass |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.993716090488579, 1.00322381900084] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.000 [0.9978665546054086, 1.0067112525610376] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9987408772730941, 1.001680256610969] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9988921727739126, 1.0020724493791988] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9996885351018692, 1.0055937899222323] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.000 [0.996159290054965, 1.0036283210007155] | pass |
| full | aa | `power_100d_e17_x1000` | 0.998 [0.9920204450208854, 1.000555327238554] | pass |
| full | aa | `sparse_array_200000` | 0.994 [0.9876552870365648, 1.0083312963811069] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9986673867910087, 1.0018746456654837] | pass |
| full | aa | `streaming_statements_20000` | 0.998 [0.985241331192009, 1.0098385568008739] | pass |
| full | aa | `square_100d_x100000` | 1.000 [0.9965263749366051, 1.0070085075803892] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.998195623728557, 1.001949800833692] | pass |
| full | paired | `startup` | 1.043 [0.9301377676536292, 1.092688612681471] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.046 [1.0371675641024354, 1.0760435458810722] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.026 [1.0119168493604427, 1.0512508621194703] | inconclusive-noisy |
| full | paired | `array_200000` | 1.045 [1.024108799210096, 1.0549688319787212] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.049 [1.043095468987554, 1.0647577944482653] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.060 [1.0504114988051798, 1.0748562767515435] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.060 [1.057268054629065, 1.0733466456646887] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.045 [1.0351117690339955, 1.0510514023618245] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.059 [1.0501194000110847, 1.0663095063832086] | confirmed regression |
| full | paired | `multiply_10000d_x1000` | 1.015 [1.0091634700901566, 1.0220801012251133] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.006 [0.9970301681919018, 1.006876461035599] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.017 [1.013617098690804, 1.0193520377185885] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.007 [1.0055680129974094, 1.0084760004770255] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.016 [1.0154400153467462, 1.017072744948035] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.000 [0.9938136059198446, 1.0080807326505372] | pass |
| full | paired | `power_100d_e17_x1000` | 0.607 [0.6056725834591803, 0.6097870672158857] | pass |
| full | paired | `sparse_array_200000` | 1.012 [1.004299928176477, 1.020404530574384] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.992 [0.9897556960110966, 0.9938705659088517] | pass |
| full | paired | `streaming_statements_20000` | 1.008 [0.9923866076710632, 1.0162462758112274] | pass |
| full | paired | `square_100d_x100000` | 0.894 [0.8865013725956362, 0.8995450101654607] | pass |
| full | paired | `square_10000d_x500` | 0.546 [0.5449556026368397, 0.5464588476382816] | pass |
