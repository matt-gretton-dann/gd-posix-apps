# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.934 [0.8937065818856513, 1.1158959386895586] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.985 [0.9767274715278685, 0.9926430767173788] | pass |
| full | aa | `calls_200000` | 0.994 [0.9669109742446278, 1.0368353768825775] | pass |
| full | aa | `array_200000` | 0.974 [0.961135269517692, 1.0211194816724953] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.980 [0.9464147027695559, 1.0483820605954877] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.990 [0.9851748001431582, 1.016099705457491] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.983 [0.9779882146455033, 1.0398987778130395] | pass |
| full | aa | `fibonacci_1000_x100` | 0.984 [0.9738039566395459, 1.0023415376043052] | pass |
| full | aa | `multiply_100d_x100000` | 0.985 [0.9697290684183766, 1.0059802758092922] | pass |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.9923747786948934, 0.9998798733756361] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.010 [0.9864089450350706, 1.0381192268021031] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.9950052964478895, 1.0050963458354463] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9836581146681727, 1.008073284354418] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.009 [0.9898298799030921, 1.0139272293714754] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.007 [0.9895743957513843, 1.024821501801653] | pass |
| full | aa | `power_100d_e17_x1000` | 0.987 [0.9779065200302388, 1.0070347874988985] | pass |
| full | aa | `sparse_array_200000` | 0.993 [0.9430071797600545, 0.9994469532553663] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.003 [0.9905702417001346, 1.0086157486478777] | pass |
| full | aa | `streaming_statements_20000` | 1.039 [0.9866698502698478, 1.1034680188178847] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.968 [0.9405048392526795, 0.9947166400797336] | pass |
| full | aa | `square_10000d_x500` | 1.004 [0.993195150744375, 1.0108048552845355] | pass |
| full | paired | `startup` | 1.079 [0.8509136808325366, 1.1135126377214701] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.981 [0.9654845864797591, 0.989339047456124] | pass |
| full | paired | `calls_200000` | 1.019 [0.9958156256229843, 1.034874719455262] | pass |
| full | paired | `array_200000` | 1.004 [0.9568684414817157, 1.0295818544153754] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.957 [0.9373577557551517, 1.0424785920210171] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.983 [0.9644803996512884, 1.0375139836713947] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.985 [0.9600554448362839, 1.0037345643304945] | pass |
| full | paired | `fibonacci_1000_x100` | 0.992 [0.9668288513376764, 1.0921859920639292] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.000 [0.971108507229437, 1.0242671255416587] | pass |
| full | paired | `multiply_10000d_x1000` | 1.000 [0.9961584894351567, 1.0045704904169532] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.999 [0.9805474769120522, 1.069981938213886] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.000 [0.9934309287286022, 1.011910546135956] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9972886698764396, 1.0152618302774286] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.003 [0.986151922344771, 1.0107567381206592] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.994 [0.9553205397799707, 1.052562237526828] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.661 [0.6504631650326215, 0.6795478871075676] | pass |
| full | paired | `sparse_array_200000` | 0.990 [0.9546357989074161, 1.037524139866612] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.007 [0.9839687537069258, 1.028636884730136] | pass |
| full | paired | `streaming_statements_20000` | 1.012 [0.9643124328519567, 1.0436563047179894] | pass |
| full | paired | `square_100d_x100000` | 0.827 [0.8157059992963726, 0.8462949801936896] | pass |
| full | paired | `square_10000d_x500` | 0.523 [0.519249950313875, 0.5258165934034746] | pass |
