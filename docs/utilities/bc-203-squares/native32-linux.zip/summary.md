# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.947 [0.7441284889250019, 1.2048872487603015] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.011 [0.9921148908543499, 1.0400052585672186] | pass |
| full | aa | `calls_200000` | 0.998 [0.9807388182220973, 1.0092131264435165] | pass |
| full | aa | `array_200000` | 0.998 [0.9911888384371081, 1.0052189179612487] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.991 [0.9808767357579385, 0.9968049629215416] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.993 [0.990102609556466, 1.0479811214785513] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.994 [0.9909429268522778, 1.0177072752340293] | pass |
| full | aa | `fibonacci_1000_x100` | 1.001 [0.9823123855337306, 1.01424365321223] | pass |
| full | aa | `multiply_100d_x100000` | 0.999 [0.9903957650696296, 1.0025274466077643] | pass |
| full | aa | `multiply_10000d_x1000` | 0.996 [0.9934991886479297, 0.9973008934237554] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.002 [0.9915517118279129, 1.0104501555024752] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.9977183786719817, 1.0006320683798218] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9974628092206735, 0.9996474718156193] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9987784762037276, 1.0015447358610556] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.000 [0.987383902921853, 1.0174326482327003] | pass |
| full | aa | `power_100d_e17_x1000` | 0.998 [0.9870205994107722, 1.0066035737772696] | pass |
| full | aa | `sparse_array_200000` | 0.995 [0.9891027963996379, 1.003676368552515] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9987896286628651, 1.0019458168075617] | pass |
| full | aa | `streaming_statements_20000` | 1.000 [0.9850942990869962, 1.0047671916245278] | pass |
| full | aa | `square_100d_x100000` | 0.998 [0.9919819820573987, 1.0107404669866127] | pass |
| full | aa | `square_10000d_x500` | 0.998 [0.998149391627523, 0.9993786482172212] | pass |
| full | paired | `startup` | 1.124 [0.9347108662870817, 1.3240540654826158] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.049 [1.0451873857288843, 1.0552730733475313] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.008 [0.990538078943339, 1.0321211807588855] | pass |
| full | paired | `array_200000` | 1.026 [1.0176170167161298, 1.0404509557392412] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.036 [1.0252126235988621, 1.0384015206331276] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.036 [1.0240707276891603, 1.0521105636721644] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.035 [1.0277888103992392, 1.0425121069146557] | pass |
| full | paired | `fibonacci_1000_x100` | 1.005 [0.9741236308198569, 1.0237111968390395] | pass |
| full | paired | `multiply_100d_x100000` | 1.024 [1.0203548767833892, 1.0301208686003205] | pass |
| full | paired | `multiply_10000d_x1000` | 1.027 [1.0230084548871985, 1.0323010949291307] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.014 [1.0055655565817503, 1.0192091089278343] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.030 [1.0269317032929808, 1.0313923346499632] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.979 [0.9764655842220489, 0.9806120383185009] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.024 [1.022920060658581, 1.0247197932769785] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.004 [0.981489887527151, 1.0207973617992794] | pass |
| full | paired | `power_100d_e17_x1000` | 0.607 [0.6015663855096645, 0.6175326563558733] | pass |
| full | paired | `sparse_array_200000` | 1.003 [0.9868517742010858, 1.0176859283841124] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.996 [0.9939786257685633, 0.9973369767601002] | pass |
| full | paired | `streaming_statements_20000` | 1.001 [0.9876830572892012, 1.0051353842561492] | pass |
| full | paired | `square_100d_x100000` | 0.865 [0.8516404354830696, 0.8681773410456398] | pass |
| full | paired | `square_10000d_x500` | 0.546 [0.5456716149545505, 0.5472804900429912] | pass |
