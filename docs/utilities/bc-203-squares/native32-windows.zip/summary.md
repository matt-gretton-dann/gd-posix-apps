# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.970 [0.9077583693365855, 1.0739334375695289] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.999 [0.9823687966698781, 1.002183158224782] | pass |
| full | aa | `calls_200000` | 1.019 [0.9788288078974782, 1.054730952310986] | inconclusive-noisy |
| full | aa | `array_200000` | 0.997 [0.974471035554162, 1.0293411758527002] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.001 [0.9933256989002484, 1.0230368243127421] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.998 [0.9457623472089719, 1.0085539182462886] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.001 [0.9846916705304916, 1.0231143318009268] | pass |
| full | aa | `fibonacci_1000_x100` | 1.008 [1.0015693046343845, 1.115333748306537] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.007 [0.999024357962191, 1.0728518520959538] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9970205698293471, 1.002150453300155] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.001 [0.9911504900930281, 1.0053630569965821] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9984710846998893, 1.0033338113844457] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.996 [0.9929568634216123, 1.0046084963872848] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9938798973742654, 1.0069734148838658] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.014 [0.9893373611087458, 1.0197651794008182] | pass |
| full | aa | `power_100d_e17_x1000` | 0.999 [0.9900265635351101, 1.0023421656271978] | pass |
| full | aa | `sparse_array_200000` | 0.999 [0.971984679839021, 1.0238057282763586] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.998 [0.9922977394386651, 1.0073058710124276] | pass |
| full | aa | `streaming_statements_20000` | 0.998 [0.9767444239867608, 1.0765841978929453] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.998 [0.9867474412427095, 1.0632806342927734] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.000 [0.9983411496362296, 1.003139776448298] | pass |
| full | paired | `startup` | 1.090 [0.9208403676688437, 1.1407897321741178] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.992 [0.965292980779022, 1.0378713146173772] | pass |
| full | paired | `calls_200000` | 0.973 [0.8650970939351762, 1.0402860520808062] | pass |
| full | paired | `array_200000` | 1.025 [0.864715109906571, 1.0335038736118645] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.993 [0.8767060074005655, 1.0338767099816166] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.955 [0.9385260291381596, 0.9661232834709892] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.960 [0.9541673839741158, 1.0922140474666278] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.977 [0.9643489881016206, 1.0240652657438674] | pass |
| full | paired | `multiply_100d_x100000` | 1.011 [0.9897765847513312, 1.0571710211338643] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.002 [1.0004479654396874, 1.0057167809319476] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.998 [0.995572849855677, 1.0260559909271039] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.006 [1.0022284350626929, 1.0237795026053098] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9801885036900335, 1.0015827512417068] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.007 [0.9970643723060482, 1.0233281176017868] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.998 [0.9880580652076032, 1.0292362502830954] | pass |
| full | paired | `power_100d_e17_x1000` | 0.675 [0.6600201958985741, 0.6826720596316229] | pass |
| full | paired | `sparse_array_200000` | 0.991 [0.9643382199042858, 1.1488925112102222] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.002 [0.9831168578748671, 1.0153050849158203] | pass |
| full | paired | `streaming_statements_20000` | 1.005 [0.9449677965925366, 1.0777956823228116] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.845 [0.8354145265444017, 0.9316437252816296] | pass |
| full | paired | `square_10000d_x500` | 0.541 [0.5398540715886668, 0.5425637036637672] | pass |
