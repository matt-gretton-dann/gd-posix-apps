# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.019 [0.9425571813077235, 1.066552462518941] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.000 [0.9802592405880738, 1.0264061713498331] | pass |
| full | aa | `calls_200000` | 0.985 [0.9693663065419708, 1.011251673942062] | pass |
| full | aa | `array_200000` | 0.998 [0.9791509403208245, 1.037711259531563] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.007 [0.985511115856918, 1.017552398926912] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.007 [1.0034834332395894, 1.0218634800276807] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.998 [0.9957586958488279, 1.010694986842051] | pass |
| full | aa | `fibonacci_1000_x100` | 0.991 [0.9271591352313698, 1.0025526406886176] | pass |
| full | aa | `multiply_100d_x100000` | 0.995 [0.9892233328776318, 0.9997548466310693] | pass |
| full | aa | `multiply_10000d_x1000` | 0.999 [0.996919451789368, 1.0011539250915626] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.995 [0.9757319586277781, 1.001654170873954] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.9955907897873287, 1.0012540143934008] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9943430195538268, 1.0126546460469592] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9953528110804623, 1.0010854679343426] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.995 [0.9783449861132467, 1.0073255114317519] | pass |
| full | aa | `power_100d_e17_x1000` | 1.000 [0.9782541032933195, 1.0229099629656995] | pass |
| full | aa | `sparse_array_200000` | 1.008 [0.9929333865032598, 1.0201757917504324] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.004 [1.0000305341514046, 1.0086835825418565] | pass |
| full | aa | `streaming_statements_20000` | 0.986 [0.9130115105851814, 1.0146623169149267] | pass |
| full | aa | `square_100d_x100000` | 0.992 [0.983557097415941, 0.9924458195022282] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9966730441967027, 1.0043287454873695] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.992 [0.9562110005742919, 1.0736404631551106] | inconclusive-noisy |
| full | paired | `startup` | 0.995 [0.9594513536264334, 1.0348851610754746] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.000 [0.9735332588672339, 1.005059375752756] | pass |
| full | paired | `calls_200000` | 0.981 [0.9640157294223807, 0.9900718045593284] | pass |
| full | paired | `array_200000` | 1.001 [0.970641069863362, 1.0336990733830271] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.007 [1.0049360128178826, 1.151926293945981] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.953 [0.9273626659726562, 0.9603492553992907] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.959 [0.9528292170205175, 1.0185620611122093] | pass |
| full | paired | `fibonacci_1000_x100` | 0.983 [0.9783995054047148, 0.9875370732629376] | pass |
| full | paired | `multiply_100d_x100000` | 1.006 [1.0002576875967895, 1.023818399598592] | pass |
| full | paired | `multiply_10000d_x1000` | 0.993 [0.9895649458388476, 0.9965630530251404] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.005 [0.9951738059428695, 1.0088671023964177] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.997 [0.9890538604719855, 1.0060640151158469] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.133 [1.0994934102260057, 1.1399168182888932] | confirmed regression |
| full | paired | `multiply_sparse_10000d_x1000` | 1.000 [0.9927857313462283, 1.0001388689663908] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.994 [0.9033629427400675, 1.0118306014961018] | pass |
| full | paired | `power_100d_e17_x1000` | 0.999 [0.9870971039893682, 1.007968176290752] | pass |
| full | paired | `sparse_array_200000` | 1.033 [0.9971522407508168, 1.1177489677611951] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.998 [0.9916511121988368, 1.0034823628626153] | pass |
| full | paired | `streaming_statements_20000` | 0.988 [0.9278145292800989, 1.0011878009633852] | pass |
| full | paired | `square_100d_x100000` | 1.017 [1.0078483796814284, 1.0620889966025613] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.997 [0.9915859384770894, 1.0053669732928423] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.002 [0.9373849716066623, 1.09349196776473] | inconclusive-noisy |
