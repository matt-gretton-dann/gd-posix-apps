# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.954 [0.7680021904222929, 1.612502363255842] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.963 [0.8498134280039151, 1.0417228938036953] | pass |
| full | aa | `calls_200000` | 1.015 [0.8912117787299029, 1.162186146706528] | inconclusive-noisy |
| full | aa | `array_200000` | 1.016 [0.9262003002941736, 1.1280336629885055] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.996 [0.9604162495963606, 1.0755437088825457] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.014 [0.8609160064051433, 1.2412073776919423] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.006 [0.9971878763905437, 1.1877060265427806] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.003 [0.7533868696676591, 1.0148509652676345] | pass |
| full | aa | `multiply_100d_x100000` | 1.045 [0.9027337072799636, 1.1296812567008956] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.015 [0.9754349797074592, 1.0741814140518064] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.009 [0.9339037792810059, 1.097602652948] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.006 [0.9606962017258887, 1.0552842840692234] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.945 [0.8420964500246431, 0.9655737883905998] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.985 [0.9581595850216558, 1.051141812126552] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.992 [0.9362759136187778, 1.2007522751623332] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.974 [0.9389923413751012, 1.0325189070404939] | pass |
| full | aa | `sparse_array_200000` | 1.047 [0.9798372093856915, 1.2296749660223418] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.034 [0.9602655305331446, 1.1362854063715624] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.002 [0.9197327849412925, 1.1093618999390034] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.014 [0.9424833024036969, 1.106557991556261] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.005 [0.9206889246784663, 1.0716721778000693] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.964 [0.7932714327312943, 1.0479783197872836] | pass |
| full | paired | `startup` | 0.934 [0.5804831872299987, 1.3070716681076582] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.002 [0.9575907973054736, 1.0410026751239225] | pass |
| full | paired | `calls_200000` | 1.004 [0.9499746602671941, 1.0233299830876275] | pass |
| full | paired | `array_200000` | 1.030 [0.9978919383436643, 1.1889438687279896] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.033 [0.8718872319452227, 1.2144955518978684] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.051 [0.8799875939664666, 1.2370827255832648] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.955 [0.8941020509305063, 1.3151131844527733] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.976 [0.8357431625762701, 1.0723243158046585] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.005 [0.7831943748655545, 1.3799810860117723] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.025 [0.9836129433716135, 1.0387265171379778] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.033 [0.9479755410533733, 1.177971680701096] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.988 [0.872400565019267, 1.0316454349294089] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.076 [1.0136140362413928, 1.2253995035577752] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.027 [0.9503659226239425, 1.0691224163893716] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.167 [0.9255674225412271, 1.2657960561780417] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.020 [0.8139196241046526, 1.0841442373210324] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.091 [0.8841174280554964, 1.4881842219710437] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.941 [0.8824461591176236, 1.0142429878724872] | pass |
| full | paired | `streaming_statements_20000` | 1.124 [1.0935452569446278, 1.2194389160827166] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.947 [0.8985117968728744, 1.3268901177486394] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.918 [0.9032604133300377, 1.0849970314081618] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.849 [0.6620434618495888, 1.1509997086922117] | inconclusive-noisy |
