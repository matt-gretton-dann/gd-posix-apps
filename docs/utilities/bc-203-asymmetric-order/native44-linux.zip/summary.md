# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.199 [0.8116219399095824, 1.3604525014523254] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.008 [0.9953017485385363, 1.0225876680169144] | pass |
| full | aa | `calls_200000` | 1.000 [0.9875889916971758, 1.0040578759379795] | pass |
| full | aa | `array_200000` | 1.005 [0.994238104539938, 1.0067437984392333] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.013 [1.0009691084111874, 1.0282469138361583] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.992 [0.9724387312072228, 1.0174910778364292] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.000 [0.984360813072366, 1.0484786853408095] | pass |
| full | aa | `fibonacci_1000_x100` | 0.999 [0.973212418710997, 1.0155716354997413] | pass |
| full | aa | `multiply_100d_x100000` | 0.990 [0.9832818023465523, 0.997627395047565] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9976266675154236, 0.9999041156620317] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.988 [0.9872411197843598, 0.9905578987123004] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9981510297395, 1.000048250057343] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.998298509997343, 1.0021010970993987] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9996117801643394, 1.0007435353368415] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.986 [0.9839949672799069, 1.008178099878121] | pass |
| full | aa | `power_100d_e17_x1000` | 1.000 [0.9969084018622887, 1.0039475194499201] | pass |
| full | aa | `sparse_array_200000` | 1.002 [0.9911316758484685, 1.0089869963367002] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.999 [0.9975187674676577, 1.000875044573593] | pass |
| full | aa | `streaming_statements_20000` | 0.995 [0.9938731827989439, 1.0015126415399036] | pass |
| full | aa | `square_100d_x100000` | 1.024 [1.007714602200925, 1.049671438768959] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9990388659798282, 1.0037007604869788] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.933 [0.8085392427756304, 1.113010926620671] | inconclusive-noisy |
| full | paired | `startup` | 0.843 [0.7498340691626675, 1.109459247442784] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.016 [0.9982676480457882, 1.0213304287115845] | pass |
| full | paired | `calls_200000` | 1.004 [0.9979264680207243, 1.0151469899208736] | pass |
| full | paired | `array_200000` | 1.012 [0.9978555041036983, 1.0203998885181478] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.012 [1.0007846545955164, 1.0400923556089452] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.012 [1.0055738679385298, 1.0299425955856925] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.027 [0.9984270551139958, 1.0527634807576824] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.009 [0.994742715229019, 1.0936162035372001] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.985 [0.9804242499998671, 1.0000651876008908] | pass |
| full | paired | `multiply_10000d_x1000` | 0.999 [0.999180618006138, 1.0006542839497174] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.999 [0.994163028130484, 1.0039994343181988] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.004 [1.0024255917444556, 1.005173652198097] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.226 [1.2251208441932986, 1.2283169053471126] | confirmed regression |
| full | paired | `multiply_sparse_10000d_x1000` | 0.999 [0.9987883136949292, 1.0010658772479233] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.003 [0.9845023021125126, 1.0212901282705045] | pass |
| full | paired | `power_100d_e17_x1000` | 1.000 [0.9931238413081445, 1.0104718228093053] | pass |
| full | paired | `sparse_array_200000` | 1.019 [1.009834546554245, 1.0256727057227835] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.002 [1.000259032905897, 1.0042519226673154] | pass |
| full | paired | `streaming_statements_20000` | 1.010 [1.0017046411213204, 1.0310807985117743] | pass |
| full | paired | `square_100d_x100000` | 1.013 [1.0024177116071986, 1.1231846191266233] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.000 [0.9991927285472386, 1.0009047353722265] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.077 [0.8755174730334827, 1.1688243366946265] | inconclusive-noisy |
