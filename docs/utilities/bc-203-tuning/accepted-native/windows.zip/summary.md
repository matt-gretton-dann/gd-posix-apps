# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.009 [0.9108226521933575, 1.0384057768961135] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.023 [0.9860862320233562, 1.0441132711474537] | pass |
| full | aa | `calls_200000` | 0.981 [0.9463802537430529, 0.9976887483568663] | pass |
| full | aa | `array_200000` | 1.000 [0.972363356427786, 1.0276532220071404] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.992 [0.9801302353766983, 1.0152157612062032] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.995 [0.9610888926424522, 1.0078879149615443] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.995 [0.926816023421122, 1.0121131182847987] | pass |
| full | aa | `fibonacci_1000_x100` | 0.990 [0.9738319381382032, 1.0132637054305376] | pass |
| full | aa | `factorial_1000_x50` | 0.992 [0.9752475647188865, 1.0756548699216446] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.975 [0.899121617392462, 0.9872513815531175] | pass |
| full | aa | `multiply_10000d_x1000` | 0.992 [0.9895978118221345, 1.0072775799505906] | pass |
| full | aa | `divide_scale100_x100000` | 0.985 [0.9552581683374768, 0.9926789224530607] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9971730102642828, 1.0610417734055535] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.003 [0.9753088648495786, 1.0096980194323568] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9916723532857575, 1.014647567198816] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.007 [0.9847763802714674, 1.0170628508405495] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.990 [0.9672118472389986, 1.0193239191141314] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.005 [0.9811270802522685, 1.0445501641410722] | pass |
| full | aa | `power_100d_e17_x1000` | 1.017 [0.985212569317045, 1.0310386215644738] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.008 [0.9210547247850587, 1.2003632385725747] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.996 [0.9915704945245395, 1.0166588137782868] | pass |
| full | aa | `sparse_array_200000` | 0.986 [0.9455704333362375, 1.0138748821824017] | pass |
| full | aa | `frontend_definitions_2000` | 1.016 [0.9909155959299585, 1.031921922817497] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.008 [0.9889362438602051, 1.0253231185382017] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.981 [0.9436290753815715, 1.0019505820740877] | pass |
| full | aa | `streaming_statements_20000` | 1.010 [0.9252206238318225, 1.0447329435183554] | pass |
| full | aa | `square_100d_x100000` | 0.982 [0.9717998153670373, 1.0039884559090764] | pass |
| full | aa | `square_10000d_x500` | 0.995 [0.9936012308351329, 1.004582103182448] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.038 [0.9678037562265271, 1.0527752947936928] | inconclusive-noisy |
| full | paired | `startup` | 1.004 [0.9195345855373908, 1.1378225205098724] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.991 [0.9652293455869343, 1.0026602457903937] | pass |
| full | paired | `calls_200000` | 0.980 [0.963162550325779, 0.9967957364482126] | pass |
| full | paired | `array_200000` | 1.006 [0.9841038730250077, 1.035089577605921] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.986 [0.9787746098156238, 1.0092067843294372] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.999 [0.9793959879275683, 1.0190473622235932] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.002 [0.9939748973755693, 1.0110114112499227] | pass |
| full | paired | `fibonacci_1000_x100` | 1.005 [0.9867311421812953, 1.0098501441211782] | pass |
| full | paired | `factorial_1000_x50` | 0.995 [0.962538655295534, 0.9980720578675681] | pass |
| full | paired | `multiply_100d_x100000` | 0.990 [0.973567913065715, 1.002001418624287] | pass |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9931722580708032, 1.0088126211806863] | pass |
| full | paired | `divide_scale100_x100000` | 0.991 [0.9759023061708314, 0.9969434645932548] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.001 [0.9973195394089818, 1.0118259600530481] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.993 [0.9829443710451712, 1.009796993109319] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9677552108424324, 1.0148359285050854] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.013 [0.9967711587227057, 1.0293569476215478] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.007 [1.0023073447776873, 1.0361466030462896] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.003 [0.9579115657381414, 1.0572672990927823] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.983 [0.961939301261311, 0.9930509992148544] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.989 [0.9682954033063531, 1.0304421727621929] | pass |
| full | paired | `recursion_50_x1000` | 0.986 [0.977017546499418, 0.998705746285501] | pass |
| full | paired | `sparse_array_200000` | 0.996 [0.9918521046770836, 1.043768341772282] | pass |
| full | paired | `frontend_definitions_2000` | 0.986 [0.8980380736667839, 1.0032709574932113] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.996 [0.9735563605358902, 1.0035508502770853] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.995 [0.9846378046533912, 1.0014909385654212] | pass |
| full | paired | `streaming_statements_20000` | 0.994 [0.9677886897115299, 1.0043404523613364] | pass |
| full | paired | `square_100d_x100000` | 0.991 [0.9847919297318033, 0.9977218045221607] | pass |
| full | paired | `square_10000d_x500` | 1.001 [0.9954338412659103, 1.0028588783923431] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.990 [0.9061062043386185, 1.004182038868601] | pass |
