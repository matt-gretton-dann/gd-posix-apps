# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.827 [0.7919039086618093, 1.1220203813373062] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.991 [0.9737616455188869, 1.0138841352818215] | pass |
| full | aa | `calls_200000` | 1.002 [0.9929846910750924, 1.0080586005447925] | pass |
| full | aa | `array_200000` | 0.982 [0.9634976112459548, 1.010467934657333] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.987 [0.9606136041674338, 1.0036089841167988] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.027 [0.9537901840427385, 1.0321168710605173] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.951 [0.9340798081452167, 1.0189263292181043] | pass |
| full | aa | `fibonacci_1000_x100` | 1.002 [0.9870893536088604, 1.0128464219745894] | pass |
| full | aa | `factorial_1000_x50` | 0.996 [0.9764939599688324, 1.013201129388693] | pass |
| full | aa | `multiply_100d_x100000` | 0.990 [0.9613308367635883, 1.0067625875753445] | pass |
| full | aa | `multiply_10000d_x1000` | 1.005 [0.9938659091070432, 1.0383110107404985] | pass |
| full | aa | `divide_scale100_x100000` | 0.995 [0.9841596391552715, 1.0255083838446408] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.008 [0.9979207149564789, 1.0173123245089346] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.9777210817633458, 1.01432542055586] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.987 [0.9708690594033966, 1.0009693402930158] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.003 [0.9966775473765279, 1.010406900728788] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.982 [0.9777358445239864, 1.0330593895114788] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.002 [0.9945386738122416, 1.005629014772233] | pass |
| full | aa | `power_100d_e17_x1000` | 1.000 [0.9871209199551005, 1.0079494594668685] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.012 [0.9910088399366588, 1.0314676624072951] | pass |
| full | aa | `recursion_50_x1000` | 0.993 [0.9859828686332284, 1.0127574858244581] | pass |
| full | aa | `sparse_array_200000` | 1.005 [0.9810524880324446, 1.0169090845358186] | pass |
| full | aa | `frontend_definitions_2000` | 1.003 [0.9728228551158057, 1.0175449764944056] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.007 [0.97701489237172, 1.0590515684132185] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.002 [0.9709241497093478, 1.014350409166515] | pass |
| full | aa | `streaming_statements_20000` | 0.988 [0.9796056025673394, 1.015915042750552] | pass |
| full | aa | `square_100d_x100000` | 0.994 [0.9881528917067174, 1.0182889605133019] | pass |
| full | aa | `square_10000d_x500` | 0.999 [0.9792108814095117, 1.0058243442788846] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.888 [0.8477559452153802, 1.151067789634291] | inconclusive-noisy |
| full | paired | `startup` | 0.870 [0.7614375810379752, 1.3156554211686782] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.007 [0.986804680359775, 1.035845379827741] | pass |
| full | paired | `calls_200000` | 1.006 [0.9918008296756163, 1.0084094019064498] | pass |
| full | paired | `array_200000` | 1.010 [0.9886690421678562, 1.0234619666066302] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.004 [0.9980230759962059, 1.0110323665062326] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.969 [0.949201875426544, 0.9874151397981299] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.025 [0.9521420351224887, 1.0515016083569646] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.999 [0.975298886373006, 1.012158792534046] | pass |
| full | paired | `factorial_1000_x50` | 0.998 [0.9889228436308588, 1.0120846489716053] | pass |
| full | paired | `multiply_100d_x100000` | 0.990 [0.9808337156529875, 1.0085850531869835] | pass |
| full | paired | `multiply_10000d_x1000` | 0.998 [0.9858990949984178, 1.0072512680873598] | pass |
| full | paired | `divide_scale100_x100000` | 0.996 [0.9776685271368872, 1.0056020521428874] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.998 [0.9894402380361587, 1.0240169036421543] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.993 [0.960085259739125, 1.0352820696631098] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.994 [0.7551535262614131, 1.0014901830881973] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.999 [0.9855975287611334, 1.0505914136315395] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.8703299625846791, 1.0177017990775945] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.993 [0.9523924773088135, 1.0100891319087668] | pass |
| full | paired | `power_100d_e17_x1000` | 1.006 [0.9831009909447973, 1.0200306033241826] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.997 [0.9389720818662046, 1.0211112844706909] | pass |
| full | paired | `recursion_50_x1000` | 1.007 [0.9905713886479933, 1.0181153630024096] | pass |
| full | paired | `sparse_array_200000` | 0.995 [0.9844889677599803, 1.0166919346199397] | pass |
| full | paired | `frontend_definitions_2000` | 0.997 [0.9716100377860148, 1.008301910006965] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.975 [0.9568266123513547, 1.0263932351489156] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.001 [0.9470415964620446, 1.043251750117535] | pass |
| full | paired | `streaming_statements_20000` | 0.988 [0.9804556257954556, 1.012380919978252] | pass |
| full | paired | `square_100d_x100000` | 0.997 [0.9814583206244569, 0.997361012915145] | pass |
| full | paired | `square_10000d_x500` | 1.000 [0.9978564620490397, 1.009770465295717] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.908 [0.8326680031123495, 1.1305175712465956] | inconclusive-noisy |
