# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.958 [0.7159981676066491, 1.2251268284013088] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.010 [0.9848882487703388, 1.1253864109992888] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.963 [0.7783541519848916, 1.142039374063259] | inconclusive-noisy |
| full | aa | `array_200000` | 0.977 [0.7803383368213379, 0.9978731515267921] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.969 [0.6950382864520949, 0.9830561275071604] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.040 [0.812044196625445, 1.1915563716146806] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.981 [0.8178732542784144, 1.0755443823541215] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.921 [0.7810573152899621, 1.0305821993257427] | pass |
| full | aa | `factorial_1000_x50` | 0.928 [0.7672797303001254, 1.0567868563248413] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.001 [0.9064779336080575, 1.0861708569766915] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.992 [0.9121982083627578, 1.0239075154674868] | pass |
| full | aa | `divide_scale100_x100000` | 1.036 [0.6916515730575051, 1.124260453200445] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.015 [0.9529890365828629, 1.2020144091216178] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 0.946 [0.7854422397192451, 1.018804775356002] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.970 [0.8449862959513104, 1.1584135921796668] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 0.970 [0.910953940509447, 1.108825941407866] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.060 [0.9458969989673229, 1.2971172088280731] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.962 [0.8289739623145707, 1.134368793084835] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.077 [0.8734630325104342, 1.1828902820706153] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 1.156 [0.7428743035754425, 1.2438475816123498] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.904 [0.8158730510528308, 1.0201742895082784] | pass |
| full | aa | `sparse_array_200000` | 1.104 [0.9199471293006537, 1.2637276034362674] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.935 [0.8111476175525798, 1.1364379190908538] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.995 [0.7390168129888207, 1.2226093910669011] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.041 [0.9890039769251739, 1.2415863241504776] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.966 [0.8420671998381759, 1.14591551852724] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.155 [0.9136242806438766, 1.297594278671204] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.916 [0.7636667918327147, 1.029049147045592] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.974 [0.8708763614541676, 1.0624337065478209] | inconclusive-noisy |
| full | paired | `startup` | 0.913 [0.7223330342015264, 1.0605302606460516] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.006 [0.9459662416271949, 1.0589809846170872] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.010 [0.9082440897042516, 1.0468476582851558] | pass |
| full | paired | `array_200000` | 0.968 [0.9172307569781886, 1.1194768320320645] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.081 [0.7443232889875958, 1.1511278547297197] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.966 [0.8074294434966922, 1.1207137743191438] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.087 [0.7957721391334497, 1.2489046828431964] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.058 [0.8795965234206492, 1.3350449270392033] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.014 [0.8532119707004422, 1.1537712998684282] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.921 [0.8824145878679106, 1.1592848311721138] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9283369906797615, 1.0218622671818036] | pass |
| full | paired | `divide_scale100_x100000` | 0.929 [0.7922976580446378, 1.5813254650844226] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.934 [0.900207628903928, 1.0761006328995963] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.958 [0.8599019373575832, 0.9928482020917828] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.8972356122365217, 1.0744051979223788] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.980 [0.9252273563905401, 1.1371076151404331] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.027 [0.8303859695054236, 1.263153715880764] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.081 [0.9759910501407845, 1.1866065143722595] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.990 [0.8347934256002109, 1.1937610275266173] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.044 [0.7251271267763106, 1.2336886769662556] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.205 [0.8392704389213419, 1.4515879935219873] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.990 [0.7482485388157997, 1.1245112775701687] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.965 [0.9232327309447826, 1.3378421316966238] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.931 [0.6983053048915377, 1.1185733418160737] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.046 [0.9771285253393756, 1.4574453677023986] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.003 [0.9097703207927502, 1.1056825270634867] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.897 [0.812507462841885, 1.0762656759826934] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.003 [0.9713829462721663, 1.0410273059898874] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.844 [0.6553962716159788, 1.0085105331472954] | pass |
