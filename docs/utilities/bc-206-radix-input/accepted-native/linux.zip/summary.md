# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.838 [0.7558521811747161, 1.087835044093674] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.002 [0.9979692103375191, 1.0086843396072704] | pass |
| full | aa | `calls_200000` | 1.001 [0.9936198613886392, 1.00424618745635] | pass |
| full | aa | `array_200000` | 1.006 [0.9934781521596856, 1.011510254580898] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.000 [0.9934208432102638, 1.0075964804015067] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.002 [0.9959642677679627, 1.0070204732247245] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.008 [1.0036816834328908, 1.0106554319656544] | pass |
| full | aa | `fibonacci_1000_x100` | 0.998 [0.9956888552271572, 1.004877092209227] | pass |
| full | aa | `factorial_1000_x50` | 1.005 [0.998680614934453, 1.008168518605085] | pass |
| full | aa | `multiply_100d_x100000` | 1.000 [0.981225979888239, 1.0160998140361805] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9956880469769691, 1.010237919749262] | pass |
| full | aa | `divide_scale100_x100000` | 1.001 [0.9990965889102381, 1.0048126918283136] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.001 [0.9943389435666296, 1.0058733133582467] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9990348286274158, 1.0356945856927515] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.992 [0.9775136790255464, 1.0179111636556641] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.996 [0.9868022461665835, 1.002736960271258] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.982 [0.9626337867552643, 1.0178798742349127] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.998 [0.9935245201229143, 1.0099519237924028] | pass |
| full | aa | `power_100d_e17_x1000` | 0.999 [0.9857060984346349, 1.008495988565354] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.994 [0.988760431460369, 0.9984264024281753] | pass |
| full | aa | `recursion_50_x1000` | 1.002 [0.9940898520532119, 1.048280948321823] | pass |
| full | aa | `sparse_array_200000` | 1.000 [0.9932690399871719, 1.0044415412858214] | pass |
| full | aa | `frontend_definitions_2000` | 1.006 [0.9906608112763763, 1.0110265398338234] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.978 [0.9223284048816061, 1.0087991159098768] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.976 [0.9591147439482072, 1.0073222304333556] | pass |
| full | aa | `streaming_statements_20000` | 0.993 [0.9704661285089204, 1.031327668739629] | pass |
| full | aa | `square_100d_x100000` | 0.999 [0.99273525360487, 1.0058671508598052] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9995001212734221, 1.0049742124733414] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.928 [0.9164832980141084, 1.0876936469929939] | inconclusive-noisy |
| full | paired | `startup` | 0.992 [0.828580318624094, 1.2078153984637958] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.939 [0.9360334585386305, 0.9414428848080475] | pass |
| full | paired | `calls_200000` | 0.954 [0.9520587716911477, 1.0225844657247556] | pass |
| full | paired | `array_200000` | 0.976 [0.9584165565270754, 0.9864861013715369] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.956 [0.9004278551218399, 0.9635735334616309] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.015 [1.00702570546518, 1.0212834588827961] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.016 [1.0158558583833797, 1.0229250260861569] | pass |
| full | paired | `fibonacci_1000_x100` | 0.980 [0.9634105240587302, 0.9933628142407177] | pass |
| full | paired | `factorial_1000_x50` | 1.009 [0.9965355986357441, 1.0171889662391527] | pass |
| full | paired | `multiply_100d_x100000` | 0.989 [0.977506694083605, 1.0640567557580283] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.999 [0.9926299211717796, 1.007801198492603] | pass |
| full | paired | `divide_scale100_x100000` | 0.965 [0.9609903582191268, 0.9674308846070145] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.990 [0.9653823943305947, 0.9920217511679491] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.993 [0.970838580437501, 1.0055759057437437] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.979 [0.8865597047293537, 0.9993623954161857] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.000 [0.992066375081085, 1.012161578602386] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.015 [0.9791415159796656, 1.0315252075120405] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.999 [0.9914522924516048, 1.0121787481693758] | pass |
| full | paired | `power_100d_e17_x1000` | 0.997 [0.9888799870845907, 1.0048020286027186] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.977 [0.9705445407942767, 0.9849336295709074] | pass |
| full | paired | `recursion_50_x1000` | 0.964 [0.9563008262549949, 0.98137509918095] | pass |
| full | paired | `sparse_array_200000` | 0.963 [0.9616853354510447, 0.9659880562404631] | pass |
| full | paired | `frontend_definitions_2000` | 0.998 [0.9865654518767978, 1.0498931154958049] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.930 [0.9176937959391653, 0.9513899055485758] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.004 [0.9819006170295543, 1.0603734311131907] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.005 [0.9771288091853005, 1.0098235323444362] | pass |
| full | paired | `square_100d_x100000` | 0.990 [0.9833886029322667, 1.0463014276310334] | pass |
| full | paired | `square_10000d_x500` | 0.997 [0.9938211346574773, 0.9995164602438672] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.910 [0.8661040170520058, 1.0013418837182495] | pass |
