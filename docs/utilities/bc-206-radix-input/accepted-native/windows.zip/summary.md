# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.938 [0.8913383114503057, 1.0538300304913806] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.008 [0.9682855207701271, 1.0334204232617223] | pass |
| full | aa | `calls_200000` | 0.993 [0.9577663359013129, 1.0395700789596412] | pass |
| full | aa | `array_200000` | 0.979 [0.9333140650641826, 1.014026103177082] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.021 [0.9797170781142535, 1.2731819039913648] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.003 [0.9979845647141289, 1.0080225204043143] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.010 [0.9856219331035403, 1.012581652279157] | pass |
| full | aa | `fibonacci_1000_x100` | 0.982 [0.9657952091078704, 1.0266347221561338] | pass |
| full | aa | `factorial_1000_x50` | 1.005 [0.9783573280664353, 1.0657351921873164] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.992 [0.904136111825031, 1.0059262525819543] | pass |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.984235764493605, 1.0115658548521191] | pass |
| full | aa | `divide_scale100_x100000` | 0.995 [0.9710437252474531, 1.009707632389137] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.003 [0.9354977752887735, 1.0081686161039551] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.9723906762570611, 1.0131272742065223] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.007 [0.9886506188090598, 1.0500795709006565] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.003 [0.9826713390824541, 1.019342273082539] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.006 [0.9842702079319473, 1.0991514665576823] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.996 [0.9838036672102836, 1.0131448279684279] | pass |
| full | aa | `power_100d_e17_x1000` | 0.986 [0.9700350123509845, 1.014068423856991] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.012 [0.8976144663947464, 1.181737983153531] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.992 [0.9582324612473239, 1.0069775512369676] | pass |
| full | aa | `sparse_array_200000` | 1.003 [0.9896651018453372, 1.0366668633394862] | pass |
| full | aa | `frontend_definitions_2000` | 1.002 [0.9639658018204564, 1.0142361792303942] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.988 [0.9445589616278477, 1.0087543616969208] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.005 [0.9708125563109712, 1.0825792736300732] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.983 [0.9773706265790971, 1.0296776416495943] | pass |
| full | aa | `square_100d_x100000` | 1.017 [0.9918761174368457, 1.0622666479276262] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.004 [0.9982369346485528, 1.010661742002137] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.990 [0.9444834542619853, 1.0772980969682648] | inconclusive-noisy |
| full | paired | `startup` | 1.008 [0.9271484581997316, 1.0569315205854493] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.002 [0.9633939779729389, 1.0104768682465863] | pass |
| full | paired | `calls_200000` | 0.975 [0.9699011742657428, 1.010667435610646] | pass |
| full | paired | `array_200000` | 0.983 [0.9697794019035771, 0.9891630583434236] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.986 [0.9670491396062398, 0.9981067963923148] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.986 [0.9788104182720102, 1.0288199233584534] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.989 [0.9829063270297721, 0.9959687098672484] | pass |
| full | paired | `fibonacci_1000_x100` | 0.976 [0.9631499671170187, 1.0193969662494078] | pass |
| full | paired | `factorial_1000_x50` | 1.001 [0.9778010417561558, 1.0104469148113784] | pass |
| full | paired | `multiply_100d_x100000` | 0.995 [0.9791695577457631, 1.0036051589984316] | pass |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.99257738738244, 1.0049433257851204] | pass |
| full | paired | `divide_scale100_x100000` | 0.987 [0.9803118325821334, 0.9962511990438554] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.007 [0.9952920797524331, 1.014513886350614] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.001 [0.9937112518931646, 1.0086111498030015] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9798496142198142, 1.003525269969934] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.998 [0.9942316519160281, 1.0313542813581402] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.9717967391690722, 1.0224512551611993] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.004 [0.9772025039980541, 1.0049306832474016] | pass |
| full | paired | `power_100d_e17_x1000` | 1.004 [0.9487905712543837, 1.0305241061301307] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.978 [0.9386502130522631, 1.0054677498032278] | pass |
| full | paired | `recursion_50_x1000` | 0.995 [0.9391479418891547, 1.013210609677933] | pass |
| full | paired | `sparse_array_200000` | 0.984 [0.9769028687476782, 1.007981598108753] | pass |
| full | paired | `frontend_definitions_2000` | 0.985 [0.9695984703640741, 1.0067080328698814] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.979 [0.9529304724896527, 0.990093147097223] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.008 [0.971024270964955, 1.035528456057453] | pass |
| full | paired | `streaming_statements_20000` | 0.996 [0.9673970555851876, 1.046189694964436] | pass |
| full | paired | `square_100d_x100000` | 0.999 [0.9512834432152417, 1.0271089797014539] | pass |
| full | paired | `square_10000d_x500` | 0.995 [0.9934526200572034, 0.9997026035971552] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.954 [0.9436998761997393, 1.0453344247000869] | pass |
