# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.949 [0.6790640394076225, 1.0894547191201491] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.986 [0.9467920897469572, 1.1580864724856985] | inconclusive-noisy |
| full | aa | `calls_200000` | 1.013 [0.880322095669108, 1.2063752051526437] | inconclusive-noisy |
| full | aa | `array_200000` | 0.989 [0.8911612136699765, 1.0484124467915892] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.026 [0.8037017571651365, 1.2560241616744603] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.031 [0.9302328994264841, 1.1106412591849044] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.993 [0.9016414163379498, 1.1624344505006108] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.100 [0.6505569018447294, 1.2131065822221359] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.020 [0.9292922428913458, 1.1593676911413084] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.958 [0.7427710085344995, 1.089636705079458] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.955 [0.8452154006735998, 1.0929317569904635] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.151 [1.0093840947261992, 1.308291774587028] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.958 [0.9015298384240291, 0.9804522427941968] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.077 [1.0263304049694166, 1.1420680552471658] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.926 [0.6877348609368822, 1.02697438035359] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.026 [0.9561052643234483, 1.2333156171776538] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.985 [0.5729249094311093, 1.0601394242327447] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 1.003 [0.7612029792827365, 1.2830652649601997] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.014 [0.9585134492957346, 1.1052973970692965] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 1.142 [0.9850061622052227, 1.3281231069516415] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 1.033 [0.8507029056595559, 1.784880935542626] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.030 [0.8334780251118965, 1.127273684045548] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.957 [0.8767776192276843, 1.0555666485762496] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.883 [0.7223602735454033, 1.2386519443370454] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 0.956 [0.7416874205350777, 1.0071671578059684] | pass |
| full | aa | `streaming_statements_20000` | 0.973 [0.9493543126866789, 1.2087233569488398] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.023 [0.8821877335353736, 1.0715903743667101] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.967 [0.8974909497326253, 1.034374832366944] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.999 [0.8694164836798983, 1.0655931711143771] | inconclusive-noisy |
| full | paired | `startup` | 1.007 [0.8278232755964494, 1.5430374168469003] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.037 [0.8488550306113781, 1.1785809465207733] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.981 [0.883434195024558, 1.250699871254012] | inconclusive-noisy |
| full | paired | `array_200000` | 0.954 [0.8231767391522085, 1.1077402787293484] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.995 [0.8746594354624543, 1.1251302567797243] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.931 [0.8211004303008108, 1.0164055528580656] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.962 [0.9065406469642614, 1.1570938193976825] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.062 [0.9798132408850629, 1.188666246099881] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.940 [0.7919170220331121, 1.145441304378011] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.004 [0.8203269069192444, 1.267795951138586] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.002 [0.9258685331039074, 1.0449891867690544] | pass |
| full | paired | `divide_scale100_x100000` | 0.893 [0.7958875777725014, 1.0217725867558878] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.962 [0.8001302599637341, 1.1497175899957952] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.064 [0.8860970374813947, 1.1965390752630858] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.953 [0.8305656887012378, 1.0314026240776861] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.062 [0.9243682391945789, 1.3248384664601112] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.899 [0.734172231985247, 1.0406715018306303] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.932 [0.7371140102549043, 1.05773557244524] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.054 [0.9538711946954119, 1.4791748528875746] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.028 [0.989720467685844, 1.1257396726335327] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.152 [1.0520198457217178, 1.3786746555225182] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.170 [0.872029046995533, 1.2453288864473941] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.938 [0.7721321998039805, 1.4283788358667295] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.912 [0.8944670666601211, 1.24454277121232] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.982 [0.6353919217974799, 1.377067265953997] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.973 [0.7536236559218822, 1.010567072594959] | pass |
| full | paired | `square_100d_x100000` | 0.969 [0.8610406864263951, 1.0576294148266043] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.962 [0.8725534929794112, 1.269710879022578] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.965 [0.682844169810185, 1.0386393508999616] | pass |
