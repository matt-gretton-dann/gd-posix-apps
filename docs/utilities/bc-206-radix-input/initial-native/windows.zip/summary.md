# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.955 [0.9161555516051245, 1.0339422745611033] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.980 [0.952109953471096, 0.9997805527266547] | pass |
| full | aa | `calls_200000` | 0.978 [0.9405906377862195, 0.9885196128052814] | pass |
| full | aa | `array_200000` | 0.957 [0.9506007677583788, 1.0008491274672215] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.951 [0.8899364174531039, 1.0092216787630246] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.989 [0.9575661226831644, 1.0005504638680358] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.984 [0.9596665430340464, 1.0263851334542629] | pass |
| full | aa | `fibonacci_1000_x100` | 1.004 [0.9861106124127776, 1.0243543749497583] | pass |
| full | aa | `factorial_1000_x50` | 1.001 [0.9975280185728604, 1.0152332027361108] | pass |
| full | aa | `multiply_100d_x100000` | 0.990 [0.9795590281096114, 1.038658739223915] | pass |
| full | aa | `multiply_10000d_x1000` | 1.002 [0.9833421906247115, 1.0142066289954266] | pass |
| full | aa | `divide_scale100_x100000` | 1.007 [0.9864940507257028, 1.0325327186920021] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.000 [0.9884354078530108, 1.0119256440485325] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9855044445300252, 1.0048166820226563] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9852826535758447, 1.014812205539148] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.005 [0.9886991931135343, 1.0168530358211745] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.987 [0.9665641562507488, 1.0381871795780597] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.996 [0.9818455330367525, 1.0075160952250475] | pass |
| full | aa | `power_100d_e17_x1000` | 1.006 [0.9862647659809806, 1.0239360826786519] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.007 [0.9752638973167717, 1.014867677672043] | pass |
| full | aa | `recursion_50_x1000` | 0.987 [0.9745131720572517, 0.9930338121817995] | pass |
| full | aa | `sparse_array_200000` | 0.973 [0.9514235251461922, 0.9904286477125803] | pass |
| full | aa | `frontend_definitions_2000` | 0.995 [0.9601628827191852, 1.0222327132164064] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.990 [0.9556661388761645, 1.0012497805129439] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.002 [0.9955977541117825, 1.0186730433329305] | pass |
| full | aa | `streaming_statements_20000` | 1.001 [0.9702311910817295, 1.016325138811207] | pass |
| full | aa | `square_100d_x100000` | 0.986 [0.972521234268315, 0.9931666597763052] | pass |
| full | aa | `square_10000d_x500` | 0.993 [0.9842533017835464, 1.0110101439025483] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.951 [0.9266639071636656, 1.0321025827468646] | pass |
| full | paired | `startup` | 1.021 [0.9017603920224215, 1.1342472360284686] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.985 [0.9430390389437152, 1.0264574695784372] | pass |
| full | paired | `calls_200000` | 0.980 [0.9502504731153796, 1.0683610433948083] | inconclusive-noisy |
| full | paired | `array_200000` | 0.997 [0.9799083106231163, 1.0362295774070602] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.998 [0.9250819364585849, 1.0361930194336155] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.987 [0.9535623261476002, 1.0171756543344077] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.977 [0.9428798230125076, 0.9961874333199596] | pass |
| full | paired | `fibonacci_1000_x100` | 0.980 [0.9645033028975055, 1.0429859545674722] | pass |
| full | paired | `factorial_1000_x50` | 0.988 [0.9589935559908775, 1.02842508197359] | pass |
| full | paired | `multiply_100d_x100000` | 0.999 [0.9868302134832369, 1.0154370617017194] | pass |
| full | paired | `multiply_10000d_x1000` | 0.997 [0.9710141457078827, 1.0283294338094122] | pass |
| full | paired | `divide_scale100_x100000` | 0.984 [0.9621933183493295, 1.0235386815214838] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.001 [0.9868634495092172, 1.0143592263924375] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.993 [0.9774578642751797, 1.0058471202687063] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.995 [0.914532486759349, 1.0002441537974354] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.003 [0.998128792847434, 1.019346860296187] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.004 [0.9860272747581903, 1.020844311016306] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.997 [0.9827975290785631, 1.0053777522421037] | pass |
| full | paired | `power_100d_e17_x1000` | 0.999 [0.975705954448168, 1.0209865470889221] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.966 [0.8883725217227312, 0.9788777198059817] | pass |
| full | paired | `recursion_50_x1000` | 0.984 [0.9465467565195403, 1.025686803292979] | pass |
| full | paired | `sparse_array_200000` | 0.981 [0.9410588371452883, 1.0038724644342831] | pass |
| full | paired | `frontend_definitions_2000` | 0.975 [0.951958047401723, 1.0334128664452154] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.971 [0.8116746569551563, 0.9944021889253929] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.969 [0.9218444638200772, 1.1614240600337378] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.004 [0.9701112811816963, 1.0527812332268358] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.961 [0.9395692953323217, 0.9842821884675542] | pass |
| full | paired | `square_10000d_x500` | 1.004 [0.9892508057532893, 1.0103549372252445] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.970 [0.9559274720893518, 1.0329335445643777] | pass |
