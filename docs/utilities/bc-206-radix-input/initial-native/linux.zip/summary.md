# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.935 [0.7930184950619402, 1.0109429065563298] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.990 [0.9652266074914996, 0.9968825971076376] | pass |
| full | aa | `calls_200000` | 0.997 [0.958718849821328, 1.0252518634386907] | pass |
| full | aa | `array_200000` | 1.006 [0.9907074701809777, 1.0140717910857373] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.010 [0.9615087016803341, 1.0274818515198811] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.003 [0.9937655542490749, 1.0243302392242257] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.018 [0.9806806435774862, 1.0378640722954418] | pass |
| full | aa | `fibonacci_1000_x100` | 0.998 [0.9737709966833198, 1.0032031369449952] | pass |
| full | aa | `factorial_1000_x50` | 1.003 [0.9918718178590645, 1.0289154040435802] | pass |
| full | aa | `multiply_100d_x100000` | 1.001 [0.9746964692917519, 1.0225712717878361] | pass |
| full | aa | `multiply_10000d_x1000` | 0.998 [0.9957361661386877, 1.001440451065357] | pass |
| full | aa | `divide_scale100_x100000` | 1.001 [0.9957020779559499, 1.0089266679895947] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.002 [0.9962389711235224, 1.0219870382180047] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9973736775678191, 1.0928643789776424] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9945106644224728, 1.018418027445474] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9950055363911043, 1.0050015129562033] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.995 [0.9925945764144412, 1.0022975608733207] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.998 [0.9962588982483231, 1.0092978720703487] | pass |
| full | aa | `power_100d_e17_x1000` | 1.001 [0.9942426578064879, 1.0220076575158625] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.020 [0.9733715750119493, 1.036550149850516] | pass |
| full | aa | `recursion_50_x1000` | 0.981 [0.9704573320479111, 0.9906375078470672] | pass |
| full | aa | `sparse_array_200000` | 1.003 [0.9862060834691623, 1.0351553527734518] | pass |
| full | aa | `frontend_definitions_2000` | 1.008 [1.0000690701738815, 1.0171780190436528] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9771578954012896, 1.0139718551128338] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.012 [0.9604621534069329, 1.032576645893301] | pass |
| full | aa | `streaming_statements_20000` | 1.000 [0.9842997593016053, 1.007884908634079] | pass |
| full | aa | `square_100d_x100000` | 1.013 [1.0070549680217085, 1.0252247809957808] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9981860702714052, 1.000874659093232] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.947 [0.8868488114354456, 1.0323271452534502] | pass |
| full | paired | `startup` | 0.974 [0.783833993447818, 1.327426098454265] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.121 [1.034507555207163, 1.1323344903769945] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.068 [1.0389492616258382, 1.1122740215631728] | inconclusive-noisy |
| full | paired | `array_200000` | 1.060 [1.0408943460288171, 1.0821625863847844] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.081 [1.0568881602656885, 1.0925632530317535] | confirmed regression |
| full | paired | `compare_low_1000d_x100000` | 1.096 [1.074521118374453, 1.1064012104401062] | confirmed regression |
| full | paired | `compare_equal_1000d_x100000` | 1.095 [1.0762511039134037, 1.113769220523473] | confirmed regression |
| full | paired | `fibonacci_1000_x100` | 1.054 [1.0477772171728252, 1.0696876164157703] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.015 [1.0068718152387315, 1.0240613481107497] | pass |
| full | paired | `multiply_100d_x100000` | 1.041 [1.030720503119617, 1.053283778720084] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.002 [0.9991814989520649, 1.004279729914189] | pass |
| full | paired | `divide_scale100_x100000` | 1.021 [1.000261664240594, 1.0271591000142204] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.006 [1.0005275169269203, 1.0166161834140492] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.9978731833436875, 1.0235481108601976] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9990388766915579, 1.0160268258856784] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.977 [0.9698830095392496, 0.9820919357079326] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.008 [0.9864349712092108, 1.0303419293778873] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.011 [1.007181492909286, 1.01262091115544] | pass |
| full | paired | `power_100d_e17_x1000` | 0.995 [0.98914520052258, 1.0052165301147085] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.105 [1.0973876147061197, 1.132294146671137] | confirmed regression |
| full | paired | `recursion_50_x1000` | 1.021 [1.0161131754566595, 1.0290579951473406] | pass |
| full | paired | `sparse_array_200000` | 1.047 [1.0399261427441855, 1.0622653149858734] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.012 [0.9907455600275872, 1.0185325002380985] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.974 [0.90753849702534, 1.0056518899494407] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.987 [0.9826718885229031, 1.0538662684483007] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.013 [0.9835371127994806, 1.0184243796018055] | pass |
| full | paired | `square_100d_x100000` | 1.041 [1.0337543446504196, 1.062216510507922] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.994 [0.9933090786670002, 0.9946854492943881] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.962 [0.9098681031086477, 1.0501265050263735] | inconclusive-noisy |
