# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.910 [0.6985696656817252, 0.9899023085357322] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.940 [0.7661774346101857, 1.0457729875123343] | pass |
| full | aa | `calls_200000` | 0.946 [0.8476313321828318, 0.9959212583427152] | pass |
| full | aa | `array_200000` | 1.094 [0.9055815311616047, 1.134500292406389] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.978 [0.8640055104689622, 1.0507667868316066] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.016 [0.9028589988387, 1.326440405153199] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.992 [0.8560155027347748, 1.0521519324093074] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.064 [0.9897017322707243, 1.1961272365764737] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.010 [0.9761902960286875, 1.1951359260117118] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.042 [0.9480781528200868, 1.1169840312911505] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.974 [0.9253164194534869, 1.0070578188257775] | pass |
| full | aa | `divide_scale100_x100000` | 0.981 [0.6958482708838405, 1.0734749650291773] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.000 [0.8698949444403399, 1.0559471920088723] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 0.969 [0.9160827796310501, 1.0274326225601553] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.979 [0.9023331880975483, 1.0486396942345857] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.983 [0.8962556808734824, 1.089484523520708] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.024 [0.9353452092429105, 1.22558269451077] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 1.018 [0.8842813367553446, 1.1546640364097074] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 0.888 [0.7990825286260244, 1.0544597001850722] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 1.010 [0.8274256834823646, 1.2666203141103476] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.992 [0.8963583085058566, 1.0917123968072973] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.998 [0.9034260378807861, 1.200254667883531] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 1.004 [0.7990682766183779, 1.0632449459778845] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.073 [0.9405843909699138, 1.2365243497797236] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.039 [0.9337515612421213, 1.1619846390159185] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.970 [0.8176161544360955, 1.0701309899616198] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.012 [0.9503000210898853, 1.0879999093685742] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.005 [0.9566385706028899, 1.074340675400314] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 1.055 [0.798086837637204, 1.2344600927275824] | inconclusive-noisy |
| full | paired | `startup` | 0.928 [0.7215766890759867, 1.0670707711618697] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.055 [0.9254972505244327, 1.2960817254484895] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.104 [0.9906100798747287, 1.1835964597226731] | inconclusive-noisy |
| full | paired | `array_200000` | 1.034 [0.9545274899694574, 1.1169461730318067] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.881 [0.7452132623414178, 1.2059571564424916] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.909 [0.8541256330136343, 1.2220591148236737] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.110 [0.8684552148577623, 1.126752974720056] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.038 [0.9998121791290243, 1.0849937620706434] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.006 [0.9113222843294959, 1.1103871847440947] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 1.021 [0.8444692371407791, 1.5236419267311907] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.948 [0.7913272650547741, 1.0520238485466706] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.025 [0.7239122616746532, 1.1489284137055167] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.070 [0.8759035577864432, 1.1433743439449406] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.987 [0.834037903134514, 1.150128671723908] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.007 [0.8408557688573932, 1.1351553853045442] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.991 [0.8534344801765277, 1.1137771943981913] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.980 [0.5830267136627504, 1.209278813801135] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.963 [0.8776830304133438, 1.1464088552943361] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.983 [0.761953287025542, 1.0620987539550801] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.876 [0.794872261129467, 1.2722508435267958] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.945 [0.7600807835644601, 1.1608863406156265] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.990 [0.8457733047212128, 1.100812372252453] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.018 [0.9395442201202224, 1.1081614537570537] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.012 [0.8227577518813521, 1.1473982794290365] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.094 [0.8105669931733518, 1.188191780824243] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.028 [0.9078308840795288, 1.0957361007356246] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.898 [0.7464443843424144, 1.1006620285767674] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.067 [0.9692928326349812, 1.126044288699973] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.928 [0.7716411121444079, 1.1191066997533334] | inconclusive-noisy |
