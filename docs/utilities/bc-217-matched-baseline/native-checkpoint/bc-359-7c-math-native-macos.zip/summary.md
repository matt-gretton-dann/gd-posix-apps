# Native ordinary-library comparisons

Ratios below one favor GD. Each row retains its own regime, scale and mode.
Intervals are the union of paired IID and circular-block intervals; small samples
and nonstationary host noise remain limitations. This report is advisory.

| Corpus | Workload | GD / standard [CI] | GD / portable [CI] | A/A | Observation |
|---|---|---|---|---|---|
| full | `math_regular_s-one_scale100_one_shot_x1` | 1.1909 [1.1150016513706633, 1.5101494169024392] | 1.3108 [1.2575713376691326, 1.4620974928123334] | inconclusive | one-shot latency observation |
| full | `math_regular_s-one_scale100_repeated_x512` | 1.5884 [1.4783876074633628, 1.6511035332217792] | 1.2570 [1.0856718060517305, 1.3817165699172478] | inconclusive | target not established |
| full | `math_regular_c-one_scale100_one_shot_x1` | 1.0291 [0.9695453636412814, 1.2111055552399996] | 1.2397 [1.0520386562318298, 1.3570143247561919] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale100_repeated_x512` | 0.6801 [0.660195016585447, 0.7488546928229115] | 1.2288 [1.1799957258814957, 1.3099249640633828] | inconclusive | target observed; A/A inconclusive |
| full | `math_regular_a-one_scale100_one_shot_x1` | 1.0870 [1.0495223115593841, 1.1863226903812216] | 1.2477 [1.0765281800053446, 1.4533382072998475] | inconclusive | one-shot latency observation |
| full | `math_regular_a-one_scale100_repeated_x1024` | 1.1188 [1.0135987018205543, 1.243507565801258] | 1.0219 [0.9406606692181958, 1.0348267368009807] | inconclusive | target not established |
| full | `math_regular_l-two_scale100_one_shot_x1` | 1.2550 [1.0818135246211646, 1.595900112778889] | 1.4709 [1.03606255172048, 1.709363330503646] | inconclusive | one-shot latency observation |
| full | `math_regular_l-two_scale100_repeated_x1024` | 1.4865 [1.287801808163193, 1.5743587866205855] | 1.0441 [0.9222569836289952, 1.127629547246311] | pass | target not established |
| full | `math_regular_e-one_scale100_one_shot_x1` | 1.2407 [1.1357719055944666, 1.522994620372804] | 1.3602 [1.185821455864265, 1.5956395690958656] | inconclusive | one-shot latency observation |
| full | `math_regular_e-one_scale100_repeated_x2048` | 1.1662 [1.132212866002688, 1.2943495924683317] | 1.5062 [1.4626083177115128, 1.6078092135730275] | inconclusive | target not established |
| full | `math_regular_j-zero-one_scale100_one_shot_x1` | 1.2205 [1.1053201863044115, 1.3798892788287405] | 1.3694 [1.1228516747427155, 1.4882688952716998] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale100_repeated_x2048` | 1.3150 [1.213845383475557, 1.3689735570586878] | 1.5424 [1.4578343237565774, 1.6137106656535054] | inconclusive | target not established |
| full | `math_turning_j-turning_scale100_one_shot_x1` | 1.1057 [0.9394313082922121, 1.3306494349790232] | 1.3317 [1.260243333006949, 1.3760996232817126] | inconclusive | one-shot latency observation |
| full | `math_turning_j-turning_scale100_repeated_x1024` | 2.1050 [2.06611221534673, 2.159162882763828] | 1.9514 [1.6760506173110898, 2.0210746066811036] | inconclusive | target not established |
| full | `math_order_dominates_j-order-dominates_scale100_one_shot_x1` | 1.1596 [1.0497904907256657, 1.3083303694047688] | 1.2074 [1.0865806085028011, 1.699840430749896] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale100_repeated_x2048` | 1.5400 [1.4217001102294515, 1.6351466812317703] | 1.7124 [1.5107665393393257, 1.8069943763069656] | inconclusive | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale100_one_shot_x1` | 1.4565 [1.2818970467875062, 2.150682636734229] | 1.8059 [1.3773890258024126, 1.8417198164086428] | inconclusive | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale100_repeated_x512` | 7.5617 [6.511080183360224, 8.128969051619237] | 3.1657 [2.8049953032902897, 3.292965760805181] | inconclusive | target not established |
| full | `math_near_root_j-near-root_scale100_one_shot_x1` | 1.1405 [1.0905579886653889, 1.3079831521927359] | 1.2904 [1.14285647014598, 1.3641339474476875] | inconclusive | one-shot latency observation |
| full | `math_near_root_j-near-root_scale100_repeated_x2048` | 2.7466 [2.577384771327741, 2.9354189442385072] | 1.8962 [1.7763635196248952, 2.053131538410107] | inconclusive | target not established |

Whole-process samples include library loading, parsing and constant generation.
Repeated cases share a frozen calibrated invocation count across every role.
One-shot rows report latency without a substantive-duration speed target.
No aggregate pass is inferred. Instruction, allocation and peak-memory diagnostics
remain separate work; a green workflow alone does not establish acceptance.
