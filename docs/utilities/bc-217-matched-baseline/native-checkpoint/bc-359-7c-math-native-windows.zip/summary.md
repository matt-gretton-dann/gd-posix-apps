# Native ordinary-library comparisons

Ratios below one favor GD. Each row retains its own regime, scale and mode.
Intervals are the union of paired IID and circular-block intervals; small samples
and nonstationary host noise remain limitations. This report is advisory.

| Corpus | Workload | GD / standard [CI] | GD / portable [CI] | A/A | Observation |
|---|---|---|---|---|---|
| full | `math_regular_s-one_scale100_one_shot_x1` | 1.2256 [1.1884288882694571, 1.247506898715215] | 1.1492 [1.0997444748182184, 1.1532299805315565] | pass | one-shot latency observation |
| full | `math_regular_s-one_scale100_repeated_x256` | 0.9333 [0.9213236114635714, 0.9405851298022164] | 0.5312 [0.5179656745105878, 0.5377206038404715] | pass | target not established |
| full | `math_regular_c-one_scale100_one_shot_x1` | 1.1858 [1.1236269572367494, 1.2004553835461484] | 1.1879 [1.1528110273945846, 1.225260498892759] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale100_repeated_x256` | 0.4126 [0.4113907268388426, 0.42112619065853996] | 0.5300 [0.5242921737582447, 0.5342745309046957] | pass | target observed |
| full | `math_regular_a-one_scale100_one_shot_x1` | 1.2396 [1.1533308195106782, 1.2569749128171654] | 1.1650 [1.1437163083676924, 1.1778490576007195] | pass | one-shot latency observation |
| full | `math_regular_a-one_scale100_repeated_x512` | 0.7720 [0.7644049264806753, 0.7760170600942708] | 0.4658 [0.46167350904319554, 0.46999620053185553] | inconclusive | target observed; A/A inconclusive |
| full | `math_regular_l-two_scale100_one_shot_x1` | 1.2576 [1.2224007825622862, 1.2693371323213136] | 1.1679 [1.119317897686204, 1.1883344954865185] | pass | one-shot latency observation |
| full | `math_regular_l-two_scale100_repeated_x512` | 0.8988 [0.8902037952569443, 0.9020207672806339] | 0.5192 [0.5120137771517858, 0.5247898136841744] | pass | target observed |
| full | `math_regular_e-one_scale100_one_shot_x1` | 1.2552 [1.216145546622994, 1.2804965045004306] | 1.2104 [1.1903647625657172, 1.237301887049911] | inconclusive | one-shot latency observation |
| full | `math_regular_e-one_scale100_repeated_x1024` | 0.8543 [0.8376742535665339, 0.8615617358914819] | 1.3330 [1.2935148583588392, 1.343784437504484] | pass | target observed |
| full | `math_regular_j-zero-one_scale100_one_shot_x1` | 1.2546 [1.241165180094602, 1.2710244535526292] | 1.1769 [1.0843523619905848, 1.2199603624019717] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale100_repeated_x2048` | 1.1076 [1.093960162225836, 1.1377903047113485] | 1.4201 [1.3912502866433305, 1.4506484153682664] | pass | target not established |
| full | `math_turning_j-turning_scale100_one_shot_x1` | 1.2787 [1.262419006481261, 1.2975771323706442] | 1.2212 [1.1552577553309853, 1.2617798221925998] | pass | one-shot latency observation |
| full | `math_turning_j-turning_scale100_repeated_x512` | 1.5925 [1.5649112144047086, 1.6146701551901714] | 1.4372 [1.4324237297695197, 1.4610285730451167] | pass | target not established |
| full | `math_order_dominates_j-order-dominates_scale100_one_shot_x1` | 1.2626 [1.2328847358812283, 1.2818911685974366] | 1.1902 [1.1344220790569357, 1.2604333211462477] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale100_repeated_x1024` | 1.3472 [1.3431489550866047, 1.364155804184879] | 1.4497 [1.4382440989733256, 1.4711157713899223] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale100_one_shot_x1` | 1.5951 [1.5494077820854308, 1.6175041758521111] | 1.3317 [1.2547439432100835, 1.3531866677201767] | pass | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale100_repeated_x256` | 4.7330 [4.682837923194773, 4.767511463290434] | 1.9124 [1.9036137147537038, 1.9287092994413626] | pass | target not established |
| full | `math_near_root_j-near-root_scale100_one_shot_x1` | 1.2467 [1.2222131847570923, 1.2924976524541762] | 1.1970 [1.1661406730986774, 1.2279351221320696] | pass | one-shot latency observation |
| full | `math_near_root_j-near-root_scale100_repeated_x512` | 1.5993 [1.5789476715958748, 1.613597222303649] | 0.9778 [0.9716958599331428, 0.9803491666932084] | pass | target not established |

Whole-process samples include library loading, parsing and constant generation.
Repeated cases share a frozen calibrated invocation count across every role.
One-shot rows report latency without a substantive-duration speed target.
No aggregate pass is inferred. Instruction, allocation and peak-memory diagnostics
remain separate work; a green workflow alone does not establish acceptance.
