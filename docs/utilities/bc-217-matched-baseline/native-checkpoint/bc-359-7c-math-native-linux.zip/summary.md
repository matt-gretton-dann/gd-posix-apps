# Native ordinary-library comparisons

Ratios below one favor GD. Each row retains its own regime, scale and mode.
Intervals are the union of paired IID and circular-block intervals; small samples
and nonstationary host noise remain limitations. This report is advisory.

| Corpus | Workload | GD / standard [CI] | GD / portable [CI] | A/A | Observation |
|---|---|---|---|---|---|
| full | `math_regular_s-one_scale100_one_shot_x1` | 1.8538 [1.7850324780827715, 1.8905590901930223] | 2.3437 [2.2708527165446095, 2.4456009932615417] | inconclusive | one-shot latency observation |
| full | `math_regular_s-one_scale100_repeated_x1024` | 1.3537 [1.335249201667623, 1.3686003066132975] | 1.0951 [1.0812516429554198, 1.0965195109636094] | pass | target not established |
| full | `math_regular_c-one_scale100_one_shot_x1` | 1.7328 [1.55780301373506, 1.823348175319622] | 2.5351 [2.3398569232125626, 2.754924975786998] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale100_repeated_x512` | 0.6481 [0.6444344536733019, 0.657388218212585] | 1.1083 [1.0993500412632355, 1.1125885600150338] | pass | target observed |
| full | `math_regular_a-one_scale100_one_shot_x1` | 1.8404 [1.7881875389365767, 1.903448305697916] | 2.3829 [2.2235607082399342, 2.5655813970756602] | inconclusive | one-shot latency observation |
| full | `math_regular_a-one_scale100_repeated_x1024` | 1.0452 [1.0428455655627569, 1.0497458109851183] | 0.9781 [0.9691230684847806, 0.9833599876578388] | pass | target not established |
| full | `math_regular_l-two_scale100_one_shot_x1` | 1.9464 [1.8601067737309198, 2.0232732414847363] | 2.4724 [2.321211414747636, 2.705774435551194] | inconclusive | one-shot latency observation |
| full | `math_regular_l-two_scale100_repeated_x2048` | 1.5291 [1.5094483883426908, 1.5384523480699626] | 1.0773 [1.0699386765628187, 1.0826384571586607] | pass | target not established |
| full | `math_regular_e-one_scale100_one_shot_x1` | 1.8666 [1.8320460109145627, 1.9471440061213814] | 2.6776 [2.538851419022778, 2.7663908119034346] | inconclusive | one-shot latency observation |
| full | `math_regular_e-one_scale100_repeated_x2048` | 1.2822 [1.276643066894326, 1.2870811431150895] | 1.6039 [1.5880931493827377, 1.6189694433034076] | pass | insufficient measured duration |
| full | `math_regular_j-zero-one_scale100_one_shot_x1` | 1.9692 [1.8806027635381433, 2.051032006272689] | 2.5271 [2.2676321621292286, 2.604950399029265] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale100_repeated_x4096` | 1.2809 [1.2759509448521296, 1.2825465016287028] | 1.5157 [1.5098222742287724, 1.524993836264186] | pass | target not established |
| full | `math_turning_j-turning_scale100_one_shot_x1` | 1.9312 [1.7384835172861413, 1.9941140178908203] | 2.5613 [2.4878923906887445, 2.7283976155850005] | inconclusive | one-shot latency observation |
| full | `math_turning_j-turning_scale100_repeated_x1024` | 2.0165 [2.00650180685422, 2.0250934153173836] | 1.8970 [1.8862672807048084, 1.8991449747882694] | pass | target not established |
| full | `math_order_dominates_j-order-dominates_scale100_one_shot_x1` | 2.0512 [1.8414270553942806, 2.195370857474923] | 2.7162 [2.297028324839046, 3.0595305353940834] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale100_repeated_x2048` | 1.4415 [1.4248634762792207, 1.4446783087560122] | 1.4935 [1.4824540307949423, 1.5049228423103127] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale100_one_shot_x1` | 2.8815 [2.8088079688026535, 2.975799522816386] | 2.8159 [2.6146409481227697, 2.9078165989228624] | inconclusive | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale100_repeated_x512` | 6.4958 [6.460922248230338, 6.504189473822664] | 3.0580 [3.0520661074060196, 3.0726775053231643] | pass | target not established |
| full | `math_near_root_j-near-root_scale100_one_shot_x1` | 1.9598 [1.8770785770317364, 2.103685495053134] | 2.6369 [2.5021843437069746, 2.7217826755046906] | inconclusive | one-shot latency observation |
| full | `math_near_root_j-near-root_scale100_repeated_x2048` | 2.7669 [2.733535314518853, 2.7748502412931715] | 1.9045 [1.8900597622926334, 1.9098891009847927] | pass | target not established |

Whole-process samples include library loading, parsing and constant generation.
Repeated cases share a frozen calibrated invocation count across every role.
One-shot rows report latency without a substantive-duration speed target.
No aggregate pass is inferred. Instruction, allocation and peak-memory diagnostics
remain separate work; a green workflow alone does not establish acceptance.
