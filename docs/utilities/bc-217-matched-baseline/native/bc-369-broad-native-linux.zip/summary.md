# Native ordinary-library comparisons

Ratios below one favor GD. Each row retains its own regime, scale and mode.
Intervals are the union of paired IID and circular-block intervals; small samples
and nonstationary host noise remain limitations. This report is advisory.

| Corpus | Workload | GD / standard [CI] | GD / portable [CI] | A/A | Observation |
|---|---|---|---|---|---|
| full | `math_regular_s-one_scale20_one_shot_x1` | 2.0094 [1.8014123315951844, 2.1426324468427445] | 2.5794 [2.5636911154056152, 2.6589271793679314] | pass | one-shot latency observation |
| full | `math_regular_s-one_scale20_repeated_x16384` | 8.3941 [8.358783329838193, 8.486722632094748] | 1.0236 [1.014689007039388, 1.0323316078915141] | pass | target not established |
| full | `math_regular_s-one_scale100_one_shot_x1` | 1.9169 [1.774552646276547, 1.9930530756289175] | 2.3249 [2.2375115863202226, 2.4269576950058314] | inconclusive | one-shot latency observation |
| full | `math_regular_s-one_scale100_repeated_x1024` | 1.5785 [1.5623558645655882, 1.5988112252032753] | 1.2598 [1.2332690388079888, 1.2703280631539995] | pass | target not established |
| full | `math_regular_s-one_scale1000_one_shot_x1` | 1.0785 [1.0701538038397516, 1.109690022573255] | 1.6257 [1.6115253962869025, 1.6710060162211395] | pass | one-shot latency observation |
| full | `math_regular_s-one_scale1000_repeated_x8` | 1.0322 [1.015803325505125, 1.0348677150903407] | 1.5722 [1.5623243504848492, 1.580530071166307] | pass | insufficient measured duration |
| full | `math_regular_c-one_scale20_one_shot_x1` | 2.0863 [1.9958359057642534, 2.125038480869402] | 2.5294 [2.406584481775563, 2.632723113487678] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale20_repeated_x16384` | 7.1395 [7.072222848522981, 7.235217842286213] | 1.0150 [0.9744818439958032, 1.0285441367984816] | pass | target not established |
| full | `math_regular_c-one_scale100_one_shot_x1` | 1.6955 [1.6457257902522817, 1.8121565695128163] | 2.3656 [2.183964673954455, 2.429214164190508] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale100_repeated_x512` | 0.6775 [0.6533379527854487, 0.6812846964867131] | 1.2636 [1.2551216041243263, 1.2936650113360277] | pass | insufficient measured duration |
| full | `math_regular_c-one_scale1000_one_shot_x1` | 0.4323 [0.4301973109201245, 0.43952274763717325] | 1.6364 [1.6258980456755605, 1.6674553718180503] | pass | one-shot latency observation |
| full | `math_regular_c-one_scale1000_repeated_x8` | 0.3930 [0.39185975255148925, 0.39939998144371835] | 1.5743 [1.567580264376685, 1.599783318701336] | pass | insufficient measured duration |
| full | `math_regular_a-one_scale20_one_shot_x1` | 2.0513 [1.9884591668346776, 2.1306416755175728] | 2.6630 [2.2864617323988314, 2.717246083693123] | inconclusive | one-shot latency observation |
| full | `math_regular_a-one_scale20_repeated_x131072` | 41.9323 [39.627403401238475, 42.87253985189315] | 0.9035 [0.8962071151416924, 0.9131675552700308] | pass | target not established |
| full | `math_regular_a-one_scale100_one_shot_x1` | 1.9108 [1.8563932892186243, 2.114166864383924] | 2.4821 [2.3983049484734478, 2.558470847893866] | inconclusive | one-shot latency observation |
| full | `math_regular_a-one_scale100_repeated_x1024` | 1.1081 [1.1014270369789116, 1.1202146558865171] | 1.0472 [1.0393050205023249, 1.0771200020363418] | pass | target not established |
| full | `math_regular_a-one_scale1000_one_shot_x1` | 1.1617 [1.1512558358332605, 1.1644066776265147] | 1.2897 [1.2830415811731777, 1.3026632001080507] | pass | one-shot latency observation |
| full | `math_regular_a-one_scale1000_repeated_x16` | 1.0872 [1.0764808331164921, 1.1016909458566022] | 1.1966 [1.1898075793618337, 1.2408286202486358] | pass | target not established |
| full | `math_regular_l-two_scale20_one_shot_x1` | 2.0234 [1.9288123414154805, 2.1199688774436596] | 2.5596 [2.428219129208257, 2.7797093943398834] | inconclusive | one-shot latency observation |
| full | `math_regular_l-two_scale20_repeated_x8192` | 2.0985 [2.053839385925999, 2.105844281467817] | 0.9771 [0.9701456137374859, 0.9893406096343144] | pass | target not established |
| full | `math_regular_l-two_scale100_one_shot_x1` | 1.9732 [1.9041153799685506, 2.0670808695219143] | 2.5468 [2.1277919554581555, 2.6046495803702343] | inconclusive | one-shot latency observation |
| full | `math_regular_l-two_scale100_repeated_x2048` | 1.5535 [1.5226863974405578, 1.5644494833593654] | 1.0841 [1.0652395787314732, 1.108106431140771] | pass | target not established |
| full | `math_regular_l-two_scale1000_one_shot_x1` | 1.1508 [1.1398107891517084, 1.1697915086830897] | 1.3530 [1.3251043065617933, 1.3645540593269483] | pass | one-shot latency observation |
| full | `math_regular_l-two_scale1000_repeated_x16` | 1.0587 [1.0498673667516623, 1.066835745539186] | 1.2326 [1.2252390657988061, 1.241068841384251] | pass | target not established |
| full | `math_regular_e-one_scale20_one_shot_x1` | 1.9545 [1.861378778618015, 2.1033651438552745] | 2.4698 [2.1710825769106665, 2.747951476044488] | inconclusive | one-shot latency observation |
| full | `math_regular_e-one_scale20_repeated_x8192` | 1.7725 [1.7505701410185244, 1.7819419536592291] | 1.2412 [1.223279871225735, 1.251423759348365] | pass | target not established |
| full | `math_regular_e-one_scale100_one_shot_x1` | 2.0106 [1.757190061978346, 2.1710717314431247] | 2.6536 [2.3214882236605137, 2.800285014115028] | inconclusive | one-shot latency observation |
| full | `math_regular_e-one_scale100_repeated_x4096` | 1.2899 [1.2271255483418537, 1.3071009785147365] | 1.5928 [1.5725344538351342, 1.623283271751581] | pass | target not established |
| full | `math_regular_e-one_scale1000_one_shot_x1` | 1.5058 [1.4761308258736865, 1.5103037443728096] | 5.7771 [5.663961207434677, 5.93422988899095] | pass | one-shot latency observation |
| full | `math_regular_e-one_scale1000_repeated_x256` | 1.3942 [1.389535776675723, 1.406477058579774] | 9.5963 [8.829635621435555, 9.708299914511478] | pass | target not established |
| full | `math_regular_j-zero-one_scale20_one_shot_x1` | 2.1231 [1.987612021484291, 2.2013406587572555] | 2.6557 [2.3228674868914068, 2.7473608446649855] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale20_repeated_x8192` | 2.0815 [2.0761532615762226, 2.101069306115632] | 1.2669 [1.2322952304942871, 1.2735454074660526] | pass | target not established |
| full | `math_regular_j-zero-one_scale100_one_shot_x1` | 1.9821 [1.876289046462353, 2.109663893417889] | 2.5490 [2.2460335167146646, 2.6261706125729014] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale100_repeated_x4096` | 1.3060 [1.2846103737576688, 1.3281795893120736] | 1.5964 [1.5739874749924079, 1.6132710422685055] | pass | target not established |
| full | `math_regular_j-zero-one_scale1000_one_shot_x1` | 2.9844 [2.925100906138852, 3.0137814995649395] | 5.5014 [5.263719544112612, 5.697457926779701] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale1000_repeated_x256` | 3.8147 [3.704763985561464, 3.8541524670201817] | 10.3725 [10.196674818031708, 10.433106864147014] | pass | target not established |
| full | `math_turning_j-turning_scale20_one_shot_x1` | 2.0849 [1.9918955484375869, 2.1203468317120584] | 2.5869 [2.4255939454360926, 2.6756121308248995] | inconclusive | one-shot latency observation |
| full | `math_turning_j-turning_scale20_repeated_x4096` | 3.1642 [3.147704539657959, 3.18440160348309] | 1.4515 [1.4362525778461672, 1.458849580850743] | pass | target not established |
| full | `math_turning_j-turning_scale100_one_shot_x1` | 2.1334 [2.0722822287138727, 2.189047852651325] | 2.6625 [2.4504557807391953, 2.7599764098731194] | inconclusive | one-shot latency observation |
| full | `math_turning_j-turning_scale100_repeated_x1024` | 2.0170 [2.0086013589154934, 2.0373960223206935] | 1.8864 [1.8399933452224628, 1.9129066346057266] | pass | target not established |
| full | `math_turning_j-turning_scale1000_one_shot_x1` | 3.7294 [3.5934501023605923, 3.751931384028317] | 7.0221 [6.650561502709733, 7.266616401394969] | pass | one-shot latency observation |
| full | `math_turning_j-turning_scale1000_repeated_x128` | 4.4912 [4.255748788076107, 4.601707088292886] | 10.8476 [10.773394125672779, 11.223767433691814] | pass | target not established |
| full | `math_order_dominates_j-order-dominates_scale20_one_shot_x1` | 1.9518 [1.8147611073969336, 2.006576805693852] | 2.5753 [2.1591419598675547, 2.713080555976636] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale20_repeated_x131072` | 0.0715 [0.07025553961303177, 0.07428685612375359] | 1.5782 [1.5524857467043403, 1.6353794520667513] | pass | target observed |
| full | `math_order_dominates_j-order-dominates_scale100_one_shot_x1` | 1.9201 [1.8831359780817774, 2.0131927545936716] | 2.6085 [2.4812651231815877, 2.6750517765573054] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale100_repeated_x2048` | 1.5412 [1.5280810954094104, 1.54300785102983] | 1.5699 [1.5568225699379408, 1.5785501458005726] | pass | target not established |
| full | `math_order_dominates_j-order-dominates_scale1000_one_shot_x1` | 3.5895 [3.5202680957209944, 3.7222619042480916] | 5.8129 [5.604541377370573, 6.1151128594976125] | pass | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale1000_repeated_x256` | 5.4704 [5.435285328738176, 5.576994479240142] | 10.3636 [10.314778484815372, 10.416156740381188] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale20_one_shot_x1` | 2.9432 [2.872144888275235, 2.968903688618895] | 1.7541 [1.6973958748496234, 1.766145599875947] | inconclusive | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale20_repeated_x1024` | 9.7628 [9.622866579236865, 10.083794552725438] | 1.1344 [1.1149299027932849, 1.156651213300183] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale100_one_shot_x1` | 3.0572 [2.89568585085747, 3.0786038840868075] | 2.8836 [2.6812945604106937, 2.9583242705125854] | inconclusive | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale100_repeated_x512` | 6.7973 [6.671197738136685, 6.981044257954449] | 3.1823 [3.0928837827853646, 3.293308094526324] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale1000_one_shot_x1` | 6.0389 [5.84028040662825, 6.1633397978399955] | 9.5185 [9.388217826699627, 10.298273947516265] | pass | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale1000_repeated_x64` | 7.1861 [7.004075784030464, 7.363712793854566] | 12.6973 [12.180936996372031, 12.955623249253694] | pass | target not established |
| full | `math_near_root_j-near-root_scale20_one_shot_x1` | 2.0698 [1.993714966061419, 2.1237005706476126] | 2.5780 [2.2349796761109277, 2.6443311457179517] | pass | one-shot latency observation |
| full | `math_near_root_j-near-root_scale20_repeated_x8192` | 6.4465 [6.412075985055702, 6.544796514247075] | 1.5802 [1.5614051697679023, 1.5902962333712396] | pass | target not established |
| full | `math_near_root_j-near-root_scale100_one_shot_x1` | 2.1036 [1.911335991248826, 2.207315746904466] | 2.5970 [2.4998462797360084, 2.879705738502184] | inconclusive | one-shot latency observation |
| full | `math_near_root_j-near-root_scale100_repeated_x2048` | 2.8987 [2.878737701354834, 2.9568073032058018] | 1.9758 [1.9267091801120535, 1.993754754870737] | pass | target not established |
| full | `math_near_root_j-near-root_scale1000_one_shot_x1` | 2.7572 [2.7311480618955626, 2.808964566096224] | 4.8517 [4.6918268845971465, 5.016566757074264] | pass | one-shot latency observation |
| full | `math_near_root_j-near-root_scale1000_repeated_x128` | 3.1941 [3.1600192869243258, 3.240337306120004] | 6.5998 [6.460375509434409, 6.748114474430782] | pass | target not established |
| holdout | `math_regular_held-s-nine-eighths_scale20_one_shot_x1` | 2.0290 [1.76199348921496, 2.126482076374656] | 2.4855 [2.42527359952552, 2.626425032699811] | pass | one-shot latency observation |
| holdout | `math_regular_held-s-nine-eighths_scale20_repeated_x16384` | 8.5184 [8.496777434542786, 8.774669482226614] | 0.9918 [0.9676437370089833, 1.0297665441734576] | pass | target not established |
| holdout | `math_regular_held-s-nine-eighths_scale100_one_shot_x1` | 1.8741 [1.763303025724633, 2.0171627658225115] | 2.2619 [2.144007458679549, 2.3983368814276327] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-s-nine-eighths_scale100_repeated_x1024` | 1.6435 [1.6359491286682006, 1.6659987184099423] | 1.2524 [1.2422550477632197, 1.2540000457753666] | pass | target not established |
| holdout | `math_regular_held-s-nine-eighths_scale1000_one_shot_x1` | 1.0745 [1.0627448894801135, 1.078283247831607] | 1.6065 [1.5791479503270547, 1.6141599834716902] | pass | one-shot latency observation |
| holdout | `math_regular_held-s-nine-eighths_scale1000_repeated_x16` | 1.0251 [1.02133256181221, 1.0323151286842842] | 1.5534 [1.5380086507858484, 1.56363876677918] | pass | target not established |
| holdout | `math_regular_held-c-nine-eighths_scale20_one_shot_x1` | 2.0557 [1.98118561111132, 2.1626084336987494] | 2.5540 [2.3925103172982642, 2.597164393965348] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-c-nine-eighths_scale20_repeated_x16384` | 7.7379 [7.629589998033581, 7.83374572994107] | 0.9966 [0.9735666674806822, 1.002364232095038] | pass | target not established |
| holdout | `math_regular_held-c-nine-eighths_scale100_one_shot_x1` | 1.6899 [1.6196243285539207, 1.71738213620998] | 2.3565 [2.065924175498386, 2.3911619135027773] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-c-nine-eighths_scale100_repeated_x512` | 0.7205 [0.7068793093222282, 0.7259097948996757] | 1.2539 [1.2460283797411142, 1.2652135493287349] | pass | target observed |
| holdout | `math_regular_held-c-nine-eighths_scale1000_one_shot_x1` | 0.4312 [0.42785384653834563, 0.4362926089385456] | 1.6280 [1.6026288243688622, 1.6382270656744653] | pass | one-shot latency observation |
| holdout | `math_regular_held-c-nine-eighths_scale1000_repeated_x16` | 0.3900 [0.38383781149474744, 0.3924164100126592] | 1.5525 [1.543208229554663, 1.5687895887211045] | pass | target observed |
| holdout | `math_regular_held-a-nine-eighths_scale20_one_shot_x1` | 2.1471 [1.9928870813211361, 2.162701163921995] | 2.4709 [2.1238144645904886, 2.5518460769206115] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-a-nine-eighths_scale20_repeated_x16384` | 8.7762 [8.690231709385886, 8.841867636940732] | 0.9154 [0.8964455456901251, 0.9254571237058326] | pass | target not established |
| holdout | `math_regular_held-a-nine-eighths_scale100_one_shot_x1` | 2.1526 [1.990138529270032, 2.1922536790580556] | 2.2821 [2.1791678292352454, 2.3839071285845805] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-a-nine-eighths_scale100_repeated_x2048` | 3.6712 [3.6533294272163417, 3.7498163758110925] | 1.1466 [1.1334506262941653, 1.149585011976623] | pass | target not established |
| holdout | `math_regular_held-a-nine-eighths_scale1000_one_shot_x1` | 3.4398 [3.4100412362527073, 3.4760930608436986] | 1.2494 [1.2367055584053046, 1.2649993219094644] | pass | one-shot latency observation |
| holdout | `math_regular_held-a-nine-eighths_scale1000_repeated_x16` | 3.7143 [3.704114218320184, 3.717704671224662] | 1.2034 [1.194276719538725, 1.2066307057869357] | pass | target not established |
| holdout | `math_regular_held-l-nine-fourths_scale20_one_shot_x1` | 2.0414 [1.9357312741269908, 2.16238447761954] | 2.6859 [2.520526957609899, 2.980378513320978] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-l-nine-fourths_scale20_repeated_x8192` | 2.1558 [2.1423884590258124, 2.1767116856572626] | 0.8848 [0.8610744676590323, 0.8905168423257124] | pass | target not established |
| holdout | `math_regular_held-l-nine-fourths_scale100_one_shot_x1` | 2.0439 [1.9459801776943924, 2.075099807953373] | 2.4675 [2.1668778569743665, 2.586542931927597] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-l-nine-fourths_scale100_repeated_x2048` | 1.6221 [1.6186514912353007, 1.6342720684503838] | 0.9882 [0.9685787064401741, 1.0456249311668635] | pass | target not established |
| holdout | `math_regular_held-l-nine-fourths_scale1000_one_shot_x1` | 3.9535 [3.9003014074209617, 3.974284009187828] | 1.3429 [1.3170129539548407, 1.3458831216688945] | pass | one-shot latency observation |
| holdout | `math_regular_held-l-nine-fourths_scale1000_repeated_x64` | 5.2138 [5.208192138362831, 5.217957051869867] | 1.2288 [1.1931729305346623, 1.2324440982389742] | pass | target not established |
| holdout | `math_regular_held-e-nine-eighths_scale20_one_shot_x1` | 1.9730 [1.8670652013171536, 2.0820557542466887] | 2.4929 [2.2296341250960148, 2.632490881674435] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-e-nine-eighths_scale20_repeated_x8192` | 1.6965 [1.6741178577493445, 1.721313336590102] | 1.2596 [1.2451894519664757, 1.26684627450002] | pass | target not established |
| holdout | `math_regular_held-e-nine-eighths_scale100_one_shot_x1` | 1.9436 [1.8010414107883863, 2.1422019194422273] | 2.6725 [2.3954008758110046, 2.820455447647213] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-e-nine-eighths_scale100_repeated_x4096` | 1.2744 [1.2685300912044741, 1.2984587842298951] | 1.6109 [1.6028024774386953, 1.6298063568240373] | pass | target not established |
| holdout | `math_regular_held-e-nine-eighths_scale1000_one_shot_x1` | 1.6261 [1.530967342150818, 1.6497249848653068] | 5.5902 [5.425644660376378, 5.715077133399595] | pass | one-shot latency observation |
| holdout | `math_regular_held-e-nine-eighths_scale1000_repeated_x256` | 1.5450 [1.5402168988235323, 1.5471694498782786] | 9.3737 [9.359323443295029, 9.397969379385724] | pass | target not established |
| holdout | `math_regular_held-j-one-nine-eighths_scale20_one_shot_x1` | 2.0860 [2.00389625933181, 2.1835835216028596] | 2.5544 [2.168268668540125, 2.6692464053384986] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-j-one-nine-eighths_scale20_repeated_x16384` | 2.4123 [2.3914798033350424, 2.4176220303330798] | 1.2382 [1.2334000073019054, 1.2509656192740144] | pass | target not established |
| holdout | `math_regular_held-j-one-nine-eighths_scale100_one_shot_x1` | 2.0605 [1.9861352921069597, 2.137721596310784] | 2.5571 [2.2542825249073415, 2.660073368329186] | pass | one-shot latency observation |
| holdout | `math_regular_held-j-one-nine-eighths_scale100_repeated_x4096` | 1.4490 [1.4356003405570048, 1.4656377973016605] | 1.6295 [1.6136505468456277, 1.6623609855732921] | pass | target not established |
| holdout | `math_regular_held-j-one-nine-eighths_scale1000_one_shot_x1` | 3.0534 [2.992426558770449, 3.085463357469614] | 5.5932 [5.453152370972515, 5.752129971677538] | pass | one-shot latency observation |
| holdout | `math_regular_held-j-one-nine-eighths_scale1000_repeated_x256` | 3.9189 [3.9038741220139723, 3.923737143667985] | 10.2584 [10.193399875844001, 10.294480954454762] | pass | target not established |
| holdout | `math_turning_held-j-turning23_scale20_one_shot_x1` | 2.0347 [1.9659349865712765, 2.0873779391730225] | 2.6035 [2.388839767964582, 2.6205075415252983] | inconclusive | one-shot latency observation |
| holdout | `math_turning_held-j-turning23_scale20_repeated_x4096` | 3.3323 [3.312637185424932, 3.413741536360806] | 1.4438 [1.397190114840508, 1.4502048985812226] | pass | target not established |
| holdout | `math_turning_held-j-turning23_scale100_one_shot_x1` | 2.1558 [1.6967294269542244, 2.2095698037393956] | 2.7136 [2.581661195930923, 2.885263735903838] | inconclusive | one-shot latency observation |
| holdout | `math_turning_held-j-turning23_scale100_repeated_x1024` | 2.2742 [2.265618952814604, 2.2786453225765237] | 2.0033 [1.9757590797384283, 2.0119088985784943] | pass | target not established |
| holdout | `math_turning_held-j-turning23_scale1000_one_shot_x1` | 3.8215 [3.7719373165521928, 3.8554393573867625] | 7.3940 [7.318734476413769, 7.516303176963151] | pass | one-shot latency observation |
| holdout | `math_turning_held-j-turning23_scale1000_repeated_x128` | 4.5621 [4.45913638464933, 4.59909309803141] | 10.9882 [10.690321618169188, 11.069806555531864] | pass | target not established |
| holdout | `math_order_dominates_held-j-order113_scale20_one_shot_x1` | 1.9164 [1.7809371706884387, 1.967300424498848] | 2.6400 [2.2001134136390808, 2.7374128883331883] | inconclusive | one-shot latency observation |
| holdout | `math_order_dominates_held-j-order113_scale20_repeated_x131072` | 0.0597 [0.057849652036806185, 0.060567596436718045] | 1.4228 [1.376338529198114, 1.4372573715383345] | pass | target observed |
| holdout | `math_order_dominates_held-j-order113_scale100_one_shot_x1` | 1.9365 [1.8505687070281562, 2.0211240053953836] | 2.6446 [2.438298832010887, 2.705096361045037] | inconclusive | one-shot latency observation |
| holdout | `math_order_dominates_held-j-order113_scale100_repeated_x2048` | 1.5426 [1.5378114250091344, 1.5568511043001594] | 1.5355 [1.522066653325521, 1.5461374618454178] | pass | target not established |
| holdout | `math_order_dominates_held-j-order113_scale1000_one_shot_x1` | 3.8293 [3.7253997895441695, 3.8513018449695933] | 5.6314 [5.5087098577267, 5.863330503197075] | pass | one-shot latency observation |
| holdout | `math_order_dominates_held-j-order113_scale1000_repeated_x256` | 5.8223 [5.740824629328373, 5.9514807535489105] | 9.7906 [9.685012910906433, 9.858726779274543] | pass | target not established |
| holdout | `math_argument_dominates_held-j-argument112_scale20_one_shot_x1` | 2.9593 [2.93245338195931, 3.005157265485539] | 1.6756 [1.6346083611659963, 1.7079483489997527] | inconclusive | one-shot latency observation |
| holdout | `math_argument_dominates_held-j-argument112_scale20_repeated_x1024` | 9.4128 [9.31771410986509, 9.476243848582277] | 1.0955 [1.0791006631862827, 1.1016479858042063] | pass | target not established |
| holdout | `math_argument_dominates_held-j-argument112_scale100_one_shot_x1` | 3.2735 [3.1773042443476256, 3.3479566534593306] | 2.9562 [2.7007588917614864, 2.9897123150874645] | inconclusive | one-shot latency observation |
| holdout | `math_argument_dominates_held-j-argument112_scale100_repeated_x512` | 7.4395 [7.3056178474292155, 7.461185933110077] | 3.1885 [3.1593546493150884, 3.224132676810415] | pass | target not established |
| holdout | `math_argument_dominates_held-j-argument112_scale1000_one_shot_x1` | 6.2375 [6.102241833672523, 6.336363016867328] | 9.5288 [9.093652875754836, 9.73324222896819] | pass | one-shot latency observation |
| holdout | `math_argument_dominates_held-j-argument112_scale1000_repeated_x64` | 7.3489 [7.2961658731260695, 7.403148681796984] | 11.8419 [11.794524398502825, 12.140048122704163] | pass | target not established |
| holdout | `math_near_root_held-j-one-near-root_scale20_one_shot_x1` | 2.0966 [1.9792572275026237, 2.1680586477106547] | 2.4751 [2.1816107970906793, 2.62150203408831] | inconclusive | one-shot latency observation |
| holdout | `math_near_root_held-j-one-near-root_scale20_repeated_x8192` | 6.5267 [6.489543762160052, 6.613319856220591] | 1.5445 [1.535282566282081, 1.5957919127276128] | pass | target not established |
| holdout | `math_near_root_held-j-one-near-root_scale100_one_shot_x1` | 2.1170 [2.0504443510694834, 2.2059632184385967] | 2.5534 [2.449811189087657, 2.872599637516922] | inconclusive | one-shot latency observation |
| holdout | `math_near_root_held-j-one-near-root_scale100_repeated_x2048` | 2.7083 [2.6985709603038943, 2.719541192449387] | 1.8479 [1.8348393598959043, 1.8511843459900204] | pass | target not established |
| holdout | `math_near_root_held-j-one-near-root_scale1000_one_shot_x1` | 2.8768 [2.8581864930502374, 2.897505492964651] | 5.0348 [4.902347006268491, 5.13805160483342] | inconclusive | one-shot latency observation |
| holdout | `math_near_root_held-j-one-near-root_scale1000_repeated_x128` | 3.3189 [3.257584826146428, 3.3372004407525377] | 6.7940 [6.742107607553989, 6.957139438638955] | pass | target not established |

Whole-process samples include library loading, parsing and constant generation.
Repeated cases share a frozen calibrated invocation count across every role.
One-shot rows report latency without a substantive-duration speed target.
No aggregate pass is inferred. Instruction, allocation and peak-memory diagnostics
remain separate work; a green workflow alone does not establish acceptance.
