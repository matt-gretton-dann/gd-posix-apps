# Native ordinary-library comparisons

Ratios below one favor GD. Each row retains its own regime, scale and mode.
Intervals are the union of paired IID and circular-block intervals; small samples
and nonstationary host noise remain limitations. This report is advisory.

| Corpus | Workload | GD / standard [CI] | GD / portable [CI] | A/A | Observation |
|---|---|---|---|---|---|
| full | `math_regular_s-one_scale20_one_shot_x1` | 1.2009 [1.1712955642082599, 1.3224274888536423] | 1.3038 [1.2630915010705253, 1.4132632941364993] | inconclusive | one-shot latency observation |
| full | `math_regular_s-one_scale20_repeated_x8192` | 8.7592 [8.519551108395346, 8.827963066897736] | 0.9421 [0.914836745239107, 0.9671879995424599] | inconclusive | insufficient measured duration |
| full | `math_regular_s-one_scale100_one_shot_x1` | 1.2485 [1.1794767838667497, 1.3206987457224622] | 1.2993 [1.237484682726162, 1.3543797049485036] | inconclusive | one-shot latency observation |
| full | `math_regular_s-one_scale100_repeated_x512` | 1.5275 [1.4666304684976192, 1.5416688281166635] | 1.2327 [1.1834824924527472, 1.2395567065823103] | pass | target not established |
| full | `math_regular_s-one_scale1000_one_shot_x1` | 1.3099 [1.2406930645499097, 1.341562291321631] | 1.8318 [1.7609998453725424, 1.8536429772301322] | inconclusive | one-shot latency observation |
| full | `math_regular_s-one_scale1000_repeated_x8` | 1.3356 [1.3322549064995575, 1.3423466427343744] | 1.9229 [1.8652478586386887, 1.9350882373023193] | pass | target not established |
| full | `math_regular_c-one_scale20_one_shot_x1` | 1.2523 [1.185294655520884, 1.269002449914127] | 1.2509 [1.1911489740285335, 1.4502949841789166] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale20_repeated_x8192` | 7.6007 [7.354171150560385, 7.747636338165343] | 0.9615 [0.8762974239382985, 1.0103460820561303] | inconclusive | insufficient measured duration |
| full | `math_regular_c-one_scale100_one_shot_x1` | 1.1406 [1.1237688895933036, 1.1761877259252616] | 1.2593 [1.2226117210638865, 1.3754551296841335] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale100_repeated_x512` | 0.7064 [0.6789847036371006, 0.7280549117512387] | 1.2278 [1.2013103844808974, 1.2567622845286177] | inconclusive | target observed; A/A inconclusive |
| full | `math_regular_c-one_scale1000_one_shot_x1` | 0.5322 [0.5179878368085977, 0.5375194503235795] | 1.8386 [1.7695303093335693, 1.8614905180012233] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale1000_repeated_x8` | 0.4905 [0.4832423050004081, 0.49674389242968015] | 1.8928 [1.8468480368094355, 1.9370326046958914] | inconclusive | target observed; A/A inconclusive |
| full | `math_regular_a-one_scale20_one_shot_x1` | 1.2262 [1.2010419984687393, 1.2611780037080216] | 1.2947 [1.257456196519824, 1.3301167825824036] | inconclusive | one-shot latency observation |
| full | `math_regular_a-one_scale20_repeated_x131072` | 40.6861 [39.425983485310496, 42.632212813768035] | 0.8237 [0.8070289334812653, 0.8382000733975196] | inconclusive | target not established |
| full | `math_regular_a-one_scale100_one_shot_x1` | 1.2096 [1.1614487919121894, 1.2970322635459544] | 1.3594 [1.189187600410158, 1.3676124506849647] | inconclusive | one-shot latency observation |
| full | `math_regular_a-one_scale100_repeated_x1024` | 1.0965 [1.086159833258142, 1.115253529603119] | 1.0121 [1.0038310828351673, 1.0286018203227507] | inconclusive | target not established |
| full | `math_regular_a-one_scale1000_one_shot_x1` | 1.3493 [1.3279923726558074, 1.3746694551426508] | 1.4216 [1.4049644175018094, 1.4301950983938072] | inconclusive | one-shot latency observation |
| full | `math_regular_a-one_scale1000_repeated_x8` | 1.3758 [1.3452696636018053, 1.3849158939138009] | 1.4543 [1.412462338913146, 1.4618529931894406] | inconclusive | target not established |
| full | `math_regular_l-two_scale20_one_shot_x1` | 1.2185 [1.1348292421510535, 1.291358128649844] | 1.3170 [1.2091006192975284, 1.4379759595202122] | inconclusive | one-shot latency observation |
| full | `math_regular_l-two_scale20_repeated_x8192` | 2.0742 [2.0506277951970193, 2.141001176817986] | 0.8988 [0.8821466473754703, 0.9281984720599692] | inconclusive | target not established |
| full | `math_regular_l-two_scale100_one_shot_x1` | 1.2145 [1.1548180765862814, 1.2843204490293452] | 1.2381 [1.1960915915634625, 1.2982719564364873] | inconclusive | one-shot latency observation |
| full | `math_regular_l-two_scale100_repeated_x1024` | 1.5737 [1.5665605176436859, 1.5866203790969071] | 1.1049 [1.075602313793472, 1.1156380278810358] | pass | insufficient measured duration |
| full | `math_regular_l-two_scale1000_one_shot_x1` | 1.3537 [1.3359156160626255, 1.385628851698218] | 1.4889 [1.4332064481063758, 1.5372341053734115] | inconclusive | one-shot latency observation |
| full | `math_regular_l-two_scale1000_repeated_x8` | 1.3957 [1.3752258932852457, 1.4055740984139542] | 1.5579 [1.541685221475563, 1.567643991610234] | pass | insufficient measured duration |
| full | `math_regular_e-one_scale20_one_shot_x1` | 1.2104 [1.175190068142585, 1.2661475235698358] | 1.3081 [1.2249698213717737, 1.3828988977056922] | inconclusive | one-shot latency observation |
| full | `math_regular_e-one_scale20_repeated_x8192` | 1.6216 [1.5930755005864483, 1.6302062481244335] | 1.1583 [1.127311666089557, 1.2041896735141226] | pass | target not established |
| full | `math_regular_e-one_scale100_one_shot_x1` | 1.2554 [1.1568420075260735, 1.3535135979897799] | 1.2843 [1.2493695270219358, 1.4373510596088952] | inconclusive | one-shot latency observation |
| full | `math_regular_e-one_scale100_repeated_x2048` | 1.1839 [1.1649974491376205, 1.207343187984612] | 1.5945 [1.5490435757171797, 1.5999530194690694] | inconclusive | target not established |
| full | `math_regular_e-one_scale1000_one_shot_x1` | 1.4524 [1.3939957582441944, 1.5030022163376309] | 3.4443 [3.387453915068381, 3.574102488410896] | inconclusive | one-shot latency observation |
| full | `math_regular_e-one_scale1000_repeated_x128` | 1.5813 [1.5358430806604246, 1.6368329117060947] | 10.4594 [10.20610366650649, 10.991067062917683] | inconclusive | target not established |
| full | `math_regular_j-zero-one_scale20_one_shot_x1` | 1.2686 [1.1475725500691385, 1.3368082557493948] | 1.3326 [1.2368990232278327, 1.3843010461491398] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale20_repeated_x8192` | 1.9897 [1.9585702355101775, 2.05016136292583] | 1.1466 [1.1397269580567584, 1.1580315976037925] | inconclusive | target not established |
| full | `math_regular_j-zero-one_scale100_one_shot_x1` | 1.1849 [1.1189015216928746, 1.309674989244702] | 1.3064 [1.197269452045465, 1.3278630508665974] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale100_repeated_x2048` | 1.3291 [1.2993137272694966, 1.3424467171862258] | 1.5693 [1.3809892441410851, 1.5925452317816522] | inconclusive | target not established |
| full | `math_regular_j-zero-one_scale1000_one_shot_x1` | 2.2809 [2.192762811566512, 2.3892458728316814] | 3.0253 [2.890595012830831, 3.0686509027093014] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale1000_repeated_x128` | 4.3688 [4.0541297997237224, 4.394261278818217] | 10.6665 [10.243091355881893, 11.042600676192075] | inconclusive | insufficient measured duration |
| full | `math_turning_j-turning_scale20_one_shot_x1` | 1.2939 [1.207584604468822, 1.3981064703392234] | 1.3964 [1.343872914978099, 1.4217182524872451] | inconclusive | one-shot latency observation |
| full | `math_turning_j-turning_scale20_repeated_x2048` | 3.2471 [3.1782966470884357, 3.313630243532762] | 1.4424 [1.4046431387619516, 1.4858848624434584] | pass | insufficient measured duration |
| full | `math_turning_j-turning_scale100_one_shot_x1` | 1.2206 [1.1877859076123607, 1.3253373184793404] | 1.3755 [1.3607708189356296, 1.4184041763498851] | inconclusive | one-shot latency observation |
| full | `math_turning_j-turning_scale100_repeated_x1024` | 2.1704 [2.136571610488254, 2.2165536986992187] | 1.9937 [1.9812640134413664, 2.0311999303935595] | pass | target not established |
| full | `math_turning_j-turning_scale1000_one_shot_x1` | 3.1641 [3.064178680444911, 3.186836521437638] | 4.6096 [4.173380744510107, 4.874449408127913] | inconclusive | one-shot latency observation |
| full | `math_turning_j-turning_scale1000_repeated_x64` | 5.2508 [5.05589708803754, 5.437957856083345] | 11.1612 [11.072228559860031, 11.266173477511428] | inconclusive | target not established |
| full | `math_order_dominates_j-order-dominates_scale20_one_shot_x1` | 1.1849 [1.1605205553304043, 1.2387699985728151] | 1.2567 [1.2365498721164851, 1.3054398098140956] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale20_repeated_x65536` | 0.0578 [0.057198409348792584, 0.0600195734103904] | 1.2742 [1.2183730081726376, 1.3354429839610686] | inconclusive | target observed; A/A inconclusive |
| full | `math_order_dominates_j-order-dominates_scale100_one_shot_x1` | 1.2097 [1.0917844609859868, 1.3175210404970221] | 1.3320 [1.2423549066493964, 1.3520393200496617] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale100_repeated_x2048` | 1.5938 [1.5572286292399822, 1.616243287758177] | 1.6509 [1.610514000743903, 1.6854142686949825] | inconclusive | target not established |
| full | `math_order_dominates_j-order-dominates_scale1000_one_shot_x1` | 2.6603 [2.441444769383638, 2.900119654211213] | 3.3567 [3.0408001181522426, 3.5762371854307506] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale1000_repeated_x128` | 6.5320 [6.3181022855858355, 6.55263946709912] | 11.6949 [10.69377585784019, 12.044450208765308] | inconclusive | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale20_one_shot_x1` | 1.6650 [1.618650772452547, 1.7011948808865618] | 1.3019 [1.209321205918888, 1.3575908462546578] | inconclusive | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale20_repeated_x512` | 9.4149 [9.352313694235583, 9.663942936190118] | 1.2149 [1.1502899150635837, 1.273343072183085] | inconclusive | insufficient measured duration |
| full | `math_argument_dominates_j-argument-dominates_scale100_one_shot_x1` | 1.8055 [1.6533938931067678, 1.9071696568153744] | 1.7072 [1.6169902776949987, 1.7926117512609316] | inconclusive | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale100_repeated_x256` | 7.3827 [7.292974983923422, 7.427821441949582] | 3.1600 [3.135092119534312, 3.21350386873722] | inconclusive | insufficient measured duration |
| full | `math_argument_dominates_j-argument-dominates_scale1000_one_shot_x1` | 5.8500 [5.627374208337191, 6.0958958147122795] | 8.0151 [7.292026561913097, 8.432538742001725] | inconclusive | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale1000_repeated_x32` | 8.6901 [8.511731081078597, 8.942994594238309] | 13.8257 [13.766491576416556, 13.932217970957506] | inconclusive | target not established |
| full | `math_near_root_j-near-root_scale20_one_shot_x1` | 1.2414 [1.1854013568366504, 1.2748500879732019] | 1.2839 [1.2177008441428199, 1.3116457829682828] | inconclusive | one-shot latency observation |
| full | `math_near_root_j-near-root_scale20_repeated_x4096` | 6.6981 [6.467781842919688, 7.006511325286573] | 1.6438 [1.5975145169842149, 1.653450153144325] | inconclusive | insufficient measured duration |
| full | `math_near_root_j-near-root_scale100_one_shot_x1` | 1.2579 [1.2024073674204097, 1.3138882759987807] | 1.3825 [1.3083440279681575, 1.4274569895237161] | inconclusive | one-shot latency observation |
| full | `math_near_root_j-near-root_scale100_repeated_x1024` | 3.1388 [3.0380642448223263, 3.155939032094796] | 2.1508 [2.115384054348955, 2.1670076903148234] | pass | insufficient measured duration |
| full | `math_near_root_j-near-root_scale1000_one_shot_x1` | 2.3823 [2.3417068279701185, 2.449685976050727] | 3.3484 [3.18094542021149, 3.532599410095612] | inconclusive | one-shot latency observation |
| full | `math_near_root_j-near-root_scale1000_repeated_x64` | 3.9431 [3.8614970515067246, 4.12161947954196] | 7.9065 [7.732605827715103, 8.252768786733089] | inconclusive | insufficient measured duration |
| holdout | `math_regular_held-s-nine-eighths_scale20_one_shot_x1` | 1.2630 [1.0356670774187489, 1.3834429799047794] | 1.1828 [0.9988994282262289, 1.365898313877499] | pass | one-shot latency observation |
| holdout | `math_regular_held-s-nine-eighths_scale20_repeated_x16384` | 9.5635 [8.793394521230995, 9.815226449069396] | 0.9747 [0.9290847969528185, 1.0292913559910386] | pass | target not established |
| holdout | `math_regular_held-s-nine-eighths_scale100_one_shot_x1` | 1.2063 [1.093633279576747, 1.6391098867122846] | 1.2951 [1.265099413295369, 1.7480379631189282] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-s-nine-eighths_scale100_repeated_x512` | 1.6030 [1.5210527573158505, 1.6445979379736253] | 1.2781 [1.232646044026517, 1.3043050235549307] | pass | target not established |
| holdout | `math_regular_held-s-nine-eighths_scale1000_one_shot_x1` | 1.2927 [1.255619261527268, 1.3258548070236282] | 1.7736 [1.7106551473012743, 1.8186670439844235] | pass | one-shot latency observation |
| holdout | `math_regular_held-s-nine-eighths_scale1000_repeated_x8` | 1.2895 [1.2217122275386834, 1.3872895214927259] | 1.7893 [1.7054986937493612, 1.9654528608015265] | pass | target not established |
| holdout | `math_regular_held-c-nine-eighths_scale20_one_shot_x1` | 1.2684 [1.0857397764489978, 1.3066545003642023] | 1.2425 [0.9994699965669572, 1.3072716795169814] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-c-nine-eighths_scale20_repeated_x8192` | 8.3310 [7.731186664112909, 8.727961669286607] | 0.9353 [0.860218017928748, 0.9958890823040575] | pass | target not established |
| holdout | `math_regular_held-c-nine-eighths_scale100_one_shot_x1` | 1.0928 [1.019118182655463, 1.1751409921616323] | 1.3034 [1.1362932835948008, 1.3805698489778888] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-c-nine-eighths_scale100_repeated_x512` | 0.7719 [0.7300010256543381, 0.7972853328414399] | 1.2486 [1.1984457327346383, 1.2877824038322845] | pass | target observed |
| holdout | `math_regular_held-c-nine-eighths_scale1000_one_shot_x1` | 0.5307 [0.5049270898162976, 0.5387143865655503] | 1.6881 [1.5693976015124083, 1.8082218992533923] | pass | one-shot latency observation |
| holdout | `math_regular_held-c-nine-eighths_scale1000_repeated_x8` | 0.4859 [0.4611830041393294, 0.5015546205379997] | 1.8623 [1.727785827077701, 1.888784320974931] | pass | target observed |
| holdout | `math_regular_held-a-nine-eighths_scale20_one_shot_x1` | 1.2912 [1.190502154312182, 1.4834242963687159] | 1.2759 [1.1474326385085736, 1.406634396079351] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-a-nine-eighths_scale20_repeated_x8192` | 9.1136 [8.480117858171232, 9.320192812097797] | 0.8306 [0.794016684856948, 0.8938880647504811] | inconclusive | target not established |
| holdout | `math_regular_held-a-nine-eighths_scale100_one_shot_x1` | 1.3854 [1.2748955014816195, 1.8778142555370998] | 1.3978 [1.225629335392823, 1.8952192418716007] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-a-nine-eighths_scale100_repeated_x1024` | 3.2932 [3.1875438295223124, 3.422232189428957] | 1.0576 [1.01134026949328, 1.1136983155006774] | pass | target not established |
| holdout | `math_regular_held-a-nine-eighths_scale1000_one_shot_x1` | 3.4241 [3.2669551673850257, 3.5371149683220207] | 1.4323 [1.31117615442635, 1.5132420372863875] | pass | one-shot latency observation |
| holdout | `math_regular_held-a-nine-eighths_scale1000_repeated_x16` | 4.6142 [4.3771216495701815, 4.775456899290056] | 1.4585 [1.3280590048032614, 1.5205776389362715] | pass | target not established |
| holdout | `math_regular_held-l-nine-fourths_scale20_one_shot_x1` | 1.1672 [1.083509699229581, 1.2564618812519806] | 1.2540 [1.144538881591568, 1.2930938104007506] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-l-nine-fourths_scale20_repeated_x8192` | 2.3591 [2.25509009252917, 2.457720192381595] | 0.8585 [0.8200854550992915, 0.9035628964428041] | pass | target not established |
| holdout | `math_regular_held-l-nine-fourths_scale100_one_shot_x1` | 1.1986 [0.9667421130589433, 1.255129539295191] | 1.2261 [1.033364133443223, 1.329187535668819] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-l-nine-fourths_scale100_repeated_x2048` | 1.6376 [1.5466489883236607, 1.6770179772029716] | 0.9774 [0.961036286268765, 0.9997145133723613] | inconclusive | target not established |
| holdout | `math_regular_held-l-nine-fourths_scale1000_one_shot_x1` | 2.9595 [2.7172688901863546, 3.178922656309078] | 1.4665 [1.388616229518667, 1.5088946587418868] | pass | one-shot latency observation |
| holdout | `math_regular_held-l-nine-fourths_scale1000_repeated_x64` | 5.3321 [5.173113717167229, 5.391589857961489] | 1.5773 [1.4963640487907022, 1.6080203109713378] | pass | target not established |
| holdout | `math_regular_held-e-nine-eighths_scale20_one_shot_x1` | 1.2129 [1.152501594906044, 1.669659416303621] | 1.2859 [1.036588250287315, 1.344100999210368] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-e-nine-eighths_scale20_repeated_x8192` | 1.6231 [1.5510425325131756, 1.6857679880418328] | 1.1768 [1.1491777633351248, 1.1925359307115269] | pass | target not established |
| holdout | `math_regular_held-e-nine-eighths_scale100_one_shot_x1` | 1.2271 [1.0976509347164431, 1.3058379251248091] | 1.2806 [1.2153232859801295, 1.3416342898617204] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-e-nine-eighths_scale100_repeated_x2048` | 1.2052 [1.1745172096270147, 1.2731392527618295] | 1.6009 [1.531851761589143, 1.6193514269855205] | pass | target not established |
| holdout | `math_regular_held-e-nine-eighths_scale1000_one_shot_x1` | 1.5198 [1.4678974804681184, 1.544758319862978] | 2.9385 [2.6628318359414127, 3.2558712839854147] | pass | one-shot latency observation |
| holdout | `math_regular_held-e-nine-eighths_scale1000_repeated_x128` | 1.6821 [1.5572111737006995, 1.7765333531924383] | 9.9222 [9.746101764493302, 10.547215133585055] | pass | target not established |
| holdout | `math_regular_held-j-one-nine-eighths_scale20_one_shot_x1` | 1.1825 [1.0430130050805362, 1.20486111114244] | 1.2500 [1.1756755470954212, 1.3571603444652904] | pass | one-shot latency observation |
| holdout | `math_regular_held-j-one-nine-eighths_scale20_repeated_x8192` | 2.4658 [2.3515827702677816, 2.54877711766036] | 1.1128 [1.0630076570601135, 1.2141684628500509] | inconclusive | target not established |
| holdout | `math_regular_held-j-one-nine-eighths_scale100_one_shot_x1` | 1.2093 [0.9925090958141809, 1.417950853018345] | 1.3361 [1.117875540201466, 1.4886559147794767] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-j-one-nine-eighths_scale100_repeated_x2048` | 1.4754 [1.3936927180503877, 1.5052562236734979] | 1.6689 [1.6084820944055682, 1.7102334003275566] | inconclusive | target not established |
| holdout | `math_regular_held-j-one-nine-eighths_scale1000_one_shot_x1` | 2.2002 [2.0886350081261913, 2.3128146027674577] | 2.8435 [2.6274909669823865, 3.280224357918447] | pass | one-shot latency observation |
| holdout | `math_regular_held-j-one-nine-eighths_scale1000_repeated_x256` | 4.4510 [4.127469527833006, 4.669094304878888] | 10.2008 [10.05078931431709, 10.542614361607844] | inconclusive | target not established |
| holdout | `math_turning_held-j-turning23_scale20_one_shot_x1` | 1.2287 [1.1595458538816181, 1.4031723888044572] | 1.3776 [1.2739023483769185, 1.4744424111018402] | inconclusive | one-shot latency observation |
| holdout | `math_turning_held-j-turning23_scale20_repeated_x2048` | 3.2155 [3.062782272857824, 3.3755112860118617] | 1.4314 [1.2884091922207623, 1.4481024449370714] | pass | target not established |
| holdout | `math_turning_held-j-turning23_scale100_one_shot_x1` | 1.2169 [1.1242134677292943, 1.419361985226039] | 1.3655 [1.2312778135556275, 1.5290449186603403] | pass | one-shot latency observation |
| holdout | `math_turning_held-j-turning23_scale100_repeated_x1024` | 2.4497 [2.3556377541456524, 2.5476964637534327] | 2.1266 [2.0091904448359457, 2.2355989545558783] | pass | target not established |
| holdout | `math_turning_held-j-turning23_scale1000_one_shot_x1` | 3.0305 [2.88139804597802, 3.043215608576139] | 4.3603 [3.6812299111143294, 4.4940773823673625] | pass | one-shot latency observation |
| holdout | `math_turning_held-j-turning23_scale1000_repeated_x128` | 5.5506 [4.755583474441988, 5.789189962479283] | 11.3435 [10.506253668857687, 12.78739691848963] | pass | target not established |
| holdout | `math_order_dominates_held-j-order113_scale20_one_shot_x1` | 1.2264 [1.1713569766255159, 1.4611425315991844] | 1.3375 [1.222502615278903, 1.5854253790708714] | inconclusive | one-shot latency observation |
| holdout | `math_order_dominates_held-j-order113_scale20_repeated_x65536` | 0.0493 [0.04728216757639728, 0.054411058691749725] | 1.2392 [1.2314371933813328, 1.3570266523361678] | pass | target observed |
| holdout | `math_order_dominates_held-j-order113_scale100_one_shot_x1` | 1.1819 [1.1092527007609332, 1.3447951278559152] | 1.2859 [1.177956982409017, 1.4355491462805294] | inconclusive | one-shot latency observation |
| holdout | `math_order_dominates_held-j-order113_scale100_repeated_x2048` | 1.5997 [1.5299878268357894, 1.6193975023470557] | 1.6337 [1.6019521918863049, 1.6417040947849024] | pass | target not established |
| holdout | `math_order_dominates_held-j-order113_scale1000_one_shot_x1` | 2.5652 [2.331391214588006, 2.936109226141473] | 3.0883 [2.698831334981728, 3.5001751980660534] | pass | one-shot latency observation |
| holdout | `math_order_dominates_held-j-order113_scale1000_repeated_x128` | 6.5675 [6.259516887175419, 6.947744980459469] | 11.0275 [10.163794433050809, 11.356359538684298] | pass | target not established |
| holdout | `math_argument_dominates_held-j-argument112_scale20_one_shot_x1` | 1.6126 [1.4937901295747027, 1.6779930193456558] | 1.2571 [1.2274441790888837, 1.2956924543945607] | pass | one-shot latency observation |
| holdout | `math_argument_dominates_held-j-argument112_scale20_repeated_x512` | 8.9893 [8.164397274251561, 9.820150056185417] | 1.1885 [1.1050025630705183, 1.2043048197424344] | pass | target not established |
| holdout | `math_argument_dominates_held-j-argument112_scale100_one_shot_x1` | 1.8034 [1.6179553243312506, 1.9676307354286315] | 1.7851 [1.7203598532892355, 1.8373621028080678] | inconclusive | one-shot latency observation |
| holdout | `math_argument_dominates_held-j-argument112_scale100_repeated_x512` | 8.4697 [8.26223902973207, 8.710040505001725] | 3.2543 [3.0657192589205065, 3.406648330633164] | pass | target not established |
| holdout | `math_argument_dominates_held-j-argument112_scale1000_one_shot_x1` | 5.6818 [5.406661755437072, 6.091096284795408] | 7.2450 [6.749863132394071, 7.592948059084264] | pass | one-shot latency observation |
| holdout | `math_argument_dominates_held-j-argument112_scale1000_repeated_x32` | 8.8135 [8.226482323631572, 9.092475034079207] | 13.2773 [12.352622111648142, 14.33653406411756] | inconclusive | target not established |
| holdout | `math_near_root_held-j-one-near-root_scale20_one_shot_x1` | 1.2318 [1.147924210098221, 1.365207267117512] | 1.2715 [1.1995182063852248, 1.3146975739614553] | inconclusive | one-shot latency observation |
| holdout | `math_near_root_held-j-one-near-root_scale20_repeated_x4096` | 6.3487 [5.838424273139294, 7.098627713984912] | 1.5796 [1.4409848275114752, 1.6514847427372614] | pass | target not established |
| holdout | `math_near_root_held-j-one-near-root_scale100_one_shot_x1` | 1.3486 [1.243960730688863, 1.5225775172021587] | 1.3971 [1.2394689400352972, 1.5324134324849008] | pass | one-shot latency observation |
| holdout | `math_near_root_held-j-one-near-root_scale100_repeated_x1024` | 2.9565 [2.705707781502347, 3.0892825109523603] | 2.0041 [1.8622445868235655, 2.18009072559408] | pass | target not established |
| holdout | `math_near_root_held-j-one-near-root_scale1000_one_shot_x1` | 2.4131 [2.35091727023223, 2.5236009640659423] | 3.0665 [2.5220308627221883, 3.51450842441041] | pass | one-shot latency observation |
| holdout | `math_near_root_held-j-one-near-root_scale1000_repeated_x64` | 4.2011 [3.989750943579994, 4.521789021248071] | 8.2393 [7.871928336428337, 8.656013510664774] | inconclusive | target not established |

Whole-process samples include library loading, parsing and constant generation.
Repeated cases share a frozen calibrated invocation count across every role.
One-shot rows report latency without a substantive-duration speed target.
No aggregate pass is inferred. Instruction, allocation and peak-memory diagnostics
remain separate work; a green workflow alone does not establish acceptance.
