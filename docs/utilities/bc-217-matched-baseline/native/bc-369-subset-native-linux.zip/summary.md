# Native ordinary-library comparisons

Ratios below one favor GD. Each row retains its own regime, scale and mode.
Intervals are the union of paired IID and circular-block intervals; small samples
and nonstationary host noise remain limitations. This report is advisory.

| Corpus | Workload | GD / standard [CI] | GD / portable [CI] | A/A | Observation |
|---|---|---|---|---|---|
| full | `math_regular_s-one_scale100_one_shot_x1` | 1.8047 [1.768267572607798, 1.840408102490742] | 2.2885 [2.2572410362848228, 2.3719782114645938] | pass | one-shot latency observation |
| full | `math_regular_s-one_scale100_repeated_x1024` | 1.5107 [1.4815601860108771, 1.520475629804004] | 1.2365 [1.2145491348932242, 1.2497504381791278] | pass | target not established |
| full | `math_regular_c-one_scale100_one_shot_x1` | 1.5690 [1.5114473327868554, 1.6333110350401103] | 2.3637 [2.291805002412115, 2.471560963390519] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale100_repeated_x512` | 0.6586 [0.6465804090775715, 0.6676461279227256] | 1.2654 [1.2275593909708458, 1.2822355442899172] | pass | target observed |
| full | `math_regular_a-one_scale100_one_shot_x1` | 1.8455 [1.7724404261469333, 1.8786449707064148] | 2.4136 [2.3602081294559842, 2.4404195418032506] | inconclusive | one-shot latency observation |
| full | `math_regular_a-one_scale100_repeated_x1024` | 1.0335 [1.0145061757030998, 1.054742186569406] | 0.9974 [0.9641711224724137, 1.0121003431929845] | pass | target not established |
| full | `math_regular_l-two_scale100_one_shot_x1` | 1.8715 [1.8198614985611685, 1.9545750015543852] | 2.4017 [2.281119555542685, 2.552699816439008] | pass | one-shot latency observation |
| full | `math_regular_l-two_scale100_repeated_x2048` | 1.4759 [1.448338875167793, 1.5140955362957014] | 1.0562 [1.0369000932064958, 1.096943850604619] | pass | target not established |
| full | `math_regular_e-one_scale100_one_shot_x1` | 1.8111 [1.7531439162461775, 1.8456534429101397] | 2.5240 [2.4697979342180045, 2.5749499967563207] | pass | one-shot latency observation |
| full | `math_regular_e-one_scale100_repeated_x2048` | 1.2788 [1.2371179942880521, 1.2984645087886926] | 1.5575 [1.501335456744951, 1.5751972278659787] | pass | target not established |
| full | `math_regular_j-zero-one_scale100_one_shot_x1` | 1.8503 [1.8171834705603584, 1.884053001366474] | 2.4739 [2.3042289563193163, 2.595706694034529] | pass | one-shot latency observation |
| full | `math_regular_j-zero-one_scale100_repeated_x4096` | 1.3220 [1.2904813109687618, 1.3351395072044245] | 1.5665 [1.529010769606467, 1.6067983841970706] | pass | target not established |
| full | `math_turning_j-turning_scale100_one_shot_x1` | 1.8884 [1.8515582732046423, 1.9685917469031993] | 2.4732 [2.414141484687996, 2.640014402568287] | pass | one-shot latency observation |
| full | `math_turning_j-turning_scale100_repeated_x1024` | 1.9786 [1.9638423370136153, 2.0173133611033003] | 1.8482 [1.8127644037265171, 1.8822093619419482] | pass | target not established |
| full | `math_order_dominates_j-order-dominates_scale100_one_shot_x1` | 1.8119 [1.7581411903641775, 1.8814937487984558] | 2.5463 [2.45930395549658, 2.646444136426115] | pass | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale100_repeated_x2048` | 1.5173 [1.4735484336015576, 1.5264106787422886] | 1.5505 [1.5147618874489164, 1.5626321061545976] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale100_one_shot_x1` | 2.9272 [2.838478216110213, 3.0066183931222823] | 2.8504 [2.7958961150472073, 2.994549067615542] | pass | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale100_repeated_x512` | 6.6037 [6.48092458603408, 6.729037720617217] | 3.1240 [3.0394902996727704, 3.1765385744629455] | pass | target not established |
| full | `math_near_root_j-near-root_scale100_one_shot_x1` | 1.9103 [1.843898834493068, 1.9687603808704723] | 2.4584 [2.4232361980528503, 2.5334480933870775] | pass | one-shot latency observation |
| full | `math_near_root_j-near-root_scale100_repeated_x2048` | 2.7985 [2.7105047344288176, 2.8777700645503748] | 1.9241 [1.8792724639235774, 1.937852375427017] | pass | target not established |

Whole-process samples include library loading, parsing and constant generation.
Repeated cases share a frozen calibrated invocation count across every role.
One-shot rows report latency without a substantive-duration speed target.
No aggregate pass is inferred. Instruction, allocation and peak-memory diagnostics
remain separate work; a green workflow alone does not establish acceptance.
