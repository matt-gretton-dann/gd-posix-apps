# Native ordinary-library comparisons

Ratios below one favor GD. Each row retains its own regime, scale and mode.
Intervals are the union of paired IID and circular-block intervals; small samples
and nonstationary host noise remain limitations. This report is advisory.

| Corpus | Workload | GD / standard [CI] | GD / portable [CI] | A/A | Observation |
|---|---|---|---|---|---|
| full | `math_regular_s-one_scale100_one_shot_x1` | 1.2306 [1.2079605780577132, 1.2487108290315] | 1.1429 [1.1239668480626799, 1.165784527106888] | inconclusive | one-shot latency observation |
| full | `math_regular_s-one_scale100_repeated_x256` | 0.9343 [0.9286115644986362, 0.954304095597717] | 0.5324 [0.5279231753003465, 0.5394616845341779] | pass | target not established |
| full | `math_regular_c-one_scale100_one_shot_x1` | 1.1532 [1.1377970478910069, 1.1843492348792057] | 1.1513 [1.124938468394819, 1.1790362995351324] | pass | one-shot latency observation |
| full | `math_regular_c-one_scale100_repeated_x256` | 0.4156 [0.41187378116550794, 0.41868300362240257] | 0.5316 [0.5288306148160197, 0.5345249886605308] | pass | target observed |
| full | `math_regular_a-one_scale100_one_shot_x1` | 1.2150 [1.1910277935446174, 1.2666543472242369] | 1.1686 [1.1177920257503586, 1.2056824396485026] | pass | one-shot latency observation |
| full | `math_regular_a-one_scale100_repeated_x512` | 0.7708 [0.7504813779983481, 0.776002093652976] | 0.4725 [0.46807540569800615, 0.47415836548223605] | pass | target observed |
| full | `math_regular_l-two_scale100_one_shot_x1` | 1.2254 [1.2029207145121665, 1.2420590081557867] | 1.1741 [1.1229753914974747, 1.1820019855240216] | pass | one-shot latency observation |
| full | `math_regular_l-two_scale100_repeated_x512` | 0.8937 [0.8885215296903242, 0.9001802340967794] | 0.5129 [0.5043659102331878, 0.520444502320715] | pass | target observed |
| full | `math_regular_e-one_scale100_one_shot_x1` | 1.2313 [1.1797072356564808, 1.2535924438722754] | 1.2068 [1.195249031640963, 1.2180545067630324] | pass | one-shot latency observation |
| full | `math_regular_e-one_scale100_repeated_x1024` | 0.8484 [0.8388303417297165, 0.852929553871222] | 1.3205 [1.2976390237528526, 1.3264453416383817] | pass | target observed |
| full | `math_regular_j-zero-one_scale100_one_shot_x1` | 1.2529 [1.2499423150930553, 1.267778348543907] | 1.1810 [1.1608242747956157, 1.2130448190816623] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale100_repeated_x2048` | 1.0928 [1.0826385130718206, 1.1035691072634985] | 1.3884 [1.3757615335958495, 1.4080451317729021] | pass | target not established |
| full | `math_turning_j-turning_scale100_one_shot_x1` | 1.2372 [1.2047217260515002, 1.267123722462002] | 1.1912 [1.1682457791822216, 1.2111565674770601] | pass | one-shot latency observation |
| full | `math_turning_j-turning_scale100_repeated_x512` | 1.5624 [1.4959561187916508, 1.5855105301542467] | 1.4680 [1.4528664154678312, 1.47933602512352] | pass | target not established |
| full | `math_order_dominates_j-order-dominates_scale100_one_shot_x1` | 1.2320 [1.2058456686977976, 1.2574078145856495] | 1.2193 [1.1773938002279805, 1.252608779338139] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale100_repeated_x1024` | 1.3344 [1.3190804481341103, 1.3520060628924822] | 1.4489 [1.4298161170970702, 1.4573763937633573] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale100_one_shot_x1` | 1.5332 [1.5059645105901402, 1.588440021955888] | 1.2990 [1.2520220874123864, 1.3341689142691113] | pass | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale100_repeated_x256` | 4.6855 [4.583831017551354, 4.723672626274488] | 1.9123 [1.9010394668631612, 1.9227468667858185] | pass | target not established |
| full | `math_near_root_j-near-root_scale100_one_shot_x1` | 1.2754 [1.222052815273484, 1.3016474742615107] | 1.1771 [1.1161109323115403, 1.2017780143711037] | pass | one-shot latency observation |
| full | `math_near_root_j-near-root_scale100_repeated_x512` | 1.6055 [1.588819230632729, 1.6715346991318611] | 0.9697 [0.9546322695068856, 0.9955087341877772] | pass | target not established |

Whole-process samples include library loading, parsing and constant generation.
Repeated cases share a frozen calibrated invocation count across every role.
One-shot rows report latency without a substantive-duration speed target.
No aggregate pass is inferred. Instruction, allocation and peak-memory diagnostics
remain separate work; a green workflow alone does not establish acceptance.
