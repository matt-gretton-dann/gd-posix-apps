# Native ordinary-library comparisons

Ratios below one favor GD. Each row retains its own regime, scale and mode.
Intervals are the union of paired IID and circular-block intervals; small samples
and nonstationary host noise remain limitations. This report is advisory.

| Corpus | Workload | GD / standard [CI] | GD / portable [CI] | A/A | Observation |
|---|---|---|---|---|---|
| full | `math_regular_s-one_scale20_one_shot_x1` | 1.2678 [1.1670499822425071, 1.3643608602563437] | 1.1999 [1.1713946645535767, 1.2792297351610333] | inconclusive | one-shot latency observation |
| full | `math_regular_s-one_scale20_repeated_x16384` | 9.6370 [9.57438043442931, 9.780837942652449] | 0.6849 [0.6809565545099249, 0.6882064597230795] | pass | target not established |
| full | `math_regular_s-one_scale100_one_shot_x1` | 1.2556 [1.1980938439609057, 1.3002098542625795] | 1.1559 [1.0598268871533485, 1.2118533022606592] | inconclusive | one-shot latency observation |
| full | `math_regular_s-one_scale100_repeated_x512` | 1.0803 [1.07372727354166, 1.1006974996203842] | 0.4871 [0.48612185527086854, 0.4925310445633747] | pass | target not established |
| full | `math_regular_s-one_scale1000_one_shot_x1` | 0.3887 [0.38519444701084127, 0.3958722979289297] | 0.5438 [0.5364459365523994, 0.5496039182523994] | pass | one-shot latency observation |
| full | `math_regular_s-one_scale1000_repeated_x4` | 0.3416 [0.33893685080257546, 0.34398770101224696] | 0.4893 [0.48480793223468654, 0.49361743431064387] | pass | target observed |
| full | `math_regular_c-one_scale20_one_shot_x1` | 1.2889 [1.2294069265099756, 1.3177175719137229] | 1.2349 [1.2088146529416424, 1.2506801038388007] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale20_repeated_x8192` | 7.7823 [7.718174979563042, 7.9125769438814615] | 0.6883 [0.6853172245059147, 0.6931208750149793] | pass | target not established |
| full | `math_regular_c-one_scale100_one_shot_x1` | 1.1563 [1.1407877778907853, 1.2019451758374673] | 1.1555 [1.0612359147805004, 1.2100757237319344] | pass | one-shot latency observation |
| full | `math_regular_c-one_scale100_repeated_x512` | 0.3834 [0.3794763280048945, 0.38874191048220963] | 0.4900 [0.48511215499160415, 0.4929446414911658] | pass | target observed |
| full | `math_regular_c-one_scale1000_one_shot_x1` | 0.1615 [0.16063962837392945, 0.1667441747032286] | 0.5504 [0.5446820243350194, 0.5555910894362805] | pass | one-shot latency observation |
| full | `math_regular_c-one_scale1000_repeated_x4` | 0.1364 [0.13575997664530864, 0.13830875891108524] | 0.4922 [0.4879705228714635, 0.4937687461125471] | pass | target observed |
| full | `math_regular_a-one_scale20_one_shot_x1` | 1.2846 [1.2545577066389582, 1.3091230539331964] | 1.2315 [1.1886664463681924, 1.25727971026094] | pass | one-shot latency observation |
| full | `math_regular_a-one_scale20_repeated_x131072` | 56.3777 [55.03732407445954, 57.11791228031418] | 0.6923 [0.6857724555957279, 0.6990903730537054] | pass | target not established |
| full | `math_regular_a-one_scale100_one_shot_x1` | 1.2748 [1.2509315343026217, 1.356271575596407] | 1.1816 [1.1159181883058018, 1.2736497653210472] | pass | one-shot latency observation |
| full | `math_regular_a-one_scale100_repeated_x1024` | 0.8816 [0.8767479127450856, 0.8933806711901459] | 0.4814 [0.47776821013306436, 0.48496539142775036] | pass | target observed |
| full | `math_regular_a-one_scale1000_one_shot_x1` | 0.4463 [0.4346168578237795, 0.44967281218805816] | 0.4329 [0.4236482178794722, 0.4402817863226189] | pass | one-shot latency observation |
| full | `math_regular_a-one_scale1000_repeated_x8` | 0.3626 [0.3612335934877797, 0.3633665290682751] | 0.3518 [0.34901697427882505, 0.35335270919077255] | pass | target observed |
| full | `math_regular_l-two_scale20_one_shot_x1` | 1.2811 [1.2652373340337792, 1.3389231268338595] | 1.2371 [1.2114930644555884, 1.3376676744378984] | inconclusive | one-shot latency observation |
| full | `math_regular_l-two_scale20_repeated_x8192` | 2.0835 [2.0646038321832303, 2.1148515646289034] | 0.7627 [0.7532337996035253, 0.7648723579358272] | pass | target not established |
| full | `math_regular_l-two_scale100_one_shot_x1` | 1.2634 [1.2439168140263448, 1.2940581359575918] | 1.1864 [1.125744550459741, 1.2244727260504458] | pass | one-shot latency observation |
| full | `math_regular_l-two_scale100_repeated_x1024` | 1.0018 [0.9910713940761011, 1.008806097299829] | 0.5558 [0.5475232056983957, 0.5585564851523463] | pass | target not established |
| full | `math_regular_l-two_scale1000_one_shot_x1` | 0.4377 [0.43471344507092446, 0.4397434951059551] | 0.4588 [0.4539758417368391, 0.46007811253505493] | pass | one-shot latency observation |
| full | `math_regular_l-two_scale1000_repeated_x8` | 0.3428 [0.3399709915532149, 0.3468286951833779] | 0.3666 [0.36551042265554734, 0.3691364275691864] | pass | target observed |
| full | `math_regular_e-one_scale20_one_shot_x1` | 1.2618 [1.1495982302513361, 1.3273321847391297] | 1.1652 [1.1480914343382742, 1.2550165145155716] | inconclusive | one-shot latency observation |
| full | `math_regular_e-one_scale20_repeated_x4096` | 1.4444 [1.3518852396896017, 1.45573659803203] | 1.2798 [1.266313856953286, 1.2920070056761874] | pass | target not established |
| full | `math_regular_e-one_scale100_one_shot_x1` | 1.2378 [1.1816251898390766, 1.2947938523307903] | 1.2520 [1.1563880851620347, 1.3160915578051584] | inconclusive | one-shot latency observation |
| full | `math_regular_e-one_scale100_repeated_x2048` | 0.8695 [0.8581592222416059, 0.8826991238697067] | 1.4156 [1.3798906423153812, 1.4322110024610497] | pass | target observed |
| full | `math_regular_e-one_scale1000_one_shot_x1` | 0.5910 [0.5707886193335799, 0.5963372236553172] | 2.1949 [2.1178588622513264, 2.222217823313264] | pass | one-shot latency observation |
| full | `math_regular_e-one_scale1000_repeated_x64` | 0.4186 [0.4176987731472517, 0.42001243104896513] | 5.6063 [5.5871509226867095, 5.630407611444511] | pass | target observed |
| full | `math_regular_j-zero-one_scale20_one_shot_x1` | 1.3481 [1.2824847720571186, 1.4139862938416727] | 1.2488 [1.2092320743199072, 1.300709852193777] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale20_repeated_x8192` | 2.1398 [2.104732343217994, 2.144675861101955] | 1.3005 [1.2845972283663265, 1.3211660333850221] | pass | target not established |
| full | `math_regular_j-zero-one_scale100_one_shot_x1` | 1.2888 [1.2450042218009556, 1.3828709937878416] | 1.2162 [1.159620432703358, 1.2529186572187534] | pass | one-shot latency observation |
| full | `math_regular_j-zero-one_scale100_repeated_x2048` | 1.1417 [1.1258343897494947, 1.1573341974244797] | 1.4550 [1.436794859926053, 1.4706366501115582] | pass | target not established |
| full | `math_regular_j-zero-one_scale1000_one_shot_x1` | 1.6670 [1.6288834152484841, 1.7069332603013332] | 1.9777 [1.947407897308378, 2.04227549801679] | pass | one-shot latency observation |
| full | `math_regular_j-zero-one_scale1000_repeated_x128` | 2.4406 [2.42422393836062, 2.448985714242528] | 5.5141 [5.498021808776597, 5.537129978130821] | pass | target not established |
| full | `math_turning_j-turning_scale20_one_shot_x1` | 1.2941 [1.1872861209448007, 1.4068466096625825] | 1.2297 [1.1993991170054237, 1.3399986065699032] | pass | one-shot latency observation |
| full | `math_turning_j-turning_scale20_repeated_x2048` | 3.2074 [3.129975217575744, 3.2627979577146387] | 1.3738 [1.3512528216786774, 1.3885864013029026] | pass | target not established |
| full | `math_turning_j-turning_scale100_one_shot_x1` | 1.2830 [1.2512602457991027, 1.3730229939423821] | 1.3418 [1.2505223076198821, 1.3660936593452988] | inconclusive | one-shot latency observation |
| full | `math_turning_j-turning_scale100_repeated_x512` | 1.6627 [1.654059306306308, 1.6876814450433262] | 1.5176 [1.4942771426591377, 1.533991067538388] | pass | target not established |
| full | `math_turning_j-turning_scale1000_one_shot_x1` | 2.0536 [2.0070551902718217, 2.0905081841442996] | 2.6214 [2.4894402615013465, 2.676945756072828] | pass | one-shot latency observation |
| full | `math_turning_j-turning_scale1000_repeated_x64` | 2.8552 [2.832053828753973, 2.8653324150807937] | 5.3246 [5.300032049953513, 5.342599864423875] | pass | target not established |
| full | `math_order_dominates_j-order-dominates_scale20_one_shot_x1` | 1.2383 [1.1509460622734213, 1.285896918307057] | 1.1632 [1.1192724622677837, 1.2433640134267043] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale20_repeated_x131072` | 0.0707 [0.0702862131760473, 0.07111322049529763] | 2.0543 [2.018302136658332, 2.0929913443716384] | pass | target observed |
| full | `math_order_dominates_j-order-dominates_scale100_one_shot_x1` | 1.2949 [1.234332378297752, 1.3088653534130619] | 1.2543 [1.2197470586392858, 1.2740504710180438] | inconclusive | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale100_repeated_x2048` | 1.3906 [1.3824652764024294, 1.4153034480479925] | 1.4968 [1.4567339720021693, 1.5099639692153783] | pass | target not established |
| full | `math_order_dominates_j-order-dominates_scale1000_one_shot_x1` | 1.8297 [1.7761843238649364, 1.880596459917916] | 2.1126 [2.039682446052395, 2.1650769937746075] | pass | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale1000_repeated_x128` | 3.4246 [3.4062133982904967, 3.436654117538797] | 5.8858 [5.874008804003661, 5.893561616818733] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale20_one_shot_x1` | 1.5777 [1.564058866321332, 1.6099704606031406] | 0.9052 [0.8955191856598187, 0.9207378047877777] | inconclusive | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale20_repeated_x512` | 7.7384 [7.380619089318983, 7.828149091093237] | 0.4179 [0.4160661182206966, 0.4200967550632733] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale100_one_shot_x1` | 1.6355 [1.5670423260174853, 1.6592274242502283] | 1.3876 [1.3556314945911736, 1.4538099023778377] | inconclusive | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale100_repeated_x256` | 4.9490 [4.93084369101083, 4.982535748658479] | 2.0006 [1.9850315857120553, 2.0068725360100936] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale1000_one_shot_x1` | 3.2066 [3.096043415550111, 3.246148341333988] | 3.6574 [3.583165696148697, 3.732144551653958] | pass | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale1000_repeated_x16` | 4.4517 [4.405654970607846, 4.461019409647696] | 5.6532 [5.534223681874378, 5.7096247759908705] | pass | target not established |
| full | `math_near_root_j-near-root_scale20_one_shot_x1` | 1.3140 [1.2788662017809291, 1.3307271158615743] | 1.2253 [1.12708839970553, 1.267711708638946] | pass | one-shot latency observation |
| full | `math_near_root_j-near-root_scale20_repeated_x8192` | 6.0739 [6.055506283565503, 6.141580071451365] | 1.1441 [1.1354324821039978, 1.147169730815881] | pass | target not established |
| full | `math_near_root_j-near-root_scale100_one_shot_x1` | 1.3421 [1.2455762667590764, 1.424392203423639] | 1.2718 [1.2308239385751387, 1.351653632003557] | inconclusive | one-shot latency observation |
| full | `math_near_root_j-near-root_scale100_repeated_x1024` | 2.0401 [2.020145546883083, 2.0556182363486264] | 1.0355 [1.0223627640842639, 1.0441761618127812] | pass | target not established |
| full | `math_near_root_j-near-root_scale1000_one_shot_x1` | 1.3115 [1.290697236797398, 1.3355146214604343] | 1.7246 [1.6991778955745815, 1.7637833938233405] | pass | one-shot latency observation |
| full | `math_near_root_j-near-root_scale1000_repeated_x32` | 1.3847 [1.3778958878486347, 1.390457855764624] | 2.3525 [2.3398850920113516, 2.357773143295145] | pass | target not established |
| holdout | `math_regular_held-s-nine-eighths_scale20_one_shot_x1` | 1.2580 [1.2157572241024917, 1.3206978528551665] | 1.2122 [1.1546757880406615, 1.2435802038022234] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-s-nine-eighths_scale20_repeated_x8192` | 8.3147 [8.099692761818012, 8.388527809901676] | 0.6533 [0.647774163862731, 0.6609171498765323] | pass | target not established |
| holdout | `math_regular_held-s-nine-eighths_scale100_one_shot_x1` | 1.2520 [1.178042899185446, 1.2784650053680775] | 1.1453 [1.0915841226637724, 1.155980328439203] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-s-nine-eighths_scale100_repeated_x512` | 1.1441 [1.130650270123882, 1.1537853544441048] | 0.4831 [0.48078810866003097, 0.4857105336274388] | pass | target not established |
| holdout | `math_regular_held-s-nine-eighths_scale1000_one_shot_x1` | 0.3898 [0.38563080473124994, 0.3940608876191661] | 0.5397 [0.533710722486813, 0.5441365307422877] | pass | one-shot latency observation |
| holdout | `math_regular_held-s-nine-eighths_scale1000_repeated_x4` | 0.3405 [0.3391796073287307, 0.3428236479957977] | 0.4833 [0.4808615615708873, 0.4861576185200578] | pass | target observed |
| holdout | `math_regular_held-c-nine-eighths_scale20_one_shot_x1` | 1.2949 [1.2602893123349377, 1.3221670016664264] | 1.2209 [1.1919408215008505, 1.2413415538674726] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-c-nine-eighths_scale20_repeated_x8192` | 8.5877 [8.545737886483867, 8.683797993977636] | 0.6578 [0.6558594817138264, 0.6628828970591866] | pass | target not established |
| holdout | `math_regular_held-c-nine-eighths_scale100_one_shot_x1` | 1.1560 [1.1397712641187498, 1.2302600034370665] | 1.1545 [1.0773554912807282, 1.1845720152191068] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-c-nine-eighths_scale100_repeated_x512` | 0.4160 [0.4091563954738739, 0.4167499586071665] | 0.4821 [0.4782786843592758, 0.4902100152119393] | pass | target observed |
| holdout | `math_regular_held-c-nine-eighths_scale1000_one_shot_x1` | 0.1609 [0.1602409006627844, 0.16229319537597048] | 0.5403 [0.5381162777838051, 0.5430178831220417] | pass | one-shot latency observation |
| holdout | `math_regular_held-c-nine-eighths_scale1000_repeated_x4` | 0.1367 [0.13601126835577929, 0.13739523102169718] | 0.4833 [0.4821963651468276, 0.4866858471684741] | pass | target observed |
| holdout | `math_regular_held-a-nine-eighths_scale20_one_shot_x1` | 1.2970 [1.2459107739923665, 1.3380527650992853] | 1.1425 [1.1044293949266883, 1.2236600491787684] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-a-nine-eighths_scale20_repeated_x8192` | 9.7830 [9.616647281164742, 9.886744657769313] | 0.6335 [0.6288311747682995, 0.6400778876282738] | pass | target not established |
| holdout | `math_regular_held-a-nine-eighths_scale100_one_shot_x1` | 1.3184 [1.293799089056999, 1.357107829686967] | 1.1351 [1.1069121829479225, 1.1882234316343672] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-a-nine-eighths_scale100_repeated_x1024` | 2.4977 [2.467666950153424, 2.502127446691498] | 0.4002 [0.3977685900524332, 0.402081116412169] | pass | target not established |
| holdout | `math_regular_held-a-nine-eighths_scale1000_one_shot_x1` | 1.1982 [1.1917040643687549, 1.2074655663886782] | 0.4028 [0.4004923094436789, 0.4055584366217297] | pass | one-shot latency observation |
| holdout | `math_regular_held-a-nine-eighths_scale1000_repeated_x4` | 1.2134 [1.2070666493045572, 1.2156780970674013] | 0.3665 [0.363671969642028, 0.3693307293166141] | pass | target not established |
| holdout | `math_regular_held-l-nine-fourths_scale20_one_shot_x1` | 1.2817 [1.2711027815213451, 1.3007722007075413] | 1.2286 [1.212685027347766, 1.2791957337345905] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-l-nine-fourths_scale20_repeated_x8192` | 2.3302 [2.3201892071295456, 2.378868266956295] | 0.7065 [0.7001370807441721, 0.723845708065127] | pass | target not established |
| holdout | `math_regular_held-l-nine-fourths_scale100_one_shot_x1` | 1.2813 [1.2540652118815991, 1.3115181771606657] | 1.1618 [1.12429943016723, 1.1917199317951022] | pass | one-shot latency observation |
| holdout | `math_regular_held-l-nine-fourths_scale100_repeated_x1024` | 1.1933 [1.186445731984919, 1.2385718603601727] | 0.4729 [0.4708030696453437, 0.4859995902007125] | pass | target not established |
| holdout | `math_regular_held-l-nine-fourths_scale1000_one_shot_x1` | 1.7779 [1.7454389157140038, 1.8190154843150925] | 0.4586 [0.45276163400248076, 0.4652945406349116] | pass | one-shot latency observation |
| holdout | `math_regular_held-l-nine-fourths_scale1000_repeated_x16` | 2.1692 [2.1358633375813745, 2.1762039267548574] | 0.3529 [0.350778269436933, 0.354984579485132] | pass | target not established |
| holdout | `math_regular_held-e-nine-eighths_scale20_one_shot_x1` | 1.2914 [1.1809156277343367, 1.3143316817854067] | 1.2291 [1.165861722411337, 1.255981524194774] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-e-nine-eighths_scale20_repeated_x8192` | 1.6718 [1.63997830552918, 1.6799852775666781] | 1.2994 [1.2775797262722268, 1.311583450472539] | pass | target not established |
| holdout | `math_regular_held-e-nine-eighths_scale100_one_shot_x1` | 1.2768 [1.1782854490299786, 1.355012913902819] | 1.2365 [1.2149602341926873, 1.3003220022745006] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-e-nine-eighths_scale100_repeated_x2048` | 0.9470 [0.931446395361955, 0.9631040669484537] | 1.3832 [1.376398296520221, 1.4053527643051555] | pass | target not established |
| holdout | `math_regular_held-e-nine-eighths_scale1000_one_shot_x1` | 0.6455 [0.6396762075199509, 0.6550740768990498] | 2.1256 [2.009139263140291, 2.1482639307044855] | pass | one-shot latency observation |
| holdout | `math_regular_held-e-nine-eighths_scale1000_repeated_x64` | 0.4709 [0.4702965246868408, 0.4712816404299777] | 5.1346 [5.112414866330237, 5.15684225521545] | pass | target observed |
| holdout | `math_regular_held-j-one-nine-eighths_scale20_one_shot_x1` | 1.3111 [1.2811652746188869, 1.3800108169799803] | 1.2203 [1.148846926207329, 1.2699784792031354] | inconclusive | one-shot latency observation |
| holdout | `math_regular_held-j-one-nine-eighths_scale20_repeated_x8192` | 2.4129 [2.3712895213862546, 2.4351910930218064] | 1.2856 [1.2610796252165641, 1.3090831102614489] | pass | target not established |
| holdout | `math_regular_held-j-one-nine-eighths_scale100_one_shot_x1` | 1.2982 [1.2716806220832522, 1.3192924677967144] | 1.2386 [1.14222942096922, 1.2643599117005897] | pass | one-shot latency observation |
| holdout | `math_regular_held-j-one-nine-eighths_scale100_repeated_x2048` | 1.2510 [1.195266891746734, 1.2632616348945818] | 1.5063 [1.4926500102834304, 1.5188941622229586] | pass | target not established |
| holdout | `math_regular_held-j-one-nine-eighths_scale1000_one_shot_x1` | 1.6952 [1.644397280493561, 1.7315161719230667] | 2.0239 [1.9628350620467243, 2.0651441299194793] | pass | one-shot latency observation |
| holdout | `math_regular_held-j-one-nine-eighths_scale1000_repeated_x128` | 2.4992 [2.4778045187249855, 2.5109451385882258] | 5.4927 [5.471225168643892, 5.518246161888409] | pass | target not established |
| holdout | `math_turning_held-j-turning23_scale20_one_shot_x1` | 1.2870 [1.274708270408014, 1.3170828052811092] | 1.2443 [1.2233734014259783, 1.299636473700326] | inconclusive | one-shot latency observation |
| holdout | `math_turning_held-j-turning23_scale20_repeated_x2048` | 3.2714 [3.234968642800003, 3.3405494230312813] | 1.3747 [1.3555416076255806, 1.4083829305004016] | pass | target not established |
| holdout | `math_turning_held-j-turning23_scale100_one_shot_x1` | 1.3227 [1.2656088526170541, 1.4094244083957164] | 1.2593 [1.2473410874519004, 1.3495476816043341] | inconclusive | one-shot latency observation |
| holdout | `math_turning_held-j-turning23_scale100_repeated_x512` | 1.8526 [1.8415437200921088, 1.8580015425239418] | 1.5843 [1.5561011020163935, 1.6048678680022193] | pass | target not established |
| holdout | `math_turning_held-j-turning23_scale1000_one_shot_x1` | 2.0628 [2.0199829675455288, 2.076471461952684] | 2.6134 [2.4958960694710832, 2.677775595689393] | pass | one-shot latency observation |
| holdout | `math_turning_held-j-turning23_scale1000_repeated_x64` | 2.8910 [2.8635616813789095, 2.9000899644478983] | 5.6748 [5.658180430355221, 5.682894005459678] | pass | target not established |
| holdout | `math_order_dominates_held-j-order113_scale20_one_shot_x1` | 1.2270 [1.161581137300545, 1.282552324468976] | 1.2252 [1.1664677054386554, 1.2399730306687684] | inconclusive | one-shot latency observation |
| holdout | `math_order_dominates_held-j-order113_scale20_repeated_x131072` | 0.0557 [0.05520473410137449, 0.05650382758289411] | 1.9470 [1.9173120849013074, 2.0030872201873304] | pass | target observed |
| holdout | `math_order_dominates_held-j-order113_scale100_one_shot_x1` | 1.2492 [1.239213322074477, 1.3105129098228858] | 1.2468 [1.15569772222963, 1.2737907722432222] | inconclusive | one-shot latency observation |
| holdout | `math_order_dominates_held-j-order113_scale100_repeated_x1024` | 1.3343 [1.328041414417918, 1.3421687341710717] | 1.4769 [1.4731475396331128, 1.5012560769126795] | pass | target not established |
| holdout | `math_order_dominates_held-j-order113_scale1000_one_shot_x1` | 1.9111 [1.8597053932468326, 1.9552034525680286] | 2.2020 [2.0454254075841205, 2.220826330461641] | pass | one-shot latency observation |
| holdout | `math_order_dominates_held-j-order113_scale1000_repeated_x128` | 3.5049 [3.4545461908540096, 3.531843708804426] | 5.7126 [5.62756075084815, 5.738492372360884] | pass | target not established |
| holdout | `math_argument_dominates_held-j-argument112_scale20_one_shot_x1` | 1.6199 [1.5203088127593616, 1.6399879351224163] | 0.8769 [0.8581086206605055, 0.8883159840183269] | inconclusive | one-shot latency observation |
| holdout | `math_argument_dominates_held-j-argument112_scale20_repeated_x512` | 7.5592 [7.38168502554546, 7.664336931715169] | 0.4075 [0.40265663218024933, 0.4109869125476138] | pass | target not established |
| holdout | `math_argument_dominates_held-j-argument112_scale100_one_shot_x1` | 1.6934 [1.6789220499591992, 1.7483107305471763] | 1.4208 [1.3663458553533243, 1.456581918883008] | inconclusive | one-shot latency observation |
| holdout | `math_argument_dominates_held-j-argument112_scale100_repeated_x256` | 5.5956 [5.544723247913341, 5.6182096972828095] | 2.0656 [2.0416468232635387, 2.0695995922625983] | pass | target not established |
| holdout | `math_argument_dominates_held-j-argument112_scale1000_one_shot_x1` | 3.3330 [3.263824921408223, 3.4026910721895063] | 3.6011 [3.461597711991865, 3.7137901575075847] | pass | one-shot latency observation |
| holdout | `math_argument_dominates_held-j-argument112_scale1000_repeated_x16` | 4.5539 [4.542724741983621, 4.564938174884919] | 5.3308 [5.297126405455638, 5.351375342895966] | pass | target not established |
| holdout | `math_near_root_held-j-one-near-root_scale20_one_shot_x1` | 1.2910 [1.2697304841930483, 1.3408724657019544] | 1.2003 [1.1669418330752364, 1.2295122423466283] | inconclusive | one-shot latency observation |
| holdout | `math_near_root_held-j-one-near-root_scale20_repeated_x4096` | 6.0277 [5.772718380954411, 6.083241666289131] | 1.1317 [1.1182880599147287, 1.134821413085113] | pass | target not established |
| holdout | `math_near_root_held-j-one-near-root_scale100_one_shot_x1` | 1.2915 [1.2511112585559596, 1.3154051676461114] | 1.2403 [1.2011745218748204, 1.2791122799477754] | inconclusive | one-shot latency observation |
| holdout | `math_near_root_held-j-one-near-root_scale100_repeated_x1024` | 1.9352 [1.9263567894340459, 1.9645921506721238] | 0.8488 [0.8325989451979128, 0.8577803520162167] | pass | target not established |
| holdout | `math_near_root_held-j-one-near-root_scale1000_one_shot_x1` | 1.2704 [1.2380974614355602, 1.313912009520104] | 1.7305 [1.6927139000889628, 1.7667403124753827] | pass | one-shot latency observation |
| holdout | `math_near_root_held-j-one-near-root_scale1000_repeated_x32` | 1.3074 [1.3027634188177442, 1.3080100937751826] | 2.2178 [2.2113028251111353, 2.2332265046678623] | pass | target not established |

Whole-process samples include library loading, parsing and constant generation.
Repeated cases share a frozen calibrated invocation count across every role.
One-shot rows report latency without a substantive-duration speed target.
No aggregate pass is inferred. Instruction, allocation and peak-memory diagnostics
remain separate work; a green workflow alone does not establish acceptance.
