# Native ordinary-library comparisons

Ratios below one favor GD. Each row retains its own regime, scale and mode.
Intervals are the union of paired IID and circular-block intervals; small samples
and nonstationary host noise remain limitations. This report is advisory.

| Corpus | Workload | GD / standard [CI] | GD / portable [CI] | A/A | Observation |
|---|---|---|---|---|---|
| full | `math_regular_s-one_scale100_one_shot_x1` | 1.1927 [1.1283169653477942, 1.2392042276728052] | 1.2900 [1.2362495065554753, 1.3410536432292746] | pass | one-shot latency observation |
| full | `math_regular_s-one_scale100_repeated_x512` | 1.5168 [1.4893824124624384, 1.5507159732307991] | 1.2178 [1.189324393496302, 1.2483536874369672] | pass | target not established |
| full | `math_regular_c-one_scale100_one_shot_x1` | 1.2482 [1.0965143046033334, 1.3477424544162562] | 1.3872 [1.1838328247999619, 1.507432405985765] | inconclusive | one-shot latency observation |
| full | `math_regular_c-one_scale100_repeated_x512` | 0.7124 [0.6852183989617034, 0.7299209357723744] | 1.2477 [1.2322011725621556, 1.266044455920687] | pass | target observed |
| full | `math_regular_a-one_scale100_one_shot_x1` | 1.1985 [1.1550229088805204, 1.246647997273631] | 1.2798 [1.1914483857011486, 1.3339361662975013] | inconclusive | one-shot latency observation |
| full | `math_regular_a-one_scale100_repeated_x1024` | 1.0974 [1.085728394742554, 1.157826914282108] | 1.0464 [1.0060141311448598, 1.0809450476860576] | pass | target not established |
| full | `math_regular_l-two_scale100_one_shot_x1` | 1.1758 [1.1462112173653898, 1.2169333277150356] | 1.3038 [1.2285262610295833, 1.3520499220797702] | inconclusive | one-shot latency observation |
| full | `math_regular_l-two_scale100_repeated_x2048` | 1.5626 [1.5486929660400852, 1.6034924259695418] | 1.0941 [1.0849803714009687, 1.112449028794466] | pass | target not established |
| full | `math_regular_e-one_scale100_one_shot_x1` | 1.1428 [1.1354626694864711, 1.2110746019697138] | 1.3212 [1.2327132508380136, 1.7924311922338692] | pass | one-shot latency observation |
| full | `math_regular_e-one_scale100_repeated_x2048` | 1.1956 [1.1690249792533185, 1.2030908030366254] | 1.5960 [1.5815935329811737, 1.6185524822109143] | pass | target not established |
| full | `math_regular_j-zero-one_scale100_one_shot_x1` | 1.2050 [1.1294233375634817, 1.22848980303412] | 1.2508 [1.1507474492858563, 1.360300941591087] | inconclusive | one-shot latency observation |
| full | `math_regular_j-zero-one_scale100_repeated_x2048` | 1.3360 [1.318565175075338, 1.3572380739968828] | 1.5713 [1.56039130700888, 1.613953058838032] | pass | target not established |
| full | `math_turning_j-turning_scale100_one_shot_x1` | 1.2104 [1.1606824661860684, 1.2835449432793933] | 1.3196 [1.2344272364774267, 1.3876979089241284] | pass | one-shot latency observation |
| full | `math_turning_j-turning_scale100_repeated_x1024` | 2.1711 [2.122270925782235, 2.2054523674336117] | 1.9868 [1.9736992036973615, 2.0017994278606714] | pass | target not established |
| full | `math_order_dominates_j-order-dominates_scale100_one_shot_x1` | 1.2214 [1.1524258122748567, 1.2754682768612147] | 1.2815 [1.1954394489482902, 1.3918365043342265] | pass | one-shot latency observation |
| full | `math_order_dominates_j-order-dominates_scale100_repeated_x2048` | 1.5717 [1.5571044338470068, 1.5879907492860266] | 1.6516 [1.6019591666699664, 1.7088548106443495] | pass | target not established |
| full | `math_argument_dominates_j-argument-dominates_scale100_one_shot_x1` | 1.8064 [1.589407414353217, 2.0623074292858496] | 1.7885 [1.479316197022979, 1.8141437607983306] | pass | one-shot latency observation |
| full | `math_argument_dominates_j-argument-dominates_scale100_repeated_x512` | 7.5483 [7.365154099542325, 7.749966605265062] | 3.2448 [3.1830335256204156, 3.3251797592833485] | pass | target not established |
| full | `math_near_root_j-near-root_scale100_one_shot_x1` | 1.1358 [1.0590705961056686, 1.2931825348614512] | 1.2742 [1.2415583534463004, 1.3922441784978974] | inconclusive | one-shot latency observation |
| full | `math_near_root_j-near-root_scale100_repeated_x2048` | 3.1773 [3.122162622066583, 3.2251391997780243] | 2.1252 [2.087567447579302, 2.1767204347418834] | pass | target not established |

Whole-process samples include library loading, parsing and constant generation.
Repeated cases share a frozen calibrated invocation count across every role.
One-shot rows report latency without a substantive-duration speed target.
No aggregate pass is inferred. Instruction, allocation and peak-memory diagnostics
remain separate work; a green workflow alone does not establish acceptance.
