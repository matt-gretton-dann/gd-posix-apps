# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.992 [0.7898137427061583, 1.065763645418271] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.992 [0.9809506672254178, 1.0086949102834282] | pass |
| full | aa | `calls_200000` | 1.000 [0.9805830995951313, 1.0099699038976833] | pass |
| full | aa | `array_200000` | 1.003 [0.979516880875955, 1.01510188957642] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.002 [0.9863903921080295, 1.012418161075643] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.987 [0.9811506660990446, 0.9985678823753525] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.998 [0.9818572517214132, 1.031137061271617] | pass |
| full | aa | `fibonacci_1000_x100` | 0.980 [0.9716735220239041, 1.003978484056302] | pass |
| full | aa | `factorial_1000_x50` | 1.003 [1.000598616943379, 1.0145616021260164] | pass |
| full | aa | `multiply_100d_x100000` | 1.001 [0.9626884723392457, 1.016227174666964] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9956271210864531, 1.1429492655984632] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.000 [0.9825169837774659, 1.007943698508193] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.003 [0.9624427301088805, 1.0045489570918316] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [1.0000236045104267, 1.004843589867233] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.990 [0.9764401431751357, 1.008320597904882] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.974113574527225, 1.001298572771444] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.989 [0.9775104842245176, 1.0222567932999675] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.999 [0.9962181650780637, 1.0017457541727548] | pass |
| full | aa | `power_100d_e17_x1000` | 1.007 [0.9799612528784567, 1.0198418659553135] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.996 [0.979891005517916, 1.0400660018573746] | pass |
| full | aa | `recursion_50_x1000` | 1.008 [0.9925911500671062, 1.0194472676648532] | pass |
| full | aa | `sparse_array_200000` | 0.991 [0.9706802433687973, 1.0118846770286147] | pass |
| full | aa | `frontend_definitions_2000` | 1.012 [1.0075449343866154, 1.0617290230155116] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.005 [0.9920581905673466, 1.0281304347774791] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.960 [0.8731487406280705, 1.104254035210657] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.005 [0.9958773122842466, 1.0161628820071043] | pass |
| full | aa | `square_100d_x100000` | 1.004 [0.9954440372301971, 1.0221312076396516] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9996321290717741, 1.001893477862966] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.991 [0.9002957086851977, 1.033001470398009] | pass |
| full | aa | `binary_output_1000d_x300` | 0.997 [0.9834342231767791, 1.0114994176064076] | pass |
| full | aa | `octal_output_1000d_x300` | 0.992 [0.9790483193810084, 1.004277725507223] | pass |
| full | aa | `binary_input_100000d_x3` | 0.990 [0.9830935338233346, 1.014807165799912] | pass |
| full | aa | `hex_input_100000d_x3` | 0.985 [0.9818699945518133, 1.003479716750954] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.998 [0.9925959081193404, 1.0016005960270618] | pass |
| full | aa | `file_statements_20000` | 0.995 [0.9778382683945708, 1.01104014851537] | pass |
| full | paired | `startup` | 0.968 [0.7967301807163808, 1.0659715618912264] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.037 [1.016938320266104, 1.0634350439185407] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.011 [1.0013648380508173, 1.0203848832534572] | pass |
| full | paired | `array_200000` | 1.015 [0.9939232830597844, 1.0198742903535793] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.042 [1.0342251414240524, 1.0687368874288448] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.012 [0.9992648528935815, 1.029540441423046] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.012 [0.9975094683398507, 1.013229077636578] | pass |
| full | paired | `fibonacci_1000_x100` | 1.038 [1.0160407908546543, 1.059528296420166] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.002 [0.9969019349678032, 1.026777391822019] | pass |
| full | paired | `multiply_100d_x100000` | 1.007 [0.9910528813791807, 1.0256691867950845] | pass |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9980033146241497, 1.0045896315815006] | pass |
| full | paired | `divide_scale100_x100000` | 1.047 [1.0380356256357413, 1.0563438164779182] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.005 [0.9983938925743191, 1.0074664311010342] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.9989366323437804, 1.003459631899924] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.007 [0.9926781322985013, 1.0074276372053192] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.021 [1.0151890831339352, 1.0289007453714267] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.979837608934742, 1.010565518181915] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.001 [0.9933162148305397, 1.0091755690182336] | pass |
| full | paired | `power_100d_e17_x1000` | 1.002 [0.9912360459934201, 1.0173277089633805] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.990 [0.9419533227835614, 1.007131199955774] | pass |
| full | paired | `recursion_50_x1000` | 1.014 [0.9858932429741096, 1.033937105651563] | pass |
| full | paired | `sparse_array_200000` | 1.006 [0.9780421073980659, 1.010553191958237] | pass |
| full | paired | `frontend_definitions_2000` | 0.990 [0.9698801427846614, 1.0121673617932607] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.024 [0.9932903979409261, 1.0347406395499974] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.929 [0.9116417188708034, 1.1383642469181208] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.005 [0.993465297311219, 1.0134497454114273] | pass |
| full | paired | `square_100d_x100000` | 1.032 [1.0252469928863306, 1.0414042439456956] | pass |
| full | paired | `square_10000d_x500` | 0.999 [0.9960094324942209, 1.0007739789596644] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.065 [1.0089501560887815, 1.141263283236631] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.002 [0.9518864989029293, 1.0269835253944146] | pass |
| full | paired | `octal_output_1000d_x300` | 0.996 [0.9854116712833316, 1.0008658159590882] | pass |
| full | paired | `binary_input_100000d_x3` | 0.995 [0.9746510501253497, 1.0129049448714649] | pass |
| full | paired | `hex_input_100000d_x3` | 0.995 [0.9884296100045237, 0.9995063959579074] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.000 [0.9840616111674149, 1.0061654457073437] | pass |
| full | paired | `file_statements_20000` | 0.996 [0.9832443882921875, 1.007277550964843] | pass |
