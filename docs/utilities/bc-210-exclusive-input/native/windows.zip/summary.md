# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.979 [0.8937863581082958, 1.114779400017135] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.005 [0.9920970771784897, 1.016624851641016] | pass |
| full | aa | `calls_200000` | 0.997 [0.9920124564493592, 1.00779707838406] | pass |
| full | aa | `array_200000` | 1.015 [0.9979000362927284, 1.0872056410484754] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.998 [0.9836890635914175, 1.0086927271428163] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.995 [0.9853452561630043, 1.0229334070483107] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.996 [0.9900393352591899, 1.01948798960123] | pass |
| full | aa | `fibonacci_1000_x100` | 1.002 [0.9844259005264112, 1.0130499627151301] | pass |
| full | aa | `factorial_1000_x50` | 1.018 [0.9819867470117496, 1.0260288234964485] | pass |
| full | aa | `multiply_100d_x100000` | 1.001 [0.9885020649353022, 1.0858794978695887] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.999 [0.9288081781029309, 1.0151120144720842] | pass |
| full | aa | `divide_scale100_x100000` | 0.999 [0.987185560812277, 1.003141716727254] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.007 [0.978373819103034, 1.0127514621038158] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.004 [0.9894216178935464, 1.0467750465237737] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.993 [0.9881971929787721, 0.9996764299897639] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9929285933739723, 1.0039773631218307] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.002 [0.9521376974760959, 1.0204761758087113] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.011 [0.9493899806270378, 1.043293150100521] | pass |
| full | aa | `power_100d_e17_x1000` | 1.005 [0.966885515162063, 1.0233801582350512] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.002 [0.9654241810429667, 1.0256213571707908] | pass |
| full | aa | `recursion_50_x1000` | 1.005 [0.9973713801697833, 1.008970892194647] | pass |
| full | aa | `sparse_array_200000` | 1.002 [0.9884041989626376, 1.0102936355952181] | pass |
| full | aa | `frontend_definitions_2000` | 1.016 [0.9856102488822215, 1.0569343224241181] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.995 [0.975004399567874, 1.0331326219987105] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.993 [0.9053277805681051, 1.0525051957452738] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.002 [0.9630326530200379, 1.0417543777292373] | pass |
| full | aa | `square_100d_x100000` | 0.989 [0.9368617760190477, 1.0058097430524302] | pass |
| full | aa | `square_10000d_x500` | 0.997 [0.9917643536556041, 1.107034988198092] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.999 [0.8792693691895461, 1.0596517933509881] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.988 [0.9803432952843669, 1.019859671061359] | pass |
| full | aa | `octal_output_1000d_x300` | 1.000 [0.9819185126135165, 1.0376531684296846] | pass |
| full | aa | `binary_input_100000d_x3` | 0.993 [0.9790676522621511, 1.0142800901910716] | pass |
| full | aa | `hex_input_100000d_x3` | 1.003 [0.9945519966360129, 1.0190299472725655] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.989 [0.9709875521227174, 1.0096931436167846] | pass |
| full | aa | `file_statements_20000` | 1.009 [0.9800243748884008, 1.2623353508149897] | inconclusive-noisy |
| full | paired | `startup` | 0.950 [0.8988964744711139, 1.0285651665340343] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.000 [0.9779429463699472, 1.0116731812438795] | pass |
| full | paired | `calls_200000` | 1.002 [0.9286374065633717, 1.06304321683162] | inconclusive-noisy |
| full | paired | `array_200000` | 1.017 [1.0056611430433828, 1.0817228181260294] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.996 [0.9909901738460182, 1.0191238966972704] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.000 [0.9901795540037799, 1.0025882808336555] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.003 [0.9215640385172069, 1.020523186967667] | pass |
| full | paired | `fibonacci_1000_x100` | 0.987 [0.9747509955159307, 1.010153732341878] | pass |
| full | paired | `factorial_1000_x50` | 1.000 [0.9944489166170198, 1.0130259017305] | pass |
| full | paired | `multiply_100d_x100000` | 0.999 [0.8842089127721785, 1.0071935711947166] | pass |
| full | paired | `multiply_10000d_x1000` | 0.996 [0.9575457634933389, 1.0087610195934946] | pass |
| full | paired | `divide_scale100_x100000` | 1.008 [0.9214912948922567, 1.0106673497386036] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.999 [0.9736859558640091, 1.006496163778066] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.011 [0.9472097765019605, 1.0897528807863774] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9693297040229497, 1.0136704766840203] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.998 [0.987732298199884, 1.022969936965183] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.991 [0.9545278473816755, 1.0571394785763493] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.030 [0.9528990751169577, 1.0651228458176634] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.987 [0.9741780012084554, 1.0240859379432834] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.974 [0.9669169915163794, 1.0256613771106278] | pass |
| full | paired | `recursion_50_x1000` | 1.001 [0.9811373074404546, 1.0276193159148392] | pass |
| full | paired | `sparse_array_200000` | 1.007 [0.9659090534234733, 1.03349839697591] | pass |
| full | paired | `frontend_definitions_2000` | 0.996 [0.9626638119039023, 1.0652323038623386] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.005 [0.988771126804194, 1.0150900584924316] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.961 [0.9324671475224939, 1.002861119701696] | pass |
| full | paired | `streaming_statements_20000` | 0.982 [0.9504068656919245, 1.0120843570169942] | pass |
| full | paired | `square_100d_x100000` | 0.996 [0.9752296746564587, 1.1004373481741478] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.996 [0.9622152629427513, 1.0125234238043068] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.026 [0.974246543307387, 1.1467738727633292] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.012 [0.9780203711594442, 1.0213113922810801] | pass |
| full | paired | `octal_output_1000d_x300` | 0.997 [0.9855746285062857, 1.0252286481956199] | pass |
| full | paired | `binary_input_100000d_x3` | 0.991 [0.9754680071907327, 1.0404225262778126] | pass |
| full | paired | `hex_input_100000d_x3` | 1.000 [0.9702169233134557, 1.0166167369053314] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.004 [0.9665836177633037, 1.0259466237123809] | pass |
| full | paired | `file_statements_20000` | 1.003 [0.9776452698660654, 1.0198680974246361] | pass |
