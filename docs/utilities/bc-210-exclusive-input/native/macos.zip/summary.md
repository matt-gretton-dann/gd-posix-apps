# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.891 [0.7879645349946975, 1.4561668839731001] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.977 [0.9244486619538363, 1.10605922481574] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.984 [0.861418104682831, 1.126399883452356] | inconclusive-noisy |
| full | aa | `array_200000` | 1.042 [0.9320565761850169, 1.1947501355539187] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 0.995 [0.8791632017085336, 1.3051880934264644] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.876 [0.7882874512088822, 1.2942935712790236] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.991 [0.9575516692512874, 1.1031181658323048] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.975 [0.8973818100527409, 1.0321002718542145] | pass |
| full | aa | `factorial_1000_x50` | 1.019 [0.9111916485071792, 1.3046694272165196] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.921 [0.7322396273537227, 0.9965586143975679] | pass |
| full | aa | `multiply_10000d_x1000` | 0.995 [0.9275914732316851, 1.1043015438720318] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.008 [0.8671648221971711, 1.2843859293677835] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.015 [0.9355487883168554, 1.0417704140894641] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.974 [0.8878771328716314, 1.0722122345449003] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.031 [1.0021407889142022, 1.1894581067980585] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.001 [0.9781577122307912, 1.0572399313537852] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.016 [0.6632043593580785, 1.0747210322434013] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.995 [0.8906203514299693, 1.2505667680358572] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.011 [0.8962667848917694, 1.0333921932526213] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.004 [0.9710483734069532, 1.1990456211866474] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 1.013 [0.9121631727227492, 1.2564763321532475] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.076 [0.8983405409370662, 1.2291474695129159] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 1.018 [0.9766050644660427, 1.1409845567024304] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.004 [0.8761288402863066, 1.047526869948946] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.968 [0.814188150903815, 1.0802556593120365] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.913 [0.7929962719308549, 1.0688092420303614] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.015 [0.8547035531219103, 1.0670773335016726] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.006 [0.849019336292734, 1.1158525869316103] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.994 [0.9466132760696682, 1.3080331584291707] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.006 [0.887383908929658, 1.057762275047746] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 1.006 [0.9549139710590412, 1.079339706107325] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 1.067 [0.8209812315928128, 1.2129234243955003] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 1.040 [0.9372967010001185, 1.1010096783996919] | inconclusive-noisy |
| full | aa | `temporary_chain_1000d_x50000` | 1.008 [0.9328210278251781, 1.1014167097423169] | inconclusive-noisy |
| full | aa | `file_statements_20000` | 1.019 [0.9873360809238292, 1.2061636208245363] | inconclusive-noisy |
| full | paired | `startup` | 0.905 [0.8309948708484403, 1.1031912356027] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.054 [1.0161024548006679, 1.1682892999115353] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.925 [0.7737732647749375, 1.005323299474704] | pass |
| full | paired | `array_200000` | 0.959 [0.8687167693433776, 1.130277218647608] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.969 [0.7357179726469303, 1.1406577933684263] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.091 [0.991537376459043, 1.1814706799917245] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.964 [0.9611553326995578, 1.208014812161357] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.022 [0.8047000448929782, 1.1494201510792756] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.955 [0.855973405422108, 1.0039469821333584] | pass |
| full | paired | `multiply_100d_x100000` | 0.988 [0.9048733662779819, 1.134237741513393] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.020 [0.9646474402805693, 1.1206484146977318] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.995 [0.9150754484807327, 1.0702169016686878] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.993 [0.8578892863059169, 1.0992230968073025] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.7753831694544906, 1.020529711816741] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.061 [0.9554778955693316, 1.2053378315981733] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.009 [0.8548256385416168, 1.2077132124975476] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.978 [0.906116766233973, 1.3617362028731592] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.931 [0.7653750495776067, 1.0802748971335405] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.993 [0.9154654070049918, 1.0300231041926329] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.002 [0.7964103606956664, 1.2522897160232365] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.997 [0.9468436226194226, 1.0987943847737667] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.040 [1.021041615440462, 1.2724245568287478] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.982 [0.7765304167161027, 1.1318404297653155] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.014 [0.8503974677243352, 1.1397358225512357] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.991 [0.8948140017415565, 1.155844381028981] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.020 [0.9675493451562899, 1.152263229718487] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.998 [0.8933234298957121, 1.0027439424193765] | pass |
| full | paired | `square_10000d_x500` | 0.959 [0.9407951652927256, 1.0034941701733937] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.004 [0.8550334424018623, 1.1991466806447402] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.094 [0.8795835786512751, 1.2599237855595087] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.032 [0.8730484508927738, 1.1122271619966464] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 1.003 [0.9908815648531358, 1.4519764091995835] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 1.030 [0.9948377859596484, 1.1097620813940998] | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 0.994 [0.9703339869262284, 1.0796259282329537] | inconclusive-noisy |
| full | paired | `file_statements_20000` | 0.986 [0.9538600176391876, 1.1979921058483152] | inconclusive-noisy |
