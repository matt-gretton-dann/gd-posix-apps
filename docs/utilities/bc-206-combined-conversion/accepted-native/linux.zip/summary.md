# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.982 [0.8885836395545168, 1.0397383140462377] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.994 [0.9839897978807187, 1.0301667230309097] | pass |
| full | aa | `calls_200000` | 1.003 [0.9706014678317365, 1.0090298183625321] | pass |
| full | aa | `array_200000` | 0.992 [0.989460604427932, 1.0011410885072474] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.000 [0.9892304011364861, 1.0125877160372065] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.023 [0.9915500623182786, 1.1217093669947065] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.993 [0.9822687359998119, 1.0061017071230127] | pass |
| full | aa | `fibonacci_1000_x100` | 0.994 [0.9784248032140717, 1.0023761215623577] | pass |
| full | aa | `factorial_1000_x50` | 0.999 [0.9915982238620576, 1.0115640609734051] | pass |
| full | aa | `multiply_100d_x100000` | 1.003 [0.949498804264399, 1.0081045629688137] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9980583698187329, 1.0026631416207923] | pass |
| full | aa | `divide_scale100_x100000` | 0.998 [0.9935773611070442, 1.0214274653101194] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.002 [0.9945669873068119, 1.0038848597951917] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.9966814064902675, 1.0047445807048752] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9875527155841829, 1.0102679422530918] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.996442149342393, 1.0017583201670566] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.998 [0.97792202846571, 1.0209568146198709] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.999 [0.9965144896691561, 1.0139241483345658] | pass |
| full | aa | `power_100d_e17_x1000` | 0.996 [0.9911775707513526, 1.002482781420489] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.993 [0.9593441265362972, 1.0076539439004482] | pass |
| full | aa | `recursion_50_x1000` | 1.008 [0.9871569224913149, 1.0141571926364885] | pass |
| full | aa | `sparse_array_200000` | 0.998 [0.9840794200425256, 1.0127647999851899] | pass |
| full | aa | `frontend_definitions_2000` | 0.999 [0.9929387771014565, 1.0136594435924586] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.999 [0.9842482409606659, 1.0170783353500137] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.008 [0.9745572819543245, 1.0650779950761258] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.008 [0.9861436509804639, 1.0161599667561352] | pass |
| full | aa | `square_100d_x100000` | 1.000 [0.996059471347112, 1.021492319058422] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9969749060650974, 1.0009743062455956] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.995 [0.979459228209682, 1.1912807330602002] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.993 [0.9722584737836132, 1.0169043527177222] | pass |
| full | aa | `octal_output_1000d_x300` | 1.004 [0.995495686863675, 1.0175546654026129] | pass |
| full | aa | `binary_input_100000d_x3` | 0.999 [0.974497667849498, 1.0116768386385742] | pass |
| full | aa | `hex_input_100000d_x3` | 1.001 [0.9951121590601029, 1.0100600695345157] | pass |
| full | paired | `startup` | 1.027 [0.8485062843525558, 1.0555100866484781] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.991 [0.9727048856888328, 1.0095604849581372] | pass |
| full | paired | `calls_200000` | 1.020 [1.0091722400338332, 1.0542859492263328] | inconclusive-noisy |
| full | paired | `array_200000` | 1.010 [1.0026365208637222, 1.0196215116614364] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.015 [0.9957268624494864, 1.0291093382549967] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.985 [0.9552833804163846, 0.9895493790805632] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.985 [0.8794562026176834, 1.015819425254913] | pass |
| full | paired | `fibonacci_1000_x100` | 1.011 [0.9943127579345805, 1.0286875786933876] | pass |
| full | paired | `factorial_1000_x50` | 1.010 [1.0046079240868866, 1.0130110949078448] | pass |
| full | paired | `multiply_100d_x100000` | 1.041 [1.0280580248400844, 1.0635575269765645] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.996901031275655, 1.0020847457915472] | pass |
| full | paired | `divide_scale100_x100000` | 1.035 [1.0292439302423426, 1.077045631901763] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.006 [1.0010345037700759, 1.0067271492678636] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.9960818720824056, 1.005271273083171] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.981 [0.9771385444791341, 0.9983469291049819] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.998 [0.9943158648845682, 1.0013364978863775] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.999 [0.9947058272108429, 1.0032413050952973] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.008 [0.9773037265012755, 1.0113132784904404] | pass |
| full | paired | `power_100d_e17_x1000` | 1.000 [0.9987593664043866, 1.0111358959853254] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.979 [0.9667623898173644, 0.9928943570015957] | pass |
| full | paired | `recursion_50_x1000` | 1.028 [1.017862166698364, 1.036269092934654] | pass |
| full | paired | `sparse_array_200000` | 1.037 [1.0269657981676532, 1.0450933000217961] | pass |
| full | paired | `frontend_definitions_2000` | 1.004 [0.986001689676133, 1.0226742832676932] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.009 [0.9907390233493956, 1.0254334428047311] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.756 [0.7166667647577935, 0.814291173757204] | pass |
| full | paired | `streaming_statements_20000` | 0.970 [0.9627694080311596, 0.9837212093863822] | pass |
| full | paired | `square_100d_x100000` | 1.050 [1.0344937538795829, 1.0657875660702827] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.001 [0.999866132560997, 1.0019980213959307] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.039 [1.0017317343919394, 1.0689512726094896] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.994 [0.9599090883646418, 1.0340622266355672] | pass |
| full | paired | `octal_output_1000d_x300` | 1.000 [0.9902153906306974, 1.0098660328215772] | pass |
| full | paired | `binary_input_100000d_x3` | 0.953 [0.9386716374882104, 0.9667182444102564] | pass |
| full | paired | `hex_input_100000d_x3` | 0.989 [0.9861588520902985, 0.9983571464810403] | pass |
