# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.957 [0.9165374466180967, 1.0398686942305777] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.977 [0.955948230808064, 1.0020304158045823] | pass |
| full | aa | `calls_200000` | 1.000 [0.9723317570069293, 1.0354877054200395] | pass |
| full | aa | `array_200000` | 0.989 [0.9564173796820414, 1.0385290709173276] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.999 [0.9849448108599749, 1.0073371986544017] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.997 [0.9841601498286218, 1.0362774995573174] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.003 [0.972927513015336, 1.0068041314842147] | pass |
| full | aa | `fibonacci_1000_x100` | 0.999 [0.995310571070592, 1.0232095253807343] | pass |
| full | aa | `factorial_1000_x50` | 0.997 [0.9919760886796867, 1.0071412767454446] | pass |
| full | aa | `multiply_100d_x100000` | 0.989 [0.981430725783766, 0.9951459762184294] | pass |
| full | aa | `multiply_10000d_x1000` | 1.004 [0.985369441569245, 1.010572657243896] | pass |
| full | aa | `divide_scale100_x100000` | 0.984 [0.975558956049499, 0.9874861611670893] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9957657531281797, 1.003026837780756] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.995 [0.981676936530157, 1.0064868773808746] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.985384331813945, 1.0232327594204025] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.005 [0.9900974377480809, 1.0458345065523407] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.994 [0.9898871095319143, 1.00347070924058] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.998 [0.987332642846609, 1.0156634431702543] | pass |
| full | aa | `power_100d_e17_x1000` | 0.987 [0.941812971937176, 1.0123725476427585] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.987 [0.838750871455802, 1.051843730806418] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 1.001 [0.9887038823060391, 1.0174372394841464] | pass |
| full | aa | `sparse_array_200000` | 1.014 [0.9573596232784505, 1.0496076702993593] | pass |
| full | aa | `frontend_definitions_2000` | 0.986 [0.9639460758692344, 1.02815791268803] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.995 [0.9664107817460087, 1.0186194606783647] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.001 [0.9687878450650717, 1.0208097747598472] | pass |
| full | aa | `streaming_statements_20000` | 1.000 [0.9802018852553568, 1.0571004241184199] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.987 [0.9776437420328229, 1.002917857757648] | pass |
| full | aa | `square_10000d_x500` | 1.002 [0.9960928677165037, 1.0077664070269559] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.996 [0.9087520870317638, 1.061223506162259] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.000 [0.969506197128712, 1.008405506634761] | pass |
| full | aa | `octal_output_1000d_x300` | 0.992 [0.9642177873642744, 1.0204310905548677] | pass |
| full | aa | `binary_input_100000d_x3` | 0.997 [0.9361321150232945, 1.0139332914490597] | pass |
| full | aa | `hex_input_100000d_x3` | 1.001 [0.9922313937621627, 1.0204764882384187] | pass |
| full | paired | `startup` | 0.983 [0.9042572797650172, 1.4015837748434616] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.001 [0.9926719232746732, 1.0289153658955608] | pass |
| full | paired | `calls_200000` | 0.994 [0.9566882680951846, 1.0096889042800088] | pass |
| full | paired | `array_200000` | 1.011 [0.9633484801711768, 1.0428377133336293] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.993 [0.9667546882353303, 1.005485866629962] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.038 [1.0024016707281067, 1.056938418982298] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.027 [0.9096434354243547, 1.0346156458516758] | pass |
| full | paired | `fibonacci_1000_x100` | 1.014 [0.9871847792704814, 1.0250104676452942] | pass |
| full | paired | `factorial_1000_x50` | 1.019 [0.9156774636260724, 1.0266986128707718] | pass |
| full | paired | `multiply_100d_x100000` | 1.008 [0.9731299212590632, 1.0404092427428049] | pass |
| full | paired | `multiply_10000d_x1000` | 0.963 [0.956185903795002, 0.9776856305095084] | pass |
| full | paired | `divide_scale100_x100000` | 0.978 [0.9719803148971885, 1.0414754540636602] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.995 [0.9691554622598592, 1.001279211722824] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.976 [0.9452567899815276, 0.9943136480327162] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.963 [0.9490448709354753, 0.9973483756171398] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.987 [0.9408885510486295, 1.0083397583793963] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.003 [0.9725658444773551, 1.0409336469585644] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.973 [0.9100171545260799, 0.9928067280932643] | pass |
| full | paired | `power_100d_e17_x1000` | 1.004 [0.9831725398611597, 1.0271636777034565] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.978 [0.9702639965685051, 0.9903500369707698] | pass |
| full | paired | `recursion_50_x1000` | 0.994 [0.9753415315104776, 1.0171708315048125] | pass |
| full | paired | `sparse_array_200000` | 1.006 [0.8997093373393276, 1.0302380177185482] | pass |
| full | paired | `frontend_definitions_2000` | 1.011 [0.9683144174201085, 1.0321905083622267] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.015 [0.991056981676866, 1.0566397492764383] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.623 [0.5807720779746154, 0.6600921452929688] | pass |
| full | paired | `streaming_statements_20000` | 1.116 [1.0754211203949269, 1.1246662982071822] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.992 [0.8939641733479005, 1.0130666107391308] | pass |
| full | paired | `square_10000d_x500` | 0.996 [0.9890478617596549, 1.0074748041202883] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.027 [0.9846862283137986, 1.0644537313515858] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.012 [0.9298959505153472, 1.0595544415384481] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.013 [0.991768172022883, 1.0223182306561254] | pass |
| full | paired | `binary_input_100000d_x3` | 0.943 [0.9287032029832623, 0.9582074204953465] | pass |
| full | paired | `hex_input_100000d_x3` | 0.941 [0.9298607648008181, 0.9689762787209455] | pass |
