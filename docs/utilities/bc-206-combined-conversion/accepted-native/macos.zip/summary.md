# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.014 [0.8978507154987874, 1.0387358112051626] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.958 [0.9383469468317092, 1.035820792584555] | pass |
| full | aa | `calls_200000` | 1.006 [0.9747759961727106, 1.1909666568851953] | inconclusive-noisy |
| full | aa | `array_200000` | 1.025 [0.9335102040984814, 1.0447522849627189] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.079 [0.9981791528525964, 1.290945213359733] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.920 [0.8165287575252765, 1.1870683038034315] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.024 [0.9942421638122054, 1.1761163314154135] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.004 [0.8429626198554784, 1.2840047698188217] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.031 [0.9743851606765975, 1.1217078380767909] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 1.006 [0.9376080577732798, 1.0779248231565912] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 0.936 [0.9037913462817484, 0.9846247738261796] | pass |
| full | aa | `divide_scale100_x100000` | 1.004 [0.9609723402603622, 1.0444481516269875] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.985 [0.887595954773993, 1.6035886399860952] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 0.972 [0.9122074124238547, 1.0743021329770266] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.006 [0.93366046984528, 1.0121200138866369] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.004 [0.890117762166104, 1.106127526429226] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.954 [0.9166398717812059, 1.047698753071938] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.996 [0.7875886453094363, 1.020254561026413] | pass |
| full | aa | `power_100d_e17_x1000` | 0.985 [0.8971947274005688, 0.9931227760475771] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.948 [0.7559469894073798, 1.0176241702900644] | pass |
| full | aa | `recursion_50_x1000` | 0.994 [0.8766203437754297, 1.0227042290865833] | pass |
| full | aa | `sparse_array_200000` | 0.955 [0.909752359376229, 1.0676349021044993] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 1.008 [0.8404512577109736, 1.241219182189229] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.008 [0.9272871955608162, 1.022874863259166] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.930 [0.7946852694869347, 1.033402432040694] | pass |
| full | aa | `streaming_statements_20000` | 1.070 [0.9561278569140488, 1.234762379611206] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.986 [0.8788332176926694, 1.0720284950368268] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 1.021 [0.9512790690122767, 1.1037191511150422] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 1.007 [0.9153147440651933, 1.1546967385685978] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.014 [0.9551105227294003, 1.0736345430785756] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 0.993 [0.9520164056286583, 1.0384608396237864] | pass |
| full | aa | `binary_input_100000d_x3` | 0.996 [0.8448502279746714, 1.0978855387767377] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 0.979 [0.9722446686047242, 1.1010828372476866] | inconclusive-noisy |
| full | paired | `startup` | 0.968 [0.7001844961763362, 1.1088428185920547] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.025 [0.9366490800644308, 1.1511249083676038] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.015 [0.9634925723147888, 1.0402470627905374] | pass |
| full | paired | `array_200000` | 1.001 [0.9405609386886357, 1.0644831992016968] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.994 [0.9745446421997881, 1.0373143922345922] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.018 [0.9818930112872806, 1.0635920095701796] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.059 [0.9641870931676824, 1.0900899233197516] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.992 [0.9539185165672919, 1.0211371673434042] | pass |
| full | paired | `factorial_1000_x50` | 1.002 [0.8578759228500336, 1.042500915542523] | pass |
| full | paired | `multiply_100d_x100000` | 1.003 [0.9105158004367027, 1.0252337650995234] | pass |
| full | paired | `multiply_10000d_x1000` | 0.965 [0.9603371177752414, 1.0331551597622866] | pass |
| full | paired | `divide_scale100_x100000` | 0.997 [0.8303303634934783, 1.0407721598815218] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.999 [0.9213811064664694, 1.0557556189910895] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.968 [0.91452984434655, 1.0737806313177338] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.010 [0.9713973634411082, 1.090319200048059] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.006 [0.9239626084606509, 1.1035322029402421] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.9225646493951517, 1.2081304925612621] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.983 [0.9440305833474485, 1.0657587787651894] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.983 [0.9489613293590159, 1.1392491052132017] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 1.013 [0.9583807885670717, 1.1402525232662313] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.990 [0.9533442832982485, 1.0151473059891174] | pass |
| full | paired | `sparse_array_200000` | 0.996 [0.8760374371605437, 1.0083078319262873] | pass |
| full | paired | `frontend_definitions_2000` | 0.997 [0.84099839631497, 1.030729765155223] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.001 [0.9820475363886858, 1.1677186320789725] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.687 [0.5513312469240238, 0.7898562340204106] | pass |
| full | paired | `streaming_statements_20000` | 0.966 [0.8786373960420021, 1.053535930194595] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.998 [0.9102366719338855, 1.0743534215352954] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.998 [0.9496578337377402, 1.0176727551390035] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.966 [0.8705502984980422, 1.0501736203681413] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.021 [0.9839538066437653, 1.048664328787499] | pass |
| full | paired | `octal_output_1000d_x300` | 0.990 [0.8175711071908845, 1.258123151492438] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.952 [0.9212052985478886, 0.9736833280901517] | pass |
| full | paired | `hex_input_100000d_x3` | 0.975 [0.8758076686347488, 0.9806404768124118] | pass |
