# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.928 [0.891975288791495, 1.0665874311072172] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.996 [0.9704014844423403, 1.0110540229268599] | pass |
| full | aa | `calls_200000` | 0.991 [0.9614725023023151, 1.0128850280569504] | pass |
| full | aa | `array_200000` | 1.006 [0.9675158996212395, 1.01053420649532] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.998 [0.9554124910815406, 1.0084135960423568] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.998 [0.9870591860847892, 1.0286460565493432] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.989 [0.9813649702984854, 1.022480468701401] | pass |
| full | aa | `fibonacci_1000_x100` | 1.010 [0.9964009746553024, 1.020932734356304] | pass |
| full | aa | `factorial_1000_x50` | 0.995 [0.9848513259733463, 1.004324748993639] | pass |
| full | aa | `multiply_100d_x100000` | 0.997 [0.9870409077286941, 1.0090300793127323] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9615362968104904, 1.025396195976774] | pass |
| full | aa | `divide_scale100_x100000` | 0.977 [0.9649023111989112, 0.9908591751772413] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.992 [0.9865675060400518, 0.996247740613256] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.9971066612722692, 1.0035618905873571] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9829877756861312, 1.0150814241024224] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9932760963041116, 1.003355302285516] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.993 [0.9746053456682678, 1.007267278631697] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.001 [0.9941151125536397, 1.0033190056952372] | pass |
| full | aa | `power_100d_e17_x1000` | 1.001 [0.9981554618747779, 1.005841043485068] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.993 [0.9831930664525005, 1.0180034322975813] | pass |
| full | aa | `recursion_50_x1000` | 0.991 [0.9762798288149747, 1.003062862111747] | pass |
| full | aa | `sparse_array_200000` | 0.996 [0.9822088279264805, 1.003607079023681] | pass |
| full | aa | `frontend_definitions_2000` | 0.997 [0.9924894497979221, 1.0124433003358138] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.003 [0.981644559170465, 1.0252623822706615] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.001 [0.9246765454209946, 1.0622713615179462] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.008 [0.9963747051270345, 1.0204312662210817] | pass |
| full | aa | `square_100d_x100000` | 0.999 [0.9819582950780399, 1.0322213189072955] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9986816333497809, 1.0021118086541454] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.997 [0.9624202575006542, 1.2024127060773118] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.997 [0.9768690785823029, 1.0039298631861868] | pass |
| full | aa | `octal_output_1000d_x300` | 1.004 [0.9977438916683152, 1.0159410317439017] | pass |
| full | aa | `binary_input_100000d_x3` | 0.997 [0.9898045253431943, 1.0049508893432717] | pass |
| full | aa | `hex_input_100000d_x3` | 1.006 [0.993776132476236, 1.0148082883662994] | pass |
| full | paired | `startup` | 0.990 [0.839409963982668, 1.108260482102409] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.996 [0.9845094841444377, 1.003659705340959] | pass |
| full | paired | `calls_200000` | 1.014 [1.0012414684685096, 1.0268508152916713] | pass |
| full | paired | `array_200000` | 0.990 [0.9663235633392327, 1.0041220027994728] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.007 [0.9955086610472178, 1.0358776356578394] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.972 [0.9621928395351044, 0.9839386428520908] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.985 [0.9649317843802286, 0.9988239880784068] | pass |
| full | paired | `fibonacci_1000_x100` | 1.025 [1.0057108506747905, 1.0422804498283647] | pass |
| full | paired | `factorial_1000_x50` | 0.995 [0.9771655017790455, 1.0049085559569098] | pass |
| full | paired | `multiply_100d_x100000` | 1.013 [1.0101486474622823, 1.0265198191510103] | pass |
| full | paired | `multiply_10000d_x1000` | 0.997 [0.9938944036916317, 1.00188421037464] | pass |
| full | paired | `divide_scale100_x100000` | 0.984 [0.9744947518918998, 1.000264799940262] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.006 [0.9984803490089802, 1.011768655111033] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.998 [0.9941195852287029, 0.9997196822212391] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.989 [0.9849054075278054, 1.0018027585664875] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.005 [0.9959483449798421, 1.0063988049727421] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.996 [0.9925836938375096, 1.0023481100222942] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.999 [0.9944749197600924, 1.0081138709711581] | pass |
| full | paired | `power_100d_e17_x1000` | 0.998 [0.9926477117879382, 1.0161179341476962] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.001 [0.9828535738354769, 1.0108632367519665] | pass |
| full | paired | `recursion_50_x1000` | 1.015 [0.9840214211679676, 1.0285624498473214] | pass |
| full | paired | `sparse_array_200000` | 1.036 [1.0245516332795104, 1.05116220662725] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.002 [0.9906475207813735, 1.0158202665672869] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.987 [0.9757755393571579, 1.0002231569906692] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.730 [0.713237888118006, 0.8801988948207488] | pass |
| full | paired | `streaming_statements_20000` | 0.974 [0.9620751252784954, 1.0075658870544613] | pass |
| full | paired | `square_100d_x100000` | 1.013 [0.996690676365196, 1.027069674574598] | pass |
| full | paired | `square_10000d_x500` | 0.999 [0.9978136563281791, 0.9999540142008864] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.003 [0.9633430331118396, 1.0651452002637358] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.973 [0.9555999410067133, 1.0384040807022683] | pass |
| full | paired | `octal_output_1000d_x300` | 0.999 [0.9922327757160683, 1.011623098430671] | pass |
| full | paired | `binary_input_100000d_x3` | 0.994 [0.9741642564205759, 0.998533731961047] | pass |
| full | paired | `hex_input_100000d_x3` | 0.995 [0.9891651610639389, 1.0138217182987517] | pass |
