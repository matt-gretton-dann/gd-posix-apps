# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.955 [0.8303070557489707, 1.0019762386342825] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.988 [0.9439321254691544, 1.0285845898679324] | pass |
| full | aa | `calls_200000` | 0.994 [0.9757108750245868, 1.0002823004565604] | pass |
| full | aa | `array_200000` | 1.003 [0.984662277955167, 1.0172896797863475] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.008 [0.9690141353677255, 1.0401238511430562] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.013 [0.9286472988471918, 1.0266122580637063] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.991 [0.9273955847669428, 1.0201991885972943] | pass |
| full | aa | `fibonacci_1000_x100` | 1.002 [0.9811925612285963, 1.0126579626446983] | pass |
| full | aa | `factorial_1000_x50` | 0.999 [0.9847454654231895, 1.0166304096408634] | pass |
| full | aa | `multiply_100d_x100000` | 0.995 [0.941046261260553, 1.0081881764289558] | pass |
| full | aa | `multiply_10000d_x1000` | 0.990 [0.9173568138536833, 1.024309058309796] | pass |
| full | aa | `divide_scale100_x100000` | 0.995 [0.9553303729489219, 1.0086674460162757] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.9772340447860323, 1.04697820751201] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.004 [0.9770234319579191, 1.0497965557995268] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.993 [0.9808505410678738, 1.0138211919716444] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.991 [0.9412035288093098, 1.053266174786214] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.987 [0.951666730661161, 1.1725861527112997] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.984 [0.9470569580825171, 1.0261951482628184] | pass |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9966918065137563, 1.030153558834023] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.996 [0.9622049320944245, 1.036380534077445] | pass |
| full | aa | `recursion_50_x1000` | 1.006 [0.9769324452043509, 1.0354527027900322] | pass |
| full | aa | `sparse_array_200000` | 1.001 [0.9428366036122038, 1.009573122362024] | pass |
| full | aa | `frontend_definitions_2000` | 0.996 [0.9774567080445989, 1.029470636713985] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.008 [0.9843526374340575, 1.0203286243057859] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.986 [0.9131191049005654, 1.0871297181273634] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.005 [0.9715115030709369, 1.023579612778428] | pass |
| full | aa | `square_100d_x100000` | 0.987 [0.95924990898695, 1.0092989385756133] | pass |
| full | aa | `square_10000d_x500` | 0.989 [0.9353482289488813, 1.0088561570360557] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.975 [0.8721774128816592, 1.0958658594658033] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.013 [0.971473992559129, 1.04732074685804] | pass |
| full | aa | `octal_output_1000d_x300` | 1.031 [0.9641250480511376, 1.0661294519270383] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 1.009 [1.0000279102994314, 1.0399677973270283] | pass |
| full | aa | `hex_input_100000d_x3` | 0.985 [0.9766804647300169, 1.004653390486178] | pass |
| full | paired | `startup` | 1.003 [0.9092296371071407, 1.0956989679124196] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.019 [0.9607557956985909, 1.0732617202239636] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.005 [0.923208537406889, 1.011535889597992] | pass |
| full | paired | `array_200000` | 1.002 [0.9310096003652125, 1.0601293912214618] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.023 [0.9546656942624411, 1.052814995086675] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.989 [0.9572434303230791, 1.0474989252960076] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.939 [0.889911946748865, 1.004638771825829] | pass |
| full | paired | `fibonacci_1000_x100` | 1.003 [0.9526091837180708, 1.1333147280094433] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.015 [0.9946629822800037, 1.0439693003234416] | pass |
| full | paired | `multiply_100d_x100000` | 0.959 [0.8534359673459474, 1.14981829121637] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.013 [0.9933597626035953, 1.065443228217701] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.987 [0.9466355002102516, 0.9989032110525518] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.050 [0.866385302519911, 1.078883909120898] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.990 [0.9386193503918194, 1.0512406314463802] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.996 [0.918317799038526, 1.0562012899014739] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.978 [0.9378817776032591, 1.0433613745017545] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.966 [0.9177112757832765, 1.1492420033581794] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.993 [0.9235068014636925, 1.251910266424755] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.001 [0.9592276374376291, 1.007417664779207] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.003 [0.9910522918808435, 1.024154639068971] | pass |
| full | paired | `recursion_50_x1000` | 1.007 [0.9830163906981952, 1.0882136209368745] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.006 [0.9989324074936557, 1.092551538226168] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.005 [0.873477727268964, 1.0300096588900014] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.978 [0.9295789182828316, 0.9920711211106245] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.733 [0.6233482558064645, 0.7598044445501161] | pass |
| full | paired | `streaming_statements_20000` | 1.052 [0.9688786265189044, 1.0712771864116812] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.004 [0.9403169212302278, 1.0272086072022324] | pass |
| full | paired | `square_10000d_x500` | 1.010 [0.9895781939628057, 1.0222126343455349] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.013 [0.9169590064904143, 1.0386319689580268] | pass |
| full | paired | `binary_output_1000d_x300` | 1.004 [0.9546281299879226, 1.0182958153818344] | pass |
| full | paired | `octal_output_1000d_x300` | 1.001 [0.9253780536723969, 1.0474280987225433] | pass |
| full | paired | `binary_input_100000d_x3` | 0.985 [0.9250244220493569, 1.0394800696852742] | pass |
| full | paired | `hex_input_100000d_x3` | 0.977 [0.935984573515591, 1.0058047071128464] | pass |
