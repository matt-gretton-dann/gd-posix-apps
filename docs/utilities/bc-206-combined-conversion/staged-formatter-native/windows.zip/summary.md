# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.921 [0.8792674148290068, 1.0975198222172207] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.007 [0.9870150447095327, 1.030439347200516] | pass |
| full | aa | `calls_200000` | 0.992 [0.983799778753985, 1.0088942102657241] | pass |
| full | aa | `array_200000` | 0.983 [0.964642790226229, 1.0004693125577906] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.987 [0.9466140997614279, 1.0189693493573095] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.995 [0.9886191044504592, 1.0585989219020744] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.991 [0.9606827993943613, 0.9969452730607798] | pass |
| full | aa | `fibonacci_1000_x100` | 0.996 [0.9858154835868137, 1.026204881111483] | pass |
| full | aa | `factorial_1000_x50` | 0.992 [0.9816988494613187, 1.0105947081317923] | pass |
| full | aa | `multiply_100d_x100000` | 0.987 [0.9603401227693893, 1.0200254089691618] | pass |
| full | aa | `multiply_10000d_x1000` | 1.003 [0.9849715790022701, 1.0105511526002513] | pass |
| full | aa | `divide_scale100_x100000` | 1.001 [0.9513176750378078, 1.006585064685844] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.989 [0.9291209962156181, 0.9998553207320034] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.004 [0.9859977438589117, 1.0100030697969333] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9918854270734271, 1.0116857428613941] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9920977064449122, 1.0163886394781176] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.011 [0.965665842458847, 1.0494863465558346] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.001 [0.9897834862387357, 1.0125503150262574] | pass |
| full | aa | `power_100d_e17_x1000` | 1.009 [1.0049261683665922, 1.014827008169746] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.983 [0.9564251099210649, 1.0130289811587612] | pass |
| full | aa | `recursion_50_x1000` | 0.999 [0.9772977551893856, 1.1385415428058472] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.006 [0.9863855850983867, 1.0283054811710148] | pass |
| full | aa | `frontend_definitions_2000` | 0.992 [0.9696252313566034, 1.0316395908891567] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.997 [0.9844406276865245, 1.0156696673250427] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.988 [0.9601771143701577, 1.017192597705667] | pass |
| full | aa | `streaming_statements_20000` | 1.013 [0.9983434632475646, 1.0358864442821383] | pass |
| full | aa | `square_100d_x100000` | 1.000 [0.9845606834668919, 1.0045242288831633] | pass |
| full | aa | `square_10000d_x500` | 0.998 [0.9908449413870849, 1.0023831402213013] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.019 [0.9425483970107262, 1.095674982787167] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.995 [0.9498430398702719, 1.0210265231249822] | pass |
| full | aa | `octal_output_1000d_x300` | 1.001 [0.9879611684414636, 1.0192151722256588] | pass |
| full | aa | `binary_input_100000d_x3` | 0.993 [0.9878207399162388, 1.0156126025699719] | pass |
| full | aa | `hex_input_100000d_x3` | 0.992 [0.9661752041241858, 1.007009500869545] | pass |
| full | paired | `startup` | 0.985 [0.9321190702772979, 1.0145294473015039] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.011 [0.966211151353832, 1.031764818660475] | pass |
| full | paired | `calls_200000` | 0.990 [0.9584440087444541, 1.0039622282195582] | pass |
| full | paired | `array_200000` | 1.029 [0.9875458350311359, 1.0521158134604287] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.021 [0.9107988339636647, 1.063080613808042] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.052 [0.9071137265625647, 1.1474483838691663] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.050 [1.0215854690969117, 1.1016413777192864] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.016 [0.993095153850677, 1.0582869408891173] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.986 [0.9684612789781244, 0.9994410410048277] | pass |
| full | paired | `multiply_100d_x100000` | 1.003 [0.9973326242041813, 1.0362449505464313] | pass |
| full | paired | `multiply_10000d_x1000` | 0.995 [0.9733036683482388, 1.0331497586690035] | pass |
| full | paired | `divide_scale100_x100000` | 0.998 [0.9818017281725792, 1.0230946532243659] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.009 [0.9890320493641784, 1.0708597054881928] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.990 [0.9675479219865638, 1.001956037349809] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.986 [0.9105556256448044, 1.0172719733905116] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.019 [0.9779683522181811, 1.0398998346290438] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.986 [0.9415620879411605, 1.0237136849637714] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.002 [0.9888021270984615, 1.0590866233469904] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 0.978 [0.9562381240365082, 1.004397771625963] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.991 [0.9814106477651175, 1.0239321738332368] | pass |
| full | paired | `recursion_50_x1000` | 0.958 [0.924012208948206, 0.9842140376353788] | pass |
| full | paired | `sparse_array_200000` | 1.006 [0.9521655278989986, 1.0481405508025028] | pass |
| full | paired | `frontend_definitions_2000` | 0.979 [0.8904750814115044, 1.0354513553235791] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.025 [0.9841804473734014, 1.0710976794388474] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.694 [0.6721521596330894, 0.73692443760265] | pass |
| full | paired | `streaming_statements_20000` | 1.098 [1.018541790878646, 1.1137548268266637] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.996 [0.9852245162204814, 1.0317199806736062] | pass |
| full | paired | `square_10000d_x500` | 1.001 [0.9903128130109617, 1.021707770044517] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.974 [0.9267022724511126, 1.0380705969306365] | pass |
| full | paired | `binary_output_1000d_x300` | 1.016 [0.9445305489836489, 1.1267800655230449] | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 0.960 [0.9082614994954864, 0.9952308545885316] | pass |
| full | paired | `binary_input_100000d_x3` | 0.991 [0.9705030144886205, 1.1240883379616042] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 1.013 [0.9635877901562854, 1.1047209366953261] | inconclusive-noisy |
