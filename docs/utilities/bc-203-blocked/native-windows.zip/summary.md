# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.947 [0.9442568035221457, 0.9698563113343145] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.002 [0.995348889524617, 1.0236592954624126] | pass |
| full | aa | `calls_200000` | 0.995 [0.9833549373013801, 1.0043913165033405] | pass |
| full | aa | `array_200000` | 1.003 [0.9947283219671186, 1.0424161570343304] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.004 [0.9950226897035577, 1.13334112029883] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.997 [0.9915438148140726, 1.0012563314058565] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.003 [0.998493636914268, 1.0054393305435723] | pass |
| full | aa | `fibonacci_1000_x100` | 1.000 [0.9838211503788037, 1.003594261996847] | pass |
| full | aa | `factorial_1000_x50` | 0.992 [0.9864535470360709, 1.011355514448527] | pass |
| full | aa | `multiply_100d_x100000` | 1.005 [1.0013966167518027, 1.0082335864193435] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [1.00000909193656, 1.0021935186463304] | pass |
| full | aa | `divide_scale100_x100000` | 1.000 [0.9456245793577251, 1.006895412974828] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.006 [0.9824427560697755, 1.0773274233574925] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 0.998 [0.9936056474060192, 1.0026518889080427] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9760775751975381, 1.0123267502664544] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.004 [0.9865653282479069, 1.009557520110656] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.999 [0.9770343414592216, 1.014169058286128] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.010 [0.9922658173525664, 1.0288551498980065] | pass |
| full | aa | `power_100d_e17_x1000` | 1.011 [0.9759952096995917, 1.0182445119214454] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.001 [0.996222330182072, 1.0236205847893733] | pass |
| full | aa | `recursion_50_x1000` | 1.013 [0.9814809870009431, 1.0600616198025654] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.997 [0.9698995013424789, 0.9989850080699795] | pass |
| full | aa | `frontend_definitions_2000` | 1.013 [1.0052413451548612, 1.029646687918892] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.001 [0.9900891666758947, 1.0053083765622013] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.998 [0.9895951587074011, 1.0197120064048137] | pass |
| full | aa | `streaming_statements_20000` | 0.994 [0.9636907144756689, 1.0014366175908251] | pass |
| full | aa | `square_100d_x100000` | 1.001 [0.9968334721596188, 1.014003380391905] | pass |
| full | aa | `square_10000d_x500` | 0.995 [0.9886687049947158, 1.0115570313367133] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.980 [0.9416714262447575, 1.0497453184312693] | pass |
| full | paired | `startup` | 0.972 [0.9315479717148338, 1.086229029256318] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.990 [0.9770071863664729, 0.9964034203913249] | pass |
| full | paired | `calls_200000` | 0.993 [0.9833134955612421, 1.0024371796706752] | pass |
| full | paired | `array_200000` | 1.003 [0.9937474149433997, 1.0086581956171525] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.997 [0.9864092746088485, 1.0032402126581643] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.962 [0.949074988478332, 0.9678156855344798] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.974 [0.9656552282359886, 0.9772478863286187] | pass |
| full | paired | `fibonacci_1000_x100` | 0.991 [0.9865704987749161, 1.0182595859915555] | pass |
| full | paired | `factorial_1000_x50` | 0.990 [0.9818283613484978, 1.0109259235109762] | pass |
| full | paired | `multiply_100d_x100000` | 0.857 [0.8506566229692704, 0.8623803786113455] | pass |
| full | paired | `multiply_10000d_x1000` | 0.483 [0.4799832547402031, 0.48381484250171786] | pass |
| full | paired | `divide_scale100_x100000` | 1.000 [0.9791885895744267, 1.0052913080315475] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.003 [0.9960958666766985, 1.0074679456976563] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.489 [0.4857372747279749, 0.4903262715872826] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.648 [0.6371664725768097, 0.6508706226063641] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.557 [0.5545642229986064, 0.5634214781939118] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.995 [0.9757790411634797, 1.054214687016448] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.790 [0.7509368702318309, 0.8102176221209649] | pass |
| full | paired | `power_100d_e17_x1000` | 0.885 [0.809034358402309, 0.8931638678020203] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.997 [0.7910835510170756, 1.027539380338747] | pass |
| full | paired | `recursion_50_x1000` | 1.001 [0.9445806863354985, 1.082284026782458] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.993 [0.9615796010879573, 1.042625899750809] | pass |
| full | paired | `frontend_definitions_2000` | 1.001 [0.9372668642148861, 1.017709226542274] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.999 [0.9908179757384882, 1.0120445858491112] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.996 [0.9883748560558222, 1.033013536239343] | pass |
| full | paired | `streaming_statements_20000` | 1.024 [0.9772144732824536, 1.0920591663299593] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.999 [0.982714107215156, 1.0290600468759583] | pass |
| full | paired | `square_10000d_x500` | 0.979 [0.977305467214665, 0.9811105925458128] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.953 [0.9302055334418203, 1.0364241262743137] | pass |
