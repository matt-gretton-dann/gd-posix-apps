# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.966 [0.9440055676373181, 1.018777781789174] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.005 [0.9954629663882134, 1.008980701059273] | pass |
| full | aa | `calls_200000` | 0.993 [0.9883106051001025, 1.0054517496505542] | pass |
| full | aa | `array_200000` | 1.010 [1.0044600735196993, 1.0235973301669472] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.998 [0.9948745126666971, 1.013858818131526] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.997 [0.978567988940768, 1.0204043183792852] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.000 [0.9861346460549181, 1.073484053493626] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.007 [0.9865029636477507, 1.0196894886840389] | pass |
| full | aa | `factorial_1000_x50` | 1.013 [0.9844304777627744, 1.0250335027978055] | pass |
| full | aa | `multiply_100d_x100000` | 0.995 [0.9833700134126516, 1.0099966027643013] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9961449811954202, 1.002115801317885] | pass |
| full | aa | `divide_scale100_x100000` | 1.002 [0.9866352705208408, 1.0170827332141679] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.998 [0.9958231306764099, 1.0030654057335824] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9979902433693953, 1.0052751740752472] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9976251863267043, 1.0067588116060753] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9988865688273999, 1.0007563577771923] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.998 [0.9919505343523393, 1.0206797691625422] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9989348901051301, 1.0026955739142498] | pass |
| full | aa | `power_100d_e17_x1000` | 1.000 [0.9958199654860975, 1.015153106714637] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.017 [0.9712248424904373, 1.0223307761021037] | pass |
| full | aa | `recursion_50_x1000` | 0.997 [0.9938185714541508, 1.0044350781579119] | pass |
| full | aa | `sparse_array_200000` | 1.002 [0.9881364821314162, 1.0087923979443738] | pass |
| full | aa | `frontend_definitions_2000` | 0.993 [0.9772554357273785, 1.0154574188599423] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9943650277597527, 1.0066947377366249] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.001 [0.9803836308677796, 1.0150003756243462] | pass |
| full | aa | `streaming_statements_20000` | 1.015 [0.993769117557914, 1.0218223644933355] | pass |
| full | aa | `square_100d_x100000` | 0.994 [0.9847923805656271, 1.0001286136785283] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9996699083982146, 1.0022484789973503] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.997 [0.9783334950530674, 1.020738794740989] | pass |
| full | paired | `startup` | 1.015 [0.9280765358315317, 1.189280389398624] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.041 [1.028809463916211, 1.0501699562148872] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.035 [1.0236763910173987, 1.0529139330067374] | inconclusive-noisy |
| full | paired | `array_200000` | 1.022 [1.0063987737374738, 1.0348032850650752] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.034 [1.0192993097669905, 1.0440681625293817] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.042 [1.0369196362449056, 1.0502699988882216] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.039 [1.0165049334670724, 1.0502920378980887] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.025 [1.0226957600666913, 1.0623098556901016] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.014 [1.0051877358972634, 1.0266102132622186] | pass |
| full | paired | `multiply_100d_x100000` | 0.785 [0.7728832488842622, 0.7923841378219497] | pass |
| full | paired | `multiply_10000d_x1000` | 0.464 [0.46230175708527554, 0.46542743870173875] | pass |
| full | paired | `divide_scale100_x100000` | 1.003 [0.9817340017499476, 1.0196431864946893] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.003 [0.9983356838285389, 1.0064411225319372] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.472 [0.4712439046802508, 0.475125744696532] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.547 [0.5452158072356899, 0.5514453526795007] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.548 [0.5478407966368027, 0.5502520874134541] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.997 [0.9897120559627905, 1.002581231502349] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.786 [0.7844359851820686, 0.7883485987932755] | pass |
| full | paired | `power_100d_e17_x1000` | 0.836 [0.8335678776020228, 0.8394049478477013] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.047 [1.0223041355074007, 1.0801725858487463] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.016 [1.005540739404944, 1.023999648264876] | pass |
| full | paired | `sparse_array_200000` | 1.016 [0.9965463140258469, 1.0288401421559374] | pass |
| full | paired | `frontend_definitions_2000` | 1.009 [0.9928772140881129, 1.016980783925711] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.002 [1.000945494191027, 1.0064189024268355] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.014 [1.0063867604158168, 1.0249445302103115] | pass |
| full | paired | `streaming_statements_20000` | 1.012 [0.9992619522056915, 1.0287252013097272] | pass |
| full | paired | `square_100d_x100000` | 1.031 [1.0222090264816173, 1.035978999000919] | pass |
| full | paired | `square_10000d_x500` | 0.997 [0.9961500585336341, 0.9998836206362449] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.996 [0.9876702584153162, 1.0033733363292663] | pass |
