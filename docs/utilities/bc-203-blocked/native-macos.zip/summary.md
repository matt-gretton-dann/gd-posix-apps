# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.989 [0.9471104231201328, 1.074985409063182] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.987 [0.9367393161004527, 1.0202638897124674] | pass |
| full | aa | `calls_200000` | 0.970 [0.9629311824091744, 1.069228048777798] | inconclusive-noisy |
| full | aa | `array_200000` | 0.972 [0.7537351263941533, 1.049436309281628] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.021 [0.9742176877456221, 1.066365312786002] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.983 [0.9561349334810224, 1.0355658480876266] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.986 [0.9618738845012914, 1.0325704064446182] | pass |
| full | aa | `fibonacci_1000_x100` | 0.994 [0.8620506423416905, 1.026819390902947] | pass |
| full | aa | `factorial_1000_x50` | 0.943 [0.9090794492767937, 1.026715965793554] | pass |
| full | aa | `multiply_100d_x100000` | 1.025 [0.9212365938172659, 1.0364658567616183] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9211557871114325, 1.0741616738239166] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.007 [0.9197230047932126, 1.0650673383242883] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.025 [1.001794609411548, 1.033136737741595] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.983 [0.9403686128606675, 1.0752888439456005] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.046 [0.9830599286777073, 1.07147769497243] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.004 [0.974172821165687, 1.0174817909374951] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.8883295588421081, 1.0596581335221618] | inconclusive-noisy |
| full | aa | `modulo_1000d_350d_x3000` | 0.952 [0.8205740955602141, 1.0234434231921938] | pass |
| full | aa | `power_100d_e17_x1000` | 1.014 [0.9591862236484858, 1.0999988872115924] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 0.998 [0.830689385276039, 1.013445120206217] | pass |
| full | aa | `recursion_50_x1000` | 1.034 [0.9122058064560055, 1.1033188058205787] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.999 [0.9728230123521815, 1.0696212549160715] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.998 [0.8812495591304197, 1.0464357262388695] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.029 [0.93844845448942, 1.1197275428406457] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.014 [0.9693830413821944, 1.0427049052499495] | pass |
| full | aa | `streaming_statements_20000` | 1.019 [0.9606432771203968, 1.0925045262125141] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.041 [0.9619692691287555, 1.08925657850348] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.955 [0.8912135146210891, 1.0589237631145472] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 1.042 [0.9992384077095331, 1.1271998393012779] | inconclusive-noisy |
| full | paired | `startup` | 1.060 [0.8194487032226464, 1.244220050574128] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.008 [0.9505360298193258, 1.0710983722227612] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.023 [0.9047211751527119, 1.1836662570945207] | inconclusive-noisy |
| full | paired | `array_200000` | 0.982 [0.9055985729612263, 1.1229329062633293] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.012 [0.6577448522947139, 1.1120096459816455] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.990 [0.762098279366864, 1.1495029675267028] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.999 [0.9627511372793143, 1.144933437972385] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.982 [0.8553492179732639, 1.126365280847161] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.076 [0.9134472980295467, 1.0996192832354739] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.626 [0.5339457942850121, 0.7402793446178733] | pass |
| full | paired | `multiply_10000d_x1000` | 0.328 [0.3085913109575677, 0.3466369592294349] | pass |
| full | paired | `divide_scale100_x100000` | 0.950 [0.8861349287771526, 1.0036573115799512] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.002 [0.8605518263258705, 1.1323023343819447] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.318 [0.3036409590982226, 0.3302164666218332] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.351 [0.3461551228887377, 0.4062589913061437] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.412 [0.38431211241077606, 0.42069011959447594] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.012 [0.862517990493645, 1.323100624443087] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.783 [0.7286800709877707, 0.8577859540323297] | pass |
| full | paired | `power_100d_e17_x1000` | 0.802 [0.6558062991841073, 0.8328082524239442] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.931 [0.8133335398024917, 1.0047174890926993] | pass |
| full | paired | `recursion_50_x1000` | 0.994 [0.8784182295143447, 1.1156530772224704] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.086 [0.9663310811486148, 1.132690217953025] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.077 [0.9028963842857125, 1.4342766184800564] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.972 [0.9567682869395843, 1.039677081163356] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.015 [0.8202265460000622, 1.6033128535609769] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.983 [0.8635195311825921, 1.0488685343189053] | pass |
| full | paired | `square_100d_x100000` | 0.976 [0.9487004533918202, 1.1350317586736174] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.988 [0.9592316176102946, 1.0235296418825364] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.040 [0.9066424673727117, 1.0614579701869362] | inconclusive-noisy |
