# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.960 [0.9111794208166752, 1.091822075604238] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.995 [0.9689779617125207, 1.0711551581841092] | inconclusive-noisy |
| full | aa | `calls_200000` | 1.000 [0.914558896667277, 1.037538359715877] | pass |
| full | aa | `array_200000` | 0.932 [0.8625507606633174, 0.9988969961547668] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.044 [0.9839155268848265, 1.1524392699073525] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 0.998 [0.807712692887437, 1.0758761351436155] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.003 [0.8707901623768101, 1.1769269155085293] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 1.003 [0.8716503153514706, 1.1118726213840124] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 0.963 [0.8894927236739792, 0.9792021548008418] | pass |
| full | aa | `multiply_100d_x100000` | 0.992 [0.8538613415088325, 1.0603331268782434] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.008 [0.9915004304279945, 1.0094579722853665] | pass |
| full | aa | `divide_scale100_x100000` | 1.004 [0.9929561192626094, 1.1412596155509727] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.8906728663581087, 1.0095269465628554] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.004 [0.915937927644496, 1.0189778862566434] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.9043510900294497, 1.00768418918293] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.996 [0.9517700087393683, 1.1528238956876458] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.949 [0.8928770502249784, 0.9872913947761903] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.993 [0.9799767711084879, 1.1111669353094595] | inconclusive-noisy |
| full | aa | `power_100d_e17_x1000` | 1.006 [0.9878112817773866, 1.0458643997427501] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.000 [0.9662488629532058, 1.0117121276016885] | pass |
| full | aa | `recursion_50_x1000` | 0.997 [0.8852817704978079, 1.2022208975205124] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 1.048 [1.0103055739897775, 1.165833497085037] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.961 [0.9226554935268394, 1.077864801909817] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.011 [0.9756702453654331, 1.1792814262839022] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 0.994 [0.939332762349618, 1.0433505401529437] | pass |
| full | aa | `streaming_statements_20000` | 1.004 [0.8487783532316511, 1.1003068801309157] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.977 [0.7636805582632954, 1.0106154810913524] | pass |
| full | aa | `square_10000d_x500` | 1.005 [1.0006808823669204, 1.0103256388358897] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.959 [0.8732092330562239, 1.19130230804508] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.998 [0.9285594409150302, 1.075845645259] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 0.998 [0.8732247698494465, 1.0356857512675661] | pass |
| full | aa | `binary_input_100000d_x3` | 1.000 [0.9175733080962853, 1.1209135394267173] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 1.000 [0.9689761335225655, 1.0281285109339424] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.997 [0.9194907286745151, 1.0291117099283464] | pass |
| full | aa | `file_statements_20000` | 0.987 [0.8731131110969014, 1.0055101299087525] | pass |
| full | paired | `startup` | 0.968 [0.8927164220408165, 1.0529830686837618] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.012 [0.9975498184637225, 1.0167783139822377] | pass |
| full | paired | `calls_200000` | 0.994 [0.9842838278646252, 1.0095713706897151] | pass |
| full | paired | `array_200000` | 0.990 [0.946594335367253, 1.002701373131753] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.991 [0.9793748248718575, 1.0724947758642758] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.989 [0.9743099118152123, 0.9928243987678416] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.976 [0.9668959801807606, 0.9955949982829475] | pass |
| full | paired | `fibonacci_1000_x100` | 1.005 [0.9866981415481323, 1.0672579195123655] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.972 [0.9535290006991065, 0.9828554937419443] | pass |
| full | paired | `multiply_100d_x100000` | 1.004 [0.9813626719015329, 1.009274029866163] | pass |
| full | paired | `multiply_10000d_x1000` | 1.051 [1.0424821608321446, 1.0536804166820564] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.985 [0.9817949157860512, 0.9947368573292785] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.002 [0.9868576489504319, 1.0029132871735063] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.062 [1.0519691196928926, 1.0733694149426196] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.055 [1.0349928022706345, 1.0903708120149522] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.034 [1.018932021603569, 1.0692873655030777] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.989 [0.968294962848004, 1.03490444421129] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.015 [0.9900591848768852, 1.0215089849588674] | pass |
| full | paired | `power_100d_e17_x1000` | 1.005 [0.9602907811583999, 1.0223955580012385] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.986 [0.9771553475813266, 0.9946613861403681] | pass |
| full | paired | `recursion_50_x1000` | 0.989 [0.9759057887045054, 1.0124961345230172] | pass |
| full | paired | `sparse_array_200000` | 0.990 [0.9791427413659942, 0.9976640968947439] | pass |
| full | paired | `frontend_definitions_2000` | 0.987 [0.9271866500095651, 1.1123608837627361] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 0.999 [0.9393335362135037, 1.015503456316375] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.985 [0.921763095912315, 1.0186725716706821] | pass |
| full | paired | `streaming_statements_20000` | 0.952 [0.8837673315814751, 0.9660524514262611] | pass |
| full | paired | `square_100d_x100000` | 0.994 [0.9703820835947977, 1.0016236232438218] | pass |
| full | paired | `square_10000d_x500` | 1.001 [0.9942279050473535, 1.012240379429299] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.997 [0.9573395326379917, 1.0351365394651837] | pass |
| full | paired | `binary_output_1000d_x300` | 0.996 [0.9265290217256427, 1.0147477947706074] | pass |
| full | paired | `octal_output_1000d_x300` | 1.011 [0.9908005876612955, 1.0290581498833766] | pass |
| full | paired | `binary_input_100000d_x3` | 1.006 [0.979867877879753, 1.0122688537841915] | pass |
| full | paired | `hex_input_100000d_x3` | 1.038 [1.023902296378438, 1.08293913424838] | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.000 [0.9949449008460749, 1.0134619229783464] | pass |
| full | paired | `file_statements_20000` | 0.985 [0.8677713042441977, 1.1021078311365287] | inconclusive-noisy |
