# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.911 [0.7973927607441604, 1.1124599845129042] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.003 [0.9884600518781068, 1.0152292903312998] | pass |
| full | aa | `calls_200000` | 1.003 [0.9746257398680301, 1.0080921309253446] | pass |
| full | aa | `array_200000` | 1.007 [0.9939177052384769, 1.012610487301731] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.001 [0.9872214085920007, 1.0253351145491858] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.003 [0.9966836130023369, 1.0152744470643724] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.003 [0.9850249626900944, 1.00733665407031] | pass |
| full | aa | `fibonacci_1000_x100` | 1.018 [0.9976226601181509, 1.0268520319016028] | pass |
| full | aa | `factorial_1000_x50` | 1.002 [0.9877813603137117, 1.0352832369534881] | pass |
| full | aa | `multiply_100d_x100000` | 1.004 [0.9994507128807173, 1.0103960241923395] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9991405938252141, 1.0029787669722041] | pass |
| full | aa | `divide_scale100_x100000` | 1.007 [0.9895323413359496, 1.013297341803554] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.001 [0.99228190099201, 1.0028360095939062] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.002 [0.9996252428861339, 1.004154782000383] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9890086631794861, 1.0081911350903794] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.9949983124733859, 1.0024698347547745] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.989 [0.9738684363828658, 1.0269043348158668] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.003 [0.9950692780453146, 1.0073724588350668] | pass |
| full | aa | `power_100d_e17_x1000` | 1.004 [0.9822457840868533, 1.0179251741309185] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.995 [0.9736134286886848, 1.0300999173777174] | pass |
| full | aa | `recursion_50_x1000` | 1.010 [0.9846942836690608, 1.0373493125476543] | pass |
| full | aa | `sparse_array_200000` | 1.007 [0.9967262579302408, 1.0168812656009691] | pass |
| full | aa | `frontend_definitions_2000` | 1.002 [0.9838995477896523, 1.021505099615975] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.000 [0.9777843337658509, 1.0155869740971841] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.975 [0.8660220468993259, 1.0659459945736143] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.993 [0.9766630847355025, 1.0091741304863686] | pass |
| full | aa | `square_100d_x100000` | 1.003 [0.9902413909788054, 1.006502731037543] | pass |
| full | aa | `square_10000d_x500` | 1.001 [0.9993778876297865, 1.0011858846645874] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.001 [0.8630512705444475, 1.0329970904266006] | pass |
| full | aa | `binary_output_1000d_x300` | 0.999 [0.9299725990444759, 1.015747516986129] | pass |
| full | aa | `octal_output_1000d_x300` | 1.024 [0.9835179810060297, 1.0434530914657025] | pass |
| full | aa | `binary_input_100000d_x3` | 0.997 [0.9839284073294311, 0.9981804079854497] | pass |
| full | aa | `hex_input_100000d_x3` | 1.000 [0.9965632415398769, 1.0073580816442342] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.995 [0.9921389811370179, 1.0028216649194412] | pass |
| full | aa | `file_statements_20000` | 0.991 [0.9844858720628683, 1.010230998562252] | pass |
| full | paired | `startup` | 0.994 [0.8257350662685896, 1.18897065580025] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.018 [1.0042551997267024, 1.0255402550746022] | pass |
| full | paired | `calls_200000` | 1.043 [1.0308864241318134, 1.0610735608174509] | inconclusive-noisy |
| full | paired | `array_200000` | 1.012 [0.9983873882997962, 1.0134590789967948] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.016 [0.9997855832442395, 1.0261844384125072] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.023 [1.0094017520926954, 1.0360047819444744] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.037 [1.0139049072564132, 1.0574576434778409] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.027 [1.0067026212713186, 1.0428046634880337] | pass |
| full | paired | `factorial_1000_x50` | 1.014 [1.0034431542239228, 1.0195475066251987] | pass |
| full | paired | `multiply_100d_x100000` | 1.024 [1.011326266471724, 1.026262620730394] | pass |
| full | paired | `multiply_10000d_x1000` | 0.996 [0.9934635306201874, 1.0009682207851793] | pass |
| full | paired | `divide_scale100_x100000` | 0.999 [0.9895539924394791, 1.0031625921096254] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.008 [0.9924925949446651, 1.013504132794634] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.996 [0.9902835207420786, 0.9995132965526649] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.995 [0.9841030392068129, 1.0024149181716264] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.984 [0.9801637566548426, 0.9859755497110156] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.015 [0.9863259438222395, 1.0242723985541866] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.002 [0.9978353960924662, 1.0031965570462642] | pass |
| full | paired | `power_100d_e17_x1000` | 1.001 [0.9885854331432071, 1.0080914087393185] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.028 [1.0083132233372438, 1.0520376621871845] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.012 [1.0043220148639904, 1.0273055312141888] | pass |
| full | paired | `sparse_array_200000` | 1.030 [1.0254338620542331, 1.0464395246602627] | pass |
| full | paired | `frontend_definitions_2000` | 1.010 [0.9879522527084814, 1.0229345830455316] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.146 [1.0970677059798304, 1.1533150073278076] | confirmed regression |
| full | paired | `decimal_output_200d_x1000` | 0.985 [0.9242843119130171, 1.0338014725663223] | pass |
| full | paired | `streaming_statements_20000` | 0.994 [0.9840770073565991, 1.0082247519939604] | pass |
| full | paired | `square_100d_x100000` | 1.004 [0.9940520613465847, 1.0076788430856742] | pass |
| full | paired | `square_10000d_x500` | 0.997 [0.9966037427422287, 0.9980779287914799] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.048 [1.00101492743456, 1.1350451998407967] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.957 [0.9434922620072419, 1.0146160902564585] | pass |
| full | paired | `octal_output_1000d_x300` | 1.002 [0.9771152612444493, 1.0097231274505207] | pass |
| full | paired | `binary_input_100000d_x3` | 1.048 [1.0392412155096626, 1.0617501142731092] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 1.006 [0.9887330538547479, 1.0150791299211381] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.011 [1.008430448412963, 1.0145883898849277] | pass |
| full | paired | `file_statements_20000` | 1.011 [1.0073211237403992, 1.0272650654677913] | pass |
