# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.878 [0.7836836628353187, 1.0331271517974963] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.982 [0.9589772160687634, 1.0233843586842994] | pass |
| full | aa | `calls_200000` | 0.934 [0.7671900444518515, 1.023479575439216] | pass |
| full | aa | `array_200000` | 1.001 [0.9537899536922304, 1.0493055115546124] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.994 [0.9434956563093331, 1.0408074384768553] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.992 [0.9219467840617651, 1.083939669091731] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.004 [0.9845602681394814, 1.0272461272801823] | pass |
| full | aa | `fibonacci_1000_x100` | 1.026 [0.9595664800279334, 1.0567091264514488] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.000 [0.8728631867517702, 1.208513484012146] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.996 [0.7328813319071042, 1.0385581745485395] | pass |
| full | aa | `multiply_10000d_x1000` | 0.993 [0.9236227351463148, 1.050124737663051] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 0.954 [0.8679710029092247, 1.0174847610471962] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.938 [0.8582377313349715, 1.0271518628005551] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.990 [0.9561450426907949, 1.0564101647641162] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.996 [0.9716812818438799, 1.01989109119302] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.002 [0.9335497709640944, 1.1103158299687759] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.019 [0.9071817047587544, 1.0242157898794422] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.976 [0.8730311892580149, 1.0140202193524568] | pass |
| full | aa | `power_100d_e17_x1000` | 1.005 [0.9401092246311336, 1.0555667142484475] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 1.021 [0.9960344941611081, 1.1589964808988367] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 1.008 [0.8010174494406934, 1.0779599465370395] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.941 [0.7903451512242684, 0.9895590714054787] | pass |
| full | aa | `frontend_definitions_2000` | 0.997 [0.9098004502196761, 1.0730220971789632] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.019 [0.965610442637129, 1.318283833344332] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.008 [0.8757455576225399, 1.0269821150328788] | pass |
| full | aa | `streaming_statements_20000` | 1.012 [0.8910680415676164, 1.120767144563114] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.000 [0.9333825326490359, 1.00803256232168] | pass |
| full | aa | `square_10000d_x500` | 1.053 [1.0139021487006865, 1.130565117539534] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.960 [0.9150103698616419, 1.384894337955937] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.016 [0.9455774154543167, 1.2327807027795878] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 0.993 [0.8726620936403665, 1.0662077774050926] | inconclusive-noisy |
| full | aa | `binary_input_100000d_x3` | 0.998 [0.848138620889237, 1.2243263592228586] | inconclusive-noisy |
| full | aa | `hex_input_100000d_x3` | 0.969 [0.9267014741258286, 1.0892048196626403] | inconclusive-noisy |
| full | aa | `temporary_chain_1000d_x50000` | 0.996 [0.7482296851904796, 1.0088544904125487] | pass |
| full | aa | `file_statements_20000` | 1.012 [0.9223209527930304, 1.0619679588218633] | inconclusive-noisy |
| full | paired | `startup` | 0.898 [0.8069098916716423, 1.5103893883968453] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.058 [0.927231517877517, 1.1420166991822875] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.974 [0.9236387156122916, 1.0193861968684652] | pass |
| full | paired | `array_200000` | 1.008 [0.8488342959859965, 1.0840512905019963] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.066 [0.9729998291489695, 1.115805023815373] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.932 [0.8386950781640563, 1.0614191441196779] | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.020 [0.9292829258710948, 1.392576554924331] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 0.899 [0.866027777334788, 1.0768437335697394] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.960 [0.9105124418626748, 1.096013388429533] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.962 [0.88095130282836, 1.0744315242240328] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.996 [0.9242461019932455, 1.1880428594212178] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.996 [0.931765242993843, 1.1275734413900187] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 0.960 [0.8888797316177924, 1.2054358099933156] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 0.978 [0.8421205343172515, 1.0047915917393535] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.037 [0.7782091814039516, 1.184822848559209] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.003 [0.944978256198605, 1.1338332423724045] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.043 [0.8639735437646867, 1.0891346133369517] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.009 [0.9355226016295098, 1.0433506300596682] | pass |
| full | paired | `power_100d_e17_x1000` | 1.074 [1.0180211506979475, 1.2782174136317301] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.938 [0.9226143933713016, 1.0386212457733162] | pass |
| full | paired | `recursion_50_x1000` | 0.957 [0.8502324818422041, 1.1865649609746798] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.180 [0.9953437496944214, 1.240022408239359] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.982 [0.7481833618313489, 1.4557569212715926] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.011 [0.8434379658411052, 1.2462693360038228] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.007 [0.9062188548525815, 1.1517161055311496] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.974 [0.9369131065577622, 1.1118475747309429] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.014 [0.9800426087996376, 1.2503434878355595] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.990 [0.9696212604631018, 1.0414195685111016] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.002 [0.7262514897815064, 1.0507783716055132] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.995 [0.8539310930623114, 1.0146452103203003] | pass |
| full | paired | `octal_output_1000d_x300` | 1.022 [0.8669746528669401, 1.1247365206210218] | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.940 [0.8583920909415721, 0.9961643278384779] | pass |
| full | paired | `hex_input_100000d_x3` | 1.019 [0.9673234229039682, 1.099322780827999] | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 0.983 [0.9017119782365244, 1.109839420918633] | inconclusive-noisy |
| full | paired | `file_statements_20000` | 1.031 [0.8980097459103973, 1.1488587779052408] | inconclusive-noisy |
