# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.896 [0.8117630623474945, 1.2088446318548418] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.003 [0.9884956810951209, 1.0075690073982255] | pass |
| full | aa | `calls_200000` | 1.001 [0.9964292481955555, 1.011255923610519] | pass |
| full | aa | `array_200000` | 1.002 [0.9901056332684445, 1.0133859608271973] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.987 [0.9673983608224559, 0.9982086273035825] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.989 [0.9849847678991239, 0.9960468024123172] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.995 [0.9787535289861142, 1.006243814133622] | pass |
| full | aa | `fibonacci_1000_x100` | 1.000 [0.9892479522334013, 1.0289539933269416] | pass |
| full | aa | `factorial_1000_x50` | 0.989 [0.9750864005185496, 0.9963942294592294] | pass |
| full | aa | `multiply_100d_x100000` | 0.997 [0.9822022705050604, 1.0079081482050707] | pass |
| full | aa | `multiply_10000d_x1000` | 1.005 [0.9983671823798171, 1.1012388963261908] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 1.000 [0.9915565228968689, 1.020925775806914] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.9893210741750891, 1.0025376058640176] | pass |
| full | aa | `sqrt_scale5000_x5` | 1.001 [0.9991906986143134, 1.0027319342282295] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9984813196364666, 1.006695966068879] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.995 [0.9342009822084824, 1.0124442528536124] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.998 [0.9941228369971973, 1.0033416275762974] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.9739853489542202, 1.0195483011043096] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.003 [0.99050632086848, 1.0159555584905222] | pass |
| full | aa | `power_100d_e17_x1000` | 1.001 [0.9805093452143421, 1.0213847569195527] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.990 [0.9677500172004418, 0.9995086726592939] | pass |
| full | aa | `recursion_50_x1000` | 1.004 [0.986083014435774, 1.0128291962708924] | pass |
| full | aa | `sparse_array_200000` | 1.000 [0.9880895579640327, 1.023770144475901] | pass |
| full | aa | `frontend_definitions_2000` | 1.002 [0.9852103360345934, 1.0121003552060037] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.998 [0.9678045661623709, 1.0194764706873556] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.000 [0.881370402112589, 1.118865302736743] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.007 [0.9942894057703322, 1.0278481419077743] | pass |
| full | aa | `square_100d_x100000` | 1.003 [0.9912024173989223, 1.0214526885086774] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9981674300381183, 1.0018967249442448] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.104 [0.9631637526398028, 1.1622320419498247] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.997 [0.9902829985368528, 1.0035437249487642] | pass |
| full | aa | `octal_output_1000d_x300` | 1.000 [0.9931515012968368, 1.0295514033893345] | pass |
| full | aa | `binary_input_100000d_x3` | 1.012 [0.996825026350428, 1.018334893311546] | pass |
| full | aa | `hex_input_100000d_x3` | 0.999 [0.9956076173267687, 1.0025376911668602] | pass |
| full | aa | `temporary_chain_1000d_x50000` | 0.996 [0.9931658135254114, 1.0035604360621504] | pass |
| full | aa | `file_statements_20000` | 0.994 [0.9760321923851804, 1.0169592462982602] | pass |
| full | aa | `sqrt_large_scale10000_x5` | 1.000 [0.9867850782382993, 1.0007529312551569] | pass |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.000 [0.9992566553329851, 1.002320431345198] | pass |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.000 [0.9990872198820479, 1.00032859665461] | pass |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.000 [0.9922683016355088, 1.0032610054970739] | pass |
| full | paired | `startup` | 1.147 [1.070036252494656, 1.1775992367468204] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.031 [0.9998181202609396, 1.0402484174381772] | pass |
| full | paired | `calls_200000` | 1.048 [1.0325862744199288, 1.067529579856138] | inconclusive-noisy |
| full | paired | `array_200000` | 1.010 [0.9974872005586545, 1.0188906452710882] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.993 [0.9709649169952435, 1.0073578794826519] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.034 [1.0175762790435006, 1.0422093933299066] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.031 [1.017166707459336, 1.078541357444165] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.026 [1.0203594832881655, 1.034496510893003] | pass |
| full | paired | `factorial_1000_x50` | 1.003 [0.9968858216281624, 1.0189119758571006] | pass |
| full | paired | `multiply_100d_x100000` | 1.008 [0.998899538485874, 1.0195243741005902] | pass |
| full | paired | `multiply_10000d_x1000` | 0.997 [0.9923139477570296, 1.0058767049224757] | pass |
| full | paired | `divide_scale100_x100000` | 1.001 [0.9759561168457888, 1.0113762362815362] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.999 [0.9901392451409587, 1.0073945147554835] | pass |
| full | paired | `sqrt_scale5000_x5` | 1.008 [1.0057122323144927, 1.0094083802731595] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.996 [0.9899842607884605, 1.0001389220367805] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9941459153753132, 1.0152130050238295] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.985 [0.9786394669723446, 0.9891376665595719] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.009 [1.0037170262587802, 1.0254294607961778] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.004 [0.9987573990554243, 1.0071980896913004] | pass |
| full | paired | `power_100d_e17_x1000` | 1.004 [0.9933770109496088, 1.0146124599431356] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.033 [1.0279502344024316, 1.0471623244967367] | pass |
| full | paired | `recursion_50_x1000` | 1.022 [1.015041218748721, 1.0276158342287234] | pass |
| full | paired | `sparse_array_200000` | 1.041 [1.021268948232699, 1.0586783559596964] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.007 [0.9833224200657058, 1.0170331855317358] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.120 [1.1147228532307052, 1.151653207949864] | confirmed regression |
| full | paired | `decimal_output_200d_x1000` | 1.009 [0.9497323612098104, 1.0518344692095114] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.009 [0.9927471758563801, 1.0226966973065479] | pass |
| full | paired | `square_100d_x100000` | 1.018 [1.0029299164321297, 1.0232792208757304] | pass |
| full | paired | `square_10000d_x500` | 0.998 [0.9968215263892919, 0.9984661177381305] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.036 [0.9745274374175674, 1.1170070793056242] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 1.009 [0.9958019772050206, 1.046513973246901] | pass |
| full | paired | `octal_output_1000d_x300` | 1.011 [0.9876235295298902, 1.0188241830775593] | pass |
| full | paired | `binary_input_100000d_x3` | 1.051 [1.046245846344818, 1.058141137528843] | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 1.009 [1.0022249361839564, 1.017725084990522] | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.018 [1.0136667583942787, 1.0215916549096171] | pass |
| full | paired | `file_statements_20000` | 1.010 [0.995375526121775, 1.0116346835265517] | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.008 [1.0073544696252408, 1.0087714214049177] | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 0.008 [0.00803525388705218, 0.008220573631003333] | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.004 [0.003509176787597494, 0.0036632750797740165] | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.007 [1.0024705261833227, 1.0113311378643355] | pass |
