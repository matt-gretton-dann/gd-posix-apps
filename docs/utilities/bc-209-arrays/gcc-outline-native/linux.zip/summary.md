# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.881 [0.8279827236000301, 1.054315598452877] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.989 [0.9688281847605825, 1.0158181693140418] | pass |
| full | aa | `calls_200000` | 0.992 [0.9791650761815742, 1.0073895219310354] | pass |
| full | aa | `array_200000` | 0.988 [0.9780426086922858, 1.0137913297276788] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.984 [0.9717474887151347, 0.992564725637165] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.974 [0.9536040524376208, 0.9868643903877675] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.981 [0.9673691476227194, 0.9928041908538042] | pass |
| full | aa | `fibonacci_1000_x100` | 0.987 [0.9771856362034316, 1.002056991628278] | pass |
| full | aa | `factorial_1000_x50` | 0.991 [0.983058091694133, 1.0101790192331244] | pass |
| full | aa | `multiply_100d_x100000` | 0.983 [0.9662879469010567, 1.0018816520669398] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9977734670597003, 1.0032045791948043] | pass |
| full | aa | `divide_scale100_x100000` | 0.976 [0.9606508978603864, 0.9868935877157027] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.989 [0.983805205139737, 0.9969360883898973] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.995094556433842, 1.00302595831716] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.991258993492545, 1.0038627866914127] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9964008553384501, 1.005137081039697] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.984 [0.9745832786573473, 1.0141845651845482] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.997 [0.9905321574327147, 1.001812866204554] | pass |
| full | aa | `power_100d_e17_x1000` | 1.002 [0.9895186492114809, 1.0139831754777238] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.002 [0.9495336336859941, 1.0245193296385047] | pass |
| full | aa | `recursion_50_x1000` | 0.989 [0.9715654049845304, 1.0026473969794454] | pass |
| full | aa | `sparse_array_200000` | 0.976 [0.9503383312933615, 0.9957964806307069] | pass |
| full | aa | `frontend_definitions_2000` | 1.002 [0.9883886048184644, 1.0206755881875273] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.995 [0.9755664838365468, 1.0148072537336854] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.018 [0.945556036700866, 1.0394337457436484] | pass |
| full | aa | `streaming_statements_20000` | 0.992 [0.9767568923788211, 1.0040755003944852] | pass |
| full | aa | `square_100d_x100000` | 0.977 [0.9729481957416126, 1.0038326997298879] | pass |
| full | aa | `square_10000d_x500` | 0.999 [0.9975483528739226, 1.0001513402302373] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.933 [0.8821562128154133, 1.108844415381379] | inconclusive-noisy |
| full | paired | `startup` | 0.994 [0.718558789374672, 1.3083129086483083] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.030 [1.017878756934281, 1.0676466954742518] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.014 [1.0012749510982115, 1.0539685278539923] | inconclusive-noisy |
| full | paired | `array_200000` | 0.765 [0.757616716816442, 0.7853833381253147] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.031 [1.0254250076347502, 1.0489112230806779] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.036 [1.0296162610709807, 1.0419121361719468] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.029 [1.0172146940309987, 1.0365979586139562] | pass |
| full | paired | `fibonacci_1000_x100` | 0.993 [0.9747564968537231, 1.0179238847815901] | pass |
| full | paired | `factorial_1000_x50` | 0.996 [0.9935200588456627, 0.998724870143326] | pass |
| full | paired | `multiply_100d_x100000` | 1.014 [0.9425822345073452, 1.025110709983516] | pass |
| full | paired | `multiply_10000d_x1000` | 1.000 [0.9982999091693904, 1.0026020280479] | pass |
| full | paired | `divide_scale100_x100000` | 0.971 [0.9573579391460899, 0.9908247740980958] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.991 [0.9869445275292162, 0.9982519536534505] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.998 [0.995135312547844, 1.004266002840572] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9890118443085544, 1.0025768063465121] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.976 [0.9714688704397972, 1.09789231961149] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.994 [0.976617365049295, 1.015223538942886] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.002 [0.9946255970084255, 1.006523681602165] | pass |
| full | paired | `power_100d_e17_x1000` | 0.986 [0.9800496332820418, 0.9942690009936097] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.072 [1.0597562953492332, 1.0899447665832624] | confirmed regression |
| full | paired | `recursion_50_x1000` | 1.019 [1.0098215412791736, 1.030704461660669] | pass |
| full | paired | `sparse_array_200000` | 0.985 [0.9823310236913798, 1.0014540722548881] | pass |
| full | paired | `frontend_definitions_2000` | 0.998 [0.989691327697442, 1.0093995321978366] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.990 [0.9720726275118131, 1.023508093012612] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.968 [0.9597880982921543, 1.0873696091790928] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.002 [0.9766278026150728, 1.004457972941757] | pass |
| full | paired | `square_100d_x100000` | 1.000 [0.9653724949700174, 1.0182604669979507] | pass |
| full | paired | `square_10000d_x500` | 0.993 [0.9904944886299971, 0.9940219310543487] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.924 [0.855451114690778, 1.1465656183604263] | inconclusive-noisy |
