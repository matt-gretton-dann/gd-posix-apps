# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.940 [0.8996024538139079, 1.0308569816256965] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.033 [1.0129131601784258, 1.039035187949386] | pass |
| full | aa | `calls_200000` | 1.012 [0.9670172353087344, 1.04403643751556] | pass |
| full | aa | `array_200000` | 0.994 [0.9779839155938981, 1.007960618459475] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.012 [0.9712511337286938, 1.0381930420231122] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.020 [0.9652107810584992, 1.0387699493972615] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.014 [1.008056104660949, 1.0255852782551909] | pass |
| full | aa | `fibonacci_1000_x100` | 1.000 [0.9881898587166783, 1.0131120949719579] | pass |
| full | aa | `factorial_1000_x50` | 0.997 [0.9255179379458359, 1.022827564092162] | pass |
| full | aa | `multiply_100d_x100000` | 1.014 [0.996438280833478, 1.0220833906290543] | pass |
| full | aa | `multiply_10000d_x1000` | 0.995 [0.9835182027726108, 1.0119629386042654] | pass |
| full | aa | `divide_scale100_x100000` | 1.019 [1.009629751283511, 1.0334492941221132] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.000 [0.9941620593708813, 1.0097687024446915] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9775482805688785, 1.0216365316076357] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.008 [0.995305664194667, 1.0348039201050323] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.996 [0.9685035037666164, 1.0085691730244655] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.989 [0.9782067018512741, 1.0393569312870456] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.006 [0.9951926841094634, 1.0164674308072985] | pass |
| full | aa | `power_100d_e17_x1000` | 0.991 [0.9823009981514655, 1.0261630728869482] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.005 [0.9634374582223546, 1.0412668511244065] | pass |
| full | aa | `recursion_50_x1000` | 0.997 [0.988669631182405, 1.018110786972325] | pass |
| full | aa | `sparse_array_200000` | 1.013 [0.9518002611360956, 1.026547169534585] | pass |
| full | aa | `frontend_definitions_2000` | 1.014 [0.9942225277083736, 1.0467399343788792] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.994 [0.9736534301834299, 1.003696091843732] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.997 [0.9730165649521876, 1.012012209563503] | pass |
| full | aa | `streaming_statements_20000` | 0.984 [0.9591165986041519, 1.0185576796117464] | pass |
| full | aa | `square_100d_x100000` | 1.020 [1.0140225611461555, 1.030346316511503] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9933355294568156, 1.0072324150026706] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.945 [0.906765215859773, 1.0630626207086218] | inconclusive-noisy |
| full | paired | `startup` | 1.003 [0.8876804735688344, 1.170007779311854] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.011 [0.9892741923336942, 1.0486979390703668] | pass |
| full | paired | `calls_200000` | 0.978 [0.971241652117057, 1.0049326984857359] | pass |
| full | paired | `array_200000` | 0.764 [0.7538172352691441, 0.785911297864469] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.004 [0.9572398646383876, 1.028339247786542] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.959 [0.9255081271393808, 0.9878110373695914] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.945 [0.9325785901283111, 0.9618695271900959] | pass |
| full | paired | `fibonacci_1000_x100` | 1.005 [0.9986790715111574, 1.0125090616008938] | pass |
| full | paired | `factorial_1000_x50` | 1.014 [0.9910088887947912, 1.0233632082644484] | pass |
| full | paired | `multiply_100d_x100000` | 0.994 [0.9651406153653935, 1.0088722489069057] | pass |
| full | paired | `multiply_10000d_x1000` | 1.000 [0.9747919344536846, 1.0050508168127827] | pass |
| full | paired | `divide_scale100_x100000` | 0.997 [0.9709157968569988, 1.0031231902865654] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.005 [1.0020951390429782, 1.0083106144275107] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.000 [0.9911516625843466, 1.02124306252782] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.9759026893901993, 1.0132191605580085] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.000 [0.9931254544413988, 1.0056015120949107] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.023 [0.9724261988055539, 1.0315781316605517] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.000 [0.9844046562468954, 1.004344219155024] | pass |
| full | paired | `power_100d_e17_x1000` | 0.991 [0.9796673445587432, 0.9993330034202846] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.015 [1.008732842077122, 1.0440831023345818] | pass |
| full | paired | `recursion_50_x1000` | 1.000 [0.9997953475685636, 1.013008677028179] | pass |
| full | paired | `sparse_array_200000` | 0.987 [0.9599948676589822, 1.0177015504594056] | pass |
| full | paired | `frontend_definitions_2000` | 1.010 [0.988632565434109, 1.0205406989064225] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.984 [0.9744998912535618, 1.0055566515454837] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.013 [0.9542442609063125, 1.0254570181723088] | pass |
| full | paired | `streaming_statements_20000` | 0.991 [0.9790046178830285, 1.0076124084339815] | pass |
| full | paired | `square_100d_x100000` | 0.999 [0.990784061561705, 1.019744265107467] | pass |
| full | paired | `square_10000d_x500` | 1.002 [0.9914950203360753, 1.0053766803655804] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.925 [0.8748353096157454, 1.0177375300825091] | pass |
