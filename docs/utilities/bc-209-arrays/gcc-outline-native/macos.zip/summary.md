# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.898 [0.8489402830850442, 1.0539802093405988] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.999 [0.966028161069769, 1.00524270684294] | pass |
| full | aa | `calls_200000` | 0.998 [0.9326924411853089, 0.9989461995928933] | pass |
| full | aa | `array_200000` | 0.996 [0.9870653647512131, 1.0063001935380382] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.000 [0.9917515046507787, 1.0403778967247923] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.992 [0.980041131823111, 1.0123538558281728] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.003 [0.9960827813055227, 1.0402724072352276] | pass |
| full | aa | `fibonacci_1000_x100` | 1.006 [0.9625719590219065, 1.0122189131467707] | pass |
| full | aa | `factorial_1000_x50` | 1.008 [0.9969549663692979, 1.0108659483215698] | pass |
| full | aa | `multiply_100d_x100000` | 0.998 [0.9757576141039201, 1.027182661170576] | pass |
| full | aa | `multiply_10000d_x1000` | 0.994 [0.9361209579130008, 1.001186092995868] | pass |
| full | aa | `divide_scale100_x100000` | 1.000 [0.9934033824835474, 1.0127379418116316] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.004 [0.9960694028765639, 1.0514768345374623] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 0.999 [0.9947296954679484, 1.0260961296072828] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.998 [0.993122523688636, 1.0051736283507724] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.002 [0.9958361422801721, 1.0059372091264351] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.991 [0.9767762347321313, 1.0284078998953194] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.997 [0.9911025958926756, 1.0023184997817713] | pass |
| full | aa | `power_100d_e17_x1000` | 1.005 [0.9906413563934198, 1.0197429176504265] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.005 [0.9995663542970024, 1.0143595412028874] | pass |
| full | aa | `recursion_50_x1000` | 0.995 [0.9804006801331795, 1.014589541817089] | pass |
| full | aa | `sparse_array_200000` | 0.991 [0.9248519150568726, 1.0006173908988776] | pass |
| full | aa | `frontend_definitions_2000` | 1.005 [0.9813440436687321, 1.0092442847859584] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.004 [0.9951411008769456, 1.0074043650086286] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.003 [0.9948595803785438, 1.0104556699226925] | pass |
| full | aa | `streaming_statements_20000` | 1.003 [0.9568754248001922, 1.124500021127842] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.000 [0.992209306102117, 1.046722929969376] | pass |
| full | aa | `square_10000d_x500` | 0.996 [0.9466876667065008, 1.0833975849639943] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.958 [0.8972840317229405, 0.9640592720336193] | pass |
| full | paired | `startup` | 0.996 [0.8792484387880508, 1.1884404719640314] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.000 [0.9894528096691784, 1.0079321871850382] | pass |
| full | paired | `calls_200000` | 0.997 [0.9752524540679199, 1.0006820691471012] | pass |
| full | paired | `array_200000` | 0.765 [0.7604329455436333, 0.7783090234083346] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.997 [0.9700477655319584, 1.0064614252932238] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.996 [0.9874894150080636, 1.0212824762562063] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.006 [0.9987242266028922, 1.015133308089879] | pass |
| full | paired | `fibonacci_1000_x100` | 0.998 [0.9876766294248154, 1.0057200845690641] | pass |
| full | paired | `factorial_1000_x50` | 1.001 [0.9937483751592713, 1.0048250370731433] | pass |
| full | paired | `multiply_100d_x100000` | 0.998 [0.9934881869880849, 1.0084077586263924] | pass |
| full | paired | `multiply_10000d_x1000` | 1.002 [0.9953034789262207, 1.0189113584584242] | pass |
| full | paired | `divide_scale100_x100000` | 0.997 [0.9885300644623347, 1.0179739208078227] | pass |
| full | paired | `sqrt_scale100_x5000` | 1.001 [0.9945554045105465, 1.003814972432404] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.001 [0.9866054817232691, 1.0046335055438267] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9842045424954369, 1.0061860670665292] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.999 [0.9933119400007018, 1.0022670307083843] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.992 [0.9828057931645691, 1.0346242795180578] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.000 [0.9919869721473136, 1.014449485829859] | pass |
| full | paired | `power_100d_e17_x1000` | 0.992 [0.981239344395398, 0.993335280441247] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.995 [0.9805657962422032, 1.0043504238781376] | pass |
| full | paired | `recursion_50_x1000` | 1.015 [0.9890628643102992, 1.0159119261336826] | pass |
| full | paired | `sparse_array_200000` | 0.997 [0.989921561477523, 1.005584713764216] | pass |
| full | paired | `frontend_definitions_2000` | 1.004 [0.972855743876869, 1.0241158951387952] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.998 [0.9887859863840098, 1.0074082270880562] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.997 [0.9717562383521129, 1.0066184940759852] | pass |
| full | paired | `streaming_statements_20000` | 0.997 [0.9468701043903062, 1.0034954004545202] | pass |
| full | paired | `square_100d_x100000` | 1.000 [0.9953064807410452, 1.0032944673717883] | pass |
| full | paired | `square_10000d_x500` | 1.002 [0.9986977889271865, 1.006132539045737] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.964 [0.9297225485646284, 1.0268837573383092] | pass |
