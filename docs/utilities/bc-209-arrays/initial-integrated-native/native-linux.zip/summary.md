# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.987 [0.968880618071517, 1.020531398242078] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.017 [0.9734495586536099, 1.025526213201582] | pass |
| full | aa | `calls_200000` | 0.974 [0.9663643844172847, 0.9983868429967262] | pass |
| full | aa | `array_200000` | 1.007 [0.9840163875502799, 1.0130332472515855] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.001 [0.9977223287108677, 1.0141996871249463] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.008 [0.9860211346143345, 1.0179273245578784] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.993 [0.9816310622165395, 1.0121265490399125] | pass |
| full | aa | `fibonacci_1000_x100` | 1.013 [1.0042193274558613, 1.028500363425897] | pass |
| full | aa | `factorial_1000_x50` | 0.990 [0.981331255590631, 0.9993408948981786] | pass |
| full | aa | `multiply_100d_x100000` | 1.001 [0.9754904411290037, 1.041769078941172] | pass |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9971658337047594, 1.0049552993775968] | pass |
| full | aa | `divide_scale100_x100000` | 0.993 [0.9815090679889048, 1.0030153132700659] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.997 [0.9950537941497283, 1.0016971596635929] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.002 [0.9933882839821581, 1.0056161045494882] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9780879107944939, 1.0122838207184588] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.004 [1.0000198111395406, 1.0074040875204204] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.999 [0.9880609087590494, 1.0293711064839715] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.001 [0.9984704146228855, 1.0021775543724996] | pass |
| full | aa | `power_100d_e17_x1000` | 1.004 [0.9968738252005462, 1.018734964589031] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.007 [0.9766030300601932, 1.0157297220823576] | pass |
| full | aa | `recursion_50_x1000` | 0.982 [0.9799030605057368, 0.998991064749654] | pass |
| full | aa | `sparse_array_200000` | 0.990 [0.9817383307888458, 1.007266558801437] | pass |
| full | aa | `frontend_definitions_2000` | 1.015 [0.9850878704463797, 1.0347661955901064] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.001 [0.9919958334922285, 1.0706200705099542] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.003 [0.9904996737968761, 1.0113678331201155] | pass |
| full | aa | `streaming_statements_20000` | 0.995 [0.9919445438095293, 1.004443231020321] | pass |
| full | aa | `square_100d_x100000` | 1.003 [0.9904211743740534, 1.020914640015728] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9993419289244112, 1.0020718043228518] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 0.991 [0.9528873317273787, 1.012266798774389] | pass |
| full | paired | `startup` | 0.991 [0.7334209734690316, 1.301230480789653] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.141 [1.0868626832884125, 1.1666572259627794] | confirmed regression |
| full | paired | `calls_200000` | 1.112 [1.074645806871627, 1.13850361168601] | confirmed regression |
| full | paired | `array_200000` | 0.828 [0.8143570941857378, 0.85310557928845] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.109 [1.072049488811896, 1.1295526833584881] | confirmed regression |
| full | paired | `compare_low_1000d_x100000` | 1.097 [1.0724192977856932, 1.1123420767727523] | confirmed regression |
| full | paired | `compare_equal_1000d_x100000` | 1.092 [1.0266593300241502, 1.1222657228768804] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.071 [1.0544136048973747, 1.0977733587549723] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.018 [1.0088466707408077, 1.0329655799342645] | pass |
| full | paired | `multiply_100d_x100000` | 1.061 [1.0380427571782258, 1.0878464539621708] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.999 [0.9941534809820262, 1.0040621864906503] | pass |
| full | paired | `divide_scale100_x100000` | 1.043 [1.0293854106266977, 1.0667870011180716] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.002 [1.0017547853052537, 1.0037232368805844] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.9937899770671793, 1.004553514873323] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.989345677994334, 1.0101785407195225] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.992 [0.986551276162969, 0.9948315342003611] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.004 [0.9713079830912469, 1.0265524702133144] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.014 [1.0009441935391092, 1.0268001444971164] | pass |
| full | paired | `power_100d_e17_x1000` | 0.998 [0.9894969579505986, 1.0027407471303682] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.087 [1.07405579846308, 1.1174005278142745] | confirmed regression |
| full | paired | `recursion_50_x1000` | 1.063 [1.0450838781230272, 1.0759466665615263] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.082 [1.0748536849467956, 1.1041757417508893] | confirmed regression |
| full | paired | `frontend_definitions_2000` | 1.006 [0.9926025913372494, 1.0201999308844345] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.999 [0.9662777312044643, 1.029255928096386] | pass |
| full | paired | `decimal_output_200d_x1000` | 1.011 [0.9677395830913605, 1.0550586518388125] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.998 [0.9940891533531769, 1.0207531804430765] | pass |
| full | paired | `square_100d_x100000` | 1.066 [1.0359722498395934, 1.0911182031008297] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 0.998 [0.9975272131730567, 1.000072863810669] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.992 [0.8675076333839103, 1.0374858782068348] | pass |
