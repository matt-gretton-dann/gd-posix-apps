# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.126 [0.8714436416489695, 1.3381076523404258] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.000 [0.9590057133746767, 1.0302412967872911] | pass |
| full | aa | `calls_200000` | 0.994 [0.9635198211716733, 1.0069004014367167] | pass |
| full | aa | `array_200000` | 0.998 [0.9712879301497637, 1.009175202106031] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.000 [0.9911873460927599, 1.0192468651299473] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.999 [0.9848184598972951, 1.0152100225719922] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.006 [0.9921417487727594, 1.0290998114619612] | pass |
| full | aa | `fibonacci_1000_x100` | 0.991 [0.9803634410552323, 0.9977446634652098] | pass |
| full | aa | `factorial_1000_x50` | 1.007 [0.993679251314428, 1.0129848383696252] | pass |
| full | aa | `multiply_100d_x100000` | 1.011 [0.9856064871686864, 1.0222397810364916] | pass |
| full | aa | `multiply_10000d_x1000` | 0.999 [0.9477758104777657, 1.000353846384643] | pass |
| full | aa | `divide_scale100_x100000` | 0.985 [0.9789254280879682, 1.0088894939560389] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.9850209386485742, 1.0203903053156236] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9700787964756761, 1.0039099718858844] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.000 [0.9967981742501022, 1.0194245295865325] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9974494377743945, 1.002873855110427] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.992 [0.9679620447350141, 1.0344424630393279] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9931697243019209, 1.0006737381231734] | pass |
| full | aa | `power_100d_e17_x1000` | 0.991 [0.9747365035422658, 1.0064173837955825] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.996 [0.982109206890279, 1.0113303976497703] | pass |
| full | aa | `recursion_50_x1000` | 1.008 [0.9916434311337737, 1.028320023933387] | pass |
| full | aa | `sparse_array_200000` | 0.996 [0.9790134952626478, 1.0236375182521609] | pass |
| full | aa | `frontend_definitions_2000` | 0.975 [0.953930540510671, 0.9819036577073516] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.998 [0.9643207787696984, 1.0132844872527553] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.040 [0.9126744700257645, 1.118962578596076] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.000 [0.9840071161962108, 1.0127724569605476] | pass |
| full | aa | `square_100d_x100000` | 1.004 [0.9905717925862995, 1.0220411103755822] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9987674198988759, 1.0007672505889005] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.088 [0.9340255804882566, 1.2115314953406093] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.998 [0.9909950342316591, 0.9993105725426944] | pass |
| full | aa | `octal_output_1000d_x300` | 0.999 [0.9973627567533705, 1.0035090535753786] | pass |
| full | paired | `startup` | 1.011 [0.9744440588779313, 1.1117412301358185] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.060 [1.0196625025369201, 1.2356074908196504] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.064 [1.0527933324126428, 1.0888272903699945] | inconclusive-noisy |
| full | paired | `array_200000` | 1.060 [1.0420922224994595, 1.071397047282818] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 1.053 [1.0351222071824353, 1.2047626918756444] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 1.021 [1.0067223163377055, 1.0405663501972315] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.022 [1.002733661769934, 1.0400860244211039] | pass |
| full | paired | `fibonacci_1000_x100` | 1.003 [0.9928263777743788, 1.0206570231304828] | pass |
| full | paired | `factorial_1000_x50` | 1.010 [1.0031367596418954, 1.02104849063797] | pass |
| full | paired | `multiply_100d_x100000` | 1.023 [1.002379406251442, 1.0401186444438768] | pass |
| full | paired | `multiply_10000d_x1000` | 1.001 [0.9990301546086918, 1.0079705994912413] | pass |
| full | paired | `divide_scale100_x100000` | 1.062 [1.0528533632120416, 1.0717487771411933] | confirmed regression |
| full | paired | `sqrt_scale100_x5000` | 1.008 [0.9652457412535935, 1.0153345542337058] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.007 [1.0035261752984115, 1.0224152715069816] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.001 [0.9864190512386114, 1.017204508783324] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.992 [0.9903762399052565, 0.9955392129053791] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.010 [1.0062956607063072, 1.0328836447460474] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.007 [1.0024659732532877, 1.011546097679656] | pass |
| full | paired | `power_100d_e17_x1000` | 0.998 [0.9877236549840209, 1.0024391227761618] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.055 [1.029997042633309, 1.1608067842339964] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.024 [1.018113475265041, 1.0567212095084548] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.048 [1.0195674994039639, 1.106801619461942] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 0.964 [0.9515068286814996, 0.9733217431980711] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.039 [1.00917280465762, 1.0681450950340132] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.969 [0.9054313120994177, 1.0216245291800123] | pass |
| full | paired | `streaming_statements_20000` | 0.986 [0.9762532116882047, 1.0471538215040874] | pass |
| full | paired | `square_100d_x100000` | 1.015 [1.0057097465985814, 1.0285204911456407] | pass |
| full | paired | `square_10000d_x500` | 1.001 [0.9991112002637754, 1.022682143525109] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.091 [1.003886504726773, 1.230046606836701] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.062 [0.05997391742087193, 0.06315005791554201] | pass |
| full | paired | `octal_output_1000d_x300` | 0.152 [0.15070950432691205, 0.15379136832437737] | pass |
