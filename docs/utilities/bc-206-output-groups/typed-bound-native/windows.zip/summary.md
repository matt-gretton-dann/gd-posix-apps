# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.081 [0.9625837937952337, 1.093984625063106] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.010 [0.9976422108588293, 1.0245227203937066] | pass |
| full | aa | `calls_200000` | 1.013 [0.9986437779621651, 1.055614338242035] | inconclusive-noisy |
| full | aa | `array_200000` | 1.014 [0.9490265762497828, 1.0243696617761475] | pass |
| full | aa | `compare_high_1000d_x100000` | 1.005 [0.9175686885104958, 1.0196394993622657] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.010 [1.0021577872799499, 1.0717348527770287] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 1.003 [0.9889039508185639, 1.0197597260137345] | pass |
| full | aa | `fibonacci_1000_x100` | 0.995 [0.9124486711742367, 1.013602561592073] | pass |
| full | aa | `factorial_1000_x50` | 1.005 [0.9889195273945729, 1.0165051681700237] | pass |
| full | aa | `multiply_100d_x100000` | 1.002 [0.9840613977798168, 1.0132625673996627] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9911251823416746, 1.0142129501858024] | pass |
| full | aa | `divide_scale100_x100000` | 1.000 [0.9880131816003624, 1.0189491529843775] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.001 [0.9853871062557616, 1.0118225894726829] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.993 [0.9716243539392841, 1.0081562684636647] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.999 [0.9938218641519717, 1.0126422656645233] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9503887827187132, 1.0119773486543777] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.993 [0.9809121550964714, 1.035217100024945] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.002 [0.9729810293112521, 1.0078365115054084] | pass |
| full | aa | `power_100d_e17_x1000` | 1.002 [0.9838378956550612, 1.0137839954122851] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.010 [1.0023358048420505, 1.0214580377966171] | pass |
| full | aa | `recursion_50_x1000` | 1.014 [0.9981169305976402, 1.0202966571868928] | pass |
| full | aa | `sparse_array_200000` | 0.996 [0.9829213785942525, 1.023785936075834] | pass |
| full | aa | `frontend_definitions_2000` | 0.996 [0.9760090930963825, 1.0635673804713655] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 1.003 [0.9844473341971974, 1.0175749300989974] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.997 [0.9864912952995191, 1.0680651405482267] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 1.000 [0.9725219971612161, 1.0668118441941477] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 1.018 [1.0113248866361892, 1.0380918288064633] | pass |
| full | aa | `square_10000d_x500` | 1.002 [0.9983293677960604, 1.0057609148934488] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.023 [0.9796303644642835, 1.0681343868762974] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.001 [0.9951623844949783, 1.0033104039713494] | pass |
| full | aa | `octal_output_1000d_x300` | 1.003 [0.9916225040417836, 1.0084503097839366] | pass |
| full | paired | `startup` | 1.001 [0.9348520119736984, 1.131068861335876] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.964 [0.9340370728512295, 1.014888615355663] | pass |
| full | paired | `calls_200000` | 0.945 [0.9372362833872281, 0.9889957498314809] | pass |
| full | paired | `array_200000` | 0.967 [0.9264723437133274, 1.076047398834557] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.967 [0.828303294793194, 0.9876896235122525] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.966 [0.9245921641116219, 0.9861868802633766] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.977 [0.921458045124543, 1.0230329564116838] | pass |
| full | paired | `fibonacci_1000_x100` | 0.978 [0.9505059765292307, 1.0002569990800712] | pass |
| full | paired | `factorial_1000_x50` | 1.004 [0.9780908763812082, 1.0252261033019097] | pass |
| full | paired | `multiply_100d_x100000` | 0.982 [0.9432675199705837, 1.1887623794933804] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 1.014 [1.003746633260332, 1.0210883037511924] | pass |
| full | paired | `divide_scale100_x100000` | 0.969 [0.9460333282596223, 1.0807623597443268] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.002 [0.9879045869576085, 1.0686043903057454] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.021 [1.0079419372277951, 1.1552605898657295] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.014 [0.994496488808152, 1.1161299904686661] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.003 [0.9318141643824277, 1.0348351977491375] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.000 [0.928682496925495, 1.0693967237178854] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.951 [0.9368225115888406, 0.998905008556216] | pass |
| full | paired | `power_100d_e17_x1000` | 0.990 [0.9778919588618101, 1.0308581152081693] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.969 [0.9087735705389677, 1.0396392949334718] | pass |
| full | paired | `recursion_50_x1000` | 0.995 [0.9620243846768265, 1.3023252372959129] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.944 [0.8947894705324714, 0.9845069173706038] | pass |
| full | paired | `frontend_definitions_2000` | 0.997 [0.972302557341174, 1.0400870853297766] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.999 [0.9746621410560736, 1.3631402806686594] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.993 [0.9774775389826841, 1.0144058684968194] | pass |
| full | paired | `streaming_statements_20000` | 0.996 [0.9615484617121356, 1.038475034657563] | pass |
| full | paired | `square_100d_x100000` | 1.008 [0.8858849831421923, 1.0132010859921534] | pass |
| full | paired | `square_10000d_x500` | 1.003 [0.991114806926553, 1.0269616460011293] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 0.995 [0.9646356525253383, 1.069962747538656] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.098 [0.09205860664472176, 0.1063187372227996] | pass |
| full | paired | `octal_output_1000d_x300` | 0.220 [0.21620955046802748, 0.25131499999494056] | pass |
