# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.128 [0.8622234430689449, 1.1778906418309143] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.998 [0.9559889459064924, 1.0744584016019358] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.999 [0.9748221459928492, 1.0075676672035347] | pass |
| full | aa | `array_200000` | 0.997 [0.9966596219776617, 1.0099618244880144] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.999 [0.9674115281349412, 1.0292885696541783] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.997 [0.9831021774945298, 1.0127931358842428] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.986 [0.9824332678776981, 0.9953377636856245] | pass |
| full | aa | `fibonacci_1000_x100` | 0.999 [0.9732549760932246, 1.000805187025597] | pass |
| full | aa | `factorial_1000_x50` | 1.002 [0.9917661626882737, 1.013945173581877] | pass |
| full | aa | `multiply_100d_x100000` | 1.003 [0.9940064914892116, 1.0081288532503854] | pass |
| full | aa | `multiply_10000d_x1000` | 1.008 [1.0019989332758275, 1.0248857683077126] | pass |
| full | aa | `divide_scale100_x100000` | 0.999 [0.9947221747265673, 1.015471954088436] | pass |
| full | aa | `sqrt_scale100_x5000` | 1.004 [0.9910535977947988, 1.0110260034244694] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.004 [0.9819892638385117, 1.0052247603350395] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.997 [0.983289117223634, 1.0161754689273297] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.996 [0.9888251577208907, 1.005885276543822] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.011 [0.9701119347949436, 1.0303459788429412] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.996 [0.9812774322943416, 1.0013085122919267] | pass |
| full | aa | `power_100d_e17_x1000` | 0.994 [0.983204331358352, 1.0065454125945568] | pass |
| full | aa | `ibase_literal_flip_20000` | 1.000 [0.9798981529947307, 1.0162357924787315] | pass |
| full | aa | `recursion_50_x1000` | 0.997 [0.9756359857058872, 1.0151326630590671] | pass |
| full | aa | `sparse_array_200000` | 0.997 [0.9836258608297423, 1.0067236911449409] | pass |
| full | aa | `frontend_definitions_2000` | 0.991 [0.9827514564092771, 1.0147490340387482] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.994 [0.9680635620386353, 1.0044855607085132] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.011 [0.9721735883481725, 1.0847095145970531] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.997 [0.9488696951516032, 1.0123705592468935] | pass |
| full | aa | `square_100d_x100000` | 1.002 [0.9980742378243604, 1.023536469352784] | pass |
| full | aa | `square_10000d_x500` | 1.002 [0.9896277018289146, 1.031727754163227] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.042 [0.8722953437512438, 1.1115252490058647] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.004 [1.000426069942759, 1.0312431658114392] | pass |
| full | aa | `octal_output_1000d_x300` | 0.998 [0.9956348991088462, 1.0202566302725535] | pass |
| full | paired | `startup` | 1.007 [0.9586165482726855, 1.1285992340068591] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.006 [0.9971810402049633, 1.0518810436649242] | inconclusive-noisy |
| full | paired | `calls_200000` | 0.994 [0.9720672564284862, 1.0055933068009175] | pass |
| full | paired | `array_200000` | 1.005 [0.9999280475933061, 1.0102234087096333] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.988 [0.9799255882630062, 1.0103733018714367] | pass |
| full | paired | `compare_low_1000d_x100000` | 1.005 [0.9994907261591601, 1.0489263004701064] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.004 [0.983691736584165, 1.0302518397518488] | pass |
| full | paired | `fibonacci_1000_x100` | 1.005 [0.991443566638443, 1.017839325095982] | pass |
| full | paired | `factorial_1000_x50` | 1.005 [0.9885520349332335, 1.0247105875266567] | pass |
| full | paired | `multiply_100d_x100000` | 0.999 [0.9922802996468335, 1.007118790870186] | pass |
| full | paired | `multiply_10000d_x1000` | 0.972 [0.9461163576237837, 1.000255951010756] | pass |
| full | paired | `divide_scale100_x100000` | 1.002 [0.9846842462220072, 1.0359777167992923] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.991 [0.9739610299325034, 1.005565537578992] | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.9948541748356272, 1.0146566018034155] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9958422585369832, 1.01097517688185] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.000 [0.9936362323658118, 1.0214749890225536] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.070 [1.0195872742899514, 1.088029961539953] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.001 [0.9818513186610583, 1.0100615805364423] | pass |
| full | paired | `power_100d_e17_x1000` | 1.000 [0.9812102537254866, 1.0095230779262783] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.984 [0.96512829588941, 1.001843566417423] | pass |
| full | paired | `recursion_50_x1000` | 0.999 [0.9834703937642886, 1.0084766310209947] | pass |
| full | paired | `sparse_array_200000` | 1.001 [0.9966994303034308, 1.0128204244262153] | pass |
| full | paired | `frontend_definitions_2000` | 0.993 [0.9825981904988141, 1.00603554162739] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.005 [0.991524796626447, 1.0170173719280378] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.959 [0.955400810680938, 1.0054584405388276] | pass |
| full | paired | `streaming_statements_20000` | 1.005 [0.9664918235003414, 1.0152063434298844] | pass |
| full | paired | `square_100d_x100000` | 0.998 [0.9901274529363717, 1.0056845563846601] | pass |
| full | paired | `square_10000d_x500` | 1.030 [0.9871451620635716, 1.035305176376055] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.025 [0.9956438253008217, 1.1327036437273752] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.067 [0.06585096425751578, 0.07472987160259065] | pass |
| full | paired | `octal_output_1000d_x300` | 0.164 [0.15631400779354446, 0.1689008713961452] | pass |
