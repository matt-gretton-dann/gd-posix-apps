# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.229 [0.7797805193578674, 1.307009604505073] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.997 [0.9927035891490992, 1.0056844187362919] | pass |
| full | aa | `calls_200000` | 0.997 [0.9927738513232435, 1.0012632134073751] | pass |
| full | aa | `array_200000` | 1.007 [0.995542748979343, 1.014245214064157] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.997 [0.9916543444404452, 1.017893358277701] | pass |
| full | aa | `compare_low_1000d_x100000` | 1.001 [0.9921497042401413, 1.015271476700172] | pass |
| full | aa | `compare_equal_1000d_x100000` | 1.002 [0.9875783757138475, 1.0110593974707025] | pass |
| full | aa | `fibonacci_1000_x100` | 1.006 [0.9861565386449733, 1.0131814234864205] | pass |
| full | aa | `factorial_1000_x50` | 0.999 [0.9871433709532369, 1.010782675845079] | pass |
| full | aa | `multiply_100d_x100000` | 0.998 [0.9878966783511653, 1.0069847257846765] | pass |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.9966071176235851, 1.007677968328064] | pass |
| full | aa | `divide_scale100_x100000` | 1.000 [0.9839578995993856, 1.005996279636028] | pass |
| full | aa | `sqrt_scale100_x5000` | 0.991 [0.9853671362193176, 0.999379973533716] | pass |
| full | aa | `multiply_dense_10000d_x500` | 1.001 [0.9980101154910959, 1.0149200012340887] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.992 [0.9849780222548382, 1.0219279989813326] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 0.999 [0.9881016459194972, 1.009289250642305] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.993 [0.9839930700951177, 1.026765514162094] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.998 [0.9916332408574184, 1.009760450267394] | pass |
| full | aa | `power_100d_e17_x1000` | 0.995 [0.9811947707808729, 1.005874286353196] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.998 [0.9450207190813499, 1.0213368198270019] | pass |
| full | aa | `recursion_50_x1000` | 0.997 [0.9883415236312214, 1.0093578893699344] | pass |
| full | aa | `sparse_array_200000` | 0.997 [0.9864601337208664, 1.0007912769050005] | pass |
| full | aa | `frontend_definitions_2000` | 1.004 [0.9784604756472778, 1.0427284450684446] | pass |
| full | aa | `decimal_input_4000d_x100` | 1.016 [0.9921141484016152, 1.032273987236179] | pass |
| full | aa | `decimal_output_200d_x1000` | 0.962 [0.9587197458621135, 1.0788245058442885] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.999 [0.977439595903408, 1.0133173335884542] | pass |
| full | aa | `square_100d_x100000` | 1.000 [0.9927771163145171, 1.013486552940561] | pass |
| full | aa | `square_10000d_x500` | 0.998 [0.9933834793010848, 1.0014393625091742] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.061 [0.8919800595662717, 1.1685806724605639] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 1.000 [0.9925082321385292, 1.0102386515302448] | pass |
| full | aa | `octal_output_1000d_x300` | 0.996 [0.993706119101596, 1.0050379306065973] | pass |
| full | paired | `startup` | 1.053 [0.910378767395991, 1.9003570618121732] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.008 [0.9863716939897711, 1.0167129314911818] | pass |
| full | paired | `calls_200000` | 1.019 [1.0128656747198006, 1.0271969336787639] | pass |
| full | paired | `array_200000` | 1.020 [1.012702704130124, 1.0256181764896386] | pass |
| full | paired | `compare_high_1000d_x100000` | 1.012 [1.0042467194626299, 1.0535727039993588] | inconclusive-noisy |
| full | paired | `compare_low_1000d_x100000` | 0.985 [0.9724278106913385, 1.0018406890413518] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.985 [0.9738900524374509, 0.9917248986159928] | pass |
| full | paired | `fibonacci_1000_x100` | 1.023 [1.0126734221133695, 1.0337539239655817] | pass |
| full | paired | `factorial_1000_x50` | 1.018 [1.0145515120415431, 1.0276600646466971] | pass |
| full | paired | `multiply_100d_x100000` | 1.025 [1.012929545305178, 1.0414009635212846] | pass |
| full | paired | `multiply_10000d_x1000` | 1.004 [0.9873479564293406, 1.017175289562477] | pass |
| full | paired | `divide_scale100_x100000` | 1.028 [1.0195037058160101, 1.0472680865074437] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.998 [0.9938825020232411, 1.004590652460157] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.008 [0.9858252478078514, 1.0140312553873752] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.008 [0.9812742038799337, 1.0180766532447227] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.002 [0.9931826524342261, 1.006216964514472] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.998 [0.9886939293684103, 1.02892048345063] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.001 [0.981020612270235, 1.011221534441146] | pass |
| full | paired | `power_100d_e17_x1000` | 1.002 [0.9892401324889802, 1.0154231594259324] | pass |
| full | paired | `ibase_literal_flip_20000` | 1.030 [1.0033339897728701, 1.0673201108069859] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.014 [1.004713268551052, 1.0351209216955342] | pass |
| full | paired | `sparse_array_200000` | 1.033 [1.0276462415261383, 1.0394191496912024] | pass |
| full | paired | `frontend_definitions_2000` | 0.990 [0.9690327331252754, 1.0026066928770094] | pass |
| full | paired | `decimal_input_4000d_x100` | 1.070 [1.0453345090166741, 1.0880048929402102] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.019 [0.9033894444962595, 1.0371670385781986] | pass |
| full | paired | `streaming_statements_20000` | 1.009 [0.9853967220626536, 1.0296054359493312] | pass |
| full | paired | `square_100d_x100000` | 1.018 [1.0140764968396172, 1.0277092377403887] | pass |
| full | paired | `square_10000d_x500` | 1.015 [1.0130079998313635, 1.0176503376102397] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.063 [0.9299475571949622, 1.1750527125925807] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.054 [0.053631799601438115, 0.054804622542209004] | pass |
| full | paired | `octal_output_1000d_x300` | 0.138 [0.13825219558451907, 0.14093733724265994] | pass |
