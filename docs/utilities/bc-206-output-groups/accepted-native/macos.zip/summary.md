# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 0.981 [0.37288578170977665, 1.152950086558316] | inconclusive-noisy |
| full | aa | `loop_1000000` | 1.025 [0.9107449814573954, 1.1555397602909097] | inconclusive-noisy |
| full | aa | `calls_200000` | 0.899 [0.7978228127062744, 1.070230784997159] | inconclusive-noisy |
| full | aa | `array_200000` | 0.905 [0.8422093638557263, 1.0856528824521958] | inconclusive-noisy |
| full | aa | `compare_high_1000d_x100000` | 1.009 [0.7879840471148373, 1.104168539592586] | inconclusive-noisy |
| full | aa | `compare_low_1000d_x100000` | 1.042 [0.9775232908199444, 1.2134028221015423] | inconclusive-noisy |
| full | aa | `compare_equal_1000d_x100000` | 0.991 [0.8082678187074254, 1.14180432755794] | inconclusive-noisy |
| full | aa | `fibonacci_1000_x100` | 0.994 [0.7080961990115077, 1.0537890507674539] | inconclusive-noisy |
| full | aa | `factorial_1000_x50` | 1.008 [0.9823582635888317, 1.0888352218288642] | inconclusive-noisy |
| full | aa | `multiply_100d_x100000` | 0.984 [0.9304213663824773, 1.2331418381087507] | inconclusive-noisy |
| full | aa | `multiply_10000d_x1000` | 1.038 [0.965730769650915, 1.104482714868201] | inconclusive-noisy |
| full | aa | `divide_scale100_x100000` | 0.913 [0.8028911135349877, 1.187418332899217] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 1.023 [0.7684037120730194, 1.2177341934065404] | inconclusive-noisy |
| full | aa | `multiply_dense_10000d_x500` | 1.018 [0.9256657879726047, 1.063193489978799] | inconclusive-noisy |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.026 [0.8436474772245632, 1.1123055752092461] | inconclusive-noisy |
| full | aa | `multiply_sparse_10000d_x1000` | 1.020 [0.9767810070666174, 1.256243903521275] | inconclusive-noisy |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 0.965 [0.8643858354856468, 1.034504136161596] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 0.943 [0.7599918459714954, 0.9802862817469018] | pass |
| full | aa | `power_100d_e17_x1000` | 0.997 [0.864742645481788, 1.2708693504298345] | inconclusive-noisy |
| full | aa | `ibase_literal_flip_20000` | 1.024 [0.8072757794112281, 1.067503843295394] | inconclusive-noisy |
| full | aa | `recursion_50_x1000` | 0.959 [0.8775779695110112, 1.0691101290118166] | inconclusive-noisy |
| full | aa | `sparse_array_200000` | 0.876 [0.8591540182873599, 1.1049863929610722] | inconclusive-noisy |
| full | aa | `frontend_definitions_2000` | 0.969 [0.6526661406403447, 1.101363754030243] | inconclusive-noisy |
| full | aa | `decimal_input_4000d_x100` | 0.994 [0.9202940810551454, 1.152124959147963] | inconclusive-noisy |
| full | aa | `decimal_output_200d_x1000` | 1.084 [0.9440466646873689, 1.8893340484280223] | inconclusive-noisy |
| full | aa | `streaming_statements_20000` | 0.959 [0.7649077138860978, 1.0576206887987414] | inconclusive-noisy |
| full | aa | `square_100d_x100000` | 0.996 [0.9285228454083034, 1.1232339128656963] | inconclusive-noisy |
| full | aa | `square_10000d_x500` | 0.962 [0.8671604895093492, 1.071659403393865] | inconclusive-noisy |
| full | aa | `literal_repeat_2000d_x2000` | 0.998 [0.7671584502869054, 1.6661108899538455] | inconclusive-noisy |
| full | aa | `binary_output_1000d_x300` | 0.997 [0.8635867302489733, 1.1031100310520034] | inconclusive-noisy |
| full | aa | `octal_output_1000d_x300` | 0.990 [0.9474026616016851, 1.2115912669339017] | inconclusive-noisy |
| full | paired | `startup` | 0.927 [0.8157571171838693, 1.1395779183460089] | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.052 [0.949627758495805, 1.1272207895346058] | inconclusive-noisy |
| full | paired | `calls_200000` | 1.035 [0.8680834422371959, 1.1364650669086152] | inconclusive-noisy |
| full | paired | `array_200000` | 1.095 [1.0115975824393497, 1.1511692234317241] | inconclusive-noisy |
| full | paired | `compare_high_1000d_x100000` | 0.840 [0.8037676958481387, 1.017186125681016] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.933 [0.6818685481099369, 1.0298297480184] | pass |
| full | paired | `compare_equal_1000d_x100000` | 1.031 [0.9839391505127919, 1.1792343723965575] | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.048 [0.9085151517947718, 1.3302644213346875] | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 1.066 [0.8700111158592848, 1.2619681080606155] | inconclusive-noisy |
| full | paired | `multiply_100d_x100000` | 0.968 [0.8565298687916594, 1.065294807359644] | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.975 [0.9251959018826398, 1.063197348716024] | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 0.994 [0.8006932203844285, 1.0707201084140938] | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.048 [0.9955179581746276, 1.2468519848899717] | inconclusive-noisy |
| full | paired | `multiply_dense_10000d_x500` | 1.009 [0.9047173330289432, 1.0685225589595888] | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.971 [0.9037578491744334, 1.0922192948550624] | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 0.976 [0.8925442660044833, 1.1059031618810038] | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.973 [0.7169685068843612, 1.129560999855201] | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 0.968 [0.9359907498518933, 1.0653027655166556] | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.011 [0.8933361259886773, 1.0739549180890784] | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.960 [0.8946749281657573, 1.0842239683518928] | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.047 [0.751764498199852, 1.3749987526064087] | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.073 [0.9262186130160536, 1.1431203518688702] | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.185 [0.9630849527989634, 1.4461643224002652] | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.072 [0.90987986565217, 1.2055443010861975] | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 1.120 [0.9790563376077382, 1.4967308064784792] | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.941 [0.8343433660933134, 1.1186632829738528] | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 0.986 [0.9267469790023892, 1.1303341915058045] | inconclusive-noisy |
| full | paired | `square_10000d_x500` | 1.044 [0.9133200394611435, 1.0981612650135129] | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 0.986 [0.7990538290663158, 1.270671780204505] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.072 [0.04761610930745832, 0.0864530697459277] | pass |
| full | paired | `octal_output_1000d_x300` | 0.188 [0.14121148751070764, 0.27112637247905813] | pass |
