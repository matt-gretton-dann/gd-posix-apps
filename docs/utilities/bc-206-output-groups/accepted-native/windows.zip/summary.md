# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base. Startup remains inconclusive until calibrated.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status |
| --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.032 [0.9864330814735857, 1.1178443857785716] | inconclusive-noisy |
| full | aa | `loop_1000000` | 0.988 [0.977627351097311, 1.0017619707648477] | pass |
| full | aa | `calls_200000` | 0.975 [0.9683971570711142, 0.9919939301972212] | pass |
| full | aa | `array_200000` | 0.987 [0.9556990202228429, 1.0104540129180226] | pass |
| full | aa | `compare_high_1000d_x100000` | 0.989 [0.9789468984912404, 1.0253281923125814] | pass |
| full | aa | `compare_low_1000d_x100000` | 0.991 [0.9854065741666803, 0.9992307255670898] | pass |
| full | aa | `compare_equal_1000d_x100000` | 0.984 [0.9691380998885086, 0.9919642432606399] | pass |
| full | aa | `fibonacci_1000_x100` | 1.001 [0.9913883282249687, 1.0065548092719774] | pass |
| full | aa | `factorial_1000_x50` | 0.993 [0.9816429486961517, 1.0064148491811065] | pass |
| full | aa | `multiply_100d_x100000` | 0.996 [0.9736013983727358, 1.0286974924130774] | pass |
| full | aa | `multiply_10000d_x1000` | 1.002 [0.9828659075062837, 1.010384405078779] | pass |
| full | aa | `divide_scale100_x100000` | 0.995 [0.9777430128576328, 1.1304008649208281] | inconclusive-noisy |
| full | aa | `sqrt_scale100_x5000` | 0.999 [0.9908743717256098, 1.0066258898426446] | pass |
| full | aa | `multiply_dense_10000d_x500` | 0.997 [0.9594464195280723, 1.0304895445237334] | pass |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.005 [0.9998058199241574, 1.010509806616308] | pass |
| full | aa | `multiply_sparse_10000d_x1000` | 1.000 [0.9905013833367587, 1.0030061125537162] | pass |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.000 [0.9822639486651831, 1.019779795664242] | pass |
| full | aa | `modulo_1000d_350d_x3000` | 1.004 [0.9857743969100943, 1.0242023407028664] | pass |
| full | aa | `power_100d_e17_x1000` | 0.994 [0.988026790686759, 1.0112253090210899] | pass |
| full | aa | `ibase_literal_flip_20000` | 0.977 [0.9611839876641429, 0.982659663485906] | pass |
| full | aa | `recursion_50_x1000` | 0.967 [0.9573812648354233, 0.9720970566720066] | pass |
| full | aa | `sparse_array_200000` | 0.967 [0.9343472880538429, 0.9849067451730593] | pass |
| full | aa | `frontend_definitions_2000` | 1.008 [0.9817826387364963, 1.0182122743115785] | pass |
| full | aa | `decimal_input_4000d_x100` | 0.994 [0.9764089065343494, 1.015103162958384] | pass |
| full | aa | `decimal_output_200d_x1000` | 1.009 [0.9961456373422173, 1.019003492767259] | pass |
| full | aa | `streaming_statements_20000` | 1.010 [0.9609553426663455, 1.0157629518818048] | pass |
| full | aa | `square_100d_x100000` | 1.000 [0.9948119151858541, 1.0152162015722503] | pass |
| full | aa | `square_10000d_x500` | 1.000 [0.9933176968956192, 1.0073341878481266] | pass |
| full | aa | `literal_repeat_2000d_x2000` | 1.014 [0.9636622121201712, 1.033388202337524] | pass |
| full | aa | `binary_output_1000d_x300` | 1.001 [0.9913045579742368, 1.0058210755562291] | pass |
| full | aa | `octal_output_1000d_x300` | 0.997 [0.9730408208897795, 1.0020053127501392] | pass |
| full | paired | `startup` | 1.006 [0.9321671942889916, 1.049358106595617] | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.965 [0.9520160383982316, 0.9859585814509875] | pass |
| full | paired | `calls_200000` | 0.912 [0.8497073498129123, 0.9248721531586959] | pass |
| full | paired | `array_200000` | 0.948 [0.8959566817307311, 0.9706339404049164] | pass |
| full | paired | `compare_high_1000d_x100000` | 0.963 [0.9431140808140346, 0.9760922002811901] | pass |
| full | paired | `compare_low_1000d_x100000` | 0.978 [0.9717666141046701, 0.989783757164911] | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.974 [0.9696838797206492, 0.9917252981663388] | pass |
| full | paired | `fibonacci_1000_x100` | 0.988 [0.9673465152811032, 0.9972893945249796] | pass |
| full | paired | `factorial_1000_x50` | 0.986 [0.9733742433684384, 1.0135655495578775] | pass |
| full | paired | `multiply_100d_x100000` | 0.992 [0.9821097768104652, 1.0016906125736789] | pass |
| full | paired | `multiply_10000d_x1000` | 1.011 [1.0070668445070843, 1.0135833270461367] | pass |
| full | paired | `divide_scale100_x100000` | 0.959 [0.9510840147000472, 0.9746878910463065] | pass |
| full | paired | `sqrt_scale100_x5000` | 0.993 [0.9747006535531936, 1.002633591611802] | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.012 [0.98525128426932, 1.0445118552954145] | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9883765593959098, 1.0243059908003875] | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.006 [1.001828041219672, 1.0098557640391976] | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.014 [0.9903802859418196, 1.029981081403188] | pass |
| full | paired | `modulo_1000d_350d_x3000` | 0.993 [0.9867040730348998, 1.0040163832966638] | pass |
| full | paired | `power_100d_e17_x1000` | 0.998 [0.9807129967347534, 1.0162102224756622] | pass |
| full | paired | `ibase_literal_flip_20000` | 0.928 [0.9133079075661801, 0.9815343024368105] | pass |
| full | paired | `recursion_50_x1000` | 0.945 [0.9150057303950259, 0.9545983729753521] | pass |
| full | paired | `sparse_array_200000` | 0.926 [0.9040015245636447, 0.9501863711316514] | pass |
| full | paired | `frontend_definitions_2000` | 1.008 [0.9595571803486517, 1.0412446980212637] | pass |
| full | paired | `decimal_input_4000d_x100` | 0.987 [0.9781385829155339, 0.9996041394020059] | pass |
| full | paired | `decimal_output_200d_x1000` | 0.996 [0.8661636909113635, 1.0076917756138197] | pass |
| full | paired | `streaming_statements_20000` | 1.003 [0.9913330814736974, 1.0180082144329052] | pass |
| full | paired | `square_100d_x100000` | 0.973 [0.9432000998103018, 0.9927245023021536] | pass |
| full | paired | `square_10000d_x500` | 1.005 [0.9948756406922687, 1.007206963227121] | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.022 [0.9726604527907342, 1.075407864952508] | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.097 [0.09569076085838976, 0.09717412295766588] | pass |
| full | paired | `octal_output_1000d_x300` | 0.215 [0.21162708621082885, 0.22129421880340727] | pass |
