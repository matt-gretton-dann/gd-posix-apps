# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.006 [0.9584815770714609, 1.0434706117658314] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.992 [0.955652061940105, 1.0220358792503528] | pass | - |
| full | aa | `calls_200000` | 1.000 [0.9865506466768068, 1.0053673674943933] | pass | - |
| full | aa | `array_200000` | 0.997 [0.9735100454214732, 1.0032065931087915] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.008 [0.9706841979947214, 1.023041203665853] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.001 [0.9931112741285497, 1.111098106723296] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.004 [0.9984425596016119, 1.1504484591637956] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 1.007 [0.9987595489052737, 1.0361718681075902] | pass | - |
| full | aa | `factorial_1000_x50` | 1.004 [1.0022396550699324, 1.0291093151526651] | pass | - |
| full | aa | `multiply_100d_x100000` | 0.998 [0.9868341145673121, 1.004394555176062] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.001 [0.9827037378212383, 1.008765602841757] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.994 [0.9890491079308923, 1.0235150449109234] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.004 [0.9944581280805603, 1.0696988575630284] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 0.998 [0.9977394029416746, 1.0419169329040496] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.000 [0.9747384759636737, 1.0217227486323077] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.002 [0.9755302310858321, 1.0096692022490121] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.994 [0.9921261127476, 1.0054151082052527] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.000 [0.9830154898285284, 1.0021791440248389] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.000 [0.9908853229130937, 1.0088478524700548] | pass | - |
| full | aa | `power_100d_e17_x1000` | 0.994 [0.9762682342717016, 1.0021437212534174] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 1.004 [0.9881448253739189, 1.0104467441695908] | pass | - |
| full | aa | `recursion_50_x1000` | 0.993 [0.9875927942232783, 1.069366754745166] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 1.013 [0.9879028812123702, 1.0314040569783551] | pass | - |
| full | aa | `frontend_definitions_2000` | 0.995 [0.9858800183162975, 1.0313092435617146] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 1.007 [0.9951459629497021, 1.0148592977278108] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.011 [0.9938402264072246, 1.0414199733787441] | pass | - |
| full | aa | `streaming_statements_20000` | 1.011 [0.9612946274085268, 1.0917621095747962] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 1.005 [0.9873502580709517, 1.0455434105187784] | pass | - |
| full | aa | `square_10000d_x500` | 1.000 [0.994332385177669, 1.0070885993105343] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 0.995 [0.9640067104136184, 1.0143465405005454] | pass | - |
| full | aa | `binary_output_1000d_x300` | 0.997 [0.9743397959048783, 1.0240237178358105] | pass | - |
| full | aa | `octal_output_1000d_x300` | 0.999 [0.9767828641814356, 1.0117608865637837] | pass | - |
| full | aa | `binary_input_100000d_x3` | 0.995 [0.9211606127006191, 1.008507249156953] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 0.999 [0.9920062115085938, 1.013130504512401] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 1.000 [0.994278736358951, 1.0067142768637334] | pass | - |
| full | aa | `file_statements_20000` | 0.968 [0.9293126563090867, 1.0124109475246088] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 1.000 [0.9860487714582599, 1.002429856537076] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 0.990 [0.9759783928182945, 1.0143520590856274] | pass | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.003 [0.9709346972525247, 1.0257432922335203] | pass | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.003 [0.9635116830350428, 1.025029984421115] | pass | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.008 [0.982227058400441, 1.0154444618787652] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.009 [0.9876028084246175, 1.0131341105385943] | pass | - |
| full | aa | `modulo_scaled_numerator_s3_b7_t43_x1000` | 0.998 [0.9951373043965442, 1.0167606376470482] | pass | - |
| full | aa | `modulo_scaled_divisor_s97_b37_t43_x1000` | 1.011 [0.9984567771126376, 1.0291960304907262] | pass | - |
| full | paired | `startup` | 0.996 [0.9848151785916893, 1.0069931176407334] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.007 [0.9742177453987239, 1.0292970676175874] | pass | pass |
| full | paired | `calls_200000` | 1.007 [0.9950271133074334, 1.0516708091215046] | inconclusive-noisy | pass |
| full | paired | `array_200000` | 1.018 [1.005443052557524, 1.051955468074205] | inconclusive-noisy | pass |
| full | paired | `compare_high_1000d_x100000` | 1.006 [0.9938861634373048, 1.0226223172824205] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 1.010 [1.0036958350648155, 1.0187162540035628] | pass | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 1.007 [0.9980707763464661, 1.0321202799418383] | pass | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.003 [0.9792667915986246, 1.0226533215793745] | pass | pass |
| full | paired | `factorial_1000_x50` | 0.999 [0.9980320101615319, 1.0108994872154278] | pass | pass |
| full | paired | `multiply_100d_x100000` | 1.001 [0.9926362739173588, 1.0029870169909814] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 1.000 [0.9924268631540706, 1.0083426747517705] | pass | pass |
| full | paired | `divide_scale100_x100000` | 1.009 [1.0060862263550645, 1.0564262841687082] | inconclusive-noisy | pass |
| full | paired | `sqrt_scale100_x5000` | 0.994 [0.9656848589225733, 1.039873938062527] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 1.010 [1.0049464116149853, 1.0132254959248763] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.013 [0.9816925734030642, 1.0250341852632718] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.996 [0.8889784400157928, 1.0140838341429257] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 0.997 [0.9886408505528972, 1.009867976354218] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.9868264304590686, 1.0134354678792188] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.000 [0.990497764319425, 1.0216859190738108] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.989 [0.9852262334592831, 1.001594908033375] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 1.011 [0.9962801821507823, 1.0245939570912672] | pass | pass |
| full | paired | `recursion_50_x1000` | 1.002 [0.9456999184156689, 1.0107714208371934] | pass | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 1.010 [0.9740509875130596, 1.026025375782682] | pass | pass |
| full | paired | `frontend_definitions_2000` | 0.969 [0.9257606240729848, 1.0031559079342216] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 1.000 [0.9934224743307705, 1.0075079684713024] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 0.979 [0.921225576277508, 1.0020759375488069] | pass | pass |
| full | paired | `streaming_statements_20000` | 1.008 [0.9535223373319212, 1.0460227014571712] | pass | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.023 [0.9967662106103989, 1.0530666021050983] | inconclusive-noisy | pass |
| full | paired | `square_10000d_x500` | 0.999 [0.9955961913934385, 1.00686135943591] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.010 [0.9928558873149941, 1.0534919602839667] | inconclusive-noisy | pass |
| full | paired | `binary_output_1000d_x300` | 1.001 [0.973157476903493, 1.011967108324475] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 0.999 [0.9874756767983285, 1.0054423390183607] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 1.005 [0.986783136639781, 1.0154844785079835] | pass | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 0.993 [0.9818422067580902, 1.0011610633050811] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 1.014 [0.9956502880359842, 1.0266727129654316] | pass | pass |
| full | paired | `file_statements_20000` | 1.003 [0.9935098841385769, 1.010952981140714] | pass | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 1.004 [1.0001266258845245, 1.0146769848977728] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 1.001 [0.9642915233107529, 1.0857339008805886] | inconclusive-noisy | pass |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.041 [0.9650519126285328, 1.1016272906150453] | inconclusive-noisy | pass |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.005 [0.9878211873914924, 1.0288988484542412] | pass | pass |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.005 [0.9959902655678068, 1.0334558191544887] | pass | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.999 [0.9681720500103231, 1.0099071870287188] | pass | pass |
| full | paired | `modulo_scaled_numerator_s3_b7_t43_x1000` | 0.992 [0.9588402207307839, 1.0062757740505497] | pass | pass |
| full | paired | `modulo_scaled_divisor_s97_b37_t43_x1000` | 0.996 [0.9925472912551027, 1.0200448842323013] | pass | pass |
