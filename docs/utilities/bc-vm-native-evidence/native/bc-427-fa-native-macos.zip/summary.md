# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.068 [0.9589948226442141, 1.2472445115092132] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.976 [0.9450187692638636, 0.9949401595728297] | inconclusive-noisy | - |
| full | aa | `calls_200000` | 0.998 [0.9115330505738283, 1.0682942588033424] | inconclusive-noisy | - |
| full | aa | `array_200000` | 0.998 [0.9804538150563763, 1.0239500922574347] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 1.007 [0.9935355508472096, 1.0199103774244693] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 0.978 [0.8119184364785075, 1.0132084878618421] | inconclusive-noisy | - |
| full | aa | `compare_equal_1000d_x100000` | 1.004 [0.9251974328626905, 1.066859151952292] | inconclusive-noisy | - |
| full | aa | `fibonacci_1000_x100` | 1.016 [0.9871404884456793, 1.062096379640119] | inconclusive-noisy | - |
| full | aa | `factorial_1000_x50` | 1.013 [0.9573127174693159, 1.0441512810373528] | pass | - |
| full | aa | `multiply_100d_x100000` | 1.001 [0.9693399260017124, 1.0595601569291375] | inconclusive-noisy | - |
| full | aa | `multiply_10000d_x1000` | 0.984 [0.9278871388710074, 1.035245877284232] | inconclusive-noisy | - |
| full | aa | `divide_scale100_x100000` | 1.021 [0.9785059044090897, 1.2914486669600516] | inconclusive-noisy | - |
| full | aa | `sqrt_scale100_x5000` | 1.006 [0.8681412044812106, 1.0334673216592658] | inconclusive-noisy | - |
| full | aa | `sqrt_scale5000_x5` | 1.000 [0.9858104026562909, 1.0404120798791179] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.012 [0.9895620490460781, 1.1342596109037035] | inconclusive-noisy | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 1.004 [0.9915986705866996, 1.062287167576366] | inconclusive-noisy | - |
| full | aa | `multiply_sparse_10000d_x1000` | 1.005 [0.9568752125660591, 1.0580217830263774] | inconclusive-noisy | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.052 [1.0348125110740205, 1.2161630270862127] | inconclusive-noisy | - |
| full | aa | `modulo_1000d_350d_x3000` | 1.003 [0.881347103614182, 1.1013040194816957] | inconclusive-noisy | - |
| full | aa | `power_100d_e17_x1000` | 1.050 [0.988354375545175, 1.2075436684977106] | inconclusive-noisy | - |
| full | aa | `ibase_literal_flip_20000` | 1.004 [0.9326267504536079, 1.062882869692069] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 0.981 [0.9316530332964302, 1.0374362350400774] | inconclusive-noisy | - |
| full | aa | `sparse_array_200000` | 0.990 [0.9627857724308646, 1.0742731040717086] | inconclusive-noisy | - |
| full | aa | `frontend_definitions_2000` | 1.004 [0.9301193677858239, 1.0886939476113127] | inconclusive-noisy | - |
| full | aa | `decimal_input_4000d_x100` | 1.002 [0.9254361022391249, 1.2202867758696658] | inconclusive-noisy | - |
| full | aa | `decimal_output_200d_x1000` | 1.019 [0.9413763240905666, 1.085904187026316] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 1.018 [0.9702372267405204, 1.1007491238964786] | inconclusive-noisy | - |
| full | aa | `square_100d_x100000` | 1.004 [0.9604193995772153, 1.0443091932126207] | pass | - |
| full | aa | `square_10000d_x500` | 0.966 [0.8860141640820138, 1.033249059782852] | inconclusive-noisy | - |
| full | aa | `literal_repeat_2000d_x2000` | 1.033 [0.9300012216152667, 1.0868005266641356] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 0.993 [0.975842008685285, 1.0181728128728498] | pass | - |
| full | aa | `octal_output_1000d_x300` | 0.992 [0.9401960256093056, 1.0500906882575405] | inconclusive-noisy | - |
| full | aa | `binary_input_100000d_x3` | 1.007 [0.9626170475444529, 1.1419509167989519] | inconclusive-noisy | - |
| full | aa | `hex_input_100000d_x3` | 0.979 [0.9064661286147729, 1.0331727594512246] | inconclusive-noisy | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.983 [0.9268022719821852, 1.0225564032555636] | inconclusive-noisy | - |
| full | aa | `file_statements_20000` | 1.007 [0.890194249513574, 1.1870166977423657] | inconclusive-noisy | - |
| full | aa | `sqrt_large_scale10000_x5` | 0.981 [0.9222096059036664, 1.0117470942782625] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.024 [0.8243691691143938, 1.0590508631095867] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 0.960 [0.9356994070806361, 1.0564122134909182] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 0.988 [0.9738428478800785, 1.2680577452924395] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 1.002 [0.8994467536466436, 1.047082767189616] | inconclusive-noisy | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.031 [0.9898546822918876, 1.0506071325006454] | inconclusive-noisy | - |
| full | aa | `modulo_scaled_numerator_s3_b7_t43_x1000` | 1.021 [0.985855010326069, 1.0470428935786802] | pass | - |
| full | aa | `modulo_scaled_divisor_s97_b37_t43_x1000` | 0.985 [0.9149727990491735, 1.055036279177439] | inconclusive-noisy | - |
| full | paired | `startup` | 1.088 [0.8891907218127921, 1.3355013692733808] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 1.003 [0.9143293384003796, 1.1033358482793547] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `calls_200000` | 1.020 [0.9507467861608604, 1.0418740254616785] | pass | inconclusive-noisy |
| full | paired | `array_200000` | 0.961 [0.9192978565995059, 1.0058541840827429] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 1.007 [0.8652930232704602, 1.045780826138504] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 0.998 [0.9337048688792077, 1.1558497398429934] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `compare_equal_1000d_x100000` | 0.961 [0.839069076953824, 1.006516610181626] | pass | inconclusive-noisy |
| full | paired | `fibonacci_1000_x100` | 1.023 [0.9365461917926545, 1.1309775586170987] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `factorial_1000_x50` | 0.960 [0.9520734990054972, 1.0442305150803894] | pass | pass |
| full | paired | `multiply_100d_x100000` | 1.037 [0.9334899990464345, 1.1363175211200258] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_10000d_x1000` | 0.948 [0.9280969555625416, 1.0203213769115342] | pass | inconclusive-noisy |
| full | paired | `divide_scale100_x100000` | 1.002 [0.7483131125785057, 1.032215150407481] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale100_x5000` | 1.002 [0.987310425126714, 1.041471169286755] | pass | inconclusive-noisy |
| full | paired | `sqrt_scale5000_x5` | 0.991 [0.9435739102039294, 1.0293032944039269] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 1.034 [0.8885841035438049, 1.1475889402078459] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 1.013 [0.9853682224035376, 1.0697491779021868] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `multiply_sparse_10000d_x1000` | 1.027 [1.024608297220026, 1.085224278143974] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 1.015 [0.933576813218629, 1.0866767250894658] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `modulo_1000d_350d_x3000` | 1.009 [0.9845047613927526, 1.112795848422411] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `power_100d_e17_x1000` | 1.000 [0.9706939402760626, 1.0746322304411866] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `ibase_literal_flip_20000` | 0.991 [0.9224124399903126, 1.0893716770780315] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 1.005 [0.8610953077123243, 1.1135541887985814] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sparse_array_200000` | 0.967 [0.8888015310674744, 0.9970576948923746] | pass | inconclusive-noisy |
| full | paired | `frontend_definitions_2000` | 1.014 [0.9893467474176378, 1.047482396682033] | pass | inconclusive-noisy |
| full | paired | `decimal_input_4000d_x100` | 1.006 [0.9479003523281375, 1.1558511382550696] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `decimal_output_200d_x1000` | 0.838 [0.7445131348785152, 0.9674920765394338] | pass | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 0.961 [0.7868442395035578, 1.0210278869521963] | pass | inconclusive-noisy |
| full | paired | `square_100d_x100000` | 1.017 [0.9685716620260305, 1.197335680076729] | inconclusive-noisy | pass |
| full | paired | `square_10000d_x500` | 1.010 [0.8846192984105142, 1.0590514134567985] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `literal_repeat_2000d_x2000` | 1.011 [0.7336880433522058, 1.2014625012920568] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.999 [0.6566730848799054, 1.027468117671675] | pass | pass |
| full | paired | `octal_output_1000d_x300` | 1.084 [0.9803358388127928, 1.2304552144363243] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_input_100000d_x3` | 0.941 [0.8872652964282789, 1.194456493762706] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `hex_input_100000d_x3` | 1.005 [0.9618437043935576, 1.113783969261982] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `temporary_chain_1000d_x50000` | 1.020 [0.9256856226009105, 1.2020173919236257] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `file_statements_20000` | 0.962 [0.8507628942004052, 1.098896155670046] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_large_scale10000_x5` | 0.975 [0.869135148286172, 1.030431259515243] | pass | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale1024_x30` | 1.066 [0.7531073181778029, 1.3865228764351347] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 0.901 [0.6417772728011873, 1.1505637641752093] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 0.943 [0.7523178871042029, 1.0830276515310913] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.004 [0.9622982085409449, 1.125505715044608] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 1.005 [0.9214506918113929, 1.1715816499851277] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `modulo_scaled_numerator_s3_b7_t43_x1000` | 1.066 [0.8928724738164663, 1.2196977429543865] | inconclusive-noisy | pass |
| full | paired | `modulo_scaled_divisor_s97_b37_t43_x1000` | 0.976 [0.8895117273908292, 1.2847999194803017] | inconclusive-noisy | inconclusive-noisy |
