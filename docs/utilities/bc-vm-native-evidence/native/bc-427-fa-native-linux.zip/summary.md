# bc native paired results

Performance decisions are advisory; correctness, builds and deadlines are hard failures.

Candidate is the exact PR head (not a synthetic merge), or checked push/main SHA.
A/A independently rebuilds the same base; its entire CI must lie in [0.95,1.05] to pass. Startup remains inconclusive until calibrated.
Paired status retains the raw A/B signal; the A/A qualifier limits attribution and competitive claims.

| Preset | Comparison | Workload | Ratio [95%] | Advisory status | A/A qualifier |
| --- | --- | --- | --- | --- | --- |
| full | aa | `startup` | 1.047 [0.9119549059102948, 1.1929430362275475] | inconclusive-noisy | - |
| full | aa | `loop_1000000` | 0.993 [0.9727145124983319, 1.010670378767746] | pass | - |
| full | aa | `calls_200000` | 0.992 [0.979908218595655, 0.999844276999929] | pass | - |
| full | aa | `array_200000` | 1.003 [0.9832481008332943, 1.0149873699899212] | pass | - |
| full | aa | `compare_high_1000d_x100000` | 0.998 [0.9840130754472018, 1.0236937182390566] | pass | - |
| full | aa | `compare_low_1000d_x100000` | 1.010 [1.0012174747095182, 1.014704119534574] | pass | - |
| full | aa | `compare_equal_1000d_x100000` | 1.000 [0.9937262373051109, 1.0381069064951665] | pass | - |
| full | aa | `fibonacci_1000_x100` | 0.999 [0.9795472125634115, 1.0161956655720608] | pass | - |
| full | aa | `factorial_1000_x50` | 0.999 [0.9904603014843263, 1.0112851298592673] | pass | - |
| full | aa | `multiply_100d_x100000` | 1.003 [0.984450000325839, 1.0203108096277012] | pass | - |
| full | aa | `multiply_10000d_x1000` | 1.000 [0.998931445246561, 1.0035268133981223] | pass | - |
| full | aa | `divide_scale100_x100000` | 0.998 [0.9929673393400893, 1.0015113682795433] | pass | - |
| full | aa | `sqrt_scale100_x5000` | 1.004 [0.9974875618978013, 1.0082228912309381] | pass | - |
| full | aa | `sqrt_scale5000_x5` | 1.004 [0.9938041632986803, 1.0085896740438196] | pass | - |
| full | aa | `multiply_dense_10000d_x500` | 1.003 [1.000422893455895, 1.0075963258791378] | pass | - |
| full | aa | `multiply_unbalanced_10000d_100d_x2000` | 0.994 [0.9890159103790375, 1.0186800146421364] | pass | - |
| full | aa | `multiply_sparse_10000d_x1000` | 0.997 [0.9902411761763718, 1.00009028097536] | pass | - |
| full | aa | `divide_multilimb_900d_450d_s100_x1000` | 1.001 [0.9776542497319254, 1.0144242843420161] | pass | - |
| full | aa | `modulo_1000d_350d_x3000` | 0.998 [0.9921383082424147, 1.002696791407091] | pass | - |
| full | aa | `power_100d_e17_x1000` | 1.003 [0.9984749406975195, 1.007893252975933] | pass | - |
| full | aa | `ibase_literal_flip_20000` | 0.989 [0.9796066136610864, 1.0505729054879223] | inconclusive-noisy | - |
| full | aa | `recursion_50_x1000` | 0.996 [0.9796037977062294, 1.0130315409913784] | pass | - |
| full | aa | `sparse_array_200000` | 0.982 [0.9701265890658258, 1.0112601346347339] | pass | - |
| full | aa | `frontend_definitions_2000` | 1.007 [0.9816795714978819, 1.015352617770457] | pass | - |
| full | aa | `decimal_input_4000d_x100` | 0.987 [0.9768250341567715, 1.0344118478797524] | pass | - |
| full | aa | `decimal_output_200d_x1000` | 1.045 [0.895002892648993, 1.1226011051209452] | inconclusive-noisy | - |
| full | aa | `streaming_statements_20000` | 0.995 [0.9777692729120986, 1.0162695741926875] | pass | - |
| full | aa | `square_100d_x100000` | 0.986 [0.9713756500635173, 1.0051922470578336] | pass | - |
| full | aa | `square_10000d_x500` | 1.001 [0.9992983492862525, 1.001556815733729] | pass | - |
| full | aa | `literal_repeat_2000d_x2000` | 1.040 [0.8856401940712114, 1.118323498081327] | inconclusive-noisy | - |
| full | aa | `binary_output_1000d_x300` | 1.001 [0.9840598301667044, 1.0557104629182685] | inconclusive-noisy | - |
| full | aa | `octal_output_1000d_x300` | 1.006 [0.9888238029052644, 1.0269821974369508] | pass | - |
| full | aa | `binary_input_100000d_x3` | 0.995 [0.9735196183703729, 1.0070842644448155] | pass | - |
| full | aa | `hex_input_100000d_x3` | 1.003 [0.9913671880937279, 1.0193773721343191] | pass | - |
| full | aa | `temporary_chain_1000d_x50000` | 0.998 [0.9948059667278164, 1.0102183346731608] | pass | - |
| full | aa | `file_statements_20000` | 1.007 [0.9944792772906328, 1.0225237466402166] | pass | - |
| full | aa | `sqrt_large_scale10000_x5` | 0.999 [0.9939070543093483, 1.0003383181839196] | pass | - |
| full | aa | `sqrt_tiny_scale1024_x30` | 1.054 [0.8756456775979103, 1.1203154726105253] | inconclusive-noisy | - |
| full | aa | `sqrt_tiny_scale4096_x1` | 1.007 [0.8512059396774336, 1.2149471520617285] | inconclusive-noisy | - |
| full | aa | `sqrt_integer_power2000_scale100_x10` | 1.016 [0.9287338443444839, 1.099064552669994] | inconclusive-noisy | - |
| full | aa | `divide_scaled_dense_s1000_t1000_x5000` | 0.985 [0.9682592452179092, 1.041297986044035] | pass | - |
| full | aa | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.987 [0.9622199603688139, 1.0243595851908227] | pass | - |
| full | aa | `modulo_scaled_numerator_s3_b7_t43_x1000` | 1.037 [0.9792982746369165, 1.0449936839145715] | pass | - |
| full | aa | `modulo_scaled_divisor_s97_b37_t43_x1000` | 1.018 [0.9717197639866563, 1.048496103939532] | pass | - |
| full | paired | `startup` | 1.136 [0.8732394991940852, 1.1823655400101072] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `loop_1000000` | 0.997 [0.9743017958469378, 1.024755757336246] | pass | pass |
| full | paired | `calls_200000` | 0.992 [0.969827170112425, 0.9998250472708262] | pass | pass |
| full | paired | `array_200000` | 1.000 [0.9919124217799153, 1.0219978943340793] | pass | pass |
| full | paired | `compare_high_1000d_x100000` | 1.004 [0.9772393812861915, 1.0120171507856284] | pass | pass |
| full | paired | `compare_low_1000d_x100000` | 1.000 [0.969561333690323, 1.0308592831062735] | pass | pass |
| full | paired | `compare_equal_1000d_x100000` | 0.999 [0.9779308442093655, 1.0080453437186268] | pass | pass |
| full | paired | `fibonacci_1000_x100` | 1.005 [0.9915511107941546, 1.0179296134523113] | pass | pass |
| full | paired | `factorial_1000_x50` | 0.995 [0.9820661690355268, 1.0029991379089862] | pass | pass |
| full | paired | `multiply_100d_x100000` | 1.001 [0.9819480505623945, 1.0295354362645934] | pass | pass |
| full | paired | `multiply_10000d_x1000` | 0.999 [0.9962102249073422, 1.0012244012616225] | pass | pass |
| full | paired | `divide_scale100_x100000` | 1.001 [0.9690847054868041, 1.0116631584072644] | pass | pass |
| full | paired | `sqrt_scale100_x5000` | 0.996 [0.9768260795364119, 1.0006280315252642] | pass | pass |
| full | paired | `sqrt_scale5000_x5` | 1.004 [1.0006024476803475, 1.014311953516296] | pass | pass |
| full | paired | `multiply_dense_10000d_x500` | 0.999 [0.9977922648833234, 1.0033811481630912] | pass | pass |
| full | paired | `multiply_unbalanced_10000d_100d_x2000` | 0.995 [0.9905267639557258, 1.0124885514783841] | pass | pass |
| full | paired | `multiply_sparse_10000d_x1000` | 1.000 [0.9941346674333437, 1.0033812774762356] | pass | pass |
| full | paired | `divide_multilimb_900d_450d_s100_x1000` | 0.995 [0.9785353633067421, 1.0029396324259334] | pass | pass |
| full | paired | `modulo_1000d_350d_x3000` | 1.001 [0.9923049412109469, 1.0050031296510018] | pass | pass |
| full | paired | `power_100d_e17_x1000` | 0.993 [0.9866125999495926, 1.0042934012978921] | pass | pass |
| full | paired | `ibase_literal_flip_20000` | 0.999 [0.9869472785771645, 1.0280305469684377] | pass | inconclusive-noisy |
| full | paired | `recursion_50_x1000` | 0.999 [0.9894134727828373, 1.0150718641225038] | pass | pass |
| full | paired | `sparse_array_200000` | 1.007 [1.0022574034874292, 1.0134351419394128] | pass | pass |
| full | paired | `frontend_definitions_2000` | 1.013 [0.9956289926040475, 1.0248449753141913] | pass | pass |
| full | paired | `decimal_input_4000d_x100` | 1.007 [0.9815773806743978, 1.0133607830652596] | pass | pass |
| full | paired | `decimal_output_200d_x1000` | 1.022 [0.8897471547939059, 1.0610366049780182] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `streaming_statements_20000` | 1.016 [1.0013147161177411, 1.0325264758867048] | pass | pass |
| full | paired | `square_100d_x100000` | 0.994 [0.9851600132901657, 1.0029953157488372] | pass | pass |
| full | paired | `square_10000d_x500` | 1.000 [0.999720614994856, 1.0024793046607108] | pass | pass |
| full | paired | `literal_repeat_2000d_x2000` | 1.115 [0.916937162504794, 1.1814308249442234] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `binary_output_1000d_x300` | 0.992 [0.986592750136652, 1.0346013075004759] | pass | inconclusive-noisy |
| full | paired | `octal_output_1000d_x300` | 1.009 [0.9823093537487606, 1.0186886246756726] | pass | pass |
| full | paired | `binary_input_100000d_x3` | 1.001 [0.9787366659827786, 1.004749545201274] | pass | pass |
| full | paired | `hex_input_100000d_x3` | 0.999 [0.9871422267738214, 1.013438288667571] | pass | pass |
| full | paired | `temporary_chain_1000d_x50000` | 0.996 [0.9905912025518028, 1.0008588330259032] | pass | pass |
| full | paired | `file_statements_20000` | 1.006 [0.9855441880948653, 1.0205850957863067] | pass | pass |
| full | paired | `sqrt_large_scale10000_x5` | 1.001 [0.9974259413395801, 1.0123413049269077] | pass | pass |
| full | paired | `sqrt_tiny_scale1024_x30` | 1.063 [0.916648082863845, 1.1936920548455847] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_tiny_scale4096_x1` | 1.018 [0.8665690662916271, 1.1669603175638796] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `sqrt_integer_power2000_scale100_x10` | 1.059 [1.0006218672438496, 1.0747420896949915] | inconclusive-noisy | inconclusive-noisy |
| full | paired | `divide_scaled_dense_s1000_t1000_x5000` | 1.029 [0.9861825727966751, 1.052265388782146] | inconclusive-noisy | pass |
| full | paired | `divide_scaled_trailing_zero_s1000_t1000_x5000` | 0.999 [0.9636118440655529, 1.030495743170001] | pass | pass |
| full | paired | `modulo_scaled_numerator_s3_b7_t43_x1000` | 1.000 [0.9535699426659634, 1.0221960274593522] | pass | pass |
| full | paired | `modulo_scaled_divisor_s97_b37_t43_x1000` | 0.973 [0.9404421893864722, 1.045508307116279] | pass | pass |
