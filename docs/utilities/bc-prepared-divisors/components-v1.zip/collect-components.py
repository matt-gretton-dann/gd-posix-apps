#!/usr/bin/env python3
"""Checked local coefficient diagnostics; profiling and timing never pooled."""
import hashlib,json,random,shutil,subprocess,sys,time
from pathlib import Path
WT=Path('/private/tmp/gd-posix-prepared-divisors')
OUT=Path('/private/tmp/bc-420-components-v1')
MODES=['coefficient-control','prepare-divisor','coefficient-divide','prepared-divide',
       'coefficient-modulo','prepared-modulo']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def command(args): return subprocess.check_output(args,cwd=WT,text=True).strip()
def fixtures():
 result=[]
 for preset,seed,sizes in [('full',197420,[(90,36),(603,234),(1206,603)]),
                            ('held-out',197421,[(108,45),(675,261),(1350,675)])]:
  rng=random.Random(seed)
  for size,(u,v) in enumerate(sizes):
   for leading in ['1','9']:
    a=int('9'+''.join(str(rng.randrange(10)) for _ in range(u-1)))
    b=int(leading+''.join(str(rng.randrange(10)) for _ in range(v-1)))
    result.append(dict(name=f'{preset}-{size}-leading-{leading}',preset=preset,
                       seed=seed,u_digits=u,v_digits=v,iterations=2000,
                       source=f'{a}\n{b}\n',dividend=str(a),divisor=str(b),
                       quotient=str(a//b),remainder=str(a%b)))
 return result
def main():
 phase=sys.argv[1]
 OUT.mkdir(exist_ok=True)
 manifest=OUT/'manifest.json'
 if phase=='profile':
  assert not manifest.exists(), 'preserve existing evidence'
  assert command(['git','status','--porcelain'])=='', 'source must be committed'
  data=dict(schema=1,source_revision=command(['git','rev-parse','HEAD']),
            compiler=command(['/usr/bin/c++','--version']),platform=command(['uname','-sm']),
            adoption_accepted=False,elapsed_isolation='unisolated local host; owned builds/tests complete before timing',
            limitations=['Coefficient-only diagnostics, no VM/scales/cache',
                          'Setup and process overhead are not subtracted',
                          'Stored limb checksum is not a cross-mode equality oracle',
                          'Selected allocator counters do not measure process RSS'],
            cases=fixtures(),binaries={},sources={},observations=[])
  for role,build in [('profile','build-profile'),('timing','build-release')]:
   dest=OUT/role;dest.mkdir()
   for rel in ['src/bc/bc-components','CMakeCache.txt','build.ninja']:
    p=WT/build/rel;q=dest/p.name;shutil.copy2(p,q)
    data['binaries'][f'{role}/{p.name}']=dict(sha256=sha(q),bytes=q.stat().st_size)
  for rel in ['src/bc/number.hh','src/bc/benchmark-components.cc','src/bc/test-components.py',
              'docs/utilities/bc-prepared-divisors.md']:
   dest=OUT/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
   shutil.copy2(WT/rel,dest);data['sources'][rel]=sha(dest)
 else:
  data=json.loads(manifest.read_text())
  assert phase=='timing' and not any(x['phase']=='timing' for x in data['observations'])
 for role in ['profile','timing']:
  p=OUT/role/'bc-components';assert sha(p)==data['binaries'][f'{role}/bc-components']['sha256']
 binary=OUT/phase/'bc-components'
 orders=[]
 for case in data['cases']:
  if phase=='profile': orders.append((case,0,MODES[:]))
  else:
   rng=random.Random(case['seed']+case['u_digits']+case['v_digits'])
   for pair in range(4):
    modes=MODES[:];rng.shuffle(modes)
    orders.extend([(case,2*pair,modes),(case,2*pair+1,list(reversed(modes)))])
 for case,trial,modes in orders:
  for position,mode in enumerate(modes):
   folder=OUT/'raw'/phase/case['name'];folder.mkdir(parents=True,exist_ok=True)
   stem=folder/f'{trial}-{position}-{mode}'
   args=[str(binary),mode,str(case['iterations']),'126']
   started=time.monotonic()
   child=subprocess.run(args,input=case['source'],text=True,capture_output=True,timeout=60)
   wall=time.monotonic()-started
   Path(str(stem)+'.stdout').write_text(child.stdout)
   Path(str(stem)+'.stderr').write_text(child.stderr)
   assert child.returncode==0 and child.stderr=='',(args,child.returncode,child.stderr)
   result=json.loads(child.stdout)
   key=('divisor' if mode=='prepare-divisor' else 'dividend' if mode=='coefficient-control'
        else 'remainder' if mode.endswith('modulo') else 'quotient')
   assert result['result']==case[key],(case['name'],mode)
   assert result['instrumented']==(phase=='profile')
   if phase=='profile': assert result['seconds'] is None and result['setup_seconds'] is None
   else: assert result['seconds']>=0 and result['setup_seconds']>=0
   data['observations'].append(dict(phase=phase,case=case['name'],trial=trial,position=position,
     argv=args,returncode=child.returncode,process_wall_seconds=wall,result=result,
     stdout=str(Path(str(stem)+'.stdout').relative_to(OUT)),
     stdout_sha256=sha(Path(str(stem)+'.stdout')),
     stderr=str(Path(str(stem)+'.stderr').relative_to(OUT)),
     stderr_sha256=sha(Path(str(stem)+'.stderr'))))
 manifest.write_text(json.dumps(data,indent=2)+'\n')
 print(json.dumps(dict(phase=phase,checked=sum(x['phase']==phase for x in data['observations']),
                       manifest_sha256=sha(manifest))))
if __name__=='__main__':main()
