#!/usr/bin/env python3
"""Retain process RSS separately from coefficient timings and tracked allocations."""
import hashlib,json,re,shutil,subprocess
from pathlib import Path
SOURCE=Path('/private/tmp/bc-420-components-v1')
OUT=Path('/private/tmp/bc-420-rss-v1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 OUT.mkdir(exist_ok=False)
 manifest=SOURCE/'manifest.json';data=json.loads(manifest.read_text())
 binary=SOURCE/'timing/bc-components'
 assert sha(binary)==data['binaries']['timing/bc-components']['sha256']
 result={'schema':1,'source_revision':data['source_revision'],
         'component_manifest_sha256':sha(manifest),'binary_sha256':sha(binary),
         'platform':data['platform'],'adoption_accepted':False,
         'limitations':['Unisolated local host, three predetermined samples',
                        'Process peak RSS includes startup and fixture parsing',
                        'Raw time durations are retained but are not component timing samples'],
         'observations':[]}
 modes=['coefficient-control','prepare-divisor','coefficient-divide','prepared-divide',
        'coefficient-modulo','prepared-modulo']
 for case in data['cases']:
  folder=OUT/case['name'];folder.mkdir()
  for trial in range(3):
   order=modes if trial%2==0 else list(reversed(modes))
   for mode in order:
    stem=folder/f'{trial}-{mode}';resource=Path(str(stem)+'.resource')
    args=['/usr/bin/time','-l','-o',str(resource),str(binary),mode,
          str(case['iterations']),'126']
    child=subprocess.run(args,input=case['source'],text=True,capture_output=True,timeout=60)
    stdout=Path(str(stem)+'.stdout');stderr=Path(str(stem)+'.stderr')
    stdout.write_text(child.stdout);stderr.write_text(child.stderr)
    assert child.returncode==0 and child.stderr=='',(case['name'],mode,child.stderr)
    output=json.loads(child.stdout)
    key='divisor' if mode=='prepare-divisor' else 'dividend' if mode=='coefficient-control' else 'remainder' if mode.endswith('modulo') else 'quotient'
    assert output['result']==case[key]
    found=re.search(r'^\s*(\d+)\s+maximum resident set size\s*$',resource.read_text(),re.M)
    assert found,resource.read_text()
    row=dict(case=case['name'],trial=trial,mode=mode,argv=args,returncode=0,
             maximum_resident_set_size_bytes=int(found.group(1)))
    for field,path in [('stdout',stdout),('stderr',stderr),('resource',resource)]:
     row[field]=str(path.relative_to(OUT));row[field+'_sha256']=sha(path)
    result['observations'].append(row)
 (OUT/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
 shutil.copy2(__file__,OUT/'collect-rss.py')
 print(json.dumps({'checked':len(result['observations']),'manifest_sha256':sha(OUT/'manifest.json')}))
if __name__=='__main__':main()
